/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather 

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/


#ifndef zzz_H
#define zzz_H 1

#ifndef __cplusplus
#include <stdbool.h>
#endif

#include "Basic_RandomFieldsUtils.h"


#if defined compatibility_to_R_h

#define none 0
#define CDEF(name, n, type) {#name, (DL_FUNC) &name, n, type}
#define CALLDEF(name, n) {#name, (DL_FUNC) &name, n}
#define EXTDEF(name, n)  {#name, (DL_FUNC) &name, n}
#define CALLABLE(FCTN)  R_RegisterCCallable(pkg, #FCTN, (DL_FUNC) FCTN)

#endif

#endif
