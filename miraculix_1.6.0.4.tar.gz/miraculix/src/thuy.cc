/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/

#define NO_OMP 1
#include "Basic_miraculix.h"

void intEV(int* x, int* z, int* Len, int *K, int *sumsq, int *n,
	   int* pos) {
  #define every 10000
  int h,diff,
    k = *K,
    len = *Len;

  for (int i=0; i<k; i++) sumsq[i] = n[i] =0;
  for (int i=0; i<len; pos[i++]=0);
  
  for (int i=0; i<len; i++) {
    if ((i % every) == 0) { PRINTF("%d (%d)\n", i / every, len / every); }
    //  print("%d %d\n", i, len);
    for (int j=i+1; j<len; j++) {      
      h = x[j] - x[i];
      if (h >= k) break;    
      diff = z[j] - z[i];
      diff *= diff;
      if (diff > 0) {
	(pos[i])++;
	(pos[j])++;
      }
      sumsq[h] += diff;
      n[h] ++;
    }
  }
  // printf("ok\n");
}
