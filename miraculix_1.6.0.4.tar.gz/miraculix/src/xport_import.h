/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/



#ifndef Miraculixxport_H
#define Miraculixxport_H 1


#define UTILS_LOCAL \
  CALL(solve_NULL);				\
  CALL(solve_DELETE);				\
  CALL(orderingL);				\
  CALL(orderingInt);				\
  CALL(SolvePosDefSp);				\
  CALL(sleepMicro);				\
  CALL(scalarX);				\
  CALL(scalarXint);				\


#include "xport_import_default.h"



extern const char *R_TYPE_NAMES[LAST_R_TYPE_NAME + 1];





#endif
