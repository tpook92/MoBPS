/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/



#ifndef xport_import_H
#define xport_import_H 1

/*
   UNUSED IN RFU !
*/

#include "def.h"
#include "General_utils.h"
#include "zzz_RFU.h"

#define LOCKLEN 15
#define KEY_type_default			\
  KEY_type *next;				\
  option_type global;				\
  utilsoption_type global_utils;		\
  int pid, visitingpid;				\
  bool ok, doshow, locked;			\
  char lock[LOCKLEN];				\
  errorstring_type error_location;		\
  int *ToIntDummy;				\
  int  ToIntN = 0



#define UTILS_ALWAYS \
  CALL(startRFU);				\
  CALL(get_utilsoption);			\
  CALL(get_utils_basic);			\
  CALL(push_utilsoption);			\
  CALL(params_utilsoption);			\
  CALL(del_utilsoption);			\
  CALL(pid)


#if defined compatibility_to_R_h 
#define UTILSCALLS				\
  CALL(setoptionsRFU);		      		\
  CALL(getoptionsRFU);		      		\
  CALL(attachRFUoptions);			\
  CALL(detachRFUoptions);			\
  CALL(RFUoptions);		     		\
  CALL(attachSetNGet);		      		\
  CALL(parallel);			      	\
  UTILS_ALWAYS;			     		\
  UTILS_LOCAL

extern SEXP Information, Filecoding, Filename, Next, Missings, Precise, Doubled;
#else
#define UTILSCALLS  UTILS_ALWAYS; UTILS_LOCAL
#endif
  
#if defined CALL
#undef CALL
#endif
#define CALL(what) extern what##_type Ext_##what
UTILSCALLS;


typedef
struct option_type option_type;

void includeXport(void);
void WhichOptionList(bool local, option_type **global,
			     utilsoption_type **utils);
void WhichToInt(int ***dummy, int **N);


void FREEglobal(void);
void load_utilsoptions(utilsoption_type *S, int local);
Uint startLocal(int cores);

void getLoptions(SEXP sublist, int i, bool local);
void setLoptions(int i, int j, SEXP el, char name[LEN_OPTIONNAME], 
		 bool isList, bool local);


  
#define check_cuda check_7_5 // the lowest number for which code exists

#endif
