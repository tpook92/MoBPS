## Authors 
## Martin Schlather, martin.schlather@uni-mannheim.de
##
##
## Copyright (C) 2017 -- 2021 Martin Schlather
##
## This program is free software; you can redistribute it and/or
## modify it under the terms of the GNU General Public License
## as published by the Free Software Foundation; either version 3
## of the License, or (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  


FileCoding <-c(  "AB? ",  "AB? ",   "AB? ",  "12? ",    "12? ",       "12345")
Header <-    c(       1,       1,        0,       0,         0,             3)
IndivPerCol<-c(    TRUE,    TRUE,     TRUE,   FALSE,      TRUE,          TRUE)
DoubledIndi<-c(    TRUE,    TRUE,     TRUE,   FALSE,     FALSE,         FALSE)
LeadingCol <-c(       2,       2,        4,       6,         6,             0)
Binary <-    c(       0,       0,        0,       0,         0,             1)
Extension <- c(   "bgl",   "txt", "phased",   "ped",    "tped",         "bed")
FileType  <- c("beagle", "beagle", "plink", "plink2", "plink2", "plinkbinary")
names(FileCoding) <- names(Header) <- names(IndivPerCol) <-
  names(DoubledIndi) <- names(LeadingCol) <- names(Binary) <-
  names(FileType) <-
  Extension
names(Extension) <- FileType


Cextension <- c("mauto", "m1g", "m2g", "m3g", "mplink", "m5", "mbed",
                "mxx", "mxx", "mxx", ## 10
		"m4", "m1Bg", "m2B", "m4Bg", ##14
		"mxx", "mxx", "mxx", "mxx", "mxx", "mxx", ##20
		"m1h", "m2h", "m1Bh", "m4Bh", "m4Bs", "m8Bh", ##27
		"mdotf", "mfdot", "mcrrsp", "munknown")
Clen <- length(Cextension)
CfileCoding <- rep("12345", Clen)
Cheader <- rep(2 + 1 + INFO_LAST * 8, Clen)#2 um konflikt mit plink vermeiden,
                                           ### 1x "INFO_LAST"
CindivPerCol <- rep(FALSE, Clen)
CdoubledIndi <- rep(FALSE, Clen)
CleadingCol <- rep(0, Clen)
Cbinary <- rep(1, Clen)
stopifnot(UnknownSNPcoding == 29)

names(Cextension) <- CODING_NAMES
names(CfileCoding) <- names(Cheader) <- names(CindivPerCol) <-
  names(CdoubledIndi) <- names(CleadingCol) <- names(Cbinary ) <-
    Cextension

    
FileCoding <- c(FileCoding, CfileCoding)
Header <- c(Header, Cheader)
IndivPerCol <- c(IndivPerCol, CindivPerCol)
DoubledIndi <- c(DoubledIndi, CdoubledIndi)
LeadingCol <- c(LeadingCol, CleadingCol)
Binary <- c(Binary, Cbinary)
Extension <- c(Extension, Cextension)
    

fileInfoIntern <- function(filename,
                       file.type=NULL, file.coding = NULL, header=NULL,
                       IndividualsPerColumn=NULL,
                       DoubledIndividuals=NULL, leadingcolumns=NULL,
		       binary = NULL,
                       loading=loading, ignore.further.files=FALSE) {
  split <- strsplit(filename, "\\.")[[1]]
  s <- pmatch(split[length(split)], Extension)
  if (is.na(s)) { 
    s <- Extension[file.type]
    if (is.na(s)) stop("file.type could not be detected.")
  } else {
    if (0 != length(file.type))
      message("given file.type is ignored and replaced by autodetection")
    file.type <- NULL
  } 

  snps <- individuals <- NA
  if (!is.na(s)) {
    if (0 == length(file.coding)) file.coding <- FileCoding[s]
    if (0 == length(header)) header <- Header[s]
    if (0 == length(IndividualsPerColumn))
      IndividualsPerColumn <- IndivPerCol[s]
    if (0 == length(DoubledIndividuals))
      DoubledIndividuals <- DoubledIndiv[s]
    if (0 == length(leadingcolumns)) leadingcolumns <- LeadingCol[s]
    if (0 == length(binary)) binary <- Binary[s]
    }
    
  if (Extension[s] == "bed" && !ignore.further.files) {
    s <- paste(split[-length(split)], collapse=".")
      
    file.lines <- function(filename) {
      warn <- options()$warn
      options(warn=-1)
      sys <- try(strsplit(system(ignore.stdout = FALSE, ignore.stderr = TRUE,
                                  paste("wc", filename), intern=TRUE)," ")[[1]],
                 silent = TRUE)
      options(warn=warn)		 
      if (class(sys) == "try-error") return(NA)
      sys <- sys[nchar(sys) > 0]
      as.integer(sys[1])
    }
       
    ##  #lines of the files give the snps or individuals
    individuals <- file.lines(paste(s, ".fam", sep=""))
    snps <- file.lines(paste(s, ".bim", sep=""))
  }
  
  if (nchar(file.coding) != 4 && nchar(file.coding) != 5)
    stop("haplotype must be given as 4 characters, e.g. 'AB? '; genomic information 5 characters")
  if (nchar(file.coding) == 4) {
    ## never change this file.coding
    file.coding <- paste(substr(file.coding, 1, 2), substr(file.coding, 2, 4), sep="")
  }
  
  if (0 == length(file.coding) || 0 == length(header) ||
      0 == length(IndividualsPerColumn) ||
      0 == length(DoubledIndividuals) || 0 == length(leadingcolumns) ||
      0 == length(binary)) {
    
    if (0 == length(file.coding) && 0 == length(header) &&
          0 == length(IndividualsPerColumn) &&
          0 == length(DoubledIndividuals) && 0 == length(leadingcolumns) &&
	  0 == length(binary))
      stop("unknown file.type. Please give the file.type")
    
    stopifnot(0 != length(file.coding))
    stopifnot(0 != length(header))
    stopifnot(0 != length(IndividualsPerColumn))
    stopifnot(0 != length(DoubledIndividuals))
    stopifnot(0 != length(leadingcolumns))    
    stopifnot(0 != length(binary))    
  }
  
  info <-rep(NA, INFO_LAST + 1)
  info[SNPS + 1] <- snps
  info[INDIVIDUALS + 1]<- individuals
  info[CODING + 1] <- if (loading) AutoCoding else UnknownSNPcoding
  info[TRANSPOSED + 1] <- FALSE;
  info[ORIGINALLY_HAPLO + 1] <- FALSE
  info[FILE_SNPxIND_READ_BYROW + 1] <- IndividualsPerColumn
  info[FILE_HEADER + 1] <- header
  info[FILE_DOUBLEINDIV + 1] <- DoubledIndividuals
  info[FILE_LEADINGCOL + 1] <- leadingcolumns
  info[FILE_BINARY + 1] <- binary

  GetAttr(filename, "information") <- info
  attr(filename, "filecoding") <-  as.character(file.coding)
  attr(filename, "filename") <-
     paste0(as.character(filename), 
           if (!is.na(s)) paste0(".", Extension[s]))

  return(filename)
}	

fileInfo <- function(filename,
                     file.type=NULL, file.coding = NULL, header=NULL,
                     IndividualsPerColumn=NULL,
                     DoubledIndividuals=NULL, leadingcolumns=NULL,
		     binary = NULL,
                     loading=loading) {
  filename <- fileInfoIntern(filename=filename,
                     file.type=file.type, file.coding = file.coding,
		     header=header,
                     IndividualsPerColumn=IndividualsPerColumn,
                     DoubledIndividuals=DoubledIndividuals,
		     leadingcolumns=leadingcolumns,
		     binary = binary,
                     loading=loading);
  TransformIntern(filename, snpcoding = UnknownSNPcoding)
}


rhaploFile <- function(freq, indiv, loci, freq2, file, file.type) {
  file <- paste0(file, ".", Extension[file.type])
  header <- Header[file.type]
  leadingcol <- LeadingCol[file.type]
  binary <- Binary[file.type]
  doubledIndi <- DoubledIndiv[file.type]
  IndivPerColumn <- IndivPerCol[file.type]
  FileCoding <- FileCoding[file.type]
  file_coding <- character(nchar(FileCoding))
  for (i in 1:length(file_coding)) file_coding[i] <- substring(FileCoding, i, i)

  codes <- file_coding[1 + (stats::runif( 2 * indiv * loci) < c(freq, freq2))]
 
  haplo <- length(file_coding) == 4
  M <- matrix(ncol = indiv * 2, codes)
  if (haplo) {
    if (!doubledIndi) {stop("not programmed yet")
      M2 <- matrix(nrow = 2 * loci, ncol = indiv)
      M2[c(TRUE, FALSE), ] <- M[, c(TRUE, FALSE)]
      M2[c(FALSE, TRUE), ] <- M[, c(FALSE, TRUE)]
      M <- M2
    }
    if (!IndivPerColumn) {stop("not programmed yet")
      M <- t(M)
    }
  } else M <- M[, c(TRUE, FALSE)] + M[, c(FALSE, TRUE)]

  if (file.type == "plinkbinary") {
    stop("not programmed yet")
  } else { ## ASCII file
    if (header == 0) file.create(file)
    else write(file=file, paste("This is header line no", 1:header))
    if (leadingcol > 0) M <- cbind(matrix("X", ncol=leadingcol, nrow=nrow(M)),M)
    sep <-file_coding[length(file_coding)]
    write.table(M, file=file, append=TRUE, quote=FALSE, sep = sep,
                row.names=FALSE, col.names=FALSE)
  }
  
  info <- rep(NA, INFO_LAST + 1)
  info[FILE_SNPxIND_READ_BYROW + 1] <- IndivPerColumn
  info[FILE_HEADER + 1] <- header
  info[FILE_DOUBLEINDIV + 1] <- doubledIndi
  info[FILE_LEADINGCOL + 1] <- leadingcol
  info[FILE_BINARY + 1] <- binary
  info[ORIGINALLY_HAPLO + 1] <- TRUE
  info
  GetAttr(file, "information") <- info
  attr(file, "filecoding") <-  as.character(FileCoding)
  attr(file, "filename") <-  as.character(file)
  
#  Print("rhaploFile !!!!!!!!!!!!!!! ")
  H <- TransformIntern(file, snpcoding=UnknownSNPcoding)
  H
}


writeGeno <- function(SNPxIndiv, filename, snpcoding=NA) {
  ## plink biary leading first 3 bytes are (always) 108, 27, 1
  filename <- fileInfoIntern(filename, ignore.further.files=TRUE)
  if (is.na(snpcoding)) 
    snpcoding <- attr(filename, "information")[CODING + 1]
   
  info <- GetAttr(SNPxIndiv, "information")
  if (info[CODING + 1] != snpcoding)
    SNPxIndiv <- TransformIntern(SNPxIndiv, snpcoding=snpcoding)
  .Call(C_writeGeno, SNPxIndiv, attr(filename, "filename") );
}


