# This file has been created automatically by 'rfGenerateConstants'


 ## from  ../../RandomFieldsUtils/RandomFieldsUtils/src/AutoRandomFieldsUtils.h

 MAXUNITS 	<- as.integer(4)
 MAXCHAR 	<- as.integer(18)
 RFOPTIONS 	<- "RFoptions"
 isGLOBAL 	<- as.integer(NA)



 ## from  src/AutoMiraculix.h

 AutoMiraculix_H 	<- as.integer(1)

 Shuffle 	<- as.integer(0)
 TwoBit 	<- as.integer(1)
 ThreeBit 	<- as.integer(2)
 Hamming2 	<- as.integer(3)
 Hamming3 	<- as.integer(4)
 NoSNPcoding 	<- as.integer(5)
 AutoCoding 	<- as.integer(6)
 Haplo 	<- as.integer(7)


 last_usr_meth 	<- as.integer(AutoCoding)
 nr_snpcoding 	<- as.integer((Haplo+1))

 HAPLO 	<- as.integer(0)
 GENO 	<- as.integer(1)
 GENOMATRIX 	<- as.integer(2)
 LAST_WHAT 	<- as.integer(2)

 WHAT 	<- as.integer(0)
 SNPS 	<- as.integer(1)
 INDIVIDUALS 	<- as.integer(2)
 ADDR0 	<- as.integer(3)
 ADDR1 	<- as.integer(4)
 ALIGNADDR 	<- as.integer(5)
 ALIGNADDR1 	<- as.integer(6)
 SUMGENO 	<- as.integer(7)
 SUMGENO_E9 	<- as.integer(8)
 MEMinUNITS 	<- as.integer(9)

 SNPxIND 	<- as.integer(10)
 INFO_BLOCKS 	<- as.integer(11)
 BITSPERCODE 	<- as.integer(12)
 BYTESPERBLOCK 	<- as.integer(13)
 CODESPERBLOCK 	<- as.integer(14)
 HEADER 	<- as.integer(15)
 DOUBLEINDIV 	<- as.integer(16)
 LEADINGCOL 	<- as.integer(17)
 INFO_LAST 	<- as.integer(LEADINGCOL)

 GENOMICMATRIX 	<- "genomicmatrix"
 HAPLOMATRIX 	<- "haplomatrix"
 ORIGINVECTOR 	<- "origindata"



 ## from  src/AutoMiraculix.cc

 SNPCODING_NAME <-
c( "Shuffle","TwoBit","ThreeBit","Hamming2","Hamming3","NoSNPcoding","AutoCoding","Haplo" )


 WHAT_NAMES <-
c( "haplo vector","geno vector","geno matrix" )

