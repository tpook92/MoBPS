
/*
 Authors 
 Martin Schlather, schlather@math.uni-mannheim.de


 Copyright (C) 2018 -- 2019  Martin Schlather

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  
*/


#ifndef miraculix_Bit23_H
#define miraculix_Bit23_H 1


#include "MX.h"
#include "AutoMiraculix.h"


SEXP matrix_coding_start23(Uint individuals, Uint snps, SEXP G);
SEXP matrix_coding23(Uint *M, Uint snps, Uint individuals);

SEXP get_matrix2(SEXP SNPxIndiv);
SEXP matrix_coding_start2(Uint individuals, Uint snps, SEXP file);
SEXP matrix2_mult(SEXP SNPxIndiv);
void matrix_coding2(Uint *SNPxIndiv, Uint start_individual, Uint end_individual,
		    Uint start_snp, Uint end_snp, Uint Mnrow,
		    SEXP Ans, double *G);
int CodesPerBlock2();

void matrix_coding3(Uint *SNPxIndiv, Uint start_individual, Uint end_individual,
		    Uint start_snp, Uint end_snp, Uint Mnrow,
		    SEXP Ans, double *G);
SEXP get_matrix3(SEXP SNPxIndiv);
SEXP matrix_coding_start3(Uint individuals, Uint snps, SEXP file);
SEXP matrix3_mult(SEXP SNPxIndiv);

Uint *Align2(SEXP Code, Uint nr, Uint snps);
Uint *Align3(SEXP Code, Uint nr, Uint snps);

void Init3();
int CodesPerBlock3();
#endif
