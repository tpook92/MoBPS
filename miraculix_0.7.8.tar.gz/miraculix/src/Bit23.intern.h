
/*
 Authors 
 Martin Schlather, schlather@math.uni-mannheim.de


 Copyright (C) 2018 -- 2019  Martin Schlather

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  
*/


#ifndef miraculix_Bit23intern_H
#define miraculix_Bit23intern_H 1

#define MMX 1

#include <stdio.h>
#include "intrinsics.h"
//#include "haplogeno.h"
#include "options.h"
#include "error.h"
#include "MX.h"
#ifdef DO_PARALLEL
#include <omp.h>
#endif


#define BytesPerMiniblock 2L
#define BitsPerMiniblock (BitsPerByte * BytesPerMiniblock)
#define MiniblocksPerBlock (BytesPerBlock / BytesPerMiniblock)
#define CodesPerMiniblock (BitsPerMiniblock / BitsPerCode)
#define genuineBitsPerMiniblock (CodesPerMiniblock * BitsPerCode)
#define two_genuineBitsPerMiniblock (1L << genuineBitsPerMiniblock)
#define bitpattern ((1L << BitsPerCode) - 1L)
#define MiniblocksPerBlock (BytesPerBlock / BytesPerMiniblock)
#define deltaMiniblockBits (BitsPerMiniblock - genuineBitsPerMiniblock)
#define genuineCodesPerBlock (MiniblocksPerBlock * CodesPerMiniblock)

#define TABLE_SIZE  two_genuineBitsPerMiniblock
 
#define nr_genotypes 3
#define nr_results 4

typedef uint16_t blockarray[MiniblocksPerBlock];
typedef union block_compressed {
  blockarray b;
  BlockType x;
} block_compressed;


void initiate_table2();
void initiate_table3();

typedef char table_type;
void initiate_tableI(table_type **TABLE, Uint TABLESIZE,
		     Uint codesPerMiniblock, Uint bits, BlockType0 *result_code,
		     Uint *result_value, Uint NrResults);

SEXP get_matrix23_start(Uint individuals, Uint snps, SEXP G);


void printbits(BlockType0 x, Uint size, Uint bits);

SEXP matrix_coding_start2(Uint individuals, Uint snps, SEXP file);
void matrix_coding2(Uint *SNPxIndiv, Uint start_individual, Uint end_individual,
		    Uint start_snp, Uint end_snp, Uint Mnrow,
		    SEXP Ans, double *G);

SEXP matrix_coding_start3(Uint individuals, Uint snps, SEXP file);
void matrix_coding3(Uint *SNPxIndiv, Uint start_individual, Uint end_individual,
		    Uint start_snp, Uint end_snp, Uint Mnrow,
		    SEXP Ans, double *G);




#define START23(Init23)							\
  (Uint individuals, Uint snps, SEXP file) {				\
  assert(genuineCodesPerBlock == CodesPerBlock);			\
  assert(TWO_GENUINEBITSPERMINIBLOCK == two_genuineBitsPerMiniblock);	\
  Init23(); 							\
  Uint mem = UnitsAlign(snps, individuals);			\
  SEXP Code =  CreateEmptyCodeVector(snps, individuals, mem);	\
  ADDALIGN(Code);							\
  start_info(Code, file, sizeof(BlockType0), genuineCodesPerBlock);	\
  if (PL > 1) {								\
    PRINTF("Size of table: %d kB\n",					\
	   (Uint) (TABLE_SIZE * sizeof(table_type) / 1024));		\
  }									\
  return(Code);								\
  }

#endif
