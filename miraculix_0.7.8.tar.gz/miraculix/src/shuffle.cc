
/*
 Authors 
 Martin Schlather, schlather@math.uni-mannheim.de


 Copyright (C) 2018 -- 2019  Martin Schlather

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  
*/

#define BitsPerCode 2L
#define PseudoSSE 1     // in case IntrinsicBase does not return anything better

//#include <smmintrin.h>
//#include <inttypes.h> // uintptr_t
#include "IntrinsicsBase.h"
#include "intrinsics.h"
//#include "kleinkram.h"
#include <General_utils.h>
#include "xport_import.h"
//#include "AutoMiraculix.h"
#include "options.h"
#include "MX.h"
#include "shuffle.intern.h"
#include "haplogeno.h"

#define checking true
#define INLINE inline

// #define Blocks(X) (1L + (X - 1L) / CodesPerBlock)
//#define UnitsAlign1(S) ( (1L + Blocks(S)) * UnitsPerBlock - 1L)
//#define UnitsAlign(S,I) (UnitsAlign1(S) + Blocks(S) * (I-1) * UnitsPerBlock)
//#define RealAlign(X) (BytesPerBlock / sizeof(real) + (1L +  (X - 1L) / CodesPerBlock) * CodesPerBlock)

ALL_INLINER


// [1 + (X - 1) / UnitsPerBlock] * UnitsPerBlock + (UnitsPerBlock - 1)
// last part: to make finally sure that first used element of R-vector
// is aligned (maximum distance to 0-elemtn: UnitsPerBlock - 1)
// first part: then memory is read in blocks; so next number of Bytes that is
// is divisible by Unitsperblock * Bytesperunit is taken:
// 1 + (X - 1) / UnitsPerBlock]




BlockType and2scalar, xor2scalar, LH,
#ifndef ANY_SIMD
  SHUFFLEMASK1, SHUFFLEMASK2,
#endif			
  BitMaskStart[CodesPerBlock], BitMaskEnd[CodesPerBlock];


 
int CodesPerBlockShuffle() { return CodesPerBlock; }


void showblock(Uint *X, Uint snps) { 
  Uint *x = X,
    bits = snps * BitsPerCode,
    endfor = 1L + (Uint) ((bits - 1L) / BitsPerBlock);
  
  for (Uint d=0; d<endfor; d++, x+=UnitsPerBlock) {
    for (Uint b=0; b<UnitsPerBlock; b++, x++) {
      Uint pattern = (Uint) 0x80000000;
      for (Uint s=0; s<BitsPerUnit; s++) {
        PRINTF("%d", (*x & pattern) != 0);
	pattern >>= 1;
	if (s==15) { PRINTF("."); }
      }
      PRINTF(" ");
    }
  }

  PRINTF("\n");
}

void showblock(BlockType0 X) { showblock((Uint *) &X, CodesPerBlock); }
void showblock(BlockType0 X, int blocks) {
  showblock((Uint *) &X, blocks * CodesPerBlock);
}

void showblock(Uint *X, Uint snps, Uint individuals) { 
  for (Uint i=0; i<individuals; i++) {
#ifdef SCHLATHERS_MACHINE    
    PRINTF("%ld\n", (uintptr_t) (X + i * Blocks(snps) * UnitsPerBlock));
#endif 
    showblock(X + i * Blocks(snps) * UnitsPerBlock, snps);
  }
}

Uint permut_finv_g_h[CodesPerBlock];
bool shuffleNotInit = true;
void InitShuffle() {
  assert(BytesPerBlock == sizeof(BlockType0));
  if (!shuffleNotInit ) BUG;
 
  if (sizeof(uintptr_t) > 4 * BytesPerUnit)
    ERR("address cannot be stored. Please contract author.");

 
  BlockType Einsen;
  SET32(Einsen, 0xFFFFFFFF);
  BlockUnitType *BME = (BlockUnitType*) BitMaskEnd;
  BME->u32[0] = 0x03;

  for (Uint k=1; k<CodesPerBlock; k++) {
    XOR(BitMaskStart[k], BitMaskEnd[k-1], Einsen); // not
    BitMaskEnd[k] = BitMaskEnd[k-1];
    BME = (BlockUnitType*) BitMaskEnd + k;
    BME->u32[k % UnitsPerBlock] |= 0x03 << (BitsPerCode * (k / UnitsPerBlock));
  }
  BitMaskStart[0] = Einsen;

  
//                   0  1  2  3  4  5  6  7   8  9 10 11 12 13 14 15
//#define andshuffle 0, 1, 4, 0, 1, 2, 5, 0,  4, 5, 8, 0, 0, 0, 0, 0
//#define xorshuffle 0, 0, 0, 2, 0, 0, 0, 2,  0, 0, 0, 2, 2, 2, 2, 4
//    SETREV8(as[i], andshuffle);
//    SETREV8(xs[i], xorshuffle);
    SETREV8(and2scalar, 0, 1, 4, 0, 1, 2, 5, 0,  4, 5, 8, 0, 0, 0, 0, 0);
    SETREV8(xor2scalar, 0, 0, 0, 2, 0, 0, 0, 2,  0, 0, 0, 2, 2, 2, 2, 4);

  SET32(LH, 0x0F0F0F0F);
#ifndef ANY_SIMD
  SET32(SHUFFLEMASK1, 0x01010101);
  SET32(SHUFFLEMASK2, 0x02020202);
#endif  

  // see permutation.tex !
  Uint f[CodesPerBlock], g[CodesPerBlock], h[CodesPerBlock],
    finv[CodesPerBlock];
    
  for (Uint i=0, z=0; i<CodesPerUnit; i++) {
    for (Uint j=0; j<UnitsPerBlock; j++) {
      f[z++] = j * CodesPerUnit + i;
    }
  }
  Ext_orderingInt((int *) f, CodesPerBlock, 1, (int *) finv);

  for (Uint i=0, z=0; i<CodesPerByte; i++) {
    for (Uint j=0; j<BytesPerBlock; j++) {
      g[z++] = j * CodesPerByte + i;
    }
  }
  
  for (Uint k=0, z=0; k<CodesPerByte; k++) {
    for (Uint j=0; j<BytesPerUnit; j++) {
      for (Uint i=0; i<UnitsPerBlock; i++) {
	h[z++] = i * BytesPerUnit + j + k * BytesPerBlock;
      }
    }
  }

  for (Uint k=0; k<CodesPerBlock; k++) {
    permut_finv_g_h[k] = finv[g[h[k]]];
  }
  
}


void assert_shuffle() {
  int method = GLOBAL.relationship.method;
#ifdef PseudoSSEconfirmed
    ERR("snpcoding=Shuffle needs at least SSE");
#endif    
  // die PseudoSSE scheint so furchtbar langsam zu sein, dass
  // es sich bis auf die Haplo-Sachen nicht lohnt die Fehler rauszuholen
  // to do ?! Fehler rausholen?
  if (method != Shuffle) { // will work if aligned: ( && method != TwoBit)
    PRINTF("NOTE: 'RFoptions(snpcoding=Shuffle)' is necessary for this function.\nSo, 'RFoptions' is set accordingly by the package.\n");
    GLOBAL.relationship.method = Shuffle;
    // ERR("Set 'RFoptions(snpcoding=Shuffle)' first.");
  }
  if (shuffleNotInit) InitShuffle();
}

void assert_shuffle(SEXP M) {
  int method = MethodOf(M);
  if (method != Shuffle && method != Haplo)
    ERR("Function only available for method 'Shuffle'\n");
  if (shuffleNotInit) InitShuffle();
}


SEXP create_codevectorHaplo(Uint snps, Uint individuals) {
  assert_shuffle();  
  Uint mem = UnitsAlign(snps, individuals);
  // printf("snps = %d indiv =%d, mem=%d\n", snps, individuals, mem);
  SEXP Code = CreateEmptyCodeVectorHaplo(snps, individuals, mem);
  //  printf("done\n");
  ADDALIGN(Code);
  info[WHAT] = HAPLO; // first SNP in SNP sequence
  MethodOf(Code) = Haplo;
  if (PRESERVE) {BUG; R_PreserveObject(Code);}
  //  printf("dxone\n");
 return(Code);
}



void InnerDetermHaplo(double *freq1, double *freq2,
		      Uint snps, Uint individuals, Uint *code) {
  Uint 
    units = Blocks(snps) * UnitsPerBlock,
    fullBlocks = snps / CodesPerBlock;
  //  printf("snps = %d\n", snps);
  for (Uint i=0; i<individuals; i++, code += units) {
    for (Uint j=0; j<fullBlocks; j++) {
      Uint *C = code + j * UnitsPerBlock,
	mm = j * CodesPerBlock;
      for (Uint u=0; u<CodesPerUnit; u++) {
	Uint shift = u * BitsPerCode;
	for (Uint k=0; k<UnitsPerBlock; k++, mm++) {
	  double f2 = freq2[mm];
	  int mm1 = freq1[mm] == 1.0,
	    mm2 = ISNA(f2) ? mm1 : (f2  == 1.0);
	  //	  printf("A mm=%d    %d %d     %f %f\n", mm, mm1, mm2, freq1[mm], freq2[mm]);
	  C[k] |= (mm1 << shift) | (mm2 << (shift + 1));
	}
      }
    }
    if (fullBlocks * CodesPerBlock < snps) {
      Uint 
	*C = code + fullBlocks * UnitsPerBlock,
	mm = CodesPerBlock * fullBlocks;
      for (Uint u=0; u<CodesPerUnit; u++) {     
	Uint shift = u * 2;
	for (Uint k=0; k<UnitsPerBlock && mm < snps; k++, mm++) {
	  double f2 = freq2[mm];
	  int mm1 = freq1[mm] == 1.0,
	    mm2 = ISNA(f2) ? mm1 : (f2  == 1.0);
	  // printf("B mm=%d    %d %d     %f %f\n", mm, mm1, mm2, freq1[mm], freq2[mm]);
	 
	  C[k] |= (mm1 << shift) | (mm2 << (shift + 1));
	}
	if (mm == snps) break;
      }
    }
  }
}


void InnerRandomHaplo(double *freq1, double *freq2,
		      Uint snps, Uint individuals, Uint *code) {
  Uint 
    units = Blocks(snps) * UnitsPerBlock,
    fullBlocks = snps / CodesPerBlock;
  //  printf("snps = %d\n", snps);
  for (Uint i=0; i<individuals; i++, code += units) {
    for (Uint j=0; j<fullBlocks; j++) {
      Uint *C = code + j * UnitsPerBlock,
	mm = j * CodesPerBlock;
      for (Uint u=0; u<CodesPerUnit; u++) {
	Uint shift = u * BitsPerCode;
	for (Uint k=0; k<UnitsPerBlock; k++, mm++) {
	  double f2 = freq2[mm];
	  int mm1 = UNIFORM_RANDOM <= freq1[mm],
	    mm2 = ISNA(f2) ? mm1 : UNIFORM_RANDOM <= f2;
	  //	  printf("C  mm=%d    %d %d     %f %f\n", mm, mm1, mm2, freq1[mm], freq2[mm]);
	  
	  C[k] |= (mm1 << shift) | (mm2 << (shift + 1));
	}
      }
    }
    if (fullBlocks * CodesPerBlock < snps) {
      Uint 
	*C = code + fullBlocks * UnitsPerBlock,
	mm = CodesPerBlock * fullBlocks;
      for (Uint u=0; u<CodesPerUnit; u++) {     
	Uint shift = u * 2;
	for (Uint k=0; k<UnitsPerBlock && mm < snps; k++, mm++) {
	  double f2 = freq2[mm];
	  int mm1 = UNIFORM_RANDOM <= freq1[mm],
	    mm2 = ISNA(f2) ? mm1 : UNIFORM_RANDOM <= f2;
	  //	  printf("D mm=%d    %d %d     %f %f %d\n", mm, mm1, mm2, freq1[mm], freq2[mm], ISNA(f2));
	  C[k] |= (mm1 << shift) | (mm2 << (shift + 1));
	}
	if (mm == snps) break;
      }
    }
    //  printf("\n");
  }
}


SEXP rhaplomatrix(SEXP Freq1, SEXP Freq2, SEXP Individuals) {
  int individuals = INTEGER(Individuals)[0],
    snps = length(Freq1);
  if (snps != length(Freq2))
    ERR("'freq' and 'freq2' do not have the same length");
  SEXP Code = create_codevectorHaplo(snps, individuals);
 return Code;
}

  
SEXP rhaplomatrixPart2(SEXP Freq1, SEXP Freq2, SEXP Individuals, SEXP Code) {
     double *freq1 = REAL(Freq1),
      *freq2 = REAL(Freq2);
  int individuals = INTEGER(Individuals)[0],
    snps = length(Freq1);
  Uint *C =  Align(Code, ALIGN_HAPLO, snps);

  bool random = false;  
  for (int i=0; i < snps; i++) {
    double f = freq1[i];
    if (f < 0 || f > 1) ERR("frequencies not in [0,1]");
    random |= f != 0 && f != 1;
    f = freq2[i];
    if (!ISNA(f)) {
      if (f < 0 || f > 1) ERR("frequencies not in [0,1]");
      random |= f != 0 &&  f != 1;
    }
  }

  if (random) {
    GetRNGstate();
    // printf("snps=%d indivi=%d \n", snps, individuals);
    InnerRandomHaplo(freq1, freq2, snps, individuals, C);
    PutRNGstate();
  } else {
    InnerDetermHaplo(freq1, freq2, snps, individuals, C);
  }

  return Code;
}

void codeInnerHaplo2(Uint *M1, Uint *M2, Uint snps, Uint *code) {
  Uint j,
    fullBlocks = snps / CodesPerBlock;
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(CORES)
#endif
  for (j=0; j<fullBlocks; j++) {
    Uint *C = code + j * UnitsPerBlock,
      *mm1 = M1 + j * CodesPerBlock,
      *mm2 = M2 + j * CodesPerBlock;
    for (Uint u=0; u<CodesPerUnit; u++) {
      Uint shift = u * BitsPerCode;
      for (Uint k=0; k<UnitsPerBlock; k++, mm1++, mm2++) {
	assert(*mm1 == 0 || *mm1 == 1);
	assert(*mm2 == 0 || *mm2 == 1);
	C[k] |= (*mm1 << shift) | (*mm2 << (shift + 1));
      }
    } 
  }
  if (fullBlocks * CodesPerBlock < snps) {
    Uint *end = M1 + snps,
      *C = code + fullBlocks * UnitsPerBlock;
    M1 += CodesPerBlock * fullBlocks;
    M2 += CodesPerBlock * fullBlocks;
    for (Uint u=0; u<CodesPerUnit; u++) {
     
      Uint shift = u * 2;
      for (Uint k=0; k<UnitsPerBlock && M1 < end; k++, M1++, M2++) {
	assert(*M1 == 0 || *M1 == 1);
	assert(*M2 == 0 || *M2 == 1);
	C[k] |= (*M1 << shift) | (*M2 << (shift + 1));
      }
      if (M1 == end) break;
    }
  }
}


SEXP codeHaplo2(SEXP M1, SEXP M2) {// 2 x Haplo - Matrix, as vector gespeichert
  if (length(M1) == 0 || length(M1) != length(M2))
    ERR("'M' has length 0 or lengths are unequal.");
  if (!isVector(M1) || !isVector(M2))
    ERR("'M' or 'N' not a vector or of wrong size.");
  Uint snps = (Uint) length(M1);  
  SEXP Code = create_codevectorHaplo(snps, 1);
  ToInt(M1);  
  ToInt(M2);  
  codeInnerHaplo2(M1int, M2int, snps, Align(Code, ALIGN_HAPLO, snps));
  if (PRESERVE) R_PreserveObject(Code);
  FREEint(M1);
  FREEint(M2);
  return Code;
}




SEXP GetHaploSequence(Uint snps, Uint indiv,
		      bool indivpercol, bool doubledIndiv,
		      Uint currentBits, // BitsPerCode
		      Uint *blockIncr, Uint *bitIncr,
		      Uint *delta, Uint *indivIncr, bool create){
  SEXP Ans = R_NilValue;
  
  if (indivpercol) {
    *indivIncr = snps * currentBits;
    if (doubledIndiv) {
      *blockIncr = CodesPerBlock; // M
      *delta = currentBits == 1 ? 0L : snps ; // M; pointing to next bit
      *bitIncr = 1L; // M
      //printf("%d %d %d\n", snps, indiv, currentBits);
      if (create) PROTECT(Ans = allocMatrix(INTSXP, snps, indiv*currentBits));
   } else {
      *blockIncr = BitsPerBlock * currentBits / BitsPerCode;
      *delta = currentBits == 1 ? 0L : 1L;
      *bitIncr = currentBits;
      if (create) PROTECT(Ans = allocMatrix(INTSXP, currentBits * snps, indiv));
    }
  } else {
    *blockIncr = BitsPerBlock * indiv * currentBits / BitsPerCode;
    *bitIncr = currentBits * indiv;
    if (doubledIndiv) {
      *delta = currentBits == 1 ? 0L : 1L;
      *indivIncr = currentBits;
      if (create) PROTECT(Ans = allocMatrix(INTSXP, currentBits * indiv, snps));
    } else {
      *delta = currentBits == 1 ? 0L : indiv;
      *indivIncr = 1L;
      if (create) PROTECT(Ans=allocMatrix(INTSXP,  indiv, currentBits * snps));
    }
  }
  if (create) UNPROTECT(1);
  return Ans;
}




void codeInnerHaplo(Uint *MM, Uint snps, Uint indiv,
		    bool indivpercol, bool doubledIndiv, Uint *code) {  
  Uint j, blockIncr, bitIncr, delta, indivIncr,
    units = Blocks(snps) * UnitsPerBlock,
    bits = snps * BitsPerCode,
    fullBlocks = bits / BitsPerBlock;

  GetHaploSequence(snps, indiv, indivpercol, doubledIndiv, BitsPerCode,
		   &blockIncr, &bitIncr, &delta, &indivIncr, false);

#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(CORES)
#endif
  for (Uint i=0; i<indiv; i++) {
    Uint *cm = code + i * units,
      *M = MM + i * indivIncr;
    for (j=0; j<fullBlocks; j++) {
      Uint *C = cm + j * UnitsPerBlock,
	*mm = M + j * blockIncr,
	*mm2 = mm + delta;
      for (Uint u=0; u<CodesPerUnit; u++) {
	Uint shift = u * BitsPerCode;
	for (Uint k=0; k<UnitsPerBlock; k++, mm+=bitIncr, mm2 += bitIncr) {
	  assert(*mm == 0 || *mm == 1);
	  assert(*mm2 == 0 || *mm2 == 1);
	  C[k] |= *mm2 << (shift + 1);
	  C[k] |= *mm << shift;	  
	}
      }
    }
    if (fullBlocks * CodesPerBlock < snps) {
      Uint 
	*C = cm  + fullBlocks * UnitsPerBlock,
	*mm = M + fullBlocks * blockIncr,
	*mm2 = mm + delta,
	*end = M + snps * bitIncr;
      for (Uint u=0; u<CodesPerUnit; u++) {
	Uint shift = u * 2;
	for (Uint k=0; k<UnitsPerBlock && mm < end;
	     k++, mm+=bitIncr, mm2 += bitIncr) {
	  assert(*mm == 0 || *mm == 1);
	  assert(*mm2 == 0 || *mm2 == 1);
	  C[k] |= *mm2 << (shift + 1);
	  C[k] |= *mm << shift;
	}
	if (mm >= end) break;
      }
    }
  }
}

SEXP codeHaplo(SEXP M, SEXP IndivPerCol, SEXP DoubledIndiv) {// 2 x Haplo - Matrix, as vector gespeichert
  if (length(M) == 0) ERR("'M' has length 0.");
  Uint snps, indiv,
    nrow = (Uint) nrows(M),
    ncol = (Uint) ncols(M);
  bool doubledIndiv = LOGICAL(DoubledIndiv)[0],
    indivpercol = LOGICAL(IndivPerCol)[0];

  if (indivpercol) {
    snps = nrow;
    indiv = ncol;
  } else {
    snps = ncol;
    indiv = nrow;
  }
  if (doubledIndiv) {
    // printf("%d (%d %d) %d \n", indiv, nrow, ncol, BitsPerCode);
    if (indiv % BitsPerCode != 0)
      ERR("information on individuals not doubled");
    indiv /= BitsPerCode;
  } else {
    if (snps % BitsPerCode != 0) ERR("information on haplotype odd");
    snps /= BitsPerCode;
  }

  SEXP Code = create_codevectorHaplo(snps, indiv);
  //  printf("? %d\n", TYPEOF(Code));
  ToInt(M);
  //  printf("! %d\n", TYPEOF(Code));
  codeInnerHaplo(Mint, snps, indiv, indivpercol, doubledIndiv,
		 Align(Code, ALIGN_HAPLO, snps));
  //  printf("@\n");
  if (PRESERVE) R_PreserveObject(Code);
  FREEint(M);
  return Code;
}


SEXP decodeHaplo(SEXP CM, SEXP Indiv,
		 SEXP Sets, SEXP IndivPerCol, SEXP DoubledIndiv) {
  assert_shuffle(CM);
  //printf("%d %d %d\n", length(CM), length(IndivPerCol), length(DoubledIndiv));
  bool IndivGiven = length(Indiv) > 0;
  Uint blockIncr, bitIncr, delta, indivIncr,
    *info = GetInfo(CM),
    currentBits = length(Sets),
    snps = info[SNPS], 
    indiv = info[INDIVIDUALS],
    currentIndiv = IndivGiven ? length(Indiv) : indiv,
    *I = IndivGiven ? (Uint*) INTEGER(Indiv) : NULL,
    bits = snps * BitsPerCode,
    fullBlocks = bits / BitsPerBlock,
    units = Blocks(snps) * UnitsPerBlock,
    *code = Align(CM, ALIGN_HAPLO, snps);
  bool doubledIndiv = LOGICAL(DoubledIndiv)[0],
    indivpercol = LOGICAL(IndivPerCol)[0];
  if (info[WHAT] != HAPLO) ERR("not a haplo coding");
  //    printf("doubledindiv = %d\n", doubledIndiv);
  if (currentBits != 1 && currentBits != BitsPerCode)
    ERR("The number of chromosome sets can only be 1 or 2.");
  bool set1 = INTEGER(Sets)[0] == 1;
  if (currentBits == 2 && (!set1 || INTEGER(Sets)[1] != 2))
    ERR("The sets must be given in the order 1:2")
  else if (!set1 && INTEGER(Sets)[0] != 2)
    ERR("The value for a chromosome set can be 1 and 2 only.");
  
  SEXP Ans = GetHaploSequence(snps, currentIndiv, indivpercol, doubledIndiv,
			      currentBits,
			      &blockIncr, &bitIncr, &delta, &indivIncr, true);
  
  Uint *MM = (Uint*) INTEGER(Ans),
    total = currentBits * snps * currentIndiv;
  for (Uint i=0; i<total; i++) MM[i] = 0; // noetig?
  assert(BitsPerCode == 2);

  assert(snps > 0);
  assert(indiv > 0);
  //printf("currentIndiv = %d\n", currentIndiv);
  
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(CORES)   
#endif
  for (Uint i=0; i<currentIndiv; i++) {
    Uint *cm = code + units * (IndivGiven ? I[i] - 1 : i),
      *M = MM + i * indivIncr;
    for (Uint j=0; j<fullBlocks; j++) {
      Uint
	*C = cm + j * UnitsPerBlock,
	*mm = M + j * blockIncr,
	*mm2 = mm + delta;
      for (Uint u=0; u<CodesPerUnit; u++) {
	Uint shift = 1 << u * 2,
	  shiftP1 = shift << 1;
	for (Uint k=0; k<UnitsPerBlock; k++, mm+=bitIncr, mm2 += bitIncr) {
	  // odering important !!! as mm2 might be overwritten by mm!!
	  *mm2 = (C[k] & shiftP1) > 0;
	  if (set1) *mm = (C[k] & shift) > 0;
	}
      }
    }
    if (fullBlocks * CodesPerBlock < snps) {
      Uint
	*C = cm + fullBlocks * UnitsPerBlock,
	*mm = M + fullBlocks * blockIncr,
	*mm2 = mm + delta,
	*end = M + snps * bitIncr;
      for (Uint u=0; u<CodesPerUnit; u++) {
	Uint shift = 1 << u * 2,
	  shiftP1 = shift << 1;
	for (Uint k=0; k<UnitsPerBlock && mm < end;
	     k++, mm+=bitIncr, mm2 += bitIncr) {
	  *mm2= (C[k] & shiftP1) > 0;
	  if (set1) *mm = (C[k] & shift) > 0;
	}
	if (mm >= end) break;
      }
    }
  }

  if (PRESERVE) R_PreserveObject(Ans);
  return Ans;
}

SEXP create_codevector(Uint snps, Uint individuals) {
  assert_shuffle();  
  Uint mem = UnitsAlign(snps, individuals);  
  SEXP Code = CreateEmptyCodeVector(snps, individuals, mem);
  ADDALIGN(Code);
  if (PRESERVE) {BUG; R_PreserveObject(Code);}
  return(Code);
}

//SEXP create_codevector(Uint what, Uint snps, Uint individuals, Uint method) {
//  SEXP Code = create_codevector(what, snps, individuals);
//  MethodOf(Code) = meMthod;
//  return Code;
//}


Ulong sumGeno(BlockType0 *S, Uint blocks) {
#define x31  (255L / 8L) // 2 : max{0,1,2}
  //                         4 : 2-bit-coding in 1 Byte
#define BytesPer64  (64 / BitsPerByte)
 //#define intgroup_size (2147483648L / (x31 * 8L * BytesPerUnit)) // 2^31 / x31
#define intgroup_size 3 // 2^31 / x31
#define intgroup_sizeM1 (intgroup_size - 1L)
  Uint
    intgroupsM1 = (blocks - 1L) / (x31 * intgroup_size),
    sizex31 = intgroup_size * x31;
  //    groupsM1 = (blocks - 1L) / x31;
  BlockType first2bits8, first8bits;
    // NullEins = SET32(0x55555555),
  SET32(first2bits8, 0x03030303);
  SET32(first8bits, 0x000000FF);
  BlockUnitType sum32;
  Ulong ans = 0;

  for (Uint X=0; X<=intgroupsM1; X++) { // this loop needed only for huge
    // data sizes of more than 50000 individuals and 10^5 SNPS each
    ZERO(sum32 VI);
    BlockType *S_int = S + X * sizex31 ;
    Uint groupsM1 = X < intgroupsM1 ? intgroup_sizeM1
			: (blocks - 1L) / x31 - intgroupsM1 * intgroup_size;
    for (Uint i=0; i<=groupsM1; i++) {
      BlockType sum,
	*cgm = S_int + i * x31;
      ZERO(sum);
      Uint endx = i < groupsM1 || X < intgroupsM1 ? x31 :
	blocks - intgroupsM1 * sizex31 - x31 * groupsM1;
      for (Uint x=0; x<endx; x++, cgm++) {
	BlockType d,
	  c = *cgm;
	//	d = SHR32(c, 1);
	//	d = AND(NullEins, d);
	//	c = XOR(c, d);      
	for (Uint j=0; j<CodesPerByte; j++) { // for-schleife aufloesen ?
	  AND(d, c, first2bits8);
	  ADD8(sum, sum, d);
	  SHR32(c, c, 2);
	}
      }
      for (Uint j=0; j<BytesPerUnit; j++) {
	BlockType L1;
	AND(L1, sum, first8bits);
	ADD32(sum32 VI, sum32 VI, L1); 
	SHR32(sum, sum, BitsPerByte);
      }
    } // for groups

    for (Uint i=0; i<UnitsPerBlock; i++) {
      ans += (Ulong) sum32.u32[i];
    }
  }

  //printf("sumgeno = %lu\n", ans);

  return ans;
}


void haplo2geno(BlockType0 *X, Uint snps, Uint individuals) {
  // Achtung!! Nach Aufruf muss sumGeno() berechnet werden!!
  Uint blocks = Blocks(snps);
  BlockType EN, NE;
  SET32(EN, 0xAAAAAAAA);
  SET32(NE, 0x55555555); 

  for (Uint j=0; j<individuals; j++) {
    BlockType *x = X + j * blocks;
    for (Uint b=0; b<blocks; b++) {
      BlockType y,z,dummy;
      AND(y, x[b], EN);
      AND(z, x[b], NE);
      SHL32(dummy, z, 1L);
      AND(dummy, y, dummy);
      SHR32(y, y, 1);
      XOR(y, y, z);
      OR(x[b], dummy, y);
      // x[b] = OR(SHR32(y, 1L), OR(z, AND(y, SHL32(z, 1L))));
    }
  }
}


SEXP haplo2geno(SEXP H) {
  Uint
    *infoH = GetInfo(H),
    individuals = (Uint) infoH[individuals],
    snps =  (Uint) infoH[SNPS],
    blocks = Blocks(snps);
  if (infoH[WHAT] != HAPLO) ERR("not a haplo coding");
  Uint
    *haplo =  Align(H, ALIGN_HAPLOGENO, snps);
  if (infoH[INDIVIDUALS] != 1)
    ERR("currently only 1 individual allowed in haplo2geno");

  SEXP Code = create_codevector(snps, infoH[INDIVIDUALS]);
  Uint *code = algn(INTEGER(Code));
  assert((uintptr_t) code >= (uintptr_t) INTEGER(Code));
  MEMCOPY(code, haplo, Blocks(snps) * BytesPerBlock);
  haplo2geno((BlockType0 *) code, snps, 1);

  Uint *info = GetInfo(Code);						
  Ulong sumgeno = sumGeno((BlockType0 *) code, blocks * individuals);
  StoreSumGeno(sumgeno);
  
  if (PRESERVE) R_PreserveObject(Code);
  return Code;  
}






void codeInnerGeno(Uint *M, Uint snps, Uint *code) {
  // Vektorisieren ?!
  Uint j,
    bits = snps * BitsPerCode,
    //fullBlocks = (bits - 1)  / BitsPerBlock;
    fullBlocks =  bits / BitsPerBlock; // 30.5.2019

  for (j=0; j<fullBlocks; j++) {
    Uint *C = code + j * UnitsPerBlock,
      *mm = M + j * CodesPerBlock;
    for (Uint u=0; u<CodesPerUnit; u++) {
      Uint shift = u * 2;
      for (Uint k=0; k<UnitsPerBlock; k++, mm++) {
	int m = *mm;
	if (checking && (m < 0 || m > 2)) ERR("wrong values for SNP matrix");
	//if (m == 2) m = 3; // schneller? schoener?
	C[k] |= m << shift; 
      }
    }
  }
  Uint snps_done = fullBlocks * CodesPerBlock;
  if (snps_done < snps) {
    Uint *end = M + snps,
      *C = code + UnitsPerBlock * fullBlocks;
    M += snps_done;
    for (Uint u=0; u<CodesPerUnit; u++) {
      Uint shift = u * 2;
      for (Uint k=0; k<UnitsPerBlock && M < end; k++, M++) {
	int m = *M;
	if (checking && (m < 0 || m > 2)) ERR("wrong values for SNP matrix");
	//	*(p++) += (double) m;
	
	//if (m == 2) m = 3;2
	C[k] |= m << shift;
      }
      if (M == end) break;
    }
  }
}



SEXP decodeNthGeno(SEXP CM, SEXP NN) { // 0.45 bei 25000 x 25000
  assert_shuffle(CM);
  //  BlockType first2bits32 = SET32(0x00000003);
  Uint
    first2bits32 = 0x00000003,
    *N = (Uint*) INTEGER(NN),
    lenN = length(NN),
    *info = GetInfo(CM),
    snps = info[SNPS],
    individuals = info[INDIVIDUALS],
    blocks = Blocks(snps),
    //    units = blocks * UnitsPerBlock,
    *C0 = Align(CM, ALIGN_HAPLO, snps);
  if (info[WHAT] != GENOMATRIX) ERR("not a genoimatrix coding");
  
  SEXP Ans;
  if (lenN ==1) PROTECT(Ans = allocVector(INTSXP, individuals));
  else PROTECT(Ans = allocMatrix(INTSXP, lenN, individuals));
  Uint *M = (Uint*) INTEGER(Ans);

  for (Uint i=0; i<individuals; i++) {    
    Uint *mm = M + i * lenN;
    for (Uint ni=0; ni<lenN; ni++, mm++) {
      Uint j=N[ni] / CodesPerBlock,
	jj = N[ni] % CodesPerBlock,
	u = jj / UnitsPerBlock,
	k = jj % UnitsPerBlock;     
      BlockType c = ((BlockType *) C0)[i * blocks + j];
      BlockUnitType d;
      d VI = c;
      // d VI = AND(SHR32(c, BitsPerCode * u), first2bits32);  *mm = d.u32[k];
      *mm = (d.u32[k] >> (BitsPerCode * u)) & first2bits32;
    }
  }
 
  UNPROTECT(1);
  return Ans;
}


SEXP zeroNthGeno(SEXP CM, SEXP NN) { // 0.45 bei 25000 x 25000
  assert_shuffle(CM);
  Uint
    first2bits32 = 0x00000003,
    *N = (Uint*) INTEGER(NN),
    lenN = length(NN),
    *info = GetInfo(CM),
    snps = info[SNPS],
    individuals = info[INDIVIDUALS],
    blocks = Blocks(snps),
    //    units = blocks * UnitsPerBlock,
    *C0 = Align(CM, ALIGN_HAPLO, snps);
  if (info[WHAT] != GENOMATRIX) ERR("not a genoimatrix coding");
  
  SEXP Ans;
  if (lenN ==1) PROTECT(Ans = allocVector(INTSXP, individuals));
  else PROTECT(Ans = allocMatrix(INTSXP, lenN, individuals));
  Uint *M = (Uint*) INTEGER(Ans);

  for (Uint i=0; i<individuals; i++) {    
    Uint *mm = M + i * lenN;
    for (Uint ni=0; ni<lenN; ni++, mm++) {
      Uint j=N[ni] / CodesPerBlock,
	jj = N[ni] % CodesPerBlock,
	u = jj / UnitsPerBlock,
	k = jj % UnitsPerBlock;     
      BlockType *C = ((BlockType *) C0) + i * blocks + j;
      BlockUnitType *d = (BlockUnitType*) C;
      d->u32[k] &= ~(first2bits32 << (BitsPerCode * u));
    }
  } 
  UNPROTECT(1);
  return R_NilValue;
}


void vectorGenoKahan(Real *V, BlockType0 *CM, Uint snps, Uint individuals,
		     double *ans) {
  Uint blocks = Blocks(snps);
  BlockType first2bits32;
  // NullEins = SET32(0x55555555),
  SET32(first2bits32, 0x00000003);


#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(CORES)   
#endif
  for (Uint i=0; i<individuals; i++) {
    BlockType
      *cm = CM + i * blocks;
    Real sum, corr,
      *v = V;
    ZEROREAL(sum);
    ZEROREAL(corr);
    for (Uint b=0; b<blocks; b++, cm++) {
      BlockUnitType d,f;
      BlockType c = *cm;
      //   d VI = SHR32(c, 1);
      // d VI = AND(NullEins, d VI);      
      // c = XOR(c, d VI);      
      for (Uint j=0; j<CodesPerUnit; j++) {
	AND(d VI, c, first2bits32);
	Real  dummy, fcorr, roughsum;

#define VGK					\
	MULTREAL(f REALVALUE, *v, f REALVALUE);			\
	SUBREAL(fcorr, f REALVALUE, corr);		\
	ADDREAL(roughsum, sum, fcorr);		\
	SUBREAL(dummy, roughsum, sum);		\
	SUBREAL(corr, dummy, fcorr);		\
	sum = roughsum

	
	IR(0,0);
#ifdef AVX2
	IR(1,1);
#endif	
	VGK;

#if not defined DO_FLOAT
#ifdef AVX2
	IR(0,2); IR(1,3);
#else
	IR(0,1);
#endif
	v++;
	VGK;
#endif
	
	v++;
	SHR32(c, c, 2L);
      }
    }
    real *s = (real*) &sum;
    ans[i] = (double) (s[0] + s[1]
#if defined AVX2 or defined DO_FLOAT
		       + s[2] + s[3]
#if defined AVX2 and defined DO_FLOAT    
		       + s[4] + s[5] + s[6] + s[7]
#endif		     
#endif		     
		       );
  }
}


void vectorGenoIntern(Real *V, BlockType0 *CM, Uint snps, Uint individuals,
		      double *ans) {

  if (GLOBAL_UTILS->basic.kahanCorrection) {
    vectorGenoKahan(V, CM, snps, individuals, ans);
    return;
  }
  Uint blocks = Blocks(snps);
  BlockType    first2bits32;
  // NullEins = SET32(0x55555555),
  SET32(first2bits32, 0x00000003);

#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(CORES)   
#endif
  for (Uint i=0; i<individuals; i++) {
    BlockType
      *cm = CM + i * blocks;
    Real sum,
      *v = V;
    ZEROREAL(sum);
    for (Uint b=0; b<blocks; b++, cm++) {
      BlockUnitType d,f;
      BlockType c = *cm;
      //      d VI = SHR32(c, 1);
      //d VI = AND(NullEins, d VI);      
      // c = XOR(c, d VI);      
      for (Uint j=0; j<CodesPerUnit; j++) {
	AND(d VI, c, first2bits32);

#define VGI							\
	MULTREAL(f REALVALUE, *v, f REALVALUE);			\
	ADDREAL(sum, sum, f REALVALUE);				\
	
	IR(0, 0);
#ifdef AVX2
	IR(1, 1);
#endif	
	VGI;

#if not defined DO_FLOAT
#ifdef AVX2
	IR(0, 2); IR(1, 3);
#else
	IR(0, 1);
#endif
	v++;
	VGI;
#endif

	
	v++;
	SHR32(c, c, 2L);
      }
    }
    real *s = (real*) &sum;
    ans[i] = (double) (s[0] + s[1]
#if defined AVX2 or defined DO_FLOAT
		       + s[2] + s[3]
#if defined AVX2 and defined DO_FLOAT    
		       + s[4] + s[5] + s[6] + s[7]
#endif		     
#endif		     
		       );
  }
}

SEXP vectorGeno(SEXP V, SEXP Z) {
  assert_shuffle(Z);
  Uint
    *info = GetInfo(Z),
    snps = info[SNPS],
    individuals = info[INDIVIDUALS],
    len = length(V);
  if (len != snps) ERR("vector 'V' not of correct length");

  real *v0 = (real *) CALLOC(RealAlign(len), sizeof(real)),
    *v = (real*) algnrl(v0);    
  switch(TYPEOF(V)) {
  case INTSXP : {
    ToInt(V);
    for (Uint i=0; i<len; i++) v[i] = (real) Vint[i];
    FREEint(V);
    break;
  }
  case REALSXP : {
    double *vp = REAL(V);
#ifdef DO_FLOAT
    for (Uint i=0; i<len; i++) v[i] = (real) vp[i];
#else
    MEMCOPY(v, vp, len * sizeof(double));
#endif
    break;
  }
  case LGLSXP : {
    int *vp = LOGICAL(V);
    for (Uint i=0; i<len; i++) v[i] = (real) vp[i];
    break;
  }
  default : ERR("'V' of unknown type.");
  }

  SEXP Ans;
  PROTECT(Ans = allocVector(REALSXP, individuals));
  double *ans = REAL(Ans);
  for (Uint i=0, endfor= individuals; i<endfor; i++) ans[i] = 0.0; // noetig?
  vectorGenoIntern((Real *) v, (BlockType0 *) Align(Z, ALIGN_VECTOR, snps),
		   snps, individuals, REAL(Ans));

  Free(v0);
  UNPROTECT(1);
  if (PRESERVE) R_PreserveObject(Ans);
  return(Ans);
}

 

void genoVectorIntern(BlockType0 *CM, double *V, Uint snps, Uint individuals,
		      double *ans) {

  if (GLOBAL_UTILS->basic.kahanCorrection) {
    //    genoVectorKahan(V, CM, snps, individuals, ans);
    // return;
  }
  Uint blocks = Blocks(snps),
    blocksM1 = blocks - 1;
  double *end_ans = ans + snps;
  BlockType c,first2bits32;
  SET32(first2bits32, 0x00000003);
  for (Uint i=0; i<snps; ans[i++] = 0.0);

  for (Uint i=0; i<individuals; i++) {
    BlockType *cm = CM + i * blocks;
    double
      *a = ans,
      f0 = V[i],
      //  factor[4] = {0.0, f0, f0, 2.0 * f0}; // so also ok for haplo types!
      //                  mit der 00, 01, 11 Codierung
      factor[4] = {0.0, f0, 2.0 * f0, 0}; // nur fuer geno mit 00, 01, 10 Code
    for (Uint b=0; b<=blocksM1; b++) {
      // BlockType
      c = cm[b];
      Uint endfor = b < blocksM1 ? CodesPerUnit
		: (snps - blocksM1 * CodesPerBlock) / UnitsPerBlock;
      //      printf("endfor = %d blocksM1=%d upb=%d cp=%d\n", endfor, blocksM1, UnitsPerBlock, CodesPerUnit);
      for (Uint j=0; j<endfor; j++) {
	BlockUnitType d;
	AND(d VI, c, first2bits32);
	a[0] += factor[d.u32[0]]; 
	a[1] += factor[d.u32[1]];
	a[2] += factor[d.u32[2]];
	a[3] += factor[d.u32[3]];
#if defined AVX2
	a[4] += factor[d.u32[4]]; 
	a[5] += factor[d.u32[5]];
	a[6] += factor[d.u32[6]];
	a[7] += factor[d.u32[7]];
	a += 8;

	/* todo speed might be improved using
mm256_bitshuffle_epi64_mask
_mm_blendv_epi8 (__m128i a, __m128i b, __m128i mask)
int _mm_cmpestra (__m128i a, int la, __m128i b, int lb, const int imm8)
__m128i _mm_hadd_epi32 (__m128i a, __m128i b)
__m64 _mm_maddubs_pi16 (__m64 a, __m64 b)
void _mm_maskmove_si64 (__m64 a, __m64 mask, char* mem_addr)
int _mm_movemask_ps (__m128 a)
int _m_pmovmskb (__m64 a)
int _mm256_movemask_pd (__m256d a)
_mm256_mask_bitshuffle_epi64_mask (__mmask32 k2, __m256i b, __m256i c)
__m128d _mm_mask_permute_pd (__m128d src, __mmask8 k, __m128d a, const int imm8)
__m256d _mm256_permute_pd (__m256d a, int imm8)
__m256d _mm256_permute2f128_pd (__m256d a, __m256d b, int imm8)
__m256d _mm256_permute4x64_pd (__m256d a, const int imm8)
	*/
	
#else
	a += 4;
#endif 
	SHR32(c, c, BitsPerCode);
      }
    }

    BlockUnitType d;
    AND(d VI, c, first2bits32);
    //   printf("i=%d, snps=%d, indiv=%d bM1=%d ans=%lu e=%lu a=%lu delta=%lu UpBl=%lu BipBl=%d BipC=%d CpBl=%d", i, snps,individuals,blocksM1, (uintptr_t)  ans,(uintptr_t)  end_ans,(uintptr_t)  a,end_ans-a, UnitsPerBlock, BitsPerBlock, BitsPerCode, CodesPerBlock);
    assert(end_ans >= a && end_ans - a < UnitsPerBlock);
    for(Uint k=0; a < end_ans; a++) {
      //   printf("%f %f\n", factor[d.u32[k]], factor[d.u32[k+4]]);
      *a += factor[d.u32[k++]];
    }
  }  
}


SEXP genoVector(SEXP Z, SEXP V) {
  assert_shuffle(Z);
  Uint
    *info = GetInfo(Z),
    snps = info[SNPS],
    individuals = info[INDIVIDUALS],
    len = length(V);
  if (len != individuals) ERR("vector 'V' not of correct length");
  SEXP Ans;
  PROTECT(Ans = allocVector(REALSXP, snps));
  genoVectorIntern((BlockType0 *) Align(Z, ALIGN_VECTOR, snps), REAL(V), 
 		   snps, individuals, REAL(Ans));
  UNPROTECT(1);
  if (PRESERVE) R_PreserveObject(Ans);
  return(Ans);
}

#ifdef ANY_SIMD
BlockType INLINE VECTORADD(BlockType0 xx, BlockType0 yy) {
  BlockType z, sum, y;  
  AND(z, xx, yy);
  AND(y, z, LH); // 0.25 von 4
  SHUFFLE8(sum, and2scalar, y); // 0.5 von 4

  SHR32(y, z, 4L);
  AND(y, y, LH); // 
  SHUFFLE8(y, and2scalar, y);// 
  ADD8(sum, sum, y); // 
  //   showblock(sum, CodesPerBlock);

#ifndef OLD_VECTORADD
  XOR(z, xx, yy);
  AND(y, z, LH);
  SHUFFLE8(y, xor2scalar, y);
  ADD8(sum, sum, y);

  SHR32(y, z, 4L);
  AND(y, y, LH);
  SHUFFLE8(y, xor2scalar, y);
#else  // FOLGENDES IST NICHT SCHNELLER !!!
  XOR(z, xx, yy);
  SHR32(y, z, 1L);
  AND(z, y, z);
  SHR32(y, z, 3L);
  OR(z, z, y);
  AND(y, z, LH);
  SHUFFLE8(y, xor2scalar, y);
#endif

  ADD8(sum, sum, y);
  return sum;
}

#else  // no SIMD available

BlockType INLINE VECTORADD(BlockType0 xx, BlockType0 yy) {
  // 1 Operation more because of highest bit
  // Idee: die werte direkt eintragen, statt ueber die Tabelle nachschauen:
  BlockType z, sum, y, x;
  // 2 * 1 oder 2 * 1
  OR(x, xx, yy);
  SHL32(z, x, 1L);
  AND(x, x, z);
  AND(x, x, SHUFFLEMASK2); // ergb
    
  AND(z, xx, yy);
  AND(y, z, SHUFFLEMASK1); // 1 * 1
  OR(x, x, y);     // "addition" zu "2 * 1"
  
  AND(z, z, SHUFFLEMASK2); // 2 * 2;

  // globaler shift left leider nicht moeglich da oberstes Bit runterfaellt
  // somit werden die beiden (*) Zeilen zusaetzlich benoetigt
  // ohne die beiden unteren Zeilen hat code nur 14 (statt VECTADD 14)
  // Operationen mit einem Zeitgewinn von somit 7% und einem damit notwendigern
  // Speichmehrbedarf von 1.5% bei SSE und 0.8% bei AVX
  SHL32(y, z, 1L);
  OR(y, z, y);
  AND(sum, y, LH);

  SHR32(y, x, 4L);
  SHR32(z, z, 3L); // (*)
  OR(y, y, z);   // (*)
  AND(y, y, LH);

  ADD8(sum, sum, y);
  
  return sum;
}

#endif //  INLINE VECTORADD


Uint INLINE ADDUPVECTOR(BlockType0 x) {
  BlockType zero;
  ZERO(zero);
#if defined AVX2
  BlockUnitType vsum;
  SAD8(vsum VI, x, zero);  
  return vsum.u32[0]+ vsum.u32[2] + vsum.u32[4] + vsum.u32[6];
#else 
  BlockType vsum;
  SAD8(vsum, x, zero); //
  int L1, L2;
  EXTRACT16(L1, vsum, 0);
  EXTRACT16(L2, vsum, 4);
  return L1 + L2;
#endif
}
 
Uint scalar012(BlockType0 *x, BlockType0 *y, Uint blocks) {
#define x15  (255L / 16L) // 4 : max=2^2
  //                         4 : 2-bit-coding in 1 Byte                    
  Uint
    bundles = blocks / x15, 
    ans = 0;

  for (Uint i=0; i<bundles; i++) { 
    BlockType L1, L2, sum,
      *xx = x + i * x15,
      *yy = y + i * x15;
    ZERO(sum);
#if x15 == 15L
    LOAD(L1, xx); xx++; LOAD(L2, yy); yy++; ADD8(sum, sum, VECTORADD(L1, L2));
    LOAD(L1, xx); xx++; LOAD(L2, yy); yy++; ADD8(sum, sum, VECTORADD(L1, L2));
    LOAD(L1, xx); xx++; LOAD(L2, yy); yy++; ADD8(sum, sum, VECTORADD(L1, L2));
    LOAD(L1, xx); xx++; LOAD(L2, yy); yy++; ADD8(sum, sum, VECTORADD(L1, L2));
    LOAD(L1, xx); xx++; LOAD(L2, yy); yy++; ADD8(sum, sum, VECTORADD(L1, L2));

    LOAD(L1, xx); xx++; LOAD(L2, yy); yy++; ADD8(sum, sum, VECTORADD(L1, L2));
    LOAD(L1, xx); xx++; LOAD(L2, yy); yy++; ADD8(sum, sum, VECTORADD(L1, L2));
    LOAD(L1, xx); xx++; LOAD(L2, yy); yy++; ADD8(sum, sum, VECTORADD(L1, L2));
    LOAD(L1, xx); xx++; LOAD(L2, yy); yy++; ADD8(sum, sum, VECTORADD(L1, L2));
    LOAD(L1, xx); xx++; LOAD(L2, yy); yy++; ADD8(sum, sum, VECTORADD(L1, L2));

    LOAD(L1, xx); xx++; LOAD(L2, yy); yy++; ADD8(sum, sum, VECTORADD(L1, L2));
    LOAD(L1, xx); xx++; LOAD(L2, yy); yy++; ADD8(sum, sum, VECTORADD(L1, L2));
    LOAD(L1, xx); xx++; LOAD(L2, yy); yy++; ADD8(sum, sum, VECTORADD(L1, L2));
    LOAD(L1, xx); xx++; LOAD(L2, yy); yy++; ADD8(sum, sum, VECTORADD(L1, L2));
    LOAD(L1, xx); xx++; LOAD(L2, yy); yy++; ADD8(sum, sum, VECTORADD(L1, L2));

#else
    for (Uint j=0; j<x15; j++) {
      LOAD(L1, xx); xx++; LOAD(L2, yy); yy++; ADD8(sum, sum, VECTORADD(L1, L2));
    }
#endif
    ans += ADDUPVECTOR(sum); 
  }
  BlockType sum ,
    *endx = x + blocks,
    *xx = x + bundles * x15,
    *yy = y + bundles * x15;
  ZERO(sum);
  for (; xx < endx; xx++, yy++) ADD8(sum, sum, VECTORADD(*xx, *yy));
  ans += ADDUPVECTOR(sum);
  return ans;
}




SEXP matrixshuffle_get(SEXP CM) { // 0.45 bei 25000 x 25000
  assert_shuffle(CM);
  BlockType first2bits32;
  SET32(first2bits32, 0x00000003);
  Uint 
    *info = GetInfo(CM),
    snps = info[SNPS],
    individuals = info[INDIVIDUALS],
    bits = snps * BitsPerCode,
    fullBlocks = bits / BitsPerBlock,
    blocks = Blocks(snps),    //    units = blocks * UnitsPerBlock,
    *C0 = Align(CM, ALIGN_HAPLO, snps);
  if (info[WHAT] != GENOMATRIX) ERR("not a geno coding");
   
  SEXP Ans;
  PROTECT(Ans = allocMatrix(INTSXP, snps, individuals));
  Uint *M = (Uint*) INTEGER(Ans);
  for (Uint i=0, endfor= snps; i<endfor; i++) M[i] = 0; // noetig?

#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(CORES)   
#endif
  for (Uint i=0; i<individuals; i++) {
    Uint *mm = M + i * snps;
    BlockType *C = (BlockType *) C0 + i * blocks;
    for (Uint j=0; j<fullBlocks; j++, C++) {
      BlockType c = *C;
      for (Uint u=0; u<CodesPerUnit; u++, mm+=UnitsPerBlock) {	  
	BlockUnitType d;
	AND(d VI, c, first2bits32);
#define MD(i) mm[i] = d.u32[i];
#if UnitsPerBlock == 4
	MD(0); MD(1); MD(2); MD(3);
#elif UnitsPerBlock == 8
	MD(0); MD(1); MD(2); MD(3); MD(4); MD(5); MD(6); MD(7);
#else	    
	for (Uint k=0; k<UnitsPerBlock; k++) MD(k);
#endif	    
	SHR32(c, c, BitsPerCode);
      }
    }
    if (fullBlocks < blocks) {
      Uint *end = M + (i+1) * snps;
      BlockType c = ((BlockType *) C0)[i * blocks + fullBlocks];
      for (Uint u=0; u<CodesPerUnit && mm < end; u++) {
	BlockUnitType d;
	AND(d VI, c, first2bits32);
	for (Uint k=0; k<UnitsPerBlock && mm < end; k++, mm++)  *mm = d.u32[k];
	SHR32(c, c, BitsPerCode);
      } 
    }
  }
 
  UNPROTECT(1);
  if (PRESERVE) R_PreserveObject(Ans);
  return Ans;
}



SEXP matrix_start_shuffle(Uint individuals, Uint snps, SEXP file) {  
  SEXP Code = create_codevector(snps, individuals);
  start_info(Code, file, sizeof(BlockType0), CodesPerBlock);
  return(Code);
}
 


void matrix_shuffle(Uint *M, Uint start_individual, Uint end_individual, 
		    Uint start_snp, Uint end_snp, Uint Mnrow,
		    SEXP Ans,
		    double VARIABLE_IS_NOT_USED *G) {
  if (start_snp % CodesPerBlock != 0) BUG;
  Uint
    *info = GetInfo(Ans),
    //    individuals = info[INDIVIDUALS],
    snps = info[SNPS],
    cur_snps = end_snp - start_snp,
    *pM = M,
    *endM = M + Mnrow * (end_individual - start_individual),
    blocks = Blocks(snps),
    units = blocks * UnitsPerBlock,    
    *ans = ((Uint*) Align(Ans, ALIGN_HAPLOGENO, snps)
	    ) + start_snp / CodesPerUnit + start_individual * units;    

  //printf("Mnrow = %d %d\n", Mnrow, end_individual - start_individual);
  for (; pM<endM; pM += Mnrow, ans += units) {
    codeInnerGeno(pM, cur_snps,ans);
  }
}


SEXP matrix_coding_shuffle(Uint *M, Uint snps, Uint individuals) {  
  SEXP Code = matrix_start_shuffle(individuals, snps, R_NilValue);
  matrix_shuffle(M, 0, individuals, 0, snps, snps, Code, NULL);    
  return Code;
}



void IIrelationshipMatrix(BlockType0* CGM, Uint snps,
			  Uint individuals, double * ans) {
  Uint blocks = Blocks(snps);
  double nSq = (double) individuals * (double) individuals;
       
  if ((double) snps * nSq * 4.0 > 4.5035996e+15) // 2^{manissen-bits = 52}
    ERR("matrix too large to calculate the relationship matrix");
  
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(CORES) schedule(dynamic, 16)  
#endif
  for (Uint i=0; i<individuals; i++) {
    for (Uint j=i; j<individuals; j++) {
      Uint Mij = scalar012(CGM + i * blocks, CGM + j * blocks, blocks);
      ans[i + j * individuals] = ans[i * individuals + j] = (double) Mij;
    }
  }
}
 
 
   
void IrelationshipMatrix(BlockType0* CGM, Uint snps,
			 Uint individuals, double *ans) {   
  Uint blocks = Blocks(snps);
  double sum = sumGeno(CGM, blocks * individuals);
  IIrelationshipMatrix(CGM, snps, individuals, ans);
  DoCentering(ans, individuals, true, true, sum);
}



SEXP matrixshuffle_mult(SEXP GM) {
  assert_shuffle(GM);
  Uint
    *info = GetInfo(GM),
    individuals = info[INDIVIDUALS],
    snps = info[SNPS],
    *cgm = Align(GM, ALIGN_RELATION, snps);
  if (info[WHAT] != GENOMATRIX) ERR("not a coded Z matrix");
 
  SEXP Ans; 
  PROTECT(Ans = allocMatrix(REALSXP, individuals, individuals));
  IIrelationshipMatrix((BlockType0 *) cgm, snps, individuals, REAL(Ans));
  UNPROTECT(1);
  if (PRESERVE) R_PreserveObject(Ans);
  return Ans;
}
  

Uint *AlignShuffle(SEXP Code, Uint nr, Uint snps) {
  return Align(Code, nr, snps); }


real *Pd0 = NULL; 					   
void allele_freq2(BlockType0* CGM, Uint snps, int individuals,
		  double *sumP, double *sumP2) {
  // NOTE! twice allel frequency (indicated by the 2 at the end) 
  double n =  (double) individuals;
  if (snps > 536870912) ERR("too many SNPs");
  Uint blocks = Blocks(snps);

  
#define x31  (255L / 8L) // 2 : max{0,1,2}
  //                         4 : 2-bit-coding in 1 Byte                    

  Uint
    byteblocks = (snps - 1L) / BytesPerBlock + CodesPerByte,
    alignedByteBlocks = byteblocks + 1L,
    units = byteblocks * BytesPerBlock,
    alignedUnits = units + UnitsPerBlock,
    // here: P= 2(p_i), not 2 p_i - 1 == expected values == means
    groupsM1 = (individuals - 1L) / x31; 
  int
    *Sums0 = (int*) MALLOC(alignedUnits * BytesPerUnit),      
    *sum0 = (int*) MALLOC(alignedByteBlocks * BytesPerBlock);// snps + zuschlag
  BlockType first8bits, first2bits8,
    *sum = (BlockType0*) algn(sum0),
    *Sums  = (BlockType0*) algn(Sums0);
  // NullEins = SET32(0x55555555),
  SET32(first8bits, 0x000000FF);
  SET32(first2bits8, 0x03030303);
  if (Sums == NULL || sum == NULL) ERR("allocation error");
  { BlockType zero;
    ZERO(zero);
    Uint endfor = units / UnitsPerBlock;
    for (Uint k=0; k<endfor; Sums[k++] = zero); }
  // parallel funktioniert nicht gut!
  for (Uint i=0; i<=groupsM1; i++) {
    BlockType *cgm = CGM + i * blocks * x31;
    Uint endx = i < groupsM1 ? x31 : individuals - x31 * groupsM1;
    {
      BlockType zero;
      ZERO(zero);
      for (Uint k=0; k < byteblocks; sum[k++] = zero);
    }
    for (Uint x=0; x<endx; x++) {
      BlockType *s = sum;
      for (Uint k=0; k<blocks; k++, cgm++) { // see permutation.tex (*)
	BlockType d,
	  c = *cgm;
       	//	d = SHR32(c, 1);
	//	d = AND(NullEins, d);
	//	c = XOR(c, d);      
	for (Uint j=0; j<CodesPerByte; j++, s++) { // for-schleife aufloesen?
	  AND(d, c, first2bits8);
	  ADD8(*s, *s, d);
	  SHR32(c, c, 2);
	}
      }
    }
    
    //    R < Simianer_sims_23_01.R --vanilla
	 
    BlockType *pS = (BlockType0*) Sums;      
    for (Uint k=0; k<byteblocks; k++) { // see permutation.tex (*)
      BlockType s0 = sum[k];
      for (Uint j=0; j<BytesPerUnit; j++, pS++) {
	BlockType L1;
	AND(L1, s0, first8bits);
	ADD32(*pS, *pS, L1); 
	SHR32(s0, s0, BitsPerByte);
      }
    }
  } // for groups
  FREE(sum0);
  
  Uint *S = (Uint*) Sums,
    alignedreal = byteblocks * BytesPerBlock * sizeof(real) + BytesPerBlock;
  Pd0 = (real*) MALLOC(alignedreal);
  real
    *Pd = (real *) algnrl(Pd0),
    *pPd = Pd;
  double
    sum_Psq = 0.0,
    sum_P = 0.0;
  if (GLOBAL_UTILS->basic.kahanCorrection) {
    double corr = 0.0,
      corrSq = 0.0;
    for (Uint b=0,i=0; b<blocks; b++, pPd += CodesPerBlock) {
      for (Uint c=0; c<CodesPerBlock; c++, i++) {
	double Pi = (double) S[i] / n;
	pPd[permut_finv_g_h[c]] = (real) Pi;

	double fcorr = Pi - corr,
	  roughsum = sum_P + fcorr;
	corr = (roughsum - sum_P) - fcorr;	
	sum_P = roughsum;
	
	fcorr = Pi * Pi - corrSq;
	roughsum = sum_Psq + fcorr;
	corrSq = (roughsum - sum_Psq) - fcorr;	
	sum_Psq = roughsum;
      }
    }
  } else {
    for (Uint b=0,i=0; b<blocks; b++, pPd += CodesPerBlock) {
      for (Uint c=0; c<CodesPerBlock; c++, i++) {
	double Pi = (double) S[i] / n;
	pPd[permut_finv_g_h[c]] = (real) Pi;
	sum_P += Pi;
	sum_Psq += Pi * Pi;
      }
    }
  }
    
  FREE(Sums0);
  if (sumP != NULL) *sumP = sum_P;
  if (sumP2 != NULL) *sumP2 = sum_Psq;    
}

      



SEXP allele_freq(SEXP GM) {
  assert_shuffle(GM);
  Uint 
    *info = GetInfo(GM),
   individuals = info[INDIVIDUALS],
    snps = info[SNPS],
    *cgm = Align(GM, ALIGN_ALLELE, snps);
  if (info[WHAT] != GENOMATRIX) ERR("not a coded Z matrix");
  SEXP Ans; 
  PROTECT(Ans = allocVector(REALSXP, snps));
  allele_freq2((BlockType0 *) cgm, snps, individuals, NULL,
	       NULL); // Pd0 set as side effect
  real *Pd = (real*) algnrl(Pd0);
  double *ans = REAL(Ans);
  for (Uint i=0; i<snps; i++) ans[i] = 0.5 * (double) Pd[i];
  FREE(Pd0);
  UNPROTECT(1);
  if (PRESERVE) R_PreserveObject(Ans);
  return Ans;
}



SEXP fillSNPmatrix(SEXP Z, SEXP Idx, SEXP V) {
  assert_shuffle(Z);
  ToInt(Idx);
  Uint
    *info = GetInfo(Z),
    snps = info[SNPS],
    *z = Align(Z, ALIGN_RELATION, snps),
    *v = Align(V, ALIGN_HAPLO, snps),
     len = length(Idx),
    blocks = Blocks(info[SNPS]),
    units = blocks * UnitsPerBlock,
    bytes = BytesPerBlock * blocks;
  if (info[WHAT] != GENOMATRIX) ERR("not a geno matrix that is filled");
  for (Uint i=0; i<len; i++, v += units) {
    Uint idx = Idxint[i] - 1;
    if (idx > info[INDIVIDUALS]) ERR("Idx out of bound");
    MEMCOPY(z + idx * units, v, bytes);
  }
  FREEint(Idx);
  return R_NilValue;
}


