
/*
 Authors 
 Martin Schlather, schlather@math.uni-mannheim.de


 Copyright (C) 2018 -- 2019  Martin Schlather

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  
*/


#ifndef miraculix_MX_H
#define miraculix_MX_H 1


#define SCHLATHERS_MACHINE 1

//#include "miraculix.h"
//#include "AutoMiraculix.h"
//#include "intrinsics.h"
// include liste nicht erweitern, sondern stattdessen haplogeno.h verwenden

#include <R.h>
#include <Rinternals.h>
#include <inttypes.h>

extern bool debugging;

extern int PL, CORES;
extern bool PRESERVE;
typedef unsigned int Uint;
//typedef unsigned long long Ulong;
typedef uint64_t Ulong;
typedef int64_t Long;

extern SEXP Information, Method, Coding; // READONLY !!!!

SEXP CreateEmptyCodeVectorALL(Uint snps, Uint individuals, Uint memInUnits,
			      Uint bytesPerBlock, Uint bitsPerCode,
				Uint codesperblock, bool haplo);

#define CreateEmptyCodeVector(snps, individuals, memInUnits)		\
  CreateEmptyCodeVectorALL(snps, individuals, memInUnits,		\
			     BytesPerBlock, BitsPerCode, CodesPerBlock, false);
#define CreateEmptyCodeVectorHaplo(snps, individuals, memInUnits)	\
  CreateEmptyCodeVectorALL(snps, individuals, memInUnits,		\
			     BytesPerBlock, BitsPerCode, CodesPerBlock, true);



void start_info(SEXP Code, SEXP file, int blocksize, int codesperblock);

// #define GetInfo(M) (Uint *) INTEGER(getAttrib(M, Information))
// OBIGES WAERE DAS RICHTIGE, ABER ALTES FORMAT EXISTIERT NOCH:
Uint *GetInfo(SEXP M);
#define MethodOf(M) INTEGER(getAttrib(M, Method))[0]
#define ClassOf(M) INTEGER(getAttrib(M, Class))[0]

#define SumGeno(info)							\
    ((Ulong) info[SUMGENO] +(uint64_t) info[SUMGENO_E9] * (Ulong) 1000000000)
#define StoreSumGeno(X) {					\
    Ulong GenoSum = X;					\
    info[SUMGENO] = GenoSum % (uint64_t) 1000000000;	\
    info[SUMGENO_E9] = GenoSum / (uint64_t) 1000000000;	\
  }



#define BitsPerByte 8L
#define BytesPerDouble 8L
#define BytesPerUnit 4L // R unit (int) !

typedef union addr_Uint{
  uintptr_t a;
  Uint u[sizeof(uintptr_t) / BytesPerUnit];
} addr_Uint;


#define ALIGN_HAPLO 0
#define ALIGN_HAPLOGENO 1
#define ALIGN_VECTOR 2
#define ALIGN_RELATION 3
#define ALIGN_ALLELE 4
#define ALIGN_COMPUTE 5
#define ALIGN_CODED 6
#define ALIGN_SSE 7
#define ALIGN_23 7
#define ALIGN_LAST ALIGN_CODED

#define algn_general(X, bytesperblock)  ((1L + (uintptr_t) (((uintptr_t) X - 1L) / bytesperblock)) * bytesperblock)


#define ADDALIGN(Code)							\
  assert(sizeof(uintptr_t)/BytesPerUnit == 2);				\
  Uint *info = GetInfo(Code);						\
  addr_Uint addalign;							\
  addalign.a = (uintptr_t) algn(INTEGER(Code));				\
  assert(sizeof(uintptr_t)/BytesPerUnit <= 2);				\
  for (Uint i=0; i<sizeof(uintptr_t)/BytesPerUnit; i++)			\
    info[ALIGNADDR + i] = addalign.u[i];					


Uint Inti(SEXP X, int i);
#define Int0(X) Inti(X, 0)

#endif
