
/*
 Authors 
 Martin Schlather, schlather@math.uni-mannheim.de


 Copyright (C) 2019 -- 2019  Martin Schlather

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, writne to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  
*/


#ifndef miraculix_shuffle_H
#define miraculix_shuffle_H 1

#include "MX.h"


SEXP matrixshuffle_mult(SEXP GM);
SEXP matrix_start_shuffle(Uint individuals, Uint snps, SEXP G);
void matrix_shuffle(Uint *M, Uint start_individual, Uint end_individual, 
		    Uint start_snp, Uint end_snp, Uint Mnrow,
		    SEXP Ans, double * G);

SEXP matrixshuffle_get(SEXP SNPxIndiv);
SEXP matrix_coding_shuffle(Uint *M, Uint snps, Uint individuals);

SEXP create_codevector(Uint snps, Uint individuals);
//SEXP create_codevector(Uint what, Uint snps, Uint individuals, Uint);
SEXP create_codevectorHaplo(Uint snps, Uint individuals);

Uint *AlignShuffle(SEXP Code, Uint nr, Uint snps);
void InitShuffle();
SEXP codeHaplo2(SEXP M1, SEXP M2);
int CodesPerBlockShuffle();

#endif
