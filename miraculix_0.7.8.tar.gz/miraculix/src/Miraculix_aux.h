
/*
 Authors 
 Martin Schlather, schlather@math.uni-mannheim.de

 Copyright (C) 2017 -- 2019 Martin Schlather

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  
*/


#ifndef MIRACULIX_AUX_H
#define MIRACUKIX_AUX_H 1

#include <R.h>
#include <Rinternals.h>

#include <Basic_utils.h>
#include "error.h"
#include <zzz_RandomFieldsUtils.h>



//#include <Rmath.h>
//#include <errno.h>
//#include <R_ext/Complex.h>
//#define MULTIPLEMATCHING -2 //kleinkram.h
//#define NOMATCHING -1
//#define MATCHESINTERNAL -3



extern utilsparam* GLOBAL_UTILS;

typedef char name_type[][MAXCHAR];

void scanC(int *positions, int *length, double *freq, int *minscan,
	  int *maxscan, double *threshold, int *nthres, 
	  int *PER_SNP,
	  int *above_threshold, double *maximum);
void sumscanC(int *positions, int *length, double *freq, int *minscan,
	     int *maxscan, double *threshold, int *nthres, 
	     int *PER_SNP,
	     int *above_threshold, double *maximum);



#endif /* miraculix_aux_h */
