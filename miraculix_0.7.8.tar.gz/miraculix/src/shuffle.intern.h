
/*
 Authors 
 Martin Schlather, schlather@math.uni-mannheim.de


 Copyright (C) 2019 -- 2019  Martin Schlather

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, writne to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  
*/


#ifndef miraculix_shuffleintern_H
#define miraculix_shuffleintern_H 1

//#include <General_utils.h>
//#include "AutoMiraculix.h"


#if defined DO_FLOAT
#define real float
#define Real Float
#define ZEROREAL ZEROFLOAT 
#define INT2REAL INT2FLOAT 
#define MULTREAL MULTFLOAT 
#define ADDREAL ADDFLOAT  
#define SUBREAL SUBFLOAT
#if defined ANY_SIMD
#define REALVALUE .f
#define IR(X, Y) INT2FLOAT(f.u128[X], d.u128[Y]);
#else
#define REALVALUE 
#define IR(X, Y) INT2FLOAT(f, d);
#endif // not ANY_SIMD
#else
#define real double
#define Real Double
#define ZEROREAL ZERODOUBLE 
#define INT2REAL INT2DOUBLE 
#define MULTREAL MULTDOUBLE 
#define ADDREAL ADDDOUBLE  
#define SUBREAL SUBDOUBLE  
#if defined ANY_SIMD
#define REALVALUE .d
#define IR(X, Y) INT2DOUBLE(f.d128[X], d.m64[Y]);
#else
#define REALVALUE 
#define IR(X, Y) INT2DOUBLE(f, d.m64[Y]);
#endif // not ANY_SIMD

#endif // not DO_FLOAT


#define BITS_GENE_INPUT 6
#define BITS_SEX 1
#define BITS_INDIVIDUALS 22
#define BITS_HAPLO 3

#define MAX_GENE_INPUT (1 << BITS_GENE_INPUT)
#define MAX_SEX (1 << BITS_SEX)
#define MAX_INDIVIDUALS (1 << BITS_INDIVIDUALS)
#define MAX_HAPLO (1 << BITS_HAPLO)

#define PATTERN_GENE_INPUT  (MAX_GENE_INPUT - 1)
#define PATTERN_SEX (MAX_SEX - 1)
#define PATTERN_INDIVIDUALS (MAX_INDIVIDUALS - 1)
#define PATTERN_HAPLO (MAX_HAPLO - 1)

extern BlockType BitMaskStart[CodesPerBlock], BitMaskEnd[CodesPerBlock];
extern bool shuffleNotInit;
// extern real *Pd0;  // NICHT loeschen -- zur Zeit ausgeblendet in shuffle.cc
extern Uint permut_finv_g_h[CodesPerBlock];

void IrelationshipMatrix(BlockType0* CGM, Uint snps,
			       Uint individuals, double *ans);
void InitShuffle();
void assert_shuffle();
void assert_shuffle(SEXP);
void haplo2geno(BlockType0 *X, Uint snps, Uint individuals);
SEXP codeHaplo2(SEXP M1, SEXP M2);
Ulong sumGeno(BlockType0 *S, Uint blocks);

#endif
