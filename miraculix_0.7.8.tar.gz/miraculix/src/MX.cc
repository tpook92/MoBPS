
/*
 Authors 
 Martin Schlather, schlather@math.uni-mannheim.de


 Copyright (C) 2018 -- 2019  Martin Schlather

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  
*/


#include <R.h>
#include <Rinternals.h>
#include <inttypes.h> // uintptr_t
//#include <Rdefines.h>
#include "AutoMiraculix.h"
#include "MX.h"
#include <General_utils.h>
#include <zzz_RandomFieldsUtils.h>
#include "options.h"

int PL=C_PRINTLEVEL,
  CORES=INITCORES; // INITI
bool PRESERVE = false;
SEXP Information = R_NilValue,
  Coding = R_NilValue,
  Method = R_NilValue;

bool debugging = false;


SEXP CreateEmptyCodeVectorALL(Uint snps, Uint individuals, Uint memInUnits,
			      Uint bytesPerBlock, Uint bitsPerCode,
			      Uint codesperblock, bool haplo) {
  
  SEXP Code, info, method, Class;

  if (bitsPerCode == 32) {
    if (snps * individuals != memInUnits) BUG;
    PROTECT(Code = allocMatrix(INTSXP, snps, individuals));
  } else {
    //printf("snps = %d %d prod=%d %d, %s\n", snps, individuals,snps * individuals, memInUnits, SNPCODING_NAME[GLOBAL.relationship.method]);
    
    if (snps * individuals <= memInUnits && snps > 1000) {
      //  printf("snps = %d %d prod=%d %d, %s\n", snps, individuals,snps * individuals, memInUnits, SNPCODING_NAME[GLOBAL.relationship.method]);
      BUG;
    }
    PROTECT(Code = allocVector(INTSXP, memInUnits)); 
  }
  
  int* A = INTEGER(Code);
  for (Uint k=0; k<memInUnits; A[k++] = 0.0);
  

  PROTECT(method = allocVector(INTSXP, 1));
  INTEGER(method)[0] = GLOBAL.relationship.method;
  
  PROTECT(Class = allocVector(STRSXP, 1));
  SET_STRING_ELT(Class, 0, mkChar(haplo ? HAPLOMATRIX : GENOMICMATRIX));
  
  
  PROTECT(info = allocVector(INTSXP, INFO_LAST + 1));
  int *pI = INTEGER(info);
  for (Uint i=0; i<=INFO_LAST; pI[i++] = NA_INTEGER);
  pI[WHAT] = GENOMATRIX;
  pI[SNPS] = snps;
  pI[INDIVIDUALS] = individuals;  
  pI[SNPxIND] = true;
  pI[MEMinUNITS] = memInUnits;
  pI[BITSPERCODE] = bitsPerCode;
  pI[CODESPERBLOCK] = codesperblock;
  pI[BYTESPERBLOCK] = bytesPerBlock;
  pI[SUMGENO] = pI[SUMGENO_E9] = 0;

  addr_Uint au;
  au.a = (uintptr_t) INTEGER(Code);
  assert(sizeof(uintptr_t)/BytesPerUnit <= 2);
  for (Uint i=0; i<sizeof(uintptr_t)/BytesPerUnit; i++) pI[ADDR0 + i] = au.u[i];
 
  setAttrib(Code, Information, info); // install("information")
  setAttrib(Code, Method, method); // install("method")
  SET_CLASS(Code, Class);
  UNPROTECT(4);

  // printf("%u", (uintptr_t) A);
  
  return Code;
}




void start_info(SEXP Code, SEXP file, int blocksize, int codesperblock) {
   Uint 
     *info = GetInfo(Code);
 
  if (file != R_NilValue) {
    Uint *fileinfo = GetInfo(file);
    info[SNPxIND] = fileinfo[SNPxIND];					
  }

  if (PL > 1) {								
    Uint
      mem = info[MEMinUNITS],
      individuals = info[INDIVIDUALS],
      sizeM = (Uint) (blocksize * mem / 1048576);		
    PRINTF("Data: %d individuals and %d SNPs\nStorage mode: %d block(s) of %d codes\nSize of M: %d MB", 
	   individuals, info[SNPS], mem / individuals, codesperblock, 
	   sizeM < 1 ? 1 : sizeM);	       
  }
}


Uint *GetInfo(SEXP M) {
#define INFO_INFO 0
  SEXP Infos = getAttrib(M, Information);
  if (TYPEOF(Infos) == INTSXP) return (Uint *) INTEGER(Infos);
  else {
    //    PRINTF("obsolete storing of information");
    return (Uint *) INTEGER(VECTOR_ELT(Infos, INFO_INFO));
  }
}


Uint Inti(SEXP X, int i) {
  switch(TYPEOF(X)) {
  case INTSXP : return (Uint) INTEGER(X)[i];
  case LGLSXP : return (Uint) LOGICAL(X)[i];
  case REALSXP : return (Uint) REAL(X)[i];
  default : ERR("not of numerical type");
  }
}
