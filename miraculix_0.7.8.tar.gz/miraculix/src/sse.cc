
/*
 Authors 
 Martin Schlather, schlather@math.uni-mannheim.de


 Copyright (C) 2014 -- 2019  Martin Schlather
Copyright (C) 2014 -- 2015 Florian Skene: SSE2+SSE3

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  
*/

#define BitsPerCode 4L

#if defined __SSSE3__ 
#define SSSE3 1
#define SSE2 1
#endif
#if defined  __SSE2__ 
#define SSE2 1
#endif

#include "intrinsics.h"
#include "miraculix.h"
#include "xport_import.h"
#include "options.h"
#include "AutoMiraculix.h"
#include <General_utils.h>
#include "MX.h"
#include "error.h"
#include "haplogeno.h"

INLINER

#define repetSSE2 10L
#define atonceSSE2 3L
#define atonce_SSE3 4L

int CodesPerBlockH() { return CodesPerBlock; }

SEXP static create_codevectorSSE(Uint snps, Uint individuals) {
  assert(BytesPerBlock == sizeof(BlockType0));

  Uint method = GLOBAL.relationship.method;
  //  if (method == Hamming2) { if (snps % 96) BUG; }
  //  else if (method == Hamming3) { if (snps % 128) BUG; }
  //  else BUG;
  
  Uint
    f = method == Hamming2 ? repetSSE2 * atonceSSE2 : atonce_SSE3, // wechsel 64 bit auf 128; 3 bzw 4
    //                                       auf ein Mal; sse2: 10x wiederholt
    //minmem = (1L + (snps - 1L) / (2 * f)) * (2 * f),
    Xblocks = (1L + (snps - 1L) / (f * CodesPerBlock)) * f,
    mem = UnitsPerBlock * ((Xblocks +1L) + Xblocks * (individuals - 1L)) - 1L,
    mem2 = 2 * mem; // M, M_T2

  //  printf("block=%lu %lu %lu %u %u\n", Xblocks, mem, f, snps, BytesPerBlock);

  SEXP Code = CreateEmptyCodeVector(snps, individuals, mem2);
  ADDALIGN(Code);

//if (PRESERVE) {BUG;  R_PreserveObject(Code);}
  return(Code);
}


static uint64_t coding1[] = {0, 5, 10},    //0, 1, 2
  coding2[] = {0, 3, 15},    //0, 1, 2
  coding3[] = {0, 6, 15},    //0, 1, 2
  coding4[] = {0, 3, 15};    //0, 1, 2
int rev_coding1[16] = {0, 0, 0, 0,  0, 1, 0, 0,  0, 0, 2, 0,  0, 0, 0, 0},
// rev_coding24[16] = {0, 0, 0, 1,  0, 0, 0, 0,  0, 0, 0, 0,  0, 0, 0, 2},
 rev_coding3[16] = {0, 0, 0, 0,  0, 0, 1, 0,  0, 0, 0, 0,  0, 0, 0, 2},
  MASK1 = (1L << BitsPerCode) - 1L;

  
void matrix_codingHI(Uint *SNPxIndiv, Uint individuals, Uint snps, Uint Mnrow,
		     uint64_t *M, uint64_t *M_T, 
		     uint64_t *code1, uint64_t  *code2, Uint Blocks) {

  Uint
    mini = sizeof(BlockType0) / sizeof(uint64_t),
    miniblocks = Blocks * mini,
    CodesPerMiniblock = CodesPerBlock / mini;
  
  // coding of M and M^T
  for (Uint i = 0; i<individuals; i++) {
    Uint count=0,
      *pSNPxI = SNPxIndiv + i * Mnrow;
    uint64_t
      *Mptr = M + i * miniblocks,
      *M_Tptr = M_T + i * miniblocks;
    for (Uint s = 0; s<snps; s++) {
      Uint snp = pSNPxI[s];
      *Mptr = *Mptr << BitsPerCode;
      *Mptr |= code1[snp];

      *M_Tptr = *M_Tptr << BitsPerCode;
      *M_Tptr |= code2[snp];

      if (++count == CodesPerMiniblock) {
	count = 0;
	Mptr++;
	M_Tptr++;
      }
    }
    if (count > 0) {
      Uint shift = BitsPerCode * (CodesPerMiniblock - count);
      *Mptr = *Mptr << shift;
      *M_Tptr = *M_Tptr << shift;
    }
  }
}

void matrixH(Uint *SNPxIndiv, Uint start_individual, Uint end_individual, 
	     Uint start_snp, Uint end_snp, Uint Mnrow, SEXP Code) {
  if (start_snp % CodesPerBlock != 0) BUG;

  bool hamming2 = GLOBAL.relationship.method == Hamming2;
  Uint
    *info = GetInfo(Code),
    individuals = info[INDIVIDUALS],
    snps = info[SNPS],
    cur_snps = end_snp - start_snp,
    memPerMatrix = info[MEMinUNITS] / 2,
    blocksPerMatrix =  memPerMatrix / UnitsPerBlock,
    blocks = blocksPerMatrix / individuals; // NICHT Blocks(snps) !!
 
  BlockType 
    *M = ((BlockType*) Align(Code, ALIGN_SSE, snps)) + start_snp / CodesPerBlock
    + start_individual * blocks,
    *M_T = M + blocksPerMatrix;

  // printf("define mem= %lu %lu %u %lu\n", M, M_T, info[ALIGNADDR], ((uint64_t*)(info + ALIGNADDR))[0]);
 
  matrix_codingHI(SNPxIndiv, end_individual-start_individual, cur_snps, Mnrow,
		  (uint64_t*) M, (uint64_t*) M_T,
		  hamming2 ? coding1 : coding3,
		  hamming2 ? coding2 : coding4,
		  blocks);
}

void matrixH(Uint *M, Uint start_individual, Uint end_individual, 
	     Uint start_snp, Uint end_snp, Uint Mnrow,
	     SEXP Code,  double VARIABLE_IS_NOT_USED *G) {
  matrixH(M, start_individual, end_individual, start_snp, end_snp, Mnrow, Code);
}


SEXP matrixH_get(SEXP SNPxIndiv) {
  bool hamming2 = MethodOf(SNPxIndiv) == Hamming2;
  int *rev = hamming2 ? rev_coding1 : rev_coding3;
  Uint 
     *info = GetInfo(SNPxIndiv),
    individuals = info[INDIVIDUALS],
    snps = info[SNPS],
    memPerMatrix = info[MEMinUNITS] / 2,    
    blocksPerMatrix =  memPerMatrix / UnitsPerBlock,
    blocks = blocksPerMatrix / individuals,
    mini = sizeof(BlockType0) / sizeof(uint64_t),
    miniblocksPerMatrix = blocksPerMatrix * mini,
    miniblocks = blocks * mini,
    BitsPerMiniblock = BitsPerBlock / mini,
    CodesPerMiniblock = CodesPerBlock / mini;

 

  SEXP Ans;
  PROTECT(Ans=allocMatrix(INTSXP, snps, individuals));
  //if (PL > 1) PRINTF("Data: %d individuals and %d SNPs\n", individuals, snps);
  Uint *ans = (Uint *) INTEGER(Ans);
  uint64_t *M = (uint64_t*) Align(SNPxIndiv, ALIGN_SSE, snps);
  // printf("get mem= %lu %lu %u\n", M, M + blocksPerMatrix * UnitsPerBlock / 2, info[ALIGNADDR]);
  for (Uint a=0; a<miniblocksPerMatrix; a+=miniblocks) {
    uint64_t *Ma = M + a;
    // uint64_t *Ma = M + blocksPerMatrix * UnitsPerBlock / 2 + a;
    for (Uint s=0; s<snps; s++) {
      *(ans++) = rev[(Ma[s / CodesPerMiniblock]
      //    *(ans++) = rev_coding24[(Ma[s / CodesPerMiniblock]
		      >> (BitsPerMiniblock - BitsPerCode -
			  BitsPerCode  * (s % CodesPerMiniblock))) & MASK1];
    }
  }
  UNPROTECT(1);
  return Ans;
}

void matrix_mult2(BlockType0 *M, BlockType0 *M_T, int individuals, int snps,
		  double *ergb, Uint blocks) {
#if not defined SSE2
  ERR("Hamming2 snp coding needs at least SSE2");
#else
  // M*M^T:
  // outer for-loop represents rows of M (only within partition, if > 1 cores
  // inner for-loop represents columns of M^T starting at diagonal element
  int
    f = repetSSE2 * atonceSSE2, // 10 * 3  
    Xblocks = (1L + (snps - 1L) / (f * CodesPerBlock)) * f,
    loops = Xblocks / f;
  BlockType m1, m2, m4, m8;
  uint64_t OOO1 = INT64_C(0x0001000100010001);

  SET8(m1, 0x55);
  SET8(m2, 0x33);
  SET8(m4, 0x0f);
  SET16(m8,0x00ff);

  //printf("size of block %d\n", sizeof(BlockType));

#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(CORES) schedule(dynamic, 20)
#endif 
  for (int i = 0; i<individuals; i++) {
    BlockType *mpp = M + i * blocks;
    for (int j = i; j<individuals; j++) {
      BlockType
	*m_tpp = M_T + j * blocks,
	*mptr = mpp; //mptr set back to first element of row in 	
      uint64_t tot = 0;
      for (int s=0; s<loops; s++) {
	uni128 acc;
	ZERO(acc VI);
	// do-while runs 10x before continuing
	for (int t=0; t<repetSSE2; t++) {
	  BlockType L1, L2, half1, half2;
	  LOADU(L1, mptr); mptr++;
	  LOADU(L2, m_tpp); m_tpp++;
	  AND(half1, L1, L2);
	  SHR64(L1, half1, 1);	  
	  AND(half2, L1, m1);
	  AND(half1, half1, m1);
	  OR(half1, half1, half2);
	  LOADU(L1, mptr); mptr++;
	  LOADU(L2, m_tpp); m_tpp++;
	    BlockType count1, count2;
	  AND(count1, L1, L2);
	  ADD64(count1, count1, half1);
	  LOADU(L1, mptr); mptr++;
	  LOADU(L2, m_tpp);m_tpp++;
	  AND(count2, L1, L2);
	  ADD64(count2, count2, half2);
#define dummy1 half1
#define dummy2 half2
	  AND(dummy1, count1, m2);
	  SHR64(L1, count1, 2);
	  AND(dummy2, L1, m2);
	  ADD64(count1,dummy1, dummy2);
	  AND(dummy1, count2, m2);
	  SHR64(L1, count2, 2);
	  AND(dummy2, L1, m2);
	  ADD64(dummy1, dummy1, dummy2);
	  ADD64(count1, count1, dummy1);
	  AND(dummy1, count1, m4);
	  SHR64(L1, count1, 4);
	  AND(dummy2, L1, m4);
	  ADD64(dummy1, dummy1, dummy2);
	  ADD64(acc VI, acc VI, dummy1);
	}
	BlockType L1, L2;
	AND(L1, acc VI, m8);
	SHR64(L2, acc VI, 8);
	AND(L2, L2, m8);
	ADD64(acc VI, L1, L2);
	tot += ((acc.u64[0] + acc.u64[1]) * OOO1) >> 48;
      }
      ergb[j + i * individuals] = ergb[i + j * individuals] = (double) tot;
    }
  }
#endif
}
 

void matrix_mult3(BlockType0 *M, BlockType0 *M_T, int individuals, int snps,
		  double *ergb, Uint blocks) {   
#if not defined SSSE3
  ERR("Hamming3 snp coding needs at least SSSE3");
#else
  // M*M^T:    
  int
    Xblocks = (1L + (snps - 1L) / (atonce_SSE3 * CodesPerBlock)) * atonce_SSE3,
    loops = 1 + (Xblocks -1) / atonce_SSE3;
  
  const unsigned _LUT[] = {0x02010100, 0x03020201, 0x03020201, 0x04030302};
  BlockType LUT, mask, zero;


  LOADU(LUT, (BlockType*) _LUT); // _mm_set_epi32(,,,)
  SET8(mask, 0x0F);
  ZERO(zero);
  
  uni128  intermed;
  ZERO(intermed VI);
   
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(CORES) schedule(dynamic, 20)
#endif
  for (int i = 0; i<individuals; i++) {
    BlockType
      *mpp = M + i * blocks;
     for (int j = i; j<individuals; j++) {
      int tot = 0;
      BlockType *mptr = mpp,
	*m_tpp = M_T + j * blocks;
      for (int k = 0; k < loops; k++) {    // '/4' hinzugefuegt
	BlockType v0, lo, count0, count1, L1, L2;
#define COUNT(count0)						\
	LOADU(L1, mptr);mptr++;					\
	LOADU(L2, m_tpp);m_tpp++;				\
	AND(v0, L1, L2);					\
	AND(lo, mask, v0);					\
	SHR16(L1, v0, 4);					\
	AND(v0, mask, L1); /* hi */				\
	SHUFFLE8(lo, LUT, lo);					\
	SHUFFLE8(v0, LUT, v0);					\
	ADD8(count0, lo, v0);
	
	COUNT(count0);
	COUNT(v0);
	ADD8(count0, count0, v0);
	COUNT(count1);
	COUNT(v0);
	ADD8(count1, count1, v0);
	ADD8(count0, count0, count1);
	
	//bitwise difference between 'tota' and all zeros
	SAD8(intermed VI, count0, zero);
	// adds the two bitcounts which are saved as unsigned 64bit integers
	// to continuous bitcount
	tot += (int) intermed.u64[0] + (int)intermed.u64[1];
      }
      ergb[j + i * individuals] = ergb[i + j * individuals] = (double) tot;
    }
  }
#endif
}


SEXP matrixH_mult(SEXP M) {
  SEXP Ans;
  Uint
    *info = GetInfo(M),
    individuals = info[INDIVIDUALS],
    snps = info[SNPS],
    memPerMatrix = info[MEMinUNITS] / 2,
    blocksPerMatrix =  memPerMatrix / UnitsPerBlock,
    blocks = blocksPerMatrix / individuals;

  PROTECT(Ans = allocMatrix(REALSXP, individuals, individuals));
  double *ans = REAL(Ans);
  BlockType *m = (BlockType*) Align(M, ALIGN_SSE, snps);
  int meth = MethodOf(M); 

  //printf("mult mem= %lu %lu %u %u %d\n", m, (uintptr_t) (m + blocksPerMatrix), info[ALIGNADDR], snps, meth == Hamming2);
    
  if (meth == Hamming2)
    matrix_mult2(m, m + blocksPerMatrix, individuals, snps, ans, blocks);
  else matrix_mult3(m, m + blocksPerMatrix, individuals, snps, ans, blocks);
   
  UNPROTECT(1);
  return Ans;
}



SEXP matrix_startH(Uint individuals, Uint snps, SEXP file) {  
  
  SEXP Code = create_codevectorSSE(snps, individuals);
  start_info(Code, file, sizeof(BlockType0), CodesPerBlock);
  return(Code);
}
 

  
SEXP matrix_codingH(Uint *M, Uint snps, Uint individuals){
  SEXP Code = matrix_startH(individuals, snps, R_NilValue);
  matrixH(M, 0, individuals, 0, snps, snps,  Code); 
  return Code;
}


Uint *AlignH(SEXP Code, Uint nr, Uint snps) { return Align(Code, nr, snps); }
