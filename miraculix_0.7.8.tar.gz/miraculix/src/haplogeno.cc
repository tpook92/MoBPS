
/*
 Authors 
 Martin Schlather, schlather@math.uni-mannheim.de


 Copyright (C) 2018 -- 2019  Martin Schlather

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  
*/

// _MM_ALIGN16 Uint ccc;

#include "AutoMiraculix.h"
#include <General_utils.h>
#include <zzz_RandomFieldsUtils.h>
#include "xport_import.h"
#include "error.h"
#include "Bit23.h"
#include "shuffle.h"
#include "sse.h"
#include "nocoding.h"
#include "options.h"
#include "miraculix.h"


typedef SEXP (*coding_start_t)(Uint , Uint, SEXP);
typedef void (*coding_main_t)(Uint *, Uint, Uint, Uint, Uint, Uint,
			      SEXP, double *);
typedef int (*codes_per_block_t)();

char EOL = '\n';



SEXP get_centered() {
  Uint len = GLOBAL.relationship.ncentered ;
  double *centered = GLOBAL.relationship.pcentered;
  assert (centered != NULL && GLOBAL.relationship.centered==Nan);
  SEXP Ans;
  PROTECT(Ans = allocVector(REALSXP, len));
  double *ans = REAL(Ans);
  MEMCOPY(ans, centered, sizeof(double) * len);
  UNPROTECT(1);
  return Ans;
}


			     


double DoCentering(double *ans, Uint individuals, bool centred, bool normalized,
		   Ulong sumGeno) {
  double
    nd = (double) individuals,
    nSq = nd * nd,
    factor = RF_NAN,
    sum_pi_qi = RF_NAN;
  if (centred || normalized) {
    double
      sum_P = RF_NAN,
      *sums = (double *) MALLOC(sizeof(double) * individuals),
      total = 0.0;
    
    Uint k = 0,
      nP1 = individuals + 1;
    for (Uint i=0; i<individuals; i++) {
      double dummy = 0.0;
      for (Uint j=0; j<individuals; j++) dummy += ans[k++];
      sums[i] = nd * dummy;
      total += dummy;
    }

    if (centred) {
      for (Uint i=0; i<individuals; i++) {
	Uint idx = i * nP1;
	for (Uint j=i; j<individuals; j++, idx++) {
	  ans[idx] = nSq * ans[idx] - sums[i] - sums[j] + total;
	}
      }
    }
    
    if (normalized) {
      sum_P = nd *  (double) sumGeno; // ^= sigma^2 * nd^2
      factor = sum_pi_qi = sum_P - 0.5 * total;
      //printf("f = %f %f %f\n", factor, sum_P, total);
        if (!centred) factor /= nSq;
    } else factor = nSq;
    
    //    print("sumpq=%10g  %10g; sumGeno=%10g\n", sum_pi_qi, sum_pi_qi * nSq, sumGeno);
    
    //    print("sigma2 = %10g\n", sum_pi_qi);
    //    printf("factor = %f\n", factor);
    
    for (Uint i=0; i<individuals; i++) {
      Uint idx = i * nP1;
      for (Uint j=i; j<individuals; j++) {
	ans[i + j * individuals] = (ans[idx++] /= factor);
      }
    }
    
    FREE(sums);
  }
  return sum_pi_qi /nSq ;
}

  
void  DoCentering(SEXP Ans, Uint individuals, Ulong sumGeno) {
  double
    sum_pi_qi = DoCentering(REAL(Ans), individuals,
			    GLOBAL.relationship.centered == True,
			    GLOBAL.relationship.normalized == True,
			    sumGeno);

  if (GLOBAL.relationship.returnsigma) {
    setAttrib(Ans, install("sigma2"),  ScalarReal(sum_pi_qi));
  }
  
}
  
  

SEXP do_centering_etc(SEXP SNPxIndiv, SEXP Ans) {
  Uint
    *info = GetInfo(SNPxIndiv),
    individuals = info[INDIVIDUALS];
  bool centered = GLOBAL.relationship.centered == True,
    normalized = GLOBAL.relationship.centered == True;
  
  DoCentering(REAL(Ans), individuals, centered, normalized, SumGeno(info));
  
  return Ans;
}




#define UPDATE								\
  if (isSNPxInd) {							\
    Uint jj, rP1 = r + 1;						\
    if (rP1 % nrow_matrix == 0) {					\
      /* always delivering matrix as snps x individuals */		\
      coding_main(matrix, 0, individuals, rP1-codesperblock, rP1,	\
		  nrow_matrix,  Ans, dG);				\
      rowidx = -plusrow;						\
      for (jj=0; jj<matrix_size; matrix[jj++] = 0);			\
    }									\
  } else {								\
    Uint jj;								\
    coding_main(matrix, r, r + 1, 0, snps, nrow_matrix, Ans, dG);	\
    rowidx = -plusrow;							\
    for (jj=0; jj<matrix_size; matrix[jj++] = 0);			\
  }


#define CLOSE								\
  if (isSNPxInd) {							\
    Uint remainder = r % nrow_matrix;					\
    if (remainder != 0) {						\
      coding_main(matrix, 0, individuals, (Uint)(r - remainder), r,	\
		  nrow_matrix,  Ans, dG);				\
    }									\
  } /* KEIN else  */							\
									\
  fclose(fp);								\
  FREE(matrix);								\
  if (PL > 1) { PRINTF("data have been read.");				\
    if (!true) {							\
      Uint j0,k0,z0=0;							\
      for (k0=0; k0<individuals; k0++) {				\
	for(j0=0; j0<units; j0++) {					\
	  PRINTF("%lu ", (Ulong) INTEGER(Ans)[z0++]);	\
	}								\
	PRINTF("\n");							\
      }									\
    }									\
  }									
  

SEXP file_binary_intern(char *file, 
			char *coding, Uint header, bool isSNPxInd, 
			bool doubledindividuals,
			// output
			Uint individuals,
			Uint snps,
			Uint codesperblock,
			Uint units,
			coding_start_t coding_start,
			coding_main_t coding_main,
			SEXP G
			) {
  // for plinkbinary files

  char ch, 
    //   A = coding[0],
    B = coding[1],
    C = coding[2]
    //  NA = coding[3],
    //  SEP = coding[4]
    ;
  bool
    haplo = B == C;

  if (haplo) ERR("haplo not recognized for binary files");
   
  FILE *fp;
  Uint j, nrow_matrix, ncol_matrix, perbyte,
    *matrix, // snps x individuals
    rows, // rowsM1, 
    cols,  r, l, i, idx,
    plusrow, rowidx, hr, hc, haplorow, haplocol;
  
  if (snps <= 0 || individuals <= 0 || snps <= individuals) {
    char msg[200];
    SPRINTF(msg, "matrix is supposed to be a '%.20s' x '%.20s' matrix with %d individuals and %d SNPs, which looks odd.\n", 
	    isSNPxInd ? "SNPs" : "individuals",
	    isSNPxInd ? "individuals" : "SNPs",
	    individuals, snps);
    if (snps > 0 && individuals > 0) { warn(msg) } else ERR(msg);
  }
  
  if (isSNPxInd) {
    plusrow = 1;
    nrow_matrix = codesperblock; 
    rows = snps;
    cols = ncol_matrix = individuals;
  } else {
    // plusrow = snps;
    plusrow = codesperblock;
    rows = individuals;
    cols = ncol_matrix = snps;
    nrow_matrix = 1;
  }
  if (haplo) {
    if (isSNPxInd xor !doubledindividuals) {
      haplocol = 2;
      haplorow = 1;
    } else {
      haplocol = 1;
      haplorow = 2;    
    } 
  } else {
    haplocol = haplorow = 1;
  }

  SEXP Ans = coding_start(individuals, snps, G);
  Uint matrix_size = nrow_matrix * (ncol_matrix + 3);
  Ulong sumgeno = 0;
  double *dG = NULL;
  if (length(G) > 0) dG = REAL(G);

  if ((matrix = (Uint*) CALLOC(matrix_size, sizeof(Uint))) == NULL)
    ERR("memory space could not be acquired");
  cols = (Uint) CEIL(0.25 * cols);
  perbyte = 4 / haplocol;
  char twobitpattern = 3;

  //   printf("plusrow %d %d , %d %d c=%d %d haplorow/col %d %d\n", plusrow, nrow_matrix, individuals, haplo, cols, isSNPxInd, haplorow, haplocol);  //assert(false);

  if ((fp = fopen(file, "r")) == NULL)  {
    ERR1("file '%.50s' could not be opened", file);
  }
  for (i=0; i<header; i++) fgetc(fp);

  for (rowidx=r=0; r<rows; r++, rowidx+=plusrow) { // number of (multiple) rows 
    for (hr=0; hr<haplorow; hr++) { 
      // genuine loop only if haplo types are given rowwise
      idx = rowidx;

      //     printf("\n"); //assert(r < 10);

      for (l=0; l<cols; l++) { // number of (multiple cols 
	Uint k = 0;
	ch = fgetc(fp);
	for (j = 0; j < perbyte; j++, idx+=nrow_matrix) {
	  for (hc=0; hc<haplocol; hc++, k+=2) {
	    char value = (ch >> k) & twobitpattern;
	    //	  for (hc=0; hc<haplocol; hc++, ch >>= 2) {
	    // char value = ch & twobitpattern;
	    // genuine loop only if haplo types are given column wise
	    //  printf("%d", value==3 ? 2 : value==2 ? 1 : value == 0 ? 0 : value);

	    if (value != 0) { // == 0
	      // print("idx=%d %d (%d %d) %d\n", idx, matrix_size,  nrow_matrix, ncol_matrix, r);
	      assert(idx <= matrix_size);
	      if (value == 2) {
		matrix[idx]++;
		sumgeno++;
	      } else if (value == 3) {
		matrix[idx] += 2;
		sumgeno += 2;
	      } else if (value == 1) ERR("missing value detected.")
	      else {
		ERR8("unknown character detected (>%c<). Note that missings are not allowed here.\n Debugging information: row=%d of %d rows, col=%d of %d columns; plus=%d; current haplocol=%d of %d\n", ch, r, rows, l, cols, nrow_matrix, hc, haplocol);
	      }
	    //assert(matrix[idx] <=2);
	    } // ch != A
	  } //hc
	} // j
      } // cols l
    } // hr

    UPDATE;    

  } // rows r
   
  CLOSE;

  Uint *info = GetInfo(Ans);						
  StoreSumGeno(sumgeno);			       

  return Ans;
}




SEXP file_coding_intern(SEXP file,
			coding_start_t coding_start,
			coding_main_t coding_main,
			int codesperblock,
			SEXP G) {

  Uint *info = GetInfo(file);
			
  int
    header = info[HEADER];
  Uint
    leadingcols = info[LEADINGCOL],
    isSNPxInd = info[SNPxIND],
    snps = info[SNPS],
    individuals = info[INDIVIDUALS],
    unitsPerIndiv = info[MEMinUNITS] / individuals,
    units = unitsPerIndiv,
    doubledindividuals = info[DOUBLEINDIV];
  info[CODESPERBLOCK] = codesperblock;

  // printf("individuals = %d doubledindiv=%d\n", individuals, doubledindividuals);
 
  char *coding = (char*) CHAR(STRING_ELT(getAttrib(file, Coding), 0));
  char *filename = (char*) CHAR(STRING_ELT(file, 0));

  if (header < 0) {
    // only for plinkbinary: snps & individuals already known
    return file_binary_intern(filename, coding,
			      -header, isSNPxInd, doubledindividuals,
			      individuals,
			      snps, codesperblock, unitsPerIndiv,
		       // output
			      coding_start, coding_main, G
			      );
  } // else snps not known yet:

  // BEAGLE 3 
  // beides: ani x snps und snps x individ
  // A B A B ?
  // ? als voraussetzung nicht vorhanden
  // 1 header-Zeile
  // 2 erste Spalten weg
  //
  // plink: kein header
  // 4 spalten, die nicht brauchen
  char ch, oldch,
    A = coding[0],
    B = coding[1],
    C = coding[2],
    NA = coding[3],
    SEP = coding[4]
    ;
  bool 
    haplo = B == C;

  // printf("%.50s|\n", *coding);  assert(!haplo);
   
  FILE *fp;
  Uint nrow_matrix, ncol_matrix,
    *matrix = NULL, // snps x individuals
    rows, // rowsM1, 
    cols, colsM1,
    plusrow,  haplorow, haplocol;
  Ulong sumgeno = 0;
  if ((fp = fopen(filename, "r")) == NULL) {
    ERR1("file '%.50s' could not be opened", filename);
  }

  // determine number of rows and columns
  for (int i=0; i<header; i++) while (fgetc(fp) != EOL);

  // determine size of matrix:
  rows = 1;
  cols = 0;
  oldch = SEP;
  while ((ch  = fgetc(fp)) != EOL) {  
    if (ch == SEP && oldch != SEP) cols++;
    oldch = ch;
  }
  if (oldch != SEP) cols++;
  cols -= leadingcols;

  while ((ch  = fgetc(fp)) != EOF) { 
    if (ch == EOL) rows++;
    oldch = ch;
  }
  if (oldch != EOL) rows++;
  fclose(fp);

  // printf("isSNPxI=%d %d %d %d\n", isSNPxInd, cols, haplo, doubledindividuals);
  
  if (isSNPxInd) {
    individuals = cols;  
    snps = rows;
  } else {  
    individuals =  rows;
    snps = cols;    
  }
  
  if (haplo) {
    if (doubledindividuals) {
      Uint dummy = individuals / 2; 
      if (dummy * 2 != individuals) ERR("odd number of values (individuals)");
      individuals = dummy;
    } else {
      Uint dummy = snps / 2; 
      if (dummy * 2 != snps) ERR("odd number of values (SNPs)");
      snps = dummy;
    }
  }

  info[INDIVIDUALS] = individuals;
  info[SNPS] = snps;
 
  if (snps <= 0 || individuals <= 0 || snps <= individuals) {
    char msg[200];
    SPRINTF(msg, "matrix is supposed to be a '%.20s' x '%.20s' matrix with %d individuals and %d SNPs, which looks odd.\n", 
	    isSNPxInd ? "SNPs" : "individuals",
	    isSNPxInd ? "individuals" : "SNPs",
	    individuals, snps);
    if (snps > 0 && individuals > 0) { warn(msg) } else ERR(msg);
  }

  colsM1 = cols - 1;
  //rowsM1 = rows - 1;

  // read in table
  
  if (isSNPxInd) {
    plusrow = 1;
    nrow_matrix = codesperblock; 
    ncol_matrix = individuals;
  } else {
    // plusrow = snps;
    plusrow = codesperblock;
    ncol_matrix = snps;
    nrow_matrix = 1;
  }
  if (haplo) {
    if (isSNPxInd xor !doubledindividuals) {
      haplocol = 2;
      haplorow = 1;
    } else {
      haplocol = 1;
      haplorow = 2;    
    } 
  } else {
    haplocol = haplorow = 1;
  }

  // now, code matrix
  SEXP Ans = coding_start(individuals, snps, G);
  Uint matrix_size = nrow_matrix * ncol_matrix;
  if ((matrix = (Uint*) CALLOC(matrix_size, sizeof(Uint))) == NULL)
    ERR("memory space could not be acquired");
   double *dG = NULL;
  if (length(G) > 0) dG = REAL(G);

  rows /= haplorow;
  cols /= haplocol;

  //   printf("plusrow %d %d, %d %d c=%d %d haplorow/col %d %d\n", plusrow, nrow_matrix, individuals, haplo, cols, isSNPxInd, haplorow, haplocol);  //assert(false);
 
  fp = fopen(filename, "r");

  // jump header lines
  for (int i=0; i<header; i++) while ((ch=fgetc(fp)) != EOL);

  Uint r=0;
  for (Uint rowidx=0; r<rows; r++, rowidx+=plusrow) {//# of (multiple) rows
    for (Uint hr=0; hr<haplorow; hr++) { 
      // genuine loop only if haplo types are given rowwise
      Uint idx = rowidx;

      //   printf("0\n"); //assert(r < 10);
      
      // jump unnecessary leading stuff
      while ((ch = fgetc(fp)) == SEP);
      for (Uint l=0; l<leadingcols; l++) {
	while ((ch=fgetc(fp)) != SEP && ch!=EOF);
	if (ch == EOF) ERR("unexpected end of file");
	while ((ch = fgetc(fp)) == SEP);
      }

      for (Uint l=0; l<cols; l++, idx+=nrow_matrix) { // # of (multiple cols 
	for (Uint hc=0; hc<haplocol; hc++) {
	  // genuine loop only if haplo types are given column wise
	  
	  if (ch != A) { // == 0
	    //  if (idx>=nrow_matrix * ncol_matrix) 
	    // print("idx=%d %d, nrow_matrix=%d\n", idx, nrow_matrix * ncol_matrix, nrow_matrix);
	    if (ch == B) {
	      matrix[idx]++;
	      sumgeno++;
	    } else if (ch == C) {
	      matrix[idx] += 2;
	      sumgeno +=2;
	    } else if (ch == NA) ERR("missing value detected.")
	    else {
	      PRINTF(">%c< row=%d of %d rows, col=%d of %d columns; plus=%d hc=%d haplocol=%d\n", ch, r, rows, l, cols, nrow_matrix, hc, haplocol);
	      ERR("Unknown character detected. Note that missings are not allowed here.");
	    }
	    //assert(matrix[idx] <=2);
	  } 
	  if (l<colsM1 || hc!=haplocol-1)
	    while((ch = fgetc(fp)) == SEP); // printf("%c", ch);
	}
	
	//print("%d", matrix[idx]);
      } // cols l
      
      // search for end of line
      if (ch != EOL && ch != EOF) while ((ch=fgetc(fp)) != EOL && ch!=EOF);
    } // hr
   
    UPDATE;
    
    // printf("\n");
  } // rows r
  
  CLOSE;

  StoreSumGeno(sumgeno);			       

  return Ans;
}


  

SEXP matrix_mult(SEXP SNPxIndiv) {
  snpcoding method = (snpcoding) MethodOf(SNPxIndiv);

  SEXP Ans = R_NilValue;
  switch (method) {
  case Shuffle : Ans =  matrixshuffle_mult(SNPxIndiv); break;
  case TwoBit : Ans = matrix2_mult(SNPxIndiv); break;
  case ThreeBit : Ans = matrix3_mult(SNPxIndiv); break;
    
  case Hamming2 :
  case Hamming3 :Ans = matrixH_mult(SNPxIndiv);
    
  case NoSNPcoding:// in R abgesichert
  case AutoCoding :
  case Haplo : BUG;
      
  default : BUG;
  }

  Uint
    *info = GetInfo(SNPxIndiv),
    individuals = info[INDIVIDUALS];
  DoCentering(Ans, individuals, SumGeno(info));
  return Ans;
}



SEXP matrix_get(SEXP SNPxIndiv) {
  snpcoding method = (snpcoding) MethodOf(SNPxIndiv);
  switch (method) {
  case Shuffle : return matrixshuffle_get(SNPxIndiv);
    
  case TwoBit :return get_matrix2(SNPxIndiv);
  case ThreeBit : return get_matrix3(SNPxIndiv);
    
  case Hamming2 :
  case Hamming3 :return matrixH_get(SNPxIndiv);
    
  case NoSNPcoding: return matrixplain_get(SNPxIndiv);
    
  case AutoCoding :
  case Haplo : BUG;
      
  default : BUG;
  }
}



SEXP file_get(SEXP file) {
  switch (GLOBAL.relationship.method) {
  case TwoBit : return file_coding_intern(file, matrix_coding_start2,
					  matrix_coding2, CodesPerBlock2(),
					  R_NilValue);
  case ThreeBit : return file_coding_intern(file, matrix_coding_start3,
					    matrix_coding3, CodesPerBlock3(),
					    R_NilValue);
  case Shuffle :  return file_coding_intern(file, matrix_start_shuffle,
					    matrix_shuffle,
					    CodesPerBlockShuffle(), R_NilValue);
  case Hamming2 :
  case Hamming3 : return file_coding_intern(file, matrix_startH, matrixH,
					    CodesPerBlockH(), R_NilValue);
  case NoSNPcoding: return file_coding_intern(file, matrix_start_plain,
					      matrix_plain,
					      CodesPerBlockPlain(), R_NilValue);

  case AutoCoding :// in R abgesichert
  case Haplo : BUG;    
    
  default : BUG;
    
  }
}


static Uint code_oldSNP = 0,
  code_oldIndiv = 0;
SEXP matrix_coding(SEXP M) {
  snpcoding method = (snpcoding) GLOBAL.relationship.method;
  if (length(M) == 0) ERR("'M' has length 0.");
  SEXP Code;
  Uint
    what,
    snps,
    indiv;
  if (isMatrix(M)) {
    snps = nrows(M);
    indiv = ncols(M);
    if (snps < indiv && PL > 0) {
      if (code_oldSNP != snps || code_oldIndiv != indiv) {
	PRINTF("less SNPS than indiv: are you sure you have given an snp x individual matrix?\n");
      }
      code_oldSNP = snps;
      code_oldIndiv = indiv;
    }
  } else {
    snps = length(M);
    indiv = 1;
  }

  if (PRESERVE) ERR("if 'dolocking' then implicite coding is impossible.");

  
  ToInt(M);
    
  switch (method) {
  case Shuffle : Code =  matrix_coding_shuffle(Mint, snps, indiv); break;

  case TwoBit :
  case ThreeBit : Code = matrix_coding23(Mint, snps, indiv); break;
 
  case Hamming2 :
  case Hamming3 : Code = matrix_codingH(Mint, snps, indiv); break;

  case NoSNPcoding: Code =  matrix_coding_plain(Mint, snps, indiv); break;

  case AutoCoding : // in R abgesichert
  case Haplo : BUG;
     
  default : BUG;
  }

  Ulong sumgeno = 0,
    endfor = snps * indiv;
  for (Ulong i=0; i<endfor; i++) sumgeno += (Ulong) Mint[i];

  Uint *info = GetInfo(Code);
  StoreSumGeno(sumgeno);


  FREEint(M);
  
  if (PRESERVE) R_PreserveObject(Code);
  return Code;
}



SEXP createSNPmatrix(Uint snps, Uint individuals) {  
  SEXP Code;
  snpcoding method = (snpcoding) GLOBAL.relationship.method;
  if (method == AutoCoding) method = getAutoCodingIntern();
  switch(method) {
  case Shuffle : Code = create_codevector(snps, individuals);
    break;

  case TwoBit : Code = matrix_coding_start2(individuals, snps, R_NilValue);
    break;
    
  case ThreeBit : Code = matrix_coding_start3(individuals, snps, R_NilValue);
    break;
 
  case Hamming2 :
  case Hamming3 : Code = matrix_startH(individuals, snps, R_NilValue);
    break;

  case NoSNPcoding: Code = matrix_start_plain(individuals, snps, R_NilValue);
    break;
    
  case AutoCoding :    
  case Haplo : BUG;
     
  default :  BUG;
  }

  if (PRESERVE) R_PreserveObject(Code);
  return Code;
}


SEXP createSNPmatrix(SEXP SNPs, SEXP Individuals) {
  Uint 
    n = Int0(Individuals),
    snps = Int0(SNPs);
  return createSNPmatrix(snps, n);
}

SEXP copyGeno(SEXP CM) {
  Uint
    *info = GetInfo(CM),
    snps = info[SNPS],
    individuals = info[INDIVIDUALS],
    what = info[WHAT];
  if (what != GENOMATRIX) ERR("not a geno matrix");
  snpcoding method = (snpcoding) MethodOf(CM);
  if (method != GLOBAL.relationship.method) {
    ERR("currently set RFoption 'snpcoding' does not match the saved method");
  }
  
  SEXP Code = createSNPmatrix(snps, individuals);
  
  Uint *from, *to,
    *info2 = GetInfo(Code),
    lag1 = (uintptr_t) Code - info2[ALIGNADDR],
    lag2 = (uintptr_t) CM - info[ALIGNADDR];

  switch(method) {
  case Shuffle :
    from = AlignShuffle(CM, ALIGN_HAPLO, snps);
    to = AlignShuffle(Code, ALIGN_HAPLO, snps);       
    break;
    
  case TwoBit : 
    from = Align2(CM, ALIGN_HAPLO, snps);
    to = Align2(Code, ALIGN_HAPLO, snps);       
    break;
    
  case ThreeBit :
    from = Align3(CM, ALIGN_HAPLO, snps);
    to = Align3(Code, ALIGN_HAPLO, snps);       
    break;
    
  case Hamming2 :
  case Hamming3 :
    from = AlignH(CM, ALIGN_HAPLO, snps);
    to = AlignH(Code, ALIGN_HAPLO, snps);       
    break;
    
  case NoSNPcoding:
    from = AlignPlain(CM, ALIGN_HAPLO, snps);
    to = AlignPlain(Code, ALIGN_HAPLO, snps);       
    break;
  
    
  case AutoCoding :
  case Haplo : BUG;
     
  default :
    ERR("Method is unknown!")
  }
  
  if (info[MEMinUNITS] != info2[MEMinUNITS]) BUG;
  if (lag1 > 100) ERR("Algnment problem -- pls contact maintainer.");
  if (lag1 != lag2) ERR("Memory was disclocated. Copying is not possible.");
  if ((uintptr_t) from != info[ALIGNADDR] || (uintptr_t) to != info2[ALIGNADDR])
    ERR("Alignment problems. Pls contact maintainer.");
  
  MEMCOPY(to, from, info[MEMinUNITS] * BytesPerUnit);
  return Code;
}



#define DotBlockSize 100 // arbitrary number


SEXP file_dot_start(Uint individuals, Uint snps, SEXP G) {
  SEXP MTdot;
  if ((Uint) length(G) !=  individuals)
    ERR("vector must have length equal to number of individuals");
  if (PL > 1) {PRINTF("Data: %d individuals and %d SNPs\n", individuals, snps);}
  PROTECT(MTdot=allocVector(REALSXP, snps));
  for (Uint i=0; i<snps; REAL(MTdot)[i++] = 0.0);
  UNPROTECT(1);
  return MTdot;
}

void file_dot_do(Uint *M, Uint start_individual, Uint end_individual, 
		 Uint start_snp, Uint end_snp, Uint Mnrow,
		 SEXP Ans, double *G) {
  double *Fdot = REAL(Ans);
  for (Uint a=start_individual; a<end_individual; a++) {
    Uint *pM = M + (a - start_individual) * Mnrow;
    double dummy = G[a];
    for (Uint s=start_snp; s<end_snp; pM++) {
      Fdot[s++] += dummy * (double) *pM;
    }
  }
}

SEXP file_dot(SEXP file, SEXP G) {
  return file_coding_intern(file, file_dot_start, file_dot_do,
			    DotBlockSize, G);
  
  /*
  usrBoolean centered = GLOBAL.relationship.centered;
  if (centered != False) {
    double *mtdot = REAL(MTdot),
      *centered = GLOBAL.relationship.pcentered,
      g = REAL(G),
      sumg = 0.0;
    Uint individuals = length(G),
      snps = length(MTdot),
      len = GLOBAL.relationship.ncentered;
    if (snps != len) ERR("length of 'centered' must equal the number of SNPs.");
    if (GLOBAL.relationship.centered == Nan) 
      for (Uint i=0; i<individuals; i++) sumg += centered[i] * g[i];
    else {
      double *p = 
    }
      
    for (Uint i=0; i<snps; i++) mtdot[i] -= sumg;
  }
  */
  
  // return Ans;
}


SEXP  dot_file_start(Uint individuals, Uint snps, SEXP G) {
  SEXP Ans;
  if ((Uint) length(G) != snps) ERR("vector must have length equal to number of snps");
  if (PL > 1) {PRINTF("Data: %d individuals and %d SNPs\n", individuals, snps);}
  PROTECT(Ans=allocVector(REALSXP, individuals));
  for (Uint i=0; i<individuals; REAL(Ans)[i++] = 0.0);
  UNPROTECT(1);
  return Ans;
}


void dot_file_do(Uint *M, Uint start_individual, Uint end_individual, 
		 Uint start_snp, Uint end_snp, Uint Mnrow,
		 SEXP Ans, double *G) {
  double *dotF = REAL(Ans);
  for (Uint a=start_individual; a<end_individual; a++) {
    Uint *pM = M + (a - start_individual) * Mnrow;
    double dummy = 0;
    for (Uint s=start_snp; s<end_snp; pM++) {
      dummy += G[s++] * (double) *pM;
    }
    dotF[a] = dummy;
  }
}


SEXP dot_file(SEXP file, SEXP G) {
  return file_coding_intern(file, dot_file_start, dot_file_do,
			    DotBlockSize, G);
}



SEXP substract_centered(SEXP SnpXindiv) {
  Uint indiv = ncols(SnpXindiv),
    snps = nrows(SnpXindiv),
    len = GLOBAL.relationship.ncentered;
  double 
    *centered = GLOBAL.relationship.pcentered;
  assert(centered != NULL && GLOBAL.relationship.centered==Nan);
  if (snps != len) ERR("length of 'centered' must equal the number of SNPs.");
  SEXP Ans;
  PROTECT(Ans = allocMatrix(REALSXP, snps, indiv));
  double *ans = REAL(Ans),
    *snpXindiv = REAL(SnpXindiv);
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(CORES)
#endif
  for (Uint i=0; i<indiv; i++) {
    int i_snps = i * snps;
    double *s = snpXindiv + i_snps,
      *a = ans + i_snps;
    for (Uint j=0; j<snps; j++) a[j] = s[j] - centered[j];
  }
  UNPROTECT(1);
  return Ans;
}



SEXP getRelmatrixIndividuals(SEXP Z, SEXP SNPxIndiv) {  
  Uint
    *info = GetInfo(SNPxIndiv),
    *zz = (Uint*) INTEGER(Z),
    individuals = info[INDIVIDUALS];
  SEXP Ans;
  PROTECT(Ans=allocMatrix(REALSXP, individuals, individuals));
  double
    *ans = REAL(Ans);
  
  for (Uint c=0; c<individuals; c++) {
    for (Uint r=c; r<individuals; r++) {
      ans[r * individuals + c] = ans[r + individuals * c] =(double) *(zz++);
    }
  }

  UNPROTECT(1);
  return do_centering_etc(SNPxIndiv, Ans);
}

/*
SEXP getRelmatrixSNP(SEXP Z, SEXP SNPxIndiv) {
  if (TYPEOF(Z) != VECSXP) ERR("unknown type in 'getmatrixSNP'");
  SEXP Ans;
  Uint
    *info = GetInfo(SNPxIndiv),
    individuals = info[INDIVIDUALS],
    isq = individuals * individuals,
    len = length(Z);
  PROTECT(Ans=allocMatrix(REALSXP, individuals, individuals));
  double
    *ans = REAL(Ans);
   
  for (Uint i=0; i<isq; ans[i++] = 0.0);
  for (Uint i=0; i<len; i++) {
    double *e = REAL(VECTOR_ELT(Z, i));
    for (Uint r=0; r<isq; r++) ans[r] += e[r];
  }
  UNPROTECT(1);
  return do_centering_etc(SNPxIndiv, Ans);
}
*/



bool do_warn_change = true, do_warn_changeOK = true;

int *Memory[ALIGN_LAST + 1] = { NULL };
Uint nMem[ALIGN_LAST + 1] = { 0 };

Uint *AlignBase(SEXP CM, Uint nr, Uint bytesperblock, Uint blocks) {
  Uint *info = GetInfo(CM);

  // printf("info=%d BPC=%d  bpb=%d block=%d\n", info[BYTESPERBLOCK], info[BITSPERCODE], bytesperblock, blocks);
  
  if (info[BYTESPERBLOCK] != bytesperblock)
    ERR("currently, data exchange between different kinds of machines (AVX2/SSE) is not possible");
  uintptr_t address = (uintptr_t) INTEGER(CM);
  Uint *algnaddress = (Uint *) algn_general(INTEGER(CM), bytesperblock);
  //printf("align = %lu %u %u\n", (uintptr_t) algnaddress, 0, info[ALIGNADDR]);
  addr_Uint au;
  for (Uint i=0; i<sizeof(uintptr_t) / BytesPerUnit; i++)
    au.u[i] = info[ADDR0 + i];
  if (au.a == address) {
    assert((uintptr_t) algnaddress % bytesperblock == 0);
    return algnaddress;
  } else if (au.a % BytesPerUnit == address % BytesPerUnit) {
#ifdef SCHLATHERS_MACHINE
    if (do_warn_changeOK) {
      PRINTF("Address has changed in a coded object (%d) by 'gc' or disk saving. But luckily got same modulus (%lu %lu)).\n", info[WHAT], (uintptr_t) au.a % (1024 * 1024), address % (1024 * 1024));
      do_warn_changeOK = debugging;
    }
#endif    
    assert((uintptr_t) algnaddress % bytesperblock == 0);
    return algnaddress;
  }
  
#ifdef SCHLATHERS_MACHINE
  if (do_warn_change) {
    PRINTF("Address has changed in a coded object (%d) by 'gc' or disk saving\n", info[WHAT]);
    do_warn_change = debugging;
  }
#endif    
  
  if (PRESERVE) ERR("severe error: has 'dolocking' be called in meanwhile? If 'dolocking' has not been called at all or only at the very beginning, please contaact maintainer.");

#ifdef DO_PARALLEL
  if (CORES > 1)
    ERR("Coded SNP matrix has been stored elsewhere or has been internally moved by R; in these cases set 'RFoptions(cores=1)'");
#endif  

  if (au.a % bytesperblock == address % bytesperblock) return algnaddress;
  if (nMem[nr] < info[MEMinUNITS]) {
    FREE(Memory[nr]);
    nMem[nr] = info[MEMinUNITS];
    Memory[nr] = (int*) CALLOC(nMem[nr], BytesPerUnit);
  }
  Uint *algnMem = (Uint *) algn_general(Memory[nr], bytesperblock),
    bytes = blocks * info[INDIVIDUALS] * BytesPerUnit;
   
  assert((uintptr_t) algnMem % bytesperblock == 0);
  assert((uintptr_t)algnMem + bytes < (uintptr_t) Memory[nr] + nMem[nr]);
  assert(bytes < (Uint) length(CM) * BytesPerUnit);
  assert(bytes < nMem[nr] * BytesPerUnit);
  
  MEMCOPY(algnMem, algnaddress, bytes);
  return algnMem;
}


SEXP dolocking(SEXP Do) {
  if (Do != R_NilValue) {
    PRESERVE = LOGICAL(Do)[0];
    if (PRESERVE) BUG;
    for (Uint i=0; i<= ALIGN_LAST; i++) {
      FREE(Memory[i]);
      nMem[i] = 0;
    }
  }

  SEXP Ans;
  PROTECT(Ans = allocVector(LGLSXP, 1));
  LOGICAL(Ans)[0] = PRESERVE;
  UNPROTECT(1);
  return Ans;
}

SEXP unlock(SEXP C) {
  BUG;
  //if (shuffleNotInit) InitShuffle();
  Uint 
    *info = GetInfo(C);
  if ((SEXP) info == R_NilValue) ERR("not a coded object");
  if (PRESERVE) {
#ifdef SCHLATHERS_MACHINE
   PRINTF("unlocking a %.50s at %ld\n", WHAT_NAMES[info[WHAT]],
	  (uintptr_t) INTEGER(C));
#endif  
  } else warning("'unlock' is called although 'dolocking()' has not been called");
  R_ReleaseObject(C);
  return R_NilValue;
}


SEXP Debug() { debugging = true; return R_NilValue; }
SEXP StopDebug() { debugging = false;  return R_NilValue; }


SEXP getAutoCoding() {
  SEXP dummy;
  PROTECT(dummy=allocVector(INTSXP, 1));
  INTEGER(dummy)[0] = GLOBAL.relationship.method = getAutoCodingIntern();
  switch(GLOBAL.relationship.method) {
  case Shuffle : InitShuffle(); break;
  case ThreeBit : Init3(); break;
  default: BUG;
  }    
  UNPROTECT(1);
  return dummy;
}
