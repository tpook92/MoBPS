
/*
 Authors 
 Martin Schlather, schlather@math.uni-mannheim.de


 Copyright (C) 2014 -- 2019  Martin Schlather
Copyright (C) 2014 -- 2015 Florian Skene: SSE2+SSE3

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  
*/

#define BitsPerCode 32L
#define UNCOMPRESSED 1

//#include <stdio.h>
//#include "options.h"
#include "AutoMiraculix.h"
#include "intrinsics.h"
#include <General_utils.h>
// #include "error.h"
#include "haplogeno.h"

INLINER

int CodesPerBlockPlain() { return CodesPerBlock; }

SEXP matrix_start_plain(Uint individuals, Uint snps,
			SEXP VARIABLE_IS_NOT_USED  file) {
  SEXP Code = CreateEmptyCodeVector(snps, individuals, snps * individuals);
  ADDALIGN(Code);
  return Code;
}



void matrix_plain(Uint *M, Uint start_individual, Uint end_individual, 
		  Uint start_snp, Uint end_snp, Uint Mnrow,
		  SEXP Ans, double VARIABLE_IS_NOT_USED *G) {
  Uint
    *info = GetInfo(Ans),
    snps = info[SNPS],
    *ans = (Uint *) INTEGER(Ans);
  for (Uint a=start_individual; a<end_individual; a++) {
    Uint *Mptr = ans + a * snps,
      *pM = M + (a - start_individual) * Mnrow;
    for (Uint s=start_snp; s<end_snp; pM++) {
      Mptr[s++] = *pM;
    }
  }
}



SEXP matrix_coding_plain(Uint *M, Uint snps, Uint individuals){
  SEXP Code = matrix_start_plain(individuals, snps, R_NilValue);
  matrix_plain(M, 0, individuals, 0, snps, snps, Code, NULL);
  return Code;
}

SEXP matrixplain_get(SEXP SNPxIndiv) {
   Uint 
     *info = GetInfo(SNPxIndiv),
     individuals = info[INDIVIDUALS],
     snps = info[SNPS],
     *M = (Uint*) Align(SNPxIndiv, ALIGN_SSE, snps);
   SEXP Ans;
   PROTECT(Ans=allocMatrix(INTSXP, snps, individuals));
   MEMCOPY(INTEGER(Ans), M, snps * individuals * sizeof(Uint));
   UNPROTECT(1);
   return Ans;
}



Uint *AlignPlain(SEXP Code, Uint nr, Uint snps) { return Align(Code, nr, snps); }
