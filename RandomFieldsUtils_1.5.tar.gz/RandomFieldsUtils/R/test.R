testStrassen <- function(A, B, truenrowA=nrow(A), truenrowB=nrow(B)) {
  stopifnot(truenrowA <= nrow(A) && truenrowB <= nrow(B))
  storage.mode(A) <- "integer"
  storage.mode(B) <- "integer"
  .Call(C_testStrassen, A, B, as.integer(truenrowA), as.integer(truenrowB))  
}
