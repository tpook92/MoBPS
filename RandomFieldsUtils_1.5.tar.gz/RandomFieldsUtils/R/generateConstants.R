

clean_name <- function(x) {
##  str(x)
  coll <- paste(strsplit(x, "\t")[[1]], collapse="")
  i <- 1
  while(i <= nchar(coll)) {
##    Print(i, coll, substr(coll, i, i))
    if (substr(coll, i, i) %in% c("\"", "'")) {
      repeat {
	i <- i + 1
	if (substr(coll, i, i) %in% c("\"", "'")) {
	  i <- i + 1
	  break;
	}
      }
    }
    if (substr(coll, i, i) == " ") {
      coll <- paste0(substr(coll, 1, i-1), substr(coll, i+1, nchar(coll)))
    } else i <- i + 1
    ## x <- paste(strsplit(coll, " ")[[1]],  collapse=""); Print(x); xx
   }
##  Print(coll)
  coll
}



clean_value <- function(s) {
  s <- clean_name(s)
  s <- paste(strsplit(s, "\\(int\\)")[[1]],  collapse="");
  if (s == "NA_INTEGER") s <- "as.integer(NA)"
  return(s)
}





CC <- function(x, envir) {
  if (is.numeric(x)) {
    Real <- TRUE
    Integer <- x == as.integer(x)
    y <- x
  } else {
    stopifnot(is.character(x))
    if (substr(x, 1, 1) =='"')  #'"')
	return(x)
    warn <- options()$warn
    options(warn = -1)
    y <- try(as.numeric(eval(parse(text=x), envir=envir)), silent=TRUE)
    options(warn = warn)
    if (Real <- !is(y, "try-error") && !is.na(y)) {
      Integer <- nchar(strsplit(x, "\\.")[[1]][1]) == nchar(x) &&
                 abs(y) <= .Machine$integer.max
##      cat(Integer, "", y,"", .Machine$integer.max, "",abs(y) <= .Machine$integer.max)
    } else Real <- Integer <- FALSE
    y <- paste(strsplit(paste(strsplit(x, "\t")[[1]], collapse=""), " ")[[1]],
               collapse="")
  }
  if (Real) {
    y <- paste("as.", if (Integer) "integer" else "double", "(", y, ")", sep="")
  }
  return(y)
}



kind <- function(Zeilen, i, start, cont="", ignore=" ",
		 endofname=" ", stops=NULL) {
#  print(Zeilen)
 # print(start)
  if (substr(Zeilen[i], 1, nchar(start)) == start) {
   
    s <- substring(Zeilen[i], nchar(start) + 1)
    j <- 2
    while (j <= nchar(s) && substr(s, j, j) != endofname) j <- j + 1
    stopifnot(j <= nchar(s))
    name <- substr(s, 1, j -1)
    u <- strsplit(substring(s, j + 1), "//")[[1]]
    kommentar <- paste(u[-1], collapse = " ")
    RC <- nchar(kommentar) > 0 &&
      nchar(strsplit(kommentar, "RC")[[1]][1]) < nchar(kommentar)
    value <- u <- clean_value(u[1])
    i <- i + 1
    RCX <- NULL
    if (any(cont != "")) {
       repeat {
 	if (i > length(Zeilen) ||
	    (length(stops) > 0 && length(strsplit(u, stops)[[1]]) > 1)) break;
	## cat(i, " >>", Zeilen[i], "<<\n", sep="")
        j <- nchar(u)
	if (ignore != "") while (substr(u, j, j) %in% ignore) {
	  j <- j - 1
	}
	##	print(u);	print(j) ;print(cont)
	##print(c(substr(u, j,j), cont, !(substr(u, j,j) %in% cont) , j))
        if (!(substr(u, j,j) %in% cont) && j > 0) break
	while (Zeilen[i] == "") i <- i + 1
	u <- strsplit(Zeilen[i], "//")[[1]]
	kommentar <- paste(u[-1], collapse = " ")
	u <- u[1]
	RCX <- c(RCX, nchar(kommentar) > 0 &&
		 nchar(strsplit(kommentar, "RC")[[1]][1]) < nchar(kommentar))
 	value <- paste(value, clean_value(u[1]))
 	## cat("u=", u, "\n")
	i <- i + 1
      }
    }
    res <- list(name=name, value=value,
		RC=if (length(RCX) == 0 || all(!RCX)) RC else RCX,
		i=i)
   ## cat("value=", value, "\n\n")
    return(res)
  } else return(NULL)
}


rfGenerateConstants <-
  function(package="RandomFieldsutils", aux.package = "RandomFieldsUtils",
	   RFpath = paste0("~/svn/",package, "/", package),
           RCauto.file = paste(RFpath, "R/aaa_auto.R", sep="/"),
	   header.source =
	   c(if (length(aux.package) > 0) paste0("../../", aux.package,"/",
				 aux.package, "/src/Auto", aux.package, ".h"),
	     paste0("src/Auto",package,".h")),
	   c.source = paste0("src/Auto", package, ".cc")) {
	   
    write(file = RCauto.file,
	  "# This file has been created automatically by 'rfGenerateConstants'")
    envir <- new.env()
    for (s in header.source) {
      write(file = RCauto.file, append = TRUE, paste("\n\n ## from ", s))
      rfGenerateConstantsHeader(RFpath = RFpath, RCauto.file=RCauto.file,
				header.source = s, envir=envir) 
    }

    cat("***********************\n");
    cat("** header files done **\n");
    cat("***********************\n");
   
    for (s in c.source) {
      write(file = RCauto.file, append = TRUE, paste("\n\n ## from ", s))
      rfGenerateConstantsC(package = package,
	RFpath = RFpath, RCauto.file=RCauto.file,
	c.source = s)
      
    }
  }
    
rfGenerateConstantsHeader <- function(RFpath, RCauto.file, header.source,
				      envir) {
  s <- scan(paste(RFpath, header.source, sep="/"),
            what=character(), sep="\n", blank.lines.skip=FALSE, skip=2)
  #if (PL > 1)for (i in 1:length(s)) cat(s[i], "\n")
  i <- 1
  typedef <- character(0) ## nur fuer alte defs a la "typedef int dom_type;"
  while (i <= length(s)) {
    if (!is.null(k <- kind(s, i, start="#define", cont="\\", ignore=""))) {
     ## if (i>130 && i<140)
      value <- clean_value(k$value)
      if (length(typedef) > 0)
        for (j in 1:length(typedef)) {
          value <- paste(strsplit(value, typedef[j])[[1]], collapse=" ")
        }
      v <- clean_name(k$name)
      ##      Print(i,  k, v);     stopifnot(i < 70)
      
      if (v != "") {
	w <- if (k$RC) paste("RC_", v, " <-", sep="") else ""
	line <- paste(w, v , "\t<-", CC(value, envir=envir))
	eval(parse(text=line), envir=envir)
	write(file = RCauto.file, append = TRUE, line)
      }
    } else if (!is.null(k <- kind(s, i, start ="typedef enum",
				  cont=c(",", "{"), ignore=" ", stops=";"))) {
 
      value <- strsplit(clean_value(k$value), "\\{")[[1]]
      
      if (value[1] != "")
	typedef <- c(typedef, paste("\\(", strsplit(value[1], ";")[[1]][1] ,
				    "\\)", sep=""))
 
      value <- strsplit(strsplit(value[2], "\\}")[[1]][1], ",")[[1]]
      
      zaehler <- 0
      for (j in 1:length(value)) {
        v <- clean_value(value[j])
##	Print(v, value)
	if (v != "") {
	  w <- if ((length(k$RC) == 1 && k$RC) || (length(k$RC) > 1) && k$RC[j])
		 paste("RC_", v, " <-", sep="") else ""
	  v <- strsplit(v, "=")[[1]]
	  if (length(v) > 1) {
	    stopifnot(length(v) == 2)
	    nr <- v[2]
	    v <- v[1]
	  } else {
	    nr <- zaehler
	    zaehler <- zaehler + 1
	  }
	  line <- paste(w, v , "\t<-", CC(nr, envir=envir))
	  eval(parse(text=line), envir=envir)
	  write(file = RCauto.file, append = TRUE, line)
	}
      }
      write(file = RCauto.file, append = TRUE, "")
    } else if (!is.null(k <- kind(s, i, start="typedef", cont="\\",
				  ignore="", stops=";"))) {
     if (value[1] != "")
       typedef <- c(typedef,
		    paste("\\(", strsplit(k$value, ";")[[1]][1] ,"\\)", sep=""))
    } else if (!is.null(k <- kind(s, i, start="extern const", cont=",",
				  ignore=" ", stops=";"))) {
      ## ignored
    } else write(file = RCauto.file, append = TRUE, "")
    i <- if (is.null(k)) i+1 else k$i
  }
}
  
rfGenerateConstantsC <- function(RFpath, RCauto.file, c.source, package="none") {
  s <- scan(paste(RFpath, c.source, sep="/"),
            what=character(), sep="\n", blank.lines.skip=FALSE, skip=1)
  i <- 1
  nl <- TRUE
  while (i <= length(s)) {
     if (!is.null(k <- kind(s, i, "  *", c(",", "{"), " ", endofname="[",
			    stops="}"))) {
       ##      Print(k); stopifnot(k$i != 55)
       value <- strsplit((clean_value(k$value)), "\\{")[[1]]
       value <- strsplit(value[2], "\\}")[[1]][1]
       v <- clean_name(k$name)
       if (v != "") {
	 w <- if (k$RC) paste("RC_", v, " <-", sep="") else ""
	 line <- paste(w, v, "<-\nc(", value, ")")
	 write(file = RCauto.file, append = TRUE, line)
	 write(file = RCauto.file, append = TRUE, "")
	 nl <- TRUE
       }
     } else if (nl) {
       write(file = RCauto.file, append = TRUE, "")
       nl <- FALSE
     }
     i <- if (is.null(k)) i+1 else k$i
  }
  
  if (package == "RandomFieldsUtils") {

    define_char <- function(name, value) {
      if (is(value, "try-error")) value <- NULL
      write(file = RCauto.file, append = TRUE,
	    paste("\n", name, " <- c('", sep="",
		  paste(value, collapse="', '"),
		  "')")
	    )
    }
    define_num <- function(name, value) {
      if (is(value, "try-error")) value <- NULL
      write(file = RCauto.file, append = TRUE,
	    paste("\n", name, " <- c(", sep="",
		  paste(value, collapse=", "),
		  ")")
	    )
    }
    
    
    envir <- as.environment("package:RandomFields")
    all <- ls(envir=envir)
    genuine <- all[substr(all, 1, 2) %in% c("iR", "RM", "R.", "RP" ,"RF", "RR")]
 
    define_char("list2RMmodel_Names", genuine) ##, RM_TREND
    define_char("list2RMmodel_oldNames",
		try(RFgetModelNames(newnames=FALSE))) # , RM_INTERNALMIXED

 
    names1 <- c("RMwhittle",
                RFgetModelNames(type=TYPE_NAMES[c(TcfType, PosDefType) + 1],
                                isotropy=ISO_NAMES[ISOTROPIC + 1],
                                operator=FALSE,
                                group.by=NULL,
                                valid.in.dim = 1,#if (sim_only1dim)1 else 2,
                                simpleArguments = TRUE,
                                vdim=1))

    do.not.include <-
      c("RMnugget", # macht kaum sinn
        "RMwendland","RMcardinalsine","RMpoweredexp", # aliase
        "RMparswmX", "RMtent", # convenience models
        "RMconstant", ## macht aerger
        "RMlsfbm", ## nur fuer |x| < 1 definiert
        "RMdagum", ## internal parameter
        "RMgneiting" ## integer parameter
        )
    names1 <- sort(names1[!(names1  %in% do.not.include)])
    define_char("rfgui1_Names", names1)
    

    names2 <- c("RMwhittle",
                RFgetModelNames(type=TYPE_NAMES[c(TcfType, PosDefType) + 1],
                                isotropy=ISO_NAMES[ISOTROPIC + 1],
                                operator=FALSE,
                                group.by=NULL,
                                valid.in.dim = 2,#if (sim_only1dim)1 else 2,
                                simpleArguments = TRUE,
                                vdim=1))
    names2 <- sort(names2[!(names2  %in% do.not.include)])
    define_char("rfgui2_Names", names2)              
  }
 
  return(NULL)
}

