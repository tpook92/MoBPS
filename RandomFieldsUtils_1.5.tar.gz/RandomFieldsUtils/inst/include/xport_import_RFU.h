/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3
 of the License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef RandomFieldsUtilsxport_H
#define RandomFieldsUtilsxport_H 1

typedef
struct KEY_type KEY_type;
struct KEY_type {
  KEY_type *next;
  utilsoption_type global_utils;
  int pid,  visitingpid;
  bool ok, doshow;
  errorstring_type error_location;

  int *ToIntDummy;
  int ToIntN, ToRealN ;
  double *ToRealDummy;

  whittle_work_type whittle;
};
extern KEY_type *PIDKEY[PIDMODULUS];
KEY_type *KEYT();

typedef
struct option_type option_type;
//utilsoption_type *WhichOption(bool local);
void PIDKEY_DELETE();

extern const char *R_TYPE_NAMES[LAST_R_TYPE_NAME + 1];

#endif
