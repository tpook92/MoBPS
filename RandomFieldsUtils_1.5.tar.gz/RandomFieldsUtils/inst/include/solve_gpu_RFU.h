
/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3
 of the License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/


#ifndef RFutils_gpusolve
#define RFutils_gpusolve 1


int cholGPU(bool copy, double *matrix, Uint size, double *B, Uint rhs_cols,
     double *LogDet, double *RESULT);
void mgpuSolve(double *matrix, Uint individuals, double *vector);
void gpu_relmat_custom(Uint*, double*, Uint, Uint);
void gpu_relmat_cublas(Uint*, double*, Uint, Uint);

// #define PADDIM 4L
//#define BLOCKS 1024
#define THREADS_PER_BLOCK 1024 //2048 / 32

#endif
