/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather 

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3
 of the License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/


#if defined MSDOS_WINDOWS
#include <windows.h>
#include <sysinfoapi.h>
#endif

#include "Basic_RFUlocal.h"
#include "extern_RFU.h"
#include "intrinsics.h"


THIS_FILE_ANYSIMD;
EXTERN_SIMD_CHECK(avx2_fctns);
EXTERN_SIMD_CHECK(avx_fctns);
EXTERN_SIMD_CHECK(solve_61);

Uint check_intrinsics() { 
 //  if (BytesPerUnit != sizeof(Uint)) // OK
  //    ERR1("The programme relies on the assumption that an unsigned integer has %u Bytes.", (Uint) BytesPerUnit);// OK
  
  if (sizeof(int) != sizeof(Uint)) // OK
    ERR2("The programme relies on the assumption that a signed integer the same lenth than an unsigned integer. Found %u and %u bytes respectively.",
	 (Uint) sizeof(int),  (Uint) sizeof(Uint));// OK
  
  if (SizeOfDouble != sizeof(double))// OK
    ERR2("The programme relies on the assumption that size of a 'double' is %d. Found %u bytes.", SizeOfDouble, (Uint) sizeof(double));// OK
  
   if (SizeOfInt != sizeof(Uint)) // OK
    ERR2("The programme relies on the assumption that size of a 'int' is %d. Found %u bytes.", SizeOfInt, (Uint) sizeof(Uint));// OK

   if (sizeof(unit_t) != BytesPerUnit) // OK
     ERR2("The programme relies on the assumption that size of 'unit_t' is %d. Found %u bytes.", BytesPerUnit, (Uint) sizeof(unit_t));// OK
 
  Uint maxsize = MaxUnitsPerAddress * BytesPerUnit; // OK
  if (sizeof(void*) > maxsize) // OK
    ERR2("The programme relies on the assumption that an 'void*' has at most %u Bytes. Found %u bytes.", 
	 maxsize, (Uint) sizeof(void*));// OK

  if (!sse)
    RFERROR("programm does not run on machine that old (even not having sse)\n");
 
  CHECK_THIS_FILE_ANYSIMD;
  CHECK_FILE(avx_fctns);
  CHECK_FILE(avx2_fctns);
  CHECK_FILE(solve_61);

  return SIMD_INFO;
}



Uint startRFU() {
  Uint simd_info = check_intrinsics();
  // utilsoption_type *utils = &O PTIONS;
  //  printf("startRFu\n");
  utilsoption_type *utils = WhichOption(false); // OK
  union {
    unsigned short a;  
    unsigned char b[2];
  } ab;
  ab.a = 0xFF00;
  bool bigendian = ab.b[0] != 0;
  assert((__BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__) xor bigendian);
  utils->basic.bigendian = bigendian;
  
  volatile uni64 U64;
  U64.u32[bigendian] = 1954;
  U64.u32[!bigendian] = 0x7ff00000;
  utils->basic.NA = U64.d8[0];
  utils->basic.NaN = 0.0 / 0.0;

#if defined compatibility_to_C_h  
  ownNA = utils->basic.NA;
  ownNaN = utils->basic.NaN;
#endif

  return simd_info;

  /*
#if defined MSDOS_WINDOWS
  //  SYSTEM_INFO sysinfo;
  SYSTEM_INFO sysinfo;
  GetNativeSystemInfo( &sysinfo );
  number_of_cores = sysinfo.dwNumberOfProcessors;
#endif
  */
 

}

