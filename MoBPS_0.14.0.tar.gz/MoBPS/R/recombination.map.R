'#
  Authors
Torsten Pook, torsten.pook@uni-goettingen.de

Copyright (C) 2017 -- 2018  Torsten Pook

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
'#

#' Bestimmung einer Rekombinationsmappe
#'
#' Funktion zur Aufstellung einer Rekombinationsmappe anhand von LD - EXPERIMENTELL!
#' @param data.matrix Datensatz mit allen Haplotypen
#' @param snp.position Position der SNPs auf Genom (population$info$snp.position)
#' @param glaettung Glaettung der LD-Funktion mittels ksmooth
#' @param glaettung.bw Bandbreite im Kerndichteschaetzer (default: 200)
#' @param combinated.position Laenge einer Treppenstufe in Basenpaaren (default: 10)
#' @param caps Minimale/Maximale Rekombinationsrate einer Stufe (default: c(0.3,5))
#' @param plot.recombination.map Setze TRUE um aktuelle Rekombinationsmappe zu plotten
#' @export

recombination.map <- function(data.matrix, snp.position, glaettung=TRUE, glaettung.bw=200, combinated.position=10,caps=c(0.3,5), plot.recombination.map=FALSE){
  n <- nrow(data.matrix)-1
  ld1 <- numeric(n)
  for(index in 1:n){
    ld1[index] <- stats::cor(data.matrix[index,], data.matrix[index+1,])
  }
  if(glaettung){
    ldest <- stats::ksmooth(1:n, abs(ld1), bandwidth = glaettung.bw, x.points=c(0.5:(n+2)))
  }
  ldsum <- numeric((n+2)/combinated.position)
  for(index in 1:((n+2)/combinated.position)){
    ldsum[index] <- mean(ldest$y[1:combinated.position + (index-1) * combinated.position])
  }
  recom.rate <- (1-ldsum)/ldsum
  recom.rate[recom.rate>caps[2]] <- caps[2]
  recom.rate[recom.rate<caps[1]] <- caps[1]
  start.points <- c(0,snp.position[1:(length(ldsum)-1)*combinated.position])
  recombination.map <- cbind(start.points, recom.rate)

  if(plot.recombination.map==TRUE){
    graphics::plot(recombination.map[1:2,1], rep(recombination.map[1,2],2), type="l", xlim=c(0,max(recombination.map[,1])), ylim=c(0, max(recombination.map[,2])))
    for(index in 2:nrow(recombination.map)){
      graphics::lines(recombination.map[index+0:1,1], rep(recombination.map[index,2],2))
    }
  }
  return(recombination.map)
}
