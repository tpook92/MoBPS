'#
  Authors
Torsten Pook, torsten.pook@uni-goettingen.de

Copyright (C) 2017 -- 2018  Torsten Pook

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
'#

inbreeding.vanRaden <- function(population, database=NULL, gen=NULL, diag1=FALSE){
  if(length(gen)>0){
    database <- cbind(rep(gen,each=2), rep(1:2, length(gen)))
  }
  n.animals <- 0
  for(index in 1:nrow(database)){
    n.animals <- n.animals + population$info$size[database[index,1], database[index,2]]
  }
  Z <- array(0,dim=c(n.animals,sum(population$info$snp)))
  cindex <- 1
  size <- cumsum(c(0,as.vector(t(population$info$size))))
  for(index in 1:nrow(database)){
    k.database <- database[index,]
    kn <- length(population$breeding[[k.database[1]]][[k.database[[2]]]])
    for(kindex in 1:kn){
      Z[cindex,] <- population$breeding[[k.database[[1]]]][[k.database[[2]]]][[kindex]][[9]] +  population$breeding[[k.database[[1]]]][[k.database[[2]]]][[kindex]][[10]]
      cindex <- cindex +1
    }
  }
  p_i <- colSums(Z) / 2 / n.animals
  P <- matrix(2*(p_i-0.5), nrow=n.animals, ncol=sum(population$info$snp), byrow=TRUE)
  Zm <- Z-P-1
  A <- Zm %*% t(Zm) / 2 / sum(p_i*(1-p_i))

  if(diag1){
    diag.values <- diag(A)
    mult <- diag(sqrt(1/diag.values))
    A <- mult %*% A %*% mult
  }
  return(A)
}
