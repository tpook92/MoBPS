'#
  Authors
Torsten Pook, torsten.pook@uni-goettingen.de

Copyright (C) 2017 -- 2018  Torsten Pook

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
'#

#' Vergleich der verschiedenen Zuchtwerte
#'
#' Plot zum vergleich der verschiedenen Entwicklungen der realen/beobachteten/geschaetzten Zuchtwerte
#' @param population Populationsliste
#' @param bvrow Betrachteter Zuchtwert
#' @param nr Welche Zuchtwertschaetzung soll betrachtet werden
#' @export

analyse.bve.plot <- function(population, bvrow = 1, nr = 1){
  bve.data <- population$info$bve.data[[nr]]
  y_real <- bve.data[[6]][,bvrow]
  y_hat <- bve.data[[7]][,bvrow]
  y_obs <- bve.data[[8]][,bvrow]

  graphics::par(pch=".", cex.lab=2, cex.axis=1.5)
  graphics::pairs(cbind(y_real,y_hat,y_obs), diag.panel=panel.hist, upper.panel=panel.cor)#,lower.panel=panel.smooth)

}

#' Vergleich der verschiedenen Zuchtwerte (Genbased)
#'
#' Plot zum vergleich der verschiedenen Entwicklungen der realen/beobachteten/geschaetzten Zuchtwerte
#' @param population Populationsliste
#' @param bvrow Betrachteter Zuchtwert
#' @param gen Welche Zuchtwertschaetzung soll betrachtet werden
#' @export
analyse.bve.plot_gen <- function(population, bvrow = 1, gen = 1){
  y_real <- population$breeding[[gen]][[7]][bvrow,]
  y_hat <- population$breeding[[gen]][[3]][bvrow,]
  y_obs <- population$breeding[[gen]][[9]][bvrow,]

  graphics::par(pch=".", cex.lab=2, cex.axis=1.5)
  graphics::pairs(cbind(y_real,y_hat,y_obs), diag.panel=panel.hist,upper.panel=panel.cor)#, lower.panel=panel.smooth)

}

#' Vergleich der verschiedenen Zuchtwerte (Genbased)
#'
#' Plot zum vergleich der verschiedenen Entwicklungen der realen/beobachteten/geschaetzten Zuchtwerte
#' @param population Populationsliste
#' @param bvrow Betrachteter Zuchtwert
#' @export
analyse.bve.plot_gen1 <- function(population, bvrow = 1){
  cor <- numeric(length(population$breeding))
  for(gen in 1:length(population$breeding)){
    y_real <- population$breeding[[gen]][[7]][bvrow,]
    y_hat <- population$breeding[[gen]][[3]][bvrow,]
    y_obs <- population$breeding[[gen]][[9]][bvrow,]

    cor[gen] <- stats::cor(y_real, y_hat)
  }

  return(cor)
}

