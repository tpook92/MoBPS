'#
  Authors
Torsten Pook, torsten.pook@uni-goettingen.de

Copyright (C) 2017 -- 2018  Torsten Pook

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
'#

#' Betrachte Zuchtwerte
#'
#' Funktion zum schnellen Ueberblick ueber alle Zuchtwerte
#' @param population Populationsliste
#' @param gen Relevante Generation (default: 1)
#' @param print Nutze printfunktion zur Ausgabe
#' @param bvrow Betrachteter Zuchtwert (default: 1)
#' @export

watchbv <- function(population, gen=1, print=TRUE,bvrow=1){
  if(print==TRUE){
    print(c("Realer ZW", mean(c(population$breeding[[gen]][[7]][bvrow,], population$breeding[[gen]][[8]][bvrow,]))))
    print(population$breeding[[gen]][[7]][bvrow,])
    print(population$breeding[[gen]][[8]][bvrow,])
    print(c("ZW - Schaetzung", mean(c(population$breeding[[gen]][[3]][bvrow,], population$breeding[[gen]][[4]][bvrow,]))))
    print(population$breeding[[gen]][[3]][bvrow,])
    print(population$breeding[[gen]][[4]][bvrow,])
    print(c("Beobachteter ZW", mean(c(population$breeding[[gen]][[9]][bvrow,], population$breeding[[gen]][[10]][bvrow,]))))
    print(population$breeding[[gen]][[9]][bvrow,])
    print(population$breeding[[gen]][[10]][bvrow,])
  }


  m <- rbind(population$breeding[[gen]][[7]][bvrow,],population$breeding[[gen]][[8]][bvrow,], population$breeding[[gen]][[3]][bvrow,],
             population$breeding[[gen]][[4]][bvrow,], population$breeding[[gen]][[9]][bvrow,],population$breeding[[gen]][[10]][bvrow,])
}
