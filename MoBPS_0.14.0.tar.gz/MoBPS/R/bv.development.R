'#
  Authors
Torsten Pook, torsten.pook@uni-goettingen.de

Copyright (C) 2017 -- 2018  Torsten Pook

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
'#

#' Entwicklung der verschiedenen Zuchtwerte
#'
#' Plot zur Entwicklung der realen/beobachteten/geschaetzten Zuchtwerte
#' @param population Populationsliste
#' @param include.sex Zu berucksichtigende Geschlechter (default: c(1,2) [m-1 w-2])
#' @param confidence Berechne Konfidenzintervall fuer (default: c(1,2,3) [1- reale, 2- beobachtete, 3- geschaetze ZW])
#' @param quantile Quantile der Konfidenzintervalle (default: 0.05)
#' @param exclude_o Vernachlaessige die letzten x- Generation fuer beobachtete ZW (default: 1)
#' @param exclude_s Vernachlaessige die letzten x- Generation fuer geschaetzte ZW (default: 2)
#' @param bvrow Betrachteter Zuchtwert (default: 1)
#' @export

bv.development <- function(population, include.sex=c(1,2), confidence=c(1,2,3), quantile=0.05, exclude_o=1, exclude_s=2, bvrow=1){
  gen <- length(population$breeding)
  real_bv <- numeric(gen)
  ob_bv <- numeric(gen)
  schaetz_bv <- numeric(gen)
  real_bv_s<- numeric(gen)
  ob_bv_s<- numeric(gen)
  schaetz_bv_s <- numeric(gen)

  for(index in 1:gen){
    bv_data <- watchbv(population, gen=index, print=FALSE,bvrow=bvrow)
    real_bv[index] <- mean(bv_data[include.sex,])
    real_bv_s[index] <- stats::sd(bv_data[include.sex,])
    ob_bv[index] <- mean(bv_data[include.sex+4,])
    ob_bv_s[index] <- stats::sd(bv_data[include.sex+4,])
    schaetz_bv[index] <- mean(bv_data[include.sex+2,])
    schaetz_bv_s[index] <- stats::sd(bv_data[include.sex+2,])
  }
  if(exclude_o >0){
    ob_bv <- ob_bv[-((gen- exclude_o):gen)]
    ob_bv_s <- ob_bv_s[-((gen- exclude_o):gen)]
  }
  if(exclude_s >0){
    schaetz_bv <- schaetz_bv[-((gen- exclude_s +1):gen)]
    schaetz_bv_s <- schaetz_bv_s[-((gen-exclude_s +1):gen)]
  }




  color <- c("black", "blue", "red")
  q <- stats::qnorm(1 - quantile/2)
  m <- list(real_bv + q *real_bv_s, real_bv - q *real_bv_s,ob_bv + q *ob_bv_s,ob_bv - q *ob_bv_s,schaetz_bv + q *schaetz_bv_s,schaetz_bv - q *schaetz_bv_s )

  ob <- max(real_bv, ob_bv, schaetz_bv)
  ub <- max(real_bv, ob_bv, schaetz_bv)
  if(sum(confidence)>0){
    ob <- max(m[[1]] * sum(confidence==1), m[[3]] * sum(confidence==2), m[[5]] * sum(confidence==3))
    ubr <- c(m[[2]] * sum(confidence==1), m[[4]] * sum(confidence==2), m[[6]]* sum(confidence==3))
    ub <- min(ubr[ubr>-Inf])

  }
  graphics::plot(real_bv,type="l", lwd=2, main="Zuchtwertentwicklung", xlab="Generationen", ylab="Zuchtwert", ylim=c(ub,ob))
  graphics::lines(ob_bv, col="blue")
  graphics::lines(schaetz_bv, col="red")
  for(art in confidence){
    graphics::lines(m[[art*2-1]], col=color[art], lty=3)
    graphics::lines(m[[art*2]], col=color[art], lty=3)
  }
  graphics::legend("bottomright",c("Zuchtwert","Beobachtung","ZW-Schaetzung"), lty=c(1,1,1), col=color)
  list(real_bv,ob_bv,schaetz_bv,real_bv_s, ob_bv_s, schaetz_bv_s)
}
