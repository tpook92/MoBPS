#' Export underlying true breeding values
#'
#' test
#' @param population Population list
#' @export
#'
get.bv2 <- function(population, database=NULL, gen=NULL, cohorts=NULL){

  if(length(gen)>0){
    database <- cbind(rep(gen,each=2), rep(1:2, length(gen)))
  }
  if(length(database)>0 && ncol(database)==2){
    start <- end <- numeric(nrow(database))
    for(index in 1:nrow(database)){
      start[index] <- 1
      end[index] <- population$info$size[database[index,1], database[index,2]]
    }
    database <- cbind(database, start, end)
  }
  if(length(cohorts)>0){
    database2 <- matrix(0, nrow=length(cohorts), ncol=4)
    for(index in 1:length(cohorts)){
      row <- which(population$info$cohorts==cohorts[index])
      gen <- as.numeric(population$info$cohorts[row,2])
      sex <- 1 + (as.numeric(population$info$cohorts[row,4])>0)
      first <- as.numeric(population$info$cohorts[row,5 + sex])
      last <- first + as.numeric(population$info$cohorts[row,2 + sex]) - 1
      database2[index,] <- c(gen,sex,first,last)
    }
    database <- rbind(database, database2)
  }


  n.animals <- sum(database[,4] - database[,3] +1)
  data <- matrix(0, ncol=n.animals, nrow=population$info$bv.nr)
  before <- 0
  names <- numeric(n.animals)
  for(row in 1:nrow(database)){
    animals <- database[row,]
    nanimals <- database[row,4] - database[row,3] +1
    data[,(before+1):(before+nanimals)] <- population$breeding[[animals[1]]][[6+ animals[2]]][, animals[3]:animals[4]]
    names[(before+1):(before+nanimals)] <- paste(if(animals[2]==1) "M" else "W", animals[3]:animals[4],"_", animals[1], sep="")
    before <- before + nanimals
  }
  row_names <- paste("Trait", 1:population$info$bv.nr)
  colnames(data) <- names
  rownames(data) <- row_names
  return(data)
}
