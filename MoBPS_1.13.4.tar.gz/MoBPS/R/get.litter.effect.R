'#
  Authors
Torsten Pook, torsten.pook@wur.nl

Copyright (C) 2017 -- 2025  Torsten Pook

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
'#

#' Export litter effect
#'
#' Function to export the litter effect of selected individuals
#' @param population Population list
#' @param database Groups of individuals to consider for the export
#' @param gen Quick-insert for database (vector of all generations to export)
#' @param cohorts Quick-insert for database (vector of names of cohorts to export)
#' @param id Individual IDs to search/collect in the database
#' @param use.id Set to TRUE to use MoBPS ids instead of Sex_Nr_Gen based names (default: TRUE)
#' @examples
#' data(ex_pop)
#' get.litter.effect(ex_pop, gen=2)
#' @return Litter effects for in gen/database/cohorts selected individuals
#' @export

get.litter.effect <- function(population, database=NULL, gen=NULL, cohorts=NULL, id = NULL, use.id=TRUE){

  if(!population$info$litter.effect.active){
    warning("no litter effects simulated")
    return()
  }

  database <- get.database(population, gen, database, cohorts, id = id)

  n.animals <- sum(database[,4] - database[,3] +1)
  data <- matrix(NA, ncol=n.animals, nrow=population$info$bv.nr)
  before <- 0
  names <- numeric(n.animals)


  for(row in 1:nrow(database)){
    animals <- database[row,]
    nanimals <- database[row,4] - database[row,3] +1
    if(nanimals>0){

      names[(before+1):(before+nanimals)] <- paste(if(animals[2]==1) "M" else "F", animals[3]:animals[4],"_", animals[1], sep="")
      for(index in animals[3]:animals[4]){
        before <- before + 1
        data[,before] <- population$breeding[[animals[1]]][[animals[2]]][[index]][[29]]
      }
    }

  }


  row_names <- paste("Trait", 1:population$info$bv.nr)
  rownames(data) <- row_names

  if(use.id){
    colnames(data) <- get.id(population, database = database)
  } else{
    colnames(data) <- names
  }

  return(data)
}
