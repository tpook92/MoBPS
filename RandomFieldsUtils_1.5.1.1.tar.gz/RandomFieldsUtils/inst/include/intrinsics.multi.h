/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3
 of the License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/


// *************************************************
// OLD STYLE MULTI INSTRUCTIONS 
// *************************************************

#define AND4(To, From, From2)				\
  const BlockType a##To = AND(a##From, a##From2);		\
  const BlockType b##To = AND(b##From, b##From2);		\
  const BlockType c##To = AND(c##From, c##From2);		\
  const BlockType d##To = AND(d##From, d##From2);
#define OR4(To, From, From2)				\
  const BlockType a##To = OR(a##From, a##From2);		\
  const BlockType b##To = OR(b##From, b##From2);		\
  const BlockType c##To = OR(c##From, c##From2);		\
  const BlockType d##To = OR(d##From, d##From2);


#define AND4_C(To, From, N)				\
  const BlockType a##To = AND(a##From, N);		\
  const BlockType b##To = AND(b##From, N);		\
  const BlockType c##To = AND(c##From, N);		\
  const BlockType d##To = AND(d##From, N);
#define SHR32_4(To, From, N)				\
  const BlockType a##To = SHR32(a##From, N);		\
  const BlockType b##To = SHR32(b##From, N);		\
  const BlockType c##To = SHR32(c##From, N);		\
  const BlockType d##To = SHR32(d##From, N);
#define SHL32_4(To, From, N)				\
  const BlockType a##To = SHL32(a##From, N);		\
  const BlockType b##To = SHL32(b##From, N);		\
  const BlockType c##To = SHL32(c##From, N);		\
  const BlockType d##To = SHL32(d##From, N);
#define SHR64_4(To, From, N)			\
  const BlockType a##To = SHR64(a##From, N);		\
  const BlockType b##To = SHR64(b##From, N);		\
  const BlockType c##To = SHR64(c##From, N);		\
  const BlockType d##To = SHR64(d##From, N);
#define PERMUTE4(To, From, N)					\
  const BlockType a##To = CROSSLINE_PERMUTE(a##From, N);	\
  const BlockType b##To = CROSSLINE_PERMUTE(b##From, N);	\
  const BlockType c##To = CROSSLINE_PERMUTE(c##From, N);	\
  const BlockType d##To = CROSSLINE_PERMUTE(d##From, N);
#define SHUFFLE8_4(To, N, From)				\
  const BlockType a##To = SHUFFLE8(N, a##From);		\
  const BlockType b##To = SHUFFLE8(N, b##From);		\
  const BlockType c##To = SHUFFLE8(N, c##From);		\
  const BlockType d##To = SHUFFLE8(N, d##From);
#define SAD8_4(To, From, N)			\
  const BlockType a##To = SAD8(a##From, N);		\
  const BlockType b##To = SAD8(b##From, N);		\
  const BlockType c##To = SAD8(c##From, N);		\
  const BlockType d##To = SAD8(d##From, N);


#define ADDUP8_4(Sum, From)				\
  a##Sum = ADD8(a##Sum, a##From);			\
  b##Sum = ADD8(b##Sum, b##From);			\
  c##Sum = ADD8(c##Sum, c##From);			\
  d##Sum = ADD8(d##Sum, d##From);
#define HORIZ_ADD64_4(From)				\
  a += HORIZ_ADD64(a##From);		\
  b += HORIZ_ADD64(b##From);		\
  c += HORIZ_ADD64(c##From);		\
  d += HORIZ_ADD64(d##From);




// *************************************************
// N E W  STYLE MULTI INSTRUCTIONS 
// *************************************************


// #define code2blockN(N,code) BlockType *code##N = (BlockType0 *) (Code + N * ld)
#define ZeroN(N,sum) Doubles sum##N = ZERODOUBLE()
#define andConstN(N, b, a, Const) const BlockType b##N = AND(a##N, Const)
#define shrConstN(N, c, b, Const) const BlockType c##N = SHR64(b##N, Const)
#define AndN(N, d, a, c) const BlockType d##N = AND(a##N, c##N)
#define OrN(N, d, a, c)	BlockType d##N = OR(a##N, c##N)
#define blend0N(N,g,f,e) const Doubles g##N = BLENDvDOUBLE(zero,f,(Doubles)e##N)
#define AddUpN(N,sum, g) sum##N = ADDDOUBLE(sum##N, g##N)
#define shl1N(N,c) c##N = SHL64(c##N, 1)
#define addAnsN(N, Ans, s, sum) \
  s = (double*) &sum##N;  Ans[N] += s[0] + s[1] + s[2] + s[3]

#define blendMultiN(N, g, f, e) \
  const Doubles g##N = BLENDvDOUBLE(zero, f##N, (Doubles) e##N)
#define AddN(N, k, g, h) const Doubles k##N = ADDDOUBLE(g##N, h##N)
#define LoadDoubleN(N,m,ans) const Doubles m##N = LOADuDOUBLE((double*)(ans +N))
#define miniAddN(N, n, m, l) const Doubles n##N = ADDDOUBLE(m##N, l##N)


#define LoadP(N, a, code) const BlockType a##N = LOADU(code##N++)
#define StoreDoubleP(N, ans, n) STOREuDOUBLE((double*) (ans++), n##N)
#define BroadcastP(N, code, V) const Doubles code##N = BROADCAST(V++)


#define MULTI0_1(X,SZ) X(0)
#define MULTI0_2(X,SZ) X(0) SZ X(1)
#define MULTI0_4(X,SZ) X(0) SZ X(1) SZ X(2) SZ X(3) SZ X(4)
#define MULTI0_6(X,SZ) X(0) SZ X(1) SZ X(2) SZ X(3) SZ X(4)\
  SZ X(5) SZ X(6)
#define MULTI0_8(X,SZ) X(0) SZ X(1) SZ X(2) SZ X(3) SZ X(4)\
  SZ X(5) SZ X(6) SZ X(6) SZ X(7)
#define MULTI0_10(X,SZ) X(0) SZ X(1) SZ X(2) SZ X(3) SZ X(4)\
  SZ X(5) SZ X(6) SZ X(6) SZ X(7) SZ X(8) SZ X(9)
#define MULTI0_12(X,SZ) X(0) SZ X(1) SZ X(2) SZ X(3) SZ X(4)\
  SZ X(5) SZ X(6) SZ X(6) SZ X(7) SZ X(8) SZ X(9)\
  SZ X(10) SZ X(11)
#define MULTI0_14(X,SZ) X(0) SZ X(1) SZ X(2) SZ X(3) SZ X(4)\
  SZ X(5) SZ X(6) SZ X(6) SZ X(7) SZ X(8) SZ X(9)\
  SZ X(10) SZ X(11) SZ X(12) SZ X(13)


#define MULTI1_1(X,N,SZ) X(0,N)
#define MULTI1_2(X,N,SZ) X(0,N) SZ X(1,N)
#define MULTI1_4(X,N,SZ) X(0,N) SZ X(1,N) SZ X(2,N) SZ X(3,N) SZ X(4,N)
#define MULTI1_6(X,N,SZ) X(0,N) SZ X(1,N) SZ X(2,N) SZ X(3,N) SZ X(4,N)\
  SZ X(5,N) SZ X(6,N)
#define MULTI1_8(X,N,SZ) X(0,N) SZ X(1,N) SZ X(2,N) SZ X(3,N) SZ X(4,N)\
  SZ X(5,N) SZ X(6,N) SZ X(6,N) SZ X(7,N)
#define MULTI1_10(X,N,SZ) X(0,N) SZ X(1,N) SZ X(2,N) SZ X(3,N) SZ X(4,N)\
  SZ X(5,N) SZ X(6,N) SZ X(6,N) SZ X(7,N) SZ X(8,N) SZ X(9,N)
#define MULTI1_12(X,N,SZ) X(0,N) SZ X(1,N) SZ X(2,N) SZ X(3,N) SZ X(4,N)\
  SZ X(5,N) SZ X(6,N) SZ X(6,N) SZ X(7,N) SZ X(8,N) SZ X(9,N)\
  SZ X(10,N) SZ X(11,N)
#define MULTI1_14(X,N,SZ) X(0,N) SZ X(1,N) SZ X(2,N) SZ X(3,N) SZ X(4,N)\
  SZ X(5,N) SZ X(6,N) SZ X(6,N) SZ X(7,N) SZ X(8,N) SZ X(9,N)\
  SZ X(10,N) SZ X(11,N) SZ X(12,N) SZ X(13,N)


#define MULTI2_1(X,N,M,SZ) X(0,N,M)
#define MULTI2_2(X,N,M,SZ) X(0,N,M) SZ X(1,N,M)
#define MULTI2_4(X,N,M,SZ) X(0,N,M) SZ X(1,N,M) SZ X(2,N,M) SZ X(3,N,M) SZ X(4,N,M)
#define MULTI2_6(X,N,M,SZ) X(0,N,M) SZ X(1,N,M) SZ X(2,N,M) SZ X(3,N,M) SZ X(4,N,M)\
  SZ X(5,N,M) SZ X(6,N,M)
#define MULTI2_8(X,N,M,SZ) X(0,N,M) SZ X(1,N,M) SZ X(2,N,M) SZ X(3,N,M) SZ X(4,N,M)\
  SZ X(5,N,M) SZ X(6,N,M) SZ X(6,N,M) SZ X(7,N,M)
#define MULTI2_10(X,N,M,SZ) X(0,N,M) SZ X(1,N,M) SZ X(2,N,M) SZ X(3,N,M) SZ X(4,N,M)\
  SZ X(5,N,M) SZ X(6,N,M) SZ X(6,N,M) SZ X(7,N,M) SZ X(8,N,M) SZ X(9,N,M)
#define MULTI2_12(X,N,M,SZ) X(0,N,M) SZ X(1,N,M) SZ X(2,N,M) SZ X(3,N,M) SZ X(4,N,M)\
  SZ X(5,N,M) SZ X(6,N,M) SZ X(6,N,M) SZ X(7,N,M) SZ X(8,N,M) SZ X(9,N,M)\
  SZ X(10,N,M) SZ X(11,N,M)
#define MULTI2_14(X,N,M,SZ) X(0,N,M) SZ X(1,N,M) SZ X(2,N,M) SZ X(3,N,M) SZ X(4,N,M)\
  SZ X(5,N,M) SZ X(6,N,M) SZ X(6,N,M) SZ X(7,N,M) SZ X(8,N,M) SZ X(9,N,M)\
  SZ X(10,N,M) SZ X(11,N,M) SZ X(12,N,M) SZ X(13,N,M)

