/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3
 of the License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#if defined (__unix__) || (defined (__APPLE__) && defined (__MACH__))
#include <unistd.h>
#endif

#include "intrinsics.h"
// #include "def_rfu.h"
#include "Basic_RandomFieldsUtils.h"
#include <pthread.h>
// #include "intrinsics.h"
#include "compatibility.general.h"
#include "compatibility.SEXP.h"


AVAILABLE_SIMD


int number_of_cores =
#if defined (__unix__) || (defined (__APPLE__) && defined (__MACH__))
  (int) sysconf(_SC_NPROCESSORS_ONLN);
#elif defined MSDOS_WINDOWS
  INT_MAX;
#else
  INT_MAX;
#endif

const bool
ssse3=ssse3Avail,
sse41=sse41Avail,
avx= avxAvail, 

sse= sseAvail, 
sse2=sse2Avail,

avx2=avx2Avail,

avx512f= avx512fAvail, 
avx512dq=avx512dqAvail,
avx512pf=avx512pfAvail,
avx512er=avx512erAvail,
avx512cd=avx512cdAvail,
avx512bw=avx512bwAvail,
avx512vl=avx512vlAvail,

avx512vbmi=avx512vbmiAvail,
avx512vmbi2=avx512vmbi2Avail,
avx512vnni= avx512vnniAvail, 
avx512bitalg=avx512bitalgAvail,
avx512popcnt=avx512popcntAvail,

avx512intersect=avx512intersectAvail,
avx512fp16= avx512fp16Avail, 

avx512bf16= avx512bf16Avail, 

amxbf16= amxbf16Avail, 
amxtile= amxtileAvail, 
amxint8= amxint8Avail;

/*

#if DO_PARALLEL == DO_FIXED_POSIX

static bool initialized = false;

//#define POLICY SCHED_FIFO
//static int max_prior = sched_get_priority_max(POLICY);
//struct sched_param max_priority = { max_prior };


#include <pthread.h>
#include "win_linux_aux.h"


// credits to https://stackoverflow.com/questions/1407786/how-to-set-cpu-affinity-of-a-particular-pthread/11583550#11583550 !!
int stick_me_to_core(int coreId) {
  //printf("stick id=%d %lu\n", coreId, threadId);
  if (coreId < 0 || coreId >= number_of_cores) {
    BUG;
  }
   cpu_set_t cpuset;
   CPU_ZERO(&cpuset);
   CPU_SET(coreId, &cpuset);
   pthread_t thread = pthread_self();
   //  pthread_setschedparam(thread, POLICY, &max_priority);
   
   return pthread_setaffinity_np(thread, sizeof(cpu_set_t), &cpuset);
}


struct struct_cpuid {
  int id;
  double part;
  int ground_freq, max_freq;
  bool hyperthreader;
};

struct struct_omp_cpuid {
  int thread;
};


struct struct_cpuid cpuidInfo[max_number_of_cores];
static void *ompfct_cpuid(void *arg_void) {
struct struct_omp_cpuid *argvar = (struct_omp_cpuid*) arg_void;
  int thread = argvar->thread;
  int ground_freq, max_freq;
  bool hyperthreader;
  //  printf("in ompfct %d\n", thread);
  stick_me_to_core(thread);
  cpuid_info(&ground_freq, &max_freq, &hyperthreader);
  cpuidInfo[thread].id = thread;
  cpuidInfo[thread].ground_freq = ground_freq;
  cpuidInfo[thread].max_freq = max_freq;
  cpuidInfo[thread].hyperthreader = hyperthreader;
  pthread_exit((void *)arg_void);        
}

static int weak = 0, hyper=0, turnOn=0;
static bool InitializedCpuidInfo = false;
static int requested_cores = -1, available_cores=-1;
static int max_max_freq=-1, max_ground_freq=-1, min_ground_freq=0x7FFFFFFF;
static int cpu_sequ[max_number_of_cores];
static int n_hyperthreaders = 0;
static int printlevel = false;
*/
void initialize_fixed_threads(int *cores, int weakperformance,
			      int hyperperformance, int hyperturnOn,
			      int print_Level) {
  BUG;
/*
  if (weakperformance < 0 || hyperperformance < 0 || hyperturnOn < 0 ||
      hyperturnOn > 100)
    ERR0("performances etc must be within 0...100.\nNote that turnOn=100 has a special meaning (fixed hyperthreads))");
  //  printf("pl = %d\n", print_Level);
  printlevel = print_Level;
  if (!InitializedCpuidInfo) {
    struct struct_omp_cpuid argvar[ max_number_of_cores];
    pthread_t Threads[ max_number_of_cores];
    if (number_of_cores > max_number_of_cores) {
      WARN2("Number of cores is limited to %d while request/hardware is for %d.\nConsider compilaton with higher number of 'max_number_of_cores'.\n", max_number_of_cores, number_of_cores);
      number_of_cores = max_number_of_cores;
    }
    for (int thread = 0; thread < number_of_cores; thread++) {
      // printf("thread = %d < %d\n", thread, number_of_cores);
      argvar[thread].thread = thread;
      pthread_create(Threads + thread, NULL, ompfct_cpuid,
		     (void *)(argvar+thread));
    }
    for (int thread = 0; thread < number_of_cores; thread++)  {		
      //printf("join thread = %d\n", thread);
      pthread_join(Threads[thread], NULL);
   }

    struct struct_cpuid tmp;
    for (int i=0; i<number_of_cores-1; i++) {
      for (int j=i+1; j<number_of_cores; j++) {
	bool swap = cpuidInfo[i].hyperthreader > cpuidInfo[j].hyperthreader;
	if (!swap) swap = cpuidInfo[i].max_freq < cpuidInfo[j].max_freq;
 	if (!swap) swap = cpuidInfo[i].ground_freq < cpuidInfo[j].ground_freq;
	if (swap) {
	  tmp = cpuidInfo[i];
	  cpuidInfo[i] = cpuidInfo[j];
	  cpuidInfo[j] = tmp;
	}
      }
    }

    
    for (int i = 0; i < number_of_cores; i++) {
      max_max_freq = MAX(max_max_freq, cpuidInfo[i].max_freq);
      min_ground_freq = MIN(cpuidInfo[i].ground_freq, min_ground_freq);
      n_hyperthreaders += (int) cpuidInfo[i].hyperthreader;
      if (printlevel)
	PRINTF("%d\tid=%d\t%d..%d\t%d\n", i, cpuidInfo[i].id, cpuidInfo[i].ground_freq, cpuidInfo[i].max_freq, cpuidInfo[i].hyperthreader);
    }

    for (int i = 0; i < number_of_cores; i++) {
      if (max_max_freq == cpuidInfo[i].max_freq)
	max_ground_freq = MAX(cpuidInfo[i].ground_freq, max_ground_freq);
    }
   }

  if (!InitializedCpuidInfo || weak != weakperformance ||
      hyper != hyperperformance || turnOn != hyperturnOn ||
      (requested_cores && requested_cores != *cores) ||
      (!requested_cores && available_cores != *cores)) {
    InitializedCpuidInfo = true;
    weak = weakperformance;
    hyper = hyperperformance;
    turnOn = hyperturnOn;
    requested_cores = *cores;
    available_cores = 0;
    
    double weights = 0.0,     
      weakweight[2] = {1.0, 0.01 * weakperformance}, 
      hyperWeight[2] = {1.0, 0.01 * hyperperformance};
    int toBeTurnedOn = (hyperturnOn * n_hyperthreaders * (hyperperformance>0))
      * 0.01 + 0.5;
    //  printf("turning on %d (%d %d) %f\n", toBeTurnedOn, hyperturnOn , n_hyperthreaders,(hyperturnOn * n_hyperthreaders * (hyperperformance>0)) * 0.01 + 0.5);
    for (int i=0; i<number_of_cores; i++) {
      bool hyperthreader = cpuidInfo[i].hyperthreader;
      bool ok = toBeTurnedOn >= 1 || !hyperthreader;      
      ok = ok && (weakperformance || (cpuidInfo[i].max_freq == max_max_freq && 
			      cpuidInfo[i].ground_freq == max_ground_freq));
      toBeTurnedOn -= hyperthreader;
      if (ok) {
	double w = hyperWeight[hyperthreader] *
	  weakweight[cpuidInfo[i].max_freq < max_max_freq] *
	  cpuidInfo[i].max_freq / max_max_freq;
	cpuidInfo[i].part = w;
	//	printf("i=%d %f %d\n", i, w, 	cpuidInfo[i].id);
	weights += w;
	cpu_sequ[available_cores++] = i;
      } else cpuidInfo[i].part = 0.0;
    }
    
    *cores = requested_cores ? MIN(requested_cores, available_cores)
      : available_cores;
     for (int i=0; i<number_of_cores; i++) cpuidInfo[i].part /= weights;    


    if (requested_cores && available_cores < requested_cores) {
      WARN4("more cores requested (%d) than available(%d) [weak=%d hyper=%d]\n",
	    requested_cores, available_cores, weak, hyper);   
    }
  }
*/
}


void initialize_thread_to_core(long loop, int *cores, long *partial_start) {
  BUG;
  /*
    if (!InitializedCpuidInfo) BUG;
  initialized = true;
  double w = 1.0;
  if (*cores > available_cores) *cores = available_cores;
  else if (*cores < available_cores) {
    w = 0.0;
    for (int i=0; i<*cores; i++) w += cpuidInfo[cpu_sequ[i]].part;
    w = 1.0 / w;
  }
  double sum = 0.0,
    dl = loop;
  partial_start[0] = 0;
  for (int i=0; i<*cores; i++) {
    sum += w * cpuidInfo[cpu_sequ[i]].part;
    partial_start[i+1] = (Long) (sum * dl + 0.9);
    if (printlevel > 1) {
      if (printlevel > 2) 
      PRINTF("i=%d\t%f\t%f\t%l d..%l d<=%l d cores=%d,%d id=%d\n", i, w, cpuidInfo[cpu_sequ[i]].part, partial_start[i], partial_start[i+1], loop, available_cores, *cores, cpu_sequ[i]);
      else // derzeit ohne aenderung zu ">2"
 	PRINTF("i=%d\t%f\t%f\t%l d..%l d<=%l d cores=%d,%d id=%d\n", i, w, cpuidInfo[cpu_sequ[i]].part, partial_start[i], partial_start[i+1], loop, available_cores, *cores, cpu_sequ[i]);
   }
    //	PRINTF("i=%d\t%f\t%f\t%l d..%l d<=%l d cores=%d,%d id=%d\n", i, w, cpuidInfo[cpu_sequ[i]].part, partial_start[i], partial_start[i+1], loop, available_cores, *cores, cpu_sequ[i]);
  }
  assert(partial_start[*cores] == loop && partial_start[0]==0);
  */
}


  
void stick_this_thread_to_core(int thread) {
  BUG;
  /*
  // der Teil sollte eigentlich mit mutex.h programmiert werden!!
  int cpuid = 0;
  static bool msg = true;
  if (thread >= number_of_cores) BUG;
  if (initialized) {
    cpuid = cpu_sequ[thread];
    if (cpuidInfo[cpuid].hyperthreader && turnOn < 100) {
      // printf("hyper %d is not bound\n", cpuid);
      return;
    }
 } else {
    cpuid = thread % number_of_cores;
    if (msg) PRINTF("Note: stick_this_thread_to_core is used without initialization.\n");
    msg = false;
    if (number_of_cores > max_number_of_cores) {
      number_of_cores = max_number_of_cores;
      WARN1("number of processors limited to %d", max_number_of_cores);
      BUG; // later on delete this line
    }
  }
  //  printf(" %d %d %d\n ", thread, cpuid, cpuidInfo[cpuid].hyperthreader);
  if (stick_me_to_core(cpuidInfo[cpuid].id)) BUG;
  */
}

/* 
#endif // FIXED_POSIX

*/
