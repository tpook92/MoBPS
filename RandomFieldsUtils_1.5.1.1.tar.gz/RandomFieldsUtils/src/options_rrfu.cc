/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather 

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3
 of the License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/


#include <unistd.h>

#include "parallel_simd.h"
#ifdef TIME_AVAILABLE
#include <time.h>
#endif


#include "Basic_RFUlocal.h" // must be before anything else
#include "kleinkram.h"
#include "zzz_RFU.h"
#include "options_RFU.h"
#include "extern_RFU.h"
#include "solve_intern.h"
#if defined compatibility_to_R_h     
#include "xport_import_RFU.h"
#endif

// IMPORTANT: all names of general must have at least 3 letters !!!
const char *basic[basicN] =
  { "printlevel","cPrintlevel", "seed", "cores",
    "skipchecks", "asList", "verbose", "helpinfo", "efficient",
    "bigendian","warn_parallel", "exactness"
  };

const char *installNrun[installNrunN] =
  { "kahanCorrection", "warn_unknown_option", "la_mode", 
    "installDefault","installPackages", "determineLAmode", "mem_is_aligned",
    "gpuDevices", "maxStreams"
  };

const char * solve[solveN] = 
  { "use_spam", "spam_tol", "spam_min_p", "svdtol", "eigen2zero",
    "solve_method", "spam_min_n", "spam_sample_n", "spam_factor", "spam_pivot",
    "max_chol", "max_svd", "pivot",
    "pivot_idx", // dynamic parameter
    "pivot_relerror", "pivot_max_deviation", "pivot_max_reldeviation",
    "det_as_log", "pivot_actual_size", "pivot_check", "pseudoinverse",
    "AtAmode", "AtAnrow", "AtAncol", "Strassen_min", "Strassen_factor"
    //, "tmp_delete"
  };


const char * prefixlist[prefixN] = {"basic", "installNrun", "solve"};
const char **allOptions[prefixN] = {basic, installNrun, solve};
int allOptionsN[prefixN] = {basicN, installNrunN, solveN};


utilsoption_type OPTIONS = { // OK
  basic_START,
  installNrun_START,
  { solve_START },
  dummy_START
};




void params_utilsoption(int local, int *params) {
  utilsoption_type *from = WhichOption(local);
  params[PIVOT_IDX_N] = from->solve.n_pivot_idx;
}

void get_utils_basic(basic_options *opt, int local) {
  //  printf("\tstart get_utils_basics local=%d cores=%d\n",local,opt->cores);
 utilsoption_type *from = WhichOption(local);
 MEMCOPY(opt, &(from->basic), sizeof(basic_options));
 // printf("\tget_utils_basics cores=%d / %d\n", opt->cores,from->basic.cores);
}

void get_utilsoption(utilsoption_type *S, int local) {
  assert(solveN == 21 && basicN == 9 && installNrunN == 10 && prefixN==3);
  utilsoption_type *from = WhichOption(local);
  assert(from->solve.n_pivot_idx!=0 xor from->solve.pivot_idx == NULL);
  assert(S->solve.n_pivot_idx!=0 xor S->solve.pivot_idx == NULL);
  if (S->solve.n_pivot_idx != from->solve.n_pivot_idx) BUG;
  int *save_idx = S->solve.pivot_idx,
    n = S->solve.n_pivot_idx < from->solve.n_pivot_idx ?
    S->solve.n_pivot_idx : from->solve.n_pivot_idx;
  MEMCOPY(S, from, sizeof(utilsoption_type)); // OK
  S->solve.pivot_idx = save_idx;
  if (n > 0) {
    MEMCOPY(S->solve.pivot_idx, from->solve.pivot_idx,
	    sizeof(*(S->solve.pivot_idx)) * n);
  }
}

void push_utilsoption(utilsoption_type *S, int local) {
  utilsoption_type *to = WhichOption(local);
  assert(to->solve.n_pivot_idx!=0 xor to->solve.pivot_idx == NULL);
  assert(S->solve.n_pivot_idx!=0 xor S->solve.pivot_idx == NULL);
  int *save_idx = to->solve.pivot_idx;
  if (to->solve.n_pivot_idx != S->solve.n_pivot_idx) {
    FREE(to->solve.pivot_idx);
    to->solve.pivot_idx =
      (int*) MALLOC(S->solve.n_pivot_idx * sizeof(*(to->solve.pivot_idx)));
    save_idx = to->solve.pivot_idx;
  }
  MEMCOPY(to, S, sizeof(utilsoption_type)); // OK
  to->solve.pivot_idx = save_idx;
  if (S->solve.n_pivot_idx > 0) {
    MEMCOPY(to->solve.pivot_idx, S->solve.pivot_idx,
	    sizeof(*(to->solve.pivot_idx)) * S->solve.n_pivot_idx);
  }
}

void del_utilsoption(utilsoption_type *S) {
  FREE(S->solve.pivot_idx);
  S->solve.n_pivot_idx = 0;
}

void update_utilsoption() {
  //  printf("pushing OPTOnns\n");
  push_utilsoption(&OPTIONS, true);// OK
}


timespec startClock1;
Long startClock0;
int specClock;
void startClock(int spec) {
  specClock = spec;
#if defined   TIME_AVAILABLE
  if (spec) clock_gettime(CLOCK_MONOTONIC, &startClock1);
  else startClock0 = clock();
#endif
}

Long getMicroSec() {
#if defined   TIME_AVAILABLE
  Long Ans;
  if (specClock) {
    timespec end;
    clock_gettime(CLOCK_MONOTONIC, &end);
    Ans = (end.tv_sec - startClock1.tv_sec) * 1000000 +
      (end.tv_nsec - startClock1.tv_nsec) / 1000;
  } else {
    Ans = (Long) clock() - startClock0;
    if (Ans < 0) Ans += MAXINT;
    Ans *= 1000000;
    Ans /= CLOCKS_PER_SEC;
  }
  if (Ans < 0) BUG; 
  return Ans;
#else
  return 0;
#endif
}

#define UPPERLIMIT 1.3
#define FACTOR 1.5
void SetLaMode(la_modes usr_mode, utilsoption_type *utils);
int own_chol_up_to(Long maxtime,  solve_options sp, utilsoption_type *utils,
		   Long loops, int clockspec) { // size is now only increased!!
  // basic assumption is that R implementation's getting faster
  // for larger matrices
  // if (cores ==1) return 1000; printf("bug");
#ifdef TIME_AVAILABLE
  Long size = 4;
  Long delta[2];
  solve_storage pt;
  solve_NULL(&pt);
  int cores = GreaterZero(utils->basic.cores);

 double f3 = FACTOR * FACTOR * FACTOR;
  Long
    limitSize = 0,
    limitSize16 = 0,
    mintime =  (int) ((double) maxtime / f3),
    stoptime = (int) ((double) maxtime / SQRT(f3));
   while (true) {
    Long 
      sizeP1 = size + 1,
      sizesq = size * size;
    double *M = (double*) MALLOC(sizesq * sizeof(double));
    //for (int j=1; j>=0; j--) {
    for (int j=0; j<=1; j++) {
      startClock(clockspec);
      SetLaMode(j == 0 ? LA_INTERN : LA_R, utils);
      for (Long k=0; k<loops; k++) {      
	MEMSET(M, 0, sizesq * sizeof(*M));
	for (Long i=0; i<sizesq; i+=sizeP1) M[i] = 1.0;

	if (false) {
	  for (Long i=0; i<size; i++) {
	    for (Long j=0; j<size; j++) {
	      M[i + j * size] = EXP(-FABS((double) i - j)) +
		(double) ( (i==j) * i / 100) ;
	    }
	  }
	}
	
	if (size > 1) M[1] = M[size] = 1e-5;
	doPosDefIntern(M, size, true, NULL, 0, NULL, NULL, MATRIXSQRT, &pt, &sp,
		       utils);
      }
      delta[j] = getMicroSec();
      if (clockspec == 0) delta[j] /= cores;
      if (PL > 3)
	PRINTF("%s\trep=%ld\tsze=%ld\tcore=%d\t%s-time=%ld\n", // ALONG
	       j ? "R" : "intern", ALONG loops, ALONG size, cores,
	       clockspec ? "waiting" : "processor",
	       ALONG delta[j]);
      if (delta[j] < 0) j--;
    }
    FREE(M);
    if (PL == 3)
      PRINTF("Cholesky (%d cores; %ld repet; size %ld): %ld [mu s] on R; %ld for facile code.\n", cores,  ALONG loops, ALONG size, ALONG (delta[1]), ALONG (delta[0]));

    double quotient = (double) delta[1] / (double) delta[0];
    bool Rfaster = quotient < UPPERLIMIT;
    if (size < 16) {
      if (Rfaster) {
	if (limitSize == 0) {
	  //printf("limit = %ld\n", size);
	  limitSize = size;
	}
      } else limitSize = 0;
    } else {
      if (Rfaster && limitSize16 == 0) {
	//printf("limit16 = %ld\n", size);
	limitSize16 = size;
      }
    }
    if (delta[0] > stoptime || delta[1] > stoptime ||
	  (Rfaster && delta[1] > mintime)){
      //	printf("MAXTIME delta %ld %ld %ld <= stopif=%ld <= %d; %5.4f, %5.4f, %d\n", delta[0], delta[1],mintime, stoptime, maxtime,quotient, UPPERLIMIT, Rfaster );
      solve_DELETE0(&pt);      
      return !Rfaster ? MAXINT :
	(int) ((double) (limitSize16 >= 16 ? limitSize16 : limitSize) / FACTOR);
      break;
    }
    size = (int) ((double) size * FACTOR);
  }
 #else 
  ERR0("option 'LA_AUTO' is available only on linux systems");
  return 0;
#endif
}
int own_chol_up_to(int clockSpec, utilsoption_type *utils) {
  //  printf("\n\nSTART TEST\n");
   solve_options solve;
   MEMCOPY(&solve, &(utils->solve), sizeof(solve_options)); 
   solve.Methods[0] = Cholesky;					     
   solve.Methods[1] = NoFurtherInversionMethod;
   solve.pivot_mode = PIVOT_NONE;	  
   solve.sparse = False;	  

   own_chol_up_to(10000, solve, utils, 20, clockSpec); //warm up for some BLAS implementatioan
 //  printf("CONT TEST\n");
 //  own_chol_up_to(256 / 2, 50000, cores);
 //  own_chol_up_to(256 / 4, 50000, cores);
 // own_chol_up_to(256 / 8, 50000, cores);
  // printf("LAST:\n");

  // return own_chol_up_to(10000, cores, 20, clockSpec); printf("bug");
   return own_chol_up_to(1000000, solve, utils, 20, clockSpec);
}


#define CLOCK_MODE 1 //[mu sec]; 0: average processor time; 1:waiting time 
void SetLaMode(la_modes usr_mode, utilsoption_type *utils) {
  la_modes la_mode = usr_mode;
  utils->solve.tinysize =
    utils->installNrun.LaMaxTakeIntern = -1;
#define TINY_SIZE_MAX 3  
  if (la_mode == LA_INTERN) {
    utils->solve.tinysize = TINY_SIZE_MAX;
    utils->installNrun.LaMaxTakeIntern = MAXINT;
  } else if (la_mode == LA_AUTO) {  
    la_mode = HAS_GPU ? LA_GPU : LA_R ;
#if defined TIME_AVAILABLE
    int PLalt = PL;
#  if !defined SCHLATHERS_MACHINE
    // PL = 0;
#  endif  
    utils->installNrun.LaMaxTakeIntern = own_chol_up_to(CLOCK_MODE, utils);
    if (utils->installNrun.LaMaxTakeIntern == MAXINT && la_mode == LA_R)
      la_mode = LA_INTERN;
    utils->solve.tinysize = MIN(TINY_SIZE_MAX, utils->installNrun.LaMaxTakeIntern);
    PL = PLalt;
    if (PL > 1)
      PRINTF("Limit size for facile Cholesky algorithm  = %d\n",
	     utils->installNrun.LaMaxTakeIntern);
#endif
  }
  
  if ((la_mode == LA_GPU || la_mode == LA_R) &&
      utils->solve.pivot_mode > PIVOT_AUTO)
    ERR0("Pivotized Cholesky decomposition has not been implemented yet for GPU and the LAPACK library");

  //  printf("la_mode=%d\n", la_mode);
  
  utils->installNrun.la_mode = la_mode;

 
}

void SetLaModeLocal(utilsoption_type *utils) {
  utilsoption_type *u = WhichOption(true); // OK
  u->installNrun.la_mode = utils->installNrun.la_mode;
  u->solve.tinysize = utils->solve.tinysize;
  u->installNrun.LaMaxTakeIntern = utils->installNrun.LaMaxTakeIntern;
  //  utils->installNrun.la_mode = LA_INTERN;
}

void SetLaMode(la_modes usr_mode) {
  utilsoption_type *utils = WhichOption(false); // OK
  SetLaMode(usr_mode, utils);
  SetLaModeLocal(utils);
}

void SetLaMode() {
  utilsoption_type *utils = WhichOption(false); // OK
  SetLaMode(utils->installNrun.la_usr, utils);
  // printf("note: utils->la_mode = %s\n", LA_NAMES[utils->installNrun.la_mode]);
  SetLaModeLocal(utils);
}



utilsoption_type *WhichOptionX(bool local) {  
  if (local) {
 #if defined compatibility_to_R_h     
    KEY_type *KT = KEYT();
    if (KT == NULL) BUG;
    //    printf("local: %ld %d\n", P2LONG &(KT->global_utils), KT->global_utils.basic.cores);

    return &(KT->global_utils);
#else
    ERR0("'local' must be 'false' in standalone packages.")
#endif
  }
  //  printf("returning &OP TIONS, cors=%d\n", OPTI ONS.basic.cores);
  return &OPTIONS; // OK
}

utilsoption_type *WhichOptionY(bool local, Long L, const char *F) {
  //  printf("%s %ld\n", F, ALONG L);
  //if (L == 412) BUG;
  return WhichOptionX(local);
}
