/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather 

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3
 of the License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/


#include "Basic_RFUlocal.h"

#if defined compatibility_to_R_h

#include <R_ext/Rdynload.h>
#include "RandomFieldsUtils.h"
#include "options_RFU.h"
#include "zzz_RFU.h"
#include "win_linux_aux.h"
#include "extern_RFU.h"
#include "RandomFieldsUtils.h"
#include "xport_import_RFU.h"
#include "compatibility.SEXP.h"



KEY_type *PIDKEY[PIDMODULUS];

void KEY_type_NULL(KEY_type *KT) {
  // ACHTUNG!! setzt nur die uninteressanten zurueck. Hier also gar ncihts.
  KT->next = NULL; // braucht es eigentlich nicht
  KT->doshow = true;
  KT->ToIntDummy = NULL;
  KT->ToIntN = 0;
  KT->ToRealDummy = NULL;
  KT->ToRealN = 0;
  whittle_work_type *work = &(KT->whittle);
  work->nu2old = work->nuOld = work->nu1old = work->nuAlt = -RF_INF;
  // option_type_NULL(KT, false)
}

void KEY_type_DELETE(KEY_type **S) {
  KEY_type *KT = *S;
  //option_type_DELETE(KT);
  FREE(KT->ToIntDummy);
  FREE(KT->ToRealDummy);
  UNCONDFREE(*S);
}



KEY_type *KEYT() {
  int mypid;
  pid(&mypid);
  KEY_type *p = PIDKEY[mypid % PIDMODULUS];
  if (p == NULL) {
    KEY_type *neu = (KEY_type *) XCALLOC(1, sizeof(KEY_type));
    assert(neu != NULL);
    //printf("pidkey = %d %ld\n", mypid % PIDMODULUS, P2LONG neu);
    PIDKEY[mypid % PIDMODULUS] = neu;
    neu->visitingpid = mypid;    
    if (PIDKEY[mypid % PIDMODULUS] != neu) { // another process had the
      //                                        same idea
      //printf("freeing\n");
      FREE(neu);
      return KEYT(); // ... and try again
    }
    neu->pid = mypid;
    //    printf("neu %d %d\n", mypid);
    neu->visitingpid = 0;
    neu->ok = true;
    if (PIDKEY[mypid % PIDMODULUS] != neu) BUG;
    KEY_type_NULL(neu);
    
    //if (basic.warn_parallel && mypid == parentpid)  PRINTF("Do not forget to run 'RFoptions(storing=FALSE)' after each call of a parallel command (e.g. from packages 'parallel') that calls a function in 'RandomFields'. (OMP within RandomFields is not affected.) This message can be suppressed by 'RFoptions(warn_parallel=FALSE)'.") /*// OK */
    
   return neu;
  }
  while (p->pid != mypid && p->next != NULL) {
    //    printf("pp = %d\n", p->pid);
    p = p->next;
  }
  //  printf("pp m = %d %d\n", p->pid, mypid);
  if (p->pid != mypid) {
    if (!p->ok || p->visitingpid != 0) {
      if (PL >= PL_ERRORS) {
	PRINTF("pid collision %d %d\n",  p->ok, p->visitingpid);
      }
      //
      BUG;
      return KEYT();
    }
    p->visitingpid = mypid;
    p->ok = false;
    if (p->visitingpid != mypid || p->ok) {
      return KEYT();
    }
    KEY_type *neu = (KEY_type *) XCALLOC(1, sizeof(KEY_type));
    neu->pid = mypid;
    if (!p->ok && p->visitingpid == mypid) {
      p->next = neu;
      p->visitingpid = 0;
      p->ok = true;      
      return neu;
    }
    FREE(neu);
    p->visitingpid = 0;
    p->ok = true;
    KEY_type_NULL(neu); 
   return KEYT();
  }
  return p;
}


 
void PIDKEY_DELETE() {
  for (int kn=0; kn<PIDMODULUS; kn++) {
    KEY_type *KT = PIDKEY[kn];
    while (KT != NULL) {
      KEY_type *q = KT;
      KT = KT->next;
      KEY_type_DELETE(&q);
    }
    PIDKEY[kn] = NULL;
  }
}


Uint startRFU(void);
void setoptions(int i, int j, SEXP el, char name[LEN_OPTIONNAME],
		bool isList, bool local);
void getoptions(SEXP sublist, int i, bool local);
void deloptions(bool VARIABLE_IS_NOT_USED local) {
#ifdef DO_PARALLEL
  if (local) RFERROR("'pivot_idx' cannot be freed on a local level");
#endif  
  utilsoption_type *options = WhichOption(local);
  FREE(options->solve.pivot_idx);
}


void finalizeLoptions(int local) {
  if (local == FINAL_PRINT_ONLY) {
    //    PRINTF("\tversions: code=%d data=%d\n",
    //	   LOCAL_VERSION, CURRENT_IMPLEMENTATION);

    utilsoption_type *utils = WhichOption(false); // OK
    utilsoption_type *lu = WhichOption(true); // OK
    
    if (utils->installNrun.la_mode == lu->installNrun.la_mode) 
      PRINTF("\tLinear algebra mode: %s\n",
	     LA_NAMES[utils->installNrun.la_mode]);
    else PRINTF("\tWARNING! Linear algebra mode: global=%s, local=%s\n",
		LA_NAMES[utils->installNrun.la_mode],
		LA_NAMES[lu->installNrun.la_mode]);
    
#if !defined INCLUDE_FORTRAN
    if (utils->installNrun.la_mode == LA_R || lu->installNrun.la_mode == LA_R)
      PRINTF("\t*** WARNING! Fortran routines are disabled e.g., Cholesky.***\n");
#endif

  }
}

void loadoptionsRFU() {
  MEMSET(PIDKEY, 0, PIDMODULUS * sizeof(KEY_type *)); // must be first
  Uint simd_info = startRFU();
  SetLaMode();
  install_default();

  pid(&parentpid);
  attachRFUoptions((char *) pkg,
		   prefixlist, prefixN,
		   allOptions, allOptionsN,
		   setoptions, getoptions,
		   finalizeLoptions, // final
		   deloptions,
		   NULL, NULL,
		   0, true,
		   GPU_NEEDS, // from configure.ac
		   simd_info,
		   RFU_VERSION, RFU_VERSION, MEMisALIGNED_NaN);
 
  update_utilsoption();
  KEY_type *KT = KEYT();
  if (KT->global_utils.basic.cores == 0) BUG;
   //finalizeoptions();
}

void  detachoptionsRFU(){
  PIDKEY_DELETE();
  detachRFUoptions(prefixlist, prefixN);
}



#endif // compatibility_to_R_h
