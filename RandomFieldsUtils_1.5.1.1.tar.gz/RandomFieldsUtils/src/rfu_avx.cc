/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather 

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3
 of the License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/


#include "def_rfu.h"
#include "intrinsics.h"
#include "Basic_RandomFieldsUtils.h"
#include "compatibility.lapack.h"
#include "kleinkram.h"
#include "options_RFU.h"
#include "utils.h"
//#include "xport_import_RFU.h"
#include "extern_RFU.h"


#if defined AVX

ASSERT_SIMD(avx_fctns, avx);

#define algn_general(X)  ((1U + (uintptr_t) (((uintptr_t) X - 1U) / BytesPerBlock)) * BytesPerBlock)
double static inline *algn(double *X) {
  assert(algn_general(X)>=(uintptr_t)X); return (double *) algn_general(X);
}

void colMaxsI256(double *M, Long r, Long c, double *ans,
		 int VARIABLE_IS_NOT_USED cores) {
  if (r < 16
#if defined AVX
       || !avx
#elif defined  SSE2
      || !sse2
#endif      
      ) {
    for (Long i=0; i<c; i++) {
      double *m = M + r * i,
	dummy = m[0];    
      for (Long j=1; j<r; j++) dummy = MAX(dummy, m[j]);
      ans[i] = dummy;
    }
    return;
  }
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif  
  for (Long i=0; i<c; i++) {
    double dummy,
      *m = M + r * i;
#if defined SSE2
    double *start = algn(m),
      *end = m + r;
    uintptr_t End = (uintptr_t) (end - doubles);
    if ((uintptr_t) start < End) {
      Doubles * m0 = (Doubles*) start, // LOADED
	Dummy = LOADuDOUBLE((double *)m0);
      for (m0++ ; (uintptr_t) m0 < End; m0++) {
	Dummy = MAXDOUBLE(Dummy, (Doubles) LOADuDOUBLE((double*) m0));
      }
      double *d = (double *) &Dummy;
      dummy = d[0];
      dummy = MAX(dummy, d[1]);
#if defined AVX
      dummy = MAX(dummy, d[2]);
      dummy = MAX(dummy, d[3]);
#endif
      for ( ; m<start; m++) dummy = MAX(dummy, *m);
      m = (double *) m0;
      for ( ; m<end; m++) dummy = MAX(dummy, *m);
    } else {
      dummy = m[0];    
      for (Long j=1; j<r; j++) dummy = MAX(dummy, m[j]);
    }
#else
    dummy = m[0];    
    for (Long j=1; j<r; j++) dummy = MAX(dummy, m[j]);
#endif    
    ans[i] = dummy;
  }
}


#define repet 8
#define atonce (doubles * repet)
#define SET_0(NR) sum##NR = ZERODOUBLE()
#define P_0(NR) prod##NR = ZERODOUBLE()
#define MUL(NR)								\
  STOREuDOUBLE(inout + i + NR * doubles,				\
	       ADDDOUBLE(LOADuDOUBLE(inout + i + NR * doubles),	\
			 MULTDOUBLE(LOADuDOUBLE(x + i + NR * doubles), y)))
			  
#if (7 != repet - 1)
  wrong repet length
#endif
#if (3 != doubles - 1)
  wrong vector length
#endif

void avx_linearprodD(double * x, double  Y, Long len, double *inout) {
  Long i = 0,
    lenM = len - (atonce - 1);  
  Doubles y = SETpd(Y);
 
  for (; i < lenM; i += atonce) {
    MUL(0); MUL(1); MUL(2); MUL(3); MUL(4); MUL(5); MUL(6); MUL(7);
    // for (Long k=0; k<atonce; k++) printf("k=%d %10g %10g %10g\n", i+k, inout[i+k], Y, x[i+k]);
  }
 

  lenM = len - doubles + 1;
  for (; i < lenM; i += doubles) {
    MUL(0);
  }

  for (; i < len; i++) inout[i] += x[i] * Y;
 }

// ***********************************************************************
// SCALAR
// ***********************************************************************


#define ADDN(NR)							\
  prod##NR = MULTDOUBLE(LOADuDOUBLE(x + i + NR * doubles),		\
			LOADuDOUBLE(y + i + NR * doubles));		\
  sum##NR = ADDDOUBLE(sum##NR, prod##NR) 
#define SUMUP(NR, nr) sum##NR = ADDDOUBLE(sum##NR, sum##nr)


#if defined FMA_AVAILABLE
#define ADDF(NR) \
  sum##NR = _mm256_fmadd_pd(LOADuDOUBLE(x + i + NR * doubles),\
			    LOADuDOUBLE(y + i + NR * doubles), sum##NR)
double avx_scalarprodDfma(double * x, double * y, Long len) {
 Long i = 0,
    lenM = len - (atonce - 1);  
   Doubles SET_0(0);
   double *D  = (double *) &sum0;

  if (len >= atonce) {
    Doubles SET_0(1), SET_0(2), SET_0(3), SET_0(4), SET_0(5), SET_0(6),SET_0(7);
   for (; i < lenM; i += atonce) { 
     ADDF(0); ADDF(1); ADDF(2); ADDF(3); ADDF(4); ADDF(5); ADDF(6); ADDF(7); 
   }
   SUMUP(0, 1); SUMUP(2, 3); SUMUP(4, 5); SUMUP(6, 7);
   SUMUP(0, 2); SUMUP(4, 6); SUMUP(0, 4);
  }
  lenM = len - doubles + 1;
  for (; i < lenM; i += doubles) { ADDF(0);  }
  double sum = D[0] + D[1] + D[2] + D[3];
  for (; i < len; i++) sum += x[i] * y[i];
  return sum;
}
#endif
  
  
double avx_scalarprodDnearfma(double * x, double * y, Long len) {
  // deutlich genauer zum 0 tarif
  Long i = 0,
     lenM = len - (atonce - 1);  
  Doubles SET_0(0), SET_0(1), SET_0(2), SET_0(3), SET_0(4), SET_0(5),
    SET_0(6),SET_0(7),
    P_0(0), P_0(1), P_0(2), P_0(3), P_0(4), P_0(5), P_0(6), P_0(7);
  double *D  = (double *) &sum0;

  if ( len >= atonce) {
    for (; i < lenM; i += atonce) {
      ADDN(0); ADDN(1); ADDN(2); ADDN(3); ADDN(4); ADDN(5); ADDN(6); ADDN(7); 
    }
    SUMUP(0, 1); SUMUP(2, 3); SUMUP(4, 5); SUMUP(6, 7);
    SUMUP(0, 2); SUMUP(4, 6); SUMUP(0, 4);
  }
  lenM = len - doubles + 1;
  for (; i < lenM; i += doubles) {  ADDN(0);  }
  double sum = D[0] + D[1] + D[2] + D[3];
  for (; i < len; i++) sum += x[i] * y[i];
  
  return sum;
}
 


#define ADDM(NR)							\
  prod0 = MULTDOUBLE(LOADuDOUBLE(x + i + NR * doubles),		\
		     LOADuDOUBLE(y + i + NR * doubles));		\
  sum0 = ADDDOUBLE(sum0, prod0)


double avx_scalarprodD(double * x, double * y, Long len){
  Long i = 0,
    lenM = len - (atonce - 1);  
  Doubles SET_0(0), P_0(0);
   double *D  = (double *) &sum0;

  if ( len >= atonce) {
    for (; i < lenM; i += atonce) {
      ADDM(0); ADDM(1); ADDM(2); ADDM(3); ADDM(4); ADDM(5); ADDM(6); ADDM(7); 
    }
  }
  lenM = len - doubles + 1;
  for (; i < lenM; i += doubles) { ADDM(0); } 
  double sum = D[0] + D[1] + D[2] + D[3];
  for (; i < len; i++) sum += x[i] * y[i];
  return sum;
}

#define AM(NR)							\
  prod0 = MULTDOUBLE(LOADuDOUBLE(x + NR * doubles),		\
		     LOADuDOUBLE(y + NR * doubles));		\
  sum0 = ADDDOUBLE(sum0, prod0)

#define L(NR)					\
  const Doubles d##NR = LOADuDOUBLE(x + NR * doubles);	\
  const Doubles e##NR = LOADuDOUBLE(y + NR * doubles)

#define M(NR) const Doubles f##NR = MULTDOUBLE(d##NR, e##NR)
#define S(A, B) const Doubles g##A##B = ADDDOUBLE(f##A, f##B);

double ZZavx_scalarprodD(double * x, double * y, Long len){
  // printf("entering len=%ld\n", len);
  double sumX =0.0;

  //sumX = XXXXavx_scalarprodD(x, y, len);
  Long i = 0,
    lenM = len - (atonce - 1);  
  Doubles SET_0(0);//, P_0(0);
  if ( len >= atonce) {
    for (; i < lenM; i += atonce, x+=atonce, y+=atonce) {
      L(0); L(1); L(2); L(3);
      M(0); M(1); M(2); M(3);
      L(4); L(5); L(6); L(7);
      M(4); M(5); M(6); M(7);
      S(0,1); S(2,3); S(4,5); S(6,7);
      const Doubles h0 = ADDDOUBLE(g01, g23);
      const Doubles h1 = ADDDOUBLE(g45, g67);
      const Doubles h2 = ADDDOUBLE(h0, h1);
      sum0 = ADDDOUBLE(sum0, h2);
    }
  }
  
  lenM = len - doubles + 1;
  Doubles P_0(0);
  for (; i < lenM; i += doubles, x+=doubles, y+=doubles) {
     AM(0);
  } // 0
  double *D = (double *) &sum0;
  double sum = D[0] + D[1] + D[2] + D[3];
  for (; i < len; i++, x++, y++) sum += *x * *y; 

  // printf("sumx = %f\n", sum);
  // printf("sums %e %e len=%ld\n", sum, sumX, ALONG len);
  if (FABS(sum - sumX) > 1e-15) {
    PRINTF("%s ", sum>sumX ? " " : "-");
    PRINTF("sums %e %e len=%ld %e\n", sum, sumX, ALONG len, sum-sumX);
    BUG;
  } // else printf("OK %e %e len=%ld %e\n", sum, sumX, ALONG len, sum-sumX);
  // if (len >= 34) BUG;
  
  return sum;
}


#if defined FMA_AVAILABLE
#define F(NR,X) sum##X = _mm256_fmadd_pd(d##NR, e##NR, sum##X)

double XXavx_scalarprodD(double * x, double * y, Long len){
  // printf("entering len=%ld\n", len);
  double sumX =0.0;

  //sumX = XXXXavx_scalarprodD(x, y, len);
  Long i = 0,
    lenM = len - (atonce - 1);  
  Doubles SET_0(0);//, P_0(0);
  Doubles SET_0(1),  SET_0(2),  SET_0(3);
  if ( len >= atonce) {
    for (; i < lenM; i += atonce, x+=atonce, y+=atonce) {
       L(0); L(1);
       F(0,0); F(1,1);
       L(2); L(3);
        F(2,0); F(3,1);
       L(4); L(5);
       F(4,0); F(5,1);
       L(6); L(7);
        F(6,0); F(7,1);
       
       
    }
   }
  
  lenM = len - doubles + 1;
  Doubles P_0(0);
  for (; i < lenM; i += doubles, x+=doubles, y+=doubles) {
     AM(0);
  } // 0
  double sum = 0;
  double *D = NULL;
#if defined HS
#undef HS
#endif
#define HS(NR) D=(double *) &sum##NR; sum += D[0] + D[1] + D[2] + D[3]
  HS(0);HS(1);HS(2);HS(3); 
   
  for (; i < len; i++, x++, y++) sum += *x * *y; 

  // printf("sumx = %f\n", sum);
  // printf("sums %e %e len=%ld\n", sum, sumX, len);
  if (FABS(sum - sumX) > 1e-15) {
    PRINTF("%s ", sum>sumX ? " " : "-");
    PRINTF("sums %e %e len=%ld %e\n", sum, sumX, ALONG len, sum-sumX);
    BUG;
  } // else printf("OK %e %e len=%ld %e\n", sum, sumX, ALONG len, sum-sumX);
  // if (len >= 34) BUG;
  
  return sum;
}


#define FF(NR) sum##NR = _mm256_fmadd_pd(a, b##NR, sum##NR)

#define LL(NR) const Doubles b##NR = LOADuDOUBLE(y + NR * ldY);

void avx_scalarprodD4(double * x, double * y, Long len, Long ldY,
		      double *s0, double *s1, double *s2, double *s3){
  // printf("entering len=%ld\n", len);
  double sumX =0.0;

  //sumX = XXXXavx_scalarprodD(x, y, len);
  Long i = 0,
    lenM = len - (atonce - 1);  
  Doubles SET_0(0), SET_0(1),  SET_0(2),  SET_0(3);
  if ( len >= atonce) {
    for (; i < lenM; i += doubles, x+=doubles, y+=doubles) {
      const Doubles a = LOADuDOUBLE(x);
      LL(0); LL(1); LL(2); LL(3); 
      FF(0); FF(1); FF(2); FF(3);        
    }
   }
  
  double z0 = 0, z1=0, z2=0, z3=0;
  double *D = NULL;
#if defined HS
#undef HS
#endif
#define HS(NR) D=(double *) &sum##NR; z##NR = D[0] + D[1] + D[2] + D[3]
  HS(0);HS(1);HS(2);HS(3); 

#define RS(NR) z##NR += *x * y[NR * ldY];  
  for (; i < len; i++, x++, y++) {
    RS(0); RS(1); RS(2); RS(3);
  }

  *s0 = z0;
  *s1 = z1;
  *s2 = z2;
  *s3 = z3;

  // printf("sumx = %f\n", sum);
  // printf("sums %e %e len=%ld\n", sum, sumX, len);
    //  if (FABS(sum - sumX) > 1e-15) {
    //    printf("%s ", sum>sumX ? " " : "-");
    //    printf("sums %e %e len=%ld %e\n", sum, sumX, len, sum-sumX);
    //    BUG;
    //  } // else printf("OK %e %e len=%ld %e\n", sum, sumX, ALONG len, sum-sumX);
  // if (len >= 34) BUG;
}
#else
void avx_scalarprodD4(double * x, double * y, Long len, Long ldY,
		      double *s0, double *s1, double *s2, double *s3){ BUG; }
#endif


/*
#define AM(NR)							\
  prod0 = MULTDOUBLE(LOADuDOUBLE(x + NR * doubles),		\
		     LOADuDOUBLE(y + NR * doubles));		\
  sum0 = ADDDOUBLE(sum0, prod0)

double avx_scalarprodD(double * x, double * y, Long len){
  Long 
    lenM = len - (atonce - 1);  
  Doubles SET_0(0), P_0(0);
  double *xend = x + len,
    *xD = xend - (doubles - 1),
    *xM = xend - (atonce - 1);
  if ( len >= atonce) {
    for (; x < xM; x+=atonce, y+=atonce) {
      AM(0); AM(1); AM(2); AM(3); AM(4); AM(5); AM(6); AM(7); 
    }
  }
  
  lenM = len - doubles + 1;
  for (; x < xD; x+=doubles, y+=doubles) { AM(0); } // 0
  double *D  = (double *) &sum0;
  double sum = D[0] + D[1] + D[2] + D[3];
  for (; x < xend; x++) sum += *x * *y; // 0.3 intern rep=20	sze=6 core=10	waiting-time=340

  
  return sum;
}

*/


/*
// #pragma clang optimize on|off.
//double avx_scalarprodDopt(double * x, double * y, Long len)  __attribute__ ((optimize(3)));
//
#pragma GCC push_options
#pragma GCC optimize ("Os") // aggressive
// aggressive
double avx_scalarprodDopt(double * x, double * y, Long len) {
  Long i = 0,
    lenM = len - (atonce - 1);  
  Doubles SET_0(0), P_0(0);
   double *D  = (double *) &sum0;

  if ( len >= atonce) {
  for (; i < lenM; i += atonce) {
    ADDM(0); ADDM(1); ADDM(2); ADDM(3); ADDM(4); ADDM(5); ADDM(6); ADDM(7); 
    }
  }
  lenM = len - doubles + 1;
  for (; i < lenM; i += doubles) { ADDM(0); } 
  double sum = D[0] + D[1] + D[2] + D[3];
  for (; i < len; i++) sum += x[i] * y[i];
  return sum;
}
#pragma GCC pop_options


#define ADDMM(NR)							\
  x0 = LOADuDOUBLE(X0 + i + NR * doubles);				\
  y0 = LOADuDOUBLE(Y0 + i + NR * doubles);				\
  prod0 = MULTDOUBLE(x0, y0);						\
  sum0 = ADDDOUBLE(sum0, prod0);					\
  x1 = LOADuDOUBLE(X1 + i + NR * doubles);				\
  prod0 = MULTDOUBLE(x1, y0);						\
  sum1 = ADDDOUBLE(sum1, prod0);					\
  y1 = LOADuDOUBLE(Y1 + i + NR * doubles);				\
  prod0 = MULTDOUBLE(x0, y1);						\
  sum2 = ADDDOUBLE(sum2, prod0);					\
  prod0 = MULTDOUBLE(x1, y1);						\
  sum3 = ADDDOUBLE(sum3, prod0);					\
  x2 = LOADuDOUBLE(X2 + i + NR * doubles);				\
  prod0 = MULTDOUBLE(x2, y0);						\
  sum4 = ADDDOUBLE(sum4, prod0);					\
  prod0 = MULTDOUBLE(x2, y1);						\
  sum5 = ADDDOUBLE(sum5, prod0);					\
  y0 = LOADuDOUBLE(Y2 + i + NR * doubles);				\
  prod0 = MULTDOUBLE(x0, y0);						\
  sum6 = ADDDOUBLE(sum6, prod0);					\
  prod0 = MULTDOUBLE(x1, y0);						\
  sum7 = ADDDOUBLE(sum7, prod0);					\
  prod0 = MULTDOUBLE(x2, y0);						\
  sum8 = ADDDOUBLE(sum8, prod0);					\


#pragma GCC optimize ("O1") // aggressive
void avx_scalarprodM(double * X0, double * Y0, Long len, double *res) {
  Long i = 0,
    lenM = len - (atonce - 1);  
 Doubles SET_0(0),
    SET_0(1),
    SET_0(2),
    SET_0(3),
    SET_0(4),
    SET_0(5),
    SET_0(6),
    SET_0(7),
    SET_0(8),
    x0, x1, x2,
    y0, y1,// y2, 
    P_0(0);
  double 
    *X1 = X0 + len,
    *Y1 = Y0 + len,
    *X2 = X0 + 2 * len,
    *Y2 = Y0 + 2 * len;

  if ( len >= atonce) {
  for (; i < lenM; i += atonce) {  
    ADDMM(0); ADDMM(1); ADDMM(2); ADDMM(3); ADDMM(4); ADDMM(5); ADDMM(6); ADDMM(7); 
    }
  }
  lenM = len - doubles + 1;
  for (; i < lenM; i += doubles) { ADDMM(0); }
  double
    *D  = (double *) &sum0,
    sum = D[0] + D[1] + D[2] + D[3];
  for (; i < len; i++) sum += X0[i] * Y0[i];
  res[0] = sum;
}

*/

double avx_scalarprodDP(double * x, double * y, Long len) {
  Long i = 0,
     lenM = len - (atonce - 1);  
  Doubles SET_0(0), SET_0(1), P_0(0);
   double *D  = (double *) &sum1;
  if ( len >= atonce) {
    for (; i < lenM; ) {
      Long lenMM = i + doubles * (repet * 10L + 1L);
      if (lenMM > lenM) lenMM = lenM;
      sum0 = MULTDOUBLE(LOADuDOUBLE(x + i), LOADuDOUBLE(y + i));
      i += doubles;
      for (; i < lenMM; i += atonce) {
	ADDM(0); ADDM(1); ADDM(2); ADDM(3); ADDM(4); ADDM(5); ADDM(6); ADDM(7); 
      }
      sum1 = ADDDOUBLE(sum0, sum1);
    }
  }
  
 lenM = len - doubles + 1;
 for (; i < lenM; i += doubles) { 
    prod0 = MULTDOUBLE(LOADuDOUBLE(x + i), LOADuDOUBLE(y + i));
    sum1 = ADDDOUBLE(sum1, prod0);
  }
  double sum = D[0] + D[1] + D[2] + D[3];
  for (; i < len; i++) sum += x[i] * y[i];
  return sum;
}


#define ADDK(NR)							\
  prod0 = MULTDOUBLE(LOADuDOUBLE(x + i + NR * doubles),		\
		     LOADuDOUBLE(y + i + NR * doubles));		\
  sum2 = SUBDOUBLE(prod0, sum1);					\
  sum3 = ADDDOUBLE(sum0, sum2);						\
  sum1 = SUBDOUBLE(sum3, sum0);						\
  sum0 = sum3;								\
  sum1 = SUBDOUBLE(sum1, sum2);
double avx_scalarprodDK(double * x, double * y, Long len) {
  // Kahan
  Long i = 0,
    lenM = len - (atonce - 1);  
  Doubles SET_0(0), // sum
    SET_0(1), 
    SET_0(2), // y
    SET_0(3), // t
    P_0(0),
    P_0(1);
  double *D  = (double *) &sum0;  
  if ( len >= atonce) {
    for (; i < lenM; i += atonce) {
      ADDK(0); ADDK(1); ADDK(2); ADDK(3); ADDK(4); ADDK(5); ADDK(6); ADDK(7);
    }
  }
  lenM = len - doubles + 1;
  for (; i < lenM; i += doubles) { ADDK(0); }
  sum0 = ADDDOUBLE(sum0, prod1);
  double sum = D[0] + D[1] + D[2] + D[3];
  
  for (; i < len; i++) sum += x[i] * y[i];
  return sum;
}


#else

void colMaxsI(double *M, Long r, Long c, double *ans, int cores);
void colMaxsI256(double *M, Long r, Long c, double *ans, int cores) {colMaxsI(M, r, c, ans, cores);}

void linearprod2by2(double * x, double  y, Long len, double *inout);
void avx_linearprodD(double * x, double  y, Long len, double *inout) {
  linearprod2by2(x, y, len, inout);}

double scalarprod4by4( double * v1, double * v2, Long N);
double avx_scalarprodDnearfma(double * x, double * y, Long L) {
  return scalarprod4by4(x,y,L);}
double avx_scalarprodD(double * x, double * y, Long L) {
 return scalarprod4by4(x,y,L);}
double avx_scalarprodDP(double * x, double * y, Long L) {
  return scalarprod4by4(x,y,L);}
double avx_scalarprodDK(double * x, double * y, Long L) {
  return scalarprod4by4(x,y,L);}

void avx_scalarprodD4(double * x, double * y, Long len, Long ldY,
		      double *s0, double *s1, double *s2, double *s3){
}

SIMD_MISS(avx_fctns, avx);

#endif



