# This file has been created automatically by 'rfGenerateConstants'


 ## from  src/AutoRandomFieldsUtils.h



 MAXUNITS 	<- as.integer(4)
 MAXCHAR 	<- as.integer(18)
 RFOPTIONS 	<- "RFoptions"



