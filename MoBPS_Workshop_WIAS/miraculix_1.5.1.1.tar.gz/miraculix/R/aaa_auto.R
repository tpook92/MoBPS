# This file has been created automatically by 'rfGenerateConstants'


 ## from  src/Automiraculix.h









 AutoMiraculix_H 	<- as.integer(1)


 CURRENT_IMPLEMENTATION 	<- as.integer(7)









 AutoCoding 	<- as.integer(0)
 OneBitGeno 	<- as.integer(1)
 TwoBitGeno 	<- as.integer(2)
 ThreeBit 	<- as.integer(3)
 Plink 	<- as.integer(4)
 FiveCodes 	<- as.integer(5)
 OrigPlink 	<- as.integer(6)
 unused7 	<- as.integer(7)
 unused8 	<- as.integer(8)
 unused9 	<- as.integer(9)
 FourBit 	<- as.integer(10)
 OneByteGeno 	<- as.integer(11)
 TwoByte 	<- as.integer(12)
 FourByteGeno 	<- as.integer(13)
 unused14 	<- as.integer(14)
 unused15 	<- as.integer(15)
 unused16 	<- as.integer(16)
 unused17 	<- as.integer(17)
 unused18 	<- as.integer(18)
 unused19 	<- as.integer(19)
 OneBitHaplo 	<- as.integer(20)
 TwoBitHaplo 	<- as.integer(21)
 OneByteHaplo 	<- as.integer(22)
 FourByteHaplo 	<- as.integer(23)
 FourByteSingleBit 	<- as.integer(24)
 EightByteHaplo 	<- as.integer(25)
 DotFile 	<- as.integer(26)
 FileDot 	<- as.integer(27)
 CorrespondingGeno 	<- as.integer(28)
 UnknownSNPcoding 	<- as.integer(29)



 nr_coding_type 	<- as.integer((UnknownSNPcoding+1))

 FirstMoBPScoding 	<- as.integer(TwoBitGeno)
 LastMoBPScoding 	<- as.integer(TwoBitGeno)

 FirstUserGenoCoding 	<- as.integer(OneByteGeno)
 LastUserGenoCoding 	<- as.integer(FourByteGeno)
 FirstGenoCoding 	<- as.integer(OneBitGeno)
 LastGenoCoding 	<- as.integer(LastUserGenoCoding)

 FirstHaplo32Coding 	<- as.integer(FourByteHaplo)
 LastHaplo32Coding 	<- as.integer(EightByteHaplo)
 FirstHaploCoding 	<- as.integer(OneBitHaplo)
 LastHaploCoding 	<- as.integer(LastHaplo32Coding)

 FirstUserCoding 	<- as.integer(AutoCoding)
 LastUserCoding 	<- as.integer(LastHaploCoding)





 VARIANT_DEFAULT 	<- as.integer(0)
 VARIANT_GPU 	<- as.integer(768)
 VARIANT_R 	<- as.integer(896)
 VARIANT_A 	<- as.integer(32)
 VARIANT_B 	<- as.integer(64)
 VARIANT_C 	<- as.integer(96)

 NoCentering 	<- as.integer(0)
 RowMeans 	<- as.integer(1)
 ColMeans 	<- as.integer(2)
 User 	<- as.integer(0)

 nr_centering_type 	<- as.integer((User+1))
 SNPmeans 	<- as.integer(RowMeans)
 INDIVmeans 	<- as.integer(ColMeans)

 NoNormalizing 	<- as.integer(0)
 RowNormalized 	<- as.integer(1)
 ColNormalized 	<- as.integer(2)
 CorrNormalizing 	<- as.integer(0)
 AccordingCentering 	<- as.integer(1)


 nr_normalizing_type 	<- as.integer((AccordingCentering+1))












 IMPLEMENTATION 	<- as.integer(0)
 SNPS 	<- as.integer(1)
 INDIVIDUALS 	<- as.integer(2)
 CODING 	<- as.integer(3)
 TRANSPOSED 	<- as.integer(4)
 VARIANT 	<- as.integer(5)
 LDABITALIGN 	<- as.integer(6)
 LDA 	<- as.integer(7)
 ORIGINALLY_HAPLO 	<- as.integer(8)
 MISSINGS 	<- as.integer(9)
 EXPECTED_REPET_V 	<- as.integer(10)

 ADDR 	<- as.integer(11)
 ALIGNADDR 	<- as.integer(12)
 MEMinUNITS 	<- as.integer(13)

 ALIGNEDUNITS 	<- as.integer(14)
 BIGENDIAN 	<- as.integer(15)

 CURRENT_SNPS 	<- as.integer(16)
 ISHAPLO 	<- as.integer(17)

 FILE_SNPxIND_READ_BYROW 	<- as.integer(18)
 FILE_HEADER 	<- as.integer(19)
 FILE_DOUBLEINDIV 	<- as.integer(20)
 FILE_LEADINGCOL 	<- as.integer(21)

 INFO_GENUINELY_LAST 	<- as.integer(FILE_LEADINGCOL)

 RECENTALIGNADDR 	<- as.integer(22)
 BLOCKEDINFO 	<- as.integer(23)
 ZAEHLER 	<- as.integer(24)


 INFO_LAST 	<- as.integer(25)

 FIRST_FILE_INFO 	<- as.integer(FILE_SNPxIND_READ_BYROW)
 LAST_FILE_INFO 	<- as.integer(FILE_LEADINGCOL)

 GENOMICMATRIX 	<- "genomicmatrix"
 HAPLOMATRIX 	<- "haplomatrix"
 ORIGINVECTOR 	<- "origindata"

 MAX_LDA_BITALIGN 	<- as.integer(1024)


 N_MIRACULIX_NAMES_OF_NAMES 	<- as.integer(4)






 ## from  ../../RandomFieldsUtils/RandomFieldsUtils/src/AutoRandomFieldsUtils.h








 auto_rfutils_h 	<- as.integer(1)



 MAXUNITS 	<- as.integer(4)
 MAXCHAR 	<- as.integer(18)
 RFOPTIONS 	<- "RFoptions"
 CLASS_TRYERROR 	<- "try-error"

 WARN_UNKNOWN_OPTION_ALL 	<- as.integer(4)
 WARN_UNKNOWN_OPTION_SINGLE 	<- as.integer(3)
 WARN_UNKNOWN_OPTION_CAPITAL 	<- as.integer(2)
 WARN_UNKNOWN_OPTION_NONE1 	<- as.integer(1)
 WARN_UNKNOWN_OPTION_NONE 	<- as.integer(0)

 CONTACT 	<- " Please contact the maintainer martin.schlather@uni-mannheim.de.\n"




 ## from  src/Automiraculix.cc

 CODING_NAMES <-
c( "AutoCoding","1bit","2bit","3bit","plink","5codes8","orig.plink","unused7","unused8","unused9","2bit4","2bit8","2bit16","2bit32","unused14","unused15","unused16","unused17","unused18","unused19","1bit-H","2bit-H","1bit8-H","1bit32-H","1-1-bit32","2bit64-H","dot.file","file.dot","anyGeno","unknown" )


 INFO_NAMES <-
c( "implementation","snps","individuals","coding","transposed","variant","ldaBitalign","lda","genuinehaplo","missings","expected_size_V","addr","align0","memInUnits","AlignedUnits","bigendian","current_snps (MoBPS)","isSNPxInd","header","DoubledIndividuals","leadingcolumns","RECENTALIGNADDR","BLOCKEDINFO","Zaehler","isHaplo","<Last>" )


 CENTERING_NAMES <-
c( "no centering","snp means","indiv means","user" )


 NORMALIZING_NAMES <-
c( "no normalizing","RowNormalized","ColNormalized","correlation normalization","according_centering" )


 MIRACULIX_NAMES_OF_NAMES <-
c( "coding","centering","info","normalizing" )




 ## from  ../../RandomFieldsUtils/RandomFieldsUtils/src/AutoRandomFieldsUtils.cc

