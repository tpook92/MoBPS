 getBest <- function(snps=1e5, individuals=300,
                    give.gain = TRUE, sort = 1 + (cores > 1),
                    allCodings=!!check, variants = !!check, tilings = -2,
                    logSnpGroupSizes=c(0, 8), indivGroupSizes=c(0, 4, 8, 16),
                    include.preparation.time=FALSE,
                    setRFoptions = TRUE, check=!setRFoptions, 
                    verbose=!!check, relMatrix=!!check, ..., cores = 1)
 {

   xxxxxx
  
  RFopt <- internalRFoptions(COPY=TRUE, basic.efficient=FALSE,
                             getoptions_="genetics", ...,
#                             basic.skipchecks = TRUE,
                             basic.cores=cores
                             )

  ## best values machine depedent
  best <- OneBitGeno
  codings <- (if (is.numeric(allCodings)) as.integer(allCodings)
              else if (is.na(allCodings)) best
              else if (allCodings) existingCrossprod(as.character=FALSE)
              else RFopt$snpcoding)
  if (is.character(codings)) {
    codings <- if (codings[1] == CODING_NAMES[UnknownSNPcoding + 1]) best 
               else pmatch(codings, CODING_NAMES) - 1L
  }
 
  Tg <- apply(expand.grid(snp=logSnpGroupSizes, ind=indivGroupSizes),
              1, as.list)
  genuinely.tiled <- sapply(Tg, function(x) !all(unlist(x) == 0))
  Tg <- Tg[genuinely.tiled]
  if (length(Tg) == 0) tilings <- FALSE
  sizes <- list(list(list(snp=0, ind=0)), Tg)
  
  N <- length(codings) * 16  * sum(sapply(sizes, length)) # rough idea of size
  N <- min(N, 1000)

  D <- data.frame(coding=character(N), variant=integer(N), sub=character(N),
                  logSnpGS=integer(N), indivGS=integer(N),
                  user=double(N),  elaps=double(N))  
  Prep <- data.frame(prepUsr=double(N), prepEl=double(N))
  count <- 0

  total <- individuals * snps
  M <- (if (check == 1) matrix(ncol=individuals,
                               sample(0:2, total, replace=TRUE))
        else if (check == 2) matrix(ncol=individuals,
                                    rep(rep(0:2, 2:4), length=total))    
        else matrix(0L, ncol=individuals, nrow=snps))

  stopifnot(is.integer(M))
  if (check == 1) {
    gc()
    S <- if (relMatrix) {
           system.time({
             p <- rowMeans(M)
             P <- p %*% t(rep(1, individuals))
             sigma2 <- sum(p * (1- p/2))
             Ccmp <- crossprod(M-P) / sigma2
           })
         } else system.time(Ccmp <- crossprod(M))
    count <- count + 1
    D[count, ] <- list("no", 32 * (2 - is.integer(M)), "R", 
                       sizes[[1]][[1]]$snp,sizes[[1]][[1]]$snp,
                       S["user.self"], S["elapsed"])
    P[count, ] <- list(prepUsr=NA, prepEl=NA)
    if (verbose>1 && individuals<=12) print(Ccmp) # OK
  }
  CP <- if (relMatrix) relMatrixIntern else crossprodx

  if (is.na(variants)) variants <- -1
  else if (!is.logical(variants)) Variants <- as.integer(variants)
  else stopifnot(length(variants) == 1)
  if (variants == 0) {
    m <- 0
    for (coding in codings) {
      eV <- existingVariant(coding, indeed=TRUE)
      m <- max(m, eV[eV < VARIANT_GPU])
    }
    m <- 2^trunc(log(m) / log(2) + 0.001) # 32,64,128,256,512
  }
  for (coding in codings) {
    if (variants[1] <= 1) { ## '[1]' notw
      Vs <- existingVariant(coding, indeed=TRUE)
      if (variants < 1) {   ## '[1]' nicht notw  
        if (variants < 0 || coding == TwoBitGeno) {# Variant A is best of 2bit 
          m <- max(Vs[Vs<VARIANT_GPU])
          if (variants == -1) m <- 2^trunc(log(m) / log(2) + 0.001)
        }        
        Vs <- Vs[Vs >= m & Vs < VARIANT_R]
      }
    }
    if (verbose>1) cat(coding, ": ", paste(Vs, collapse=","), "\n")
    for (variant in Vs) {
      Tilings <- existingTiling(coding,variant)
      if (!is.na(tilings[1]) && tilings[1] != -1)
        Tilings <- if (tilings[1] < -1) any(Tilings)
                   else Tilings[pmatch(tilings, Tilings, nomatch=0)]
      for (tilingList in sizes[Tilings + 1]) {
        for (size in tilingList){
           internalRFoptions(snpcoding = coding, variant=variant, 
                            logSnpGroupSize=size$snp,
                            indivGroupSize=size$ind,
                            RETURN = FALSE, COPY=FALSE)
           if (verbose) cat("coding=", CODING_NAMES[coding + 1],
                            "\tvariant=", variant,
                            "\ttiling=", paste(size$snp,"x",size$ind),
                            "\n")
           gc()
           S0 <- system.time({G <- Transform(M, snpcoding=FourByteGeno)})          
           S <- system.time({C <- CP(G, COPY=FALSE)})
           count <- count + 1
           D[count, ] <- list(CODING_NAMES[coding + 1],
                              if (variant >= VARIANT_GPU) {
                                if (variant < VARIANT_R) 1024 else 32
                              } else 2^trunc(log(variant)/log(2) + 0.001),
                              if (variant < 128 || (variant %% 128 == 0 &&
                                                    variant < VARIANT_R)) ""
                             else LETTERS[(variant %% 128) / 32 +
                                          (variant >= VARIANT_R) * 18],
                             size$snp, size$ind,
                             S["user.self"], S["elapsed"])
           Prep[count,] <-S0[c("user.self","elapsed")]
           if (check) {
             if (count >= 2 && !all(abs(C-Ccmp)<1e-10)) {
              print(cbind(D[1:count, ], Prep[1:count, ])) # OK
              if (verbose > 1 && individuals <= 12) print(C / Ccmp) # OK
              Print(C, Ccmp, range(C), range(Ccmp), range(C / Ccmp)) # OK
              stop(CODING_NAMES[coding + 1], " v", variant,
                   " tiling=",  size$snp, "x", size$ind,
                   " differs from R. Pls contact authors!")
            } else Ccmp <- C
          }
        }
      }
    }
  }

  if (count  == 0) stop("arguments lead to void result")
  if (check && count == 1) stop("a single result is not comparable")
  
  if (is.na(include.preparation.time)) D <- cbind(D, Prep)
  else if (include.preparation.time) {
    time.idx <- c("prepUsr", "prepEl")
    D[, time.idx] <- D[, time.idx] + Prep
  }

  D <- D[1:count, ]
  if (sort || !is.na(give.gain)) {
    if (sort == 0) sort <- 1
    ord <- order(if (abs(sort) == 1) D$user else D$elaps)
    if (sort < 0) ord <- rev(ord)
    D <- D[ord, ]    
    if (!is.na(give.gain)) {
      if (give.gain) {
        user <- D$user[nrow(D)] / D$user
        elaps  <- D$elaps[nrow(D)] / D$elaps
        D <- cbind(D, accelUsr=signif(user, 3), accelEl=signif(elaps, 3))
       } else {
         user <- D$user / D$user[1]
         elaps  <- D$elaps / D$elaps[1]
         D <- cbind(D, relucUsr=signif(user, 3), relucEl=signif(elaps,3))
       }
    }
  }
  rownames(D) <- 1:count
  times <- if (abs(sort) <= 1) D$user else D$elaps
  if (check == 1) times[1] <- Inf # never choose first
  mini <- min(times)
  best <- D[which(mini == times)[1], ]    
  sub <- pmatch(best$sub, LETTERS, nomatch=0)
  if (sub >= 18) variant <- VARIANT_R + 32 * (sub - 18)
   else variant <- 32 * sub + (if (best$variant == 1024) VARIANT_GPU
                              else if (best$variant<=512) best$variant
                              else NA)
  
  if (verbose) {
    Print(best) # OK
    cat("Hence, setting ", if (setRFoptions) "is:" else "would be:",
        "\nRFoptions(snpcoding=", which(best$coding == CODING_NAMES)-1,
        ", variant=", variant,
        ", logSnpGroupSize=", best$logSnpGS,
        ", indivGroupSize=", best$indivGS, ")\n\n",
        sep="")
  }
  
  if (setRFoptions) {
    for (L in c(FALSE, TRUE)) {
      ##Print(best, variant, best$logSnpGS)
      RFoptions(local_ = L,
                snpcoding = best$coding, variant=variant,
                logSnpGroupSize=best$logSnpGS, indivGroupSize=best$indivGS)
    }
  }
  if (setRFoptions) invisible(D) else D
}

