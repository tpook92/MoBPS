/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/

#include "Basic_miraculix.h"

#if defined compatibility_to_R_h
#include "miraculix.h"
#include "xport_import.h"
#include "MXinfo.h"
// #include "zzz_RFU.h"
#include "scan.h"


SEXP scan(SEXP positions, SEXP length, SEXP freq, 
	  SEXP minscan,  SEXP maxscan, SEXP threshold, SEXP nthres,
	  SEXP PER_SNP,
	  SEXP above_threshold, SEXP Maximum) {
  scanC(INTEGER(positions), INTEGER(length), REAL(freq), 
	INTEGER(minscan),  INTEGER(maxscan), REAL(threshold),
	INTEGER(nthres),
	INTEGER(PER_SNP),
	INTEGER(above_threshold), REAL(Maximum));
  return R_NilValue;
}


  
SEXP collect_scan(SEXP positions, SEXP length, SEXP freq, 
		  SEXP minscan,  SEXP maxscan, SEXP threshold, SEXP nthres,
		  SEXP PER_SNP, SEXP areas,  SEXP value
		  ) {
   return collect_scan(INTEGER(positions), INTEGER(length), REAL(freq), 
	   INTEGER(minscan), INTEGER(maxscan), REAL(threshold), INTEGER(nthres),
	   INTEGER(PER_SNP), INTEGER(areas), REAL(value));
 }



SEXP collect_scan2(SEXP positions, SEXP length, SEXP freq, 
		   SEXP minscan,  SEXP maxscan, SEXP threshold, SEXP nthres,
		   SEXP PER_SNP, SEXP max_intervals, SEXP max_basepair_dist, 
		   SEXP exclude_negative, 
		   SEXP above_threshold, SEXP maximum
		  ) {
   return collect_scan2(INTEGER(positions), INTEGER(length), REAL(freq), 
			INTEGER(minscan), INTEGER(maxscan), REAL(threshold), 
			INTEGER(nthres),
			INTEGER(PER_SNP), INTEGER(max_intervals)[0],
			INTEGER(max_basepair_dist)[0],
			(bool) INTEGER(exclude_negative)[0],
			INTEGER(above_threshold),
			REAL(maximum));
 }


SEXP sumscan(SEXP positions, SEXP length, SEXP freq, 
	     SEXP minscan,  SEXP maxscan, SEXP threshold, SEXP nthres,
	     SEXP PER_SNP,
	     SEXP above_threshold, SEXP Maximum) {
  sumscanC(INTEGER(positions), INTEGER(length), REAL(freq), 
	  INTEGER(minscan), INTEGER(maxscan), REAL(threshold), INTEGER(nthres),
	  INTEGER(PER_SNP),
	  INTEGER(above_threshold), REAL(Maximum));
  return R_NilValue;
}

#endif
