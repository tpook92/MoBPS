/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/


#include "Basic_miraculix.h"


#if defined compatibility_to_R_h
#include "options.h"
//#include "miraculix.h"
//#include "kleinkram.h"
//#include "extern.h"
//#include "utils_miraculix.h"
//#include "errors_messages.h"


void options_localcopy(KEY_type *KT, option_type *options){
  assert(geneticsN==9 && tuningN == 17 && messagesN == 1);
  option_type *global = &(KT->global);
  int n = global->genetics.ncentered;
  if (n > 0) {
    Long bytes = n * sizeof(*(global->genetics.pcentered));
    global->genetics.pcentered = (double*) MALLOC(bytes);
    MEMCOPY(global->genetics.pcentered, options, bytes);
  }

}

void options_localdel(KEY_type *KT){
  option_type *global = &(KT->global);
  genetics_options *gp = &(global->genetics);
  FREE(gp->pcentered);
}


void FREElocal(KEY_type VARIABLE_IS_NOT_USED *KT){
}



/*
#define PLoffset -10
SEXP setlocalRFutils(SEXP seed, SEXP printlevel) {
option_type *global;
  utilsoption_type *utils;
  WhichOptionList(true, &global, &utils);

  basic_options *opt = &(utils->basic);
   if (LENGTH(seed) > 0) opt->seed = Integer(seed, (char *) "seed", 0);
  if (LENGTH(printlevel) > 0) {
    opt->Rprintlevel = Integer(printlevel, (char *) "printlevel", 0);
    opt->Cprintlevel = opt->Rprintlevel + PLoffset;
  }
  return R_NilValue;
}
*/



// RFU INCLUDE extern "C" void loadoptionsRFU();


  
//void loadoptionsMiraculix() {
  // printf("in loadoptionsMiraculix\n");
//  BUG;
//}



#endif
