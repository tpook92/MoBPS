/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/


#include "def.h"
#include "parallel_simd.h"
#include "Basic_RandomFieldsUtils.h"
#include "options_RFU.h"
#include "compatibility.SEXP.h"
#include "zzz_RFU.h"

#include "options.h"

#define importfrom "RandomFieldsUtils"

KEY_type *PIDKEY_LOCAL[PIDMODULUS];


#if defined CALL
#undef CALL
#endif
#define CALL(what) what##_type Ext_##what = NULL
UTILSCALLS;


#if defined CALL
#undef CALL
#endif

#if defined compatibility_to_C_h
#define CALL(what) Ext_##what = (what##_type) what; 
#else 
#define CALL(what) Ext_##what = (what##_type) R_GetCCallable(importfrom, #what)
#endif


void includeXport() {
  UTILSCALLS;
} 

#if defined compatibility_to_C_h  
extern utilsoption_type OPTIONS;
#endif
KEY_type *KEYT_LOCAL(void);
void WhichOptionList(bool VARIABLE_IS_NOT_USED local, option_type **global,
		     utilsoption_type **utils // readonly
		     ) {
  //  printf("which\n   ");
  //WhichOptionsList considers 'local' whenever possible, otherwise alternatives
  option_type *G = &OPTIONS_LOCAL;
  utilsoption_type *U = NULL;
#if defined compatibility_to_R_h
  KEY_type *KT = KEYT_LOCAL();
  if (KT == NULL) BUG;
  U = &(KT->global_utils);  // readonly!
  if (local) G = &(KT->global);
#else
  U = &OPTIONS;
#endif
  if (global != NULL) *global = G;
  if (utils != NULL) *utils = U;
  //  printf("miraculix: %ld %d\n", P2LONG U, U->basic.cores);
}


void WhichToInt(int ***dummy, int **N) {
  //  printf("whichtoint\n");
  KEY_type *KT = KEYT_LOCAL();
  *dummy = &(KT->ToIntDummy);
  *N = &(KT->ToIntN);
}


void load_utilsoptions(utilsoption_type *S, int local) {
  int params[N_UTILS_PARAM];
  Ext_params_utilsoption(local, params);
  S->solve.n_pivot_idx = params[PIVOT_IDX_N];
  S->solve.pivot_idx = S->solve.n_pivot_idx == 0 ? NULL
    : (int*) MALLOC(S->solve.n_pivot_idx * sizeof(*(S->solve.pivot_idx)));
  Ext_get_utilsoption(S, local);
}



void options_localcopy(KEY_type *KT, option_type *options);

void options_copy(KEY_type *KT, bool keep_messages) {
  //  printf("options_copy\n  ");
  const bool local = false;
  option_type *optGlobal = &(KT->global);
  option_type *options;
  WhichOptionList(local, &options, NULL);
  
  messages_options m;
  if (keep_messages)
    MEMCOPY(&m, &(optGlobal->messages), sizeof(messages_options));

  MEMCOPY(optGlobal, options, sizeof(option_type));
// pointer auf NULL setzten
  if (keep_messages)
    MEMCOPY(&(optGlobal->messages), &m, sizeof(messages_options));

  options_localcopy(KT, options);
  load_utilsoptions(&(KT->global_utils), false);
}



void options_localdel(KEY_type *KT);
void options_delete(KEY_type *KT) {
  options_localdel(KT);
  Ext_del_utilsoption(&(KT->global_utils));
}





//Uint startRFU();
void startUtils() {
#if defined compatibility_to_C_h
  //  printf("RFU\n");
  startRFU();
#else
  //  printf("install\n");
    install_default();
#endif  
  includeXport();
  MEMSET(PIDKEY_LOCAL, 0, PIDMODULUS * sizeof(KEY_type *));
  //  printf("end startutils\n");
}




void KEY_type_init(KEY_type *KT) {
  //  printf("key_type_init\n  ");
  // ACHTUNG!! setzt nur die uninteressanten zurueck. Hier also gar ncihts.
  KT->next = NULL; // braucht es eigentlich nicht
  KT->doshow = true;
  KT->ToIntDummy = NULL;
  KT->ToIntN = 0;
  options_copy(KT, false);
  //  printf("key_type_init done\n");
}



KEY_type *KEYT_LOCAL() {
  //  printf("KEYT\n     ");
  int mypid;
  Ext_pid(&mypid);
   KEY_type *p = PIDKEY_LOCAL[mypid % PIDMODULUS];
  //   printf("%d %d %ld\n", mypid,  PIDMODULUS, p);
  if (p == NULL) {
     KEY_type *neu = (KEY_type *) XCALLOC(1, sizeof(KEY_type));
     assert(neu != NULL);

    PIDKEY_LOCAL[mypid % PIDMODULUS] = neu;
    neu->visitingpid = mypid;    
    if (PIDKEY_LOCAL[mypid % PIDMODULUS] != neu) { // another process had same idea
      FREE(neu);
      return KEYT_LOCAL(); // ... and try again
    }
    neu->pid = mypid;
    neu->visitingpid = 0;
    neu->ok = true;
    if (PIDKEY_LOCAL[mypid % PIDMODULUS] != neu) BUG;
    KEY_type_init(neu);
    //    printf("neu %ld\n", &(neu->global));
    return neu;
  }

   
  while (p->pid != mypid && p->next != NULL) {
      //    printf("pp = %d\n", p->pid);
    p = p->next;
  }
  //  printf("pp m = %d %d\n", p->pid, mypid);
  if (p->pid != mypid) {
    if (!p->ok || p->visitingpid != 0) {
      PRINTF("pid collision %d %d\n",  p->ok, p->visitingpid);
      BUG;
      return KEYT_LOCAL();
    }
    p->visitingpid = mypid;
    p->ok = false;
    if (p->visitingpid != mypid || p->ok) {
      return KEYT_LOCAL();
    }
   KEY_type *neu = (KEY_type *) XCALLOC(1, sizeof(KEY_type));
   neu->pid = mypid;
    if (!p->ok && p->visitingpid == mypid) {
      p->next = neu;
      p->visitingpid = 0;
      p->ok = true;      
      //      printf("neuX %ld\n", &(neu->global));
     return neu;
    }
    FREE(neu);
    p->visitingpid = 0;
    p->ok = true;
    KEY_type_init(neu); 
   return KEYT_LOCAL();
  }  
  //   printf("KEYT %ld\n", &(p->global));
   return p;
}


void FREElocal(KEY_type  *KT);
void FREEglobal() {
  //  printf("free keyt\n");
  KEY_type *KT = KEYT_LOCAL(); 
  FREE(KT->ToIntDummy);
  KT->ToIntN = 0;
  FREElocal(KT);
}


void KEY_type_all_delete(KEY_type **S) {
  KEY_type *KT = *S;
  options_delete(KT);
  FREEglobal();
  UNCONDFREE(*S);
}



void PIDKEY_LOCAL_DELETE() {
  for (int kn=0; kn<PIDMODULUS; kn++) {
    KEY_type *KT = PIDKEY_LOCAL[kn];
    while (KT != NULL) {
      KEY_type *q = KT;
      KT = KT->next;
      KEY_type_all_delete(&q);
    }
    PIDKEY_LOCAL[kn] = NULL;
  }
}



#if defined compatibility_to_R_h  


void finalizeLoptions(int local) {  
  if (!local) {
    //    option_type *options;
    //   utilsoption_type *utils;
    // WhichOptionList(local, &options, &utils);
  }
}


void setoptionsRFUlocal(int i, int j, SEXP el, char name[LEN_OPTIONNAME], 
		       bool isList, bool local) {
  //  printf("setoptionsRFU\n");
   utilsoption_type *utils;
   WhichOptionList(local, NULL, &utils);
   if (!local && Ext_parallel()) 
     ERR1("Option '%.25s' can be set only through 'RFoptions' at global level",
	  allLoptions[i][j]);
   Ext_setoptionsRFU(i, j, el, name, isList, utils);
}


void getoptionsRFUlocal(SEXP sublist, int i, bool local) {  
  //  printf("get local RFU %d\n", i);
    utilsoption_type *utils;
   WhichOptionList(local, NULL, &utils);
   Ext_getoptionsRFU(sublist, i, utils);
}


Uint startLocal(int cores);


#ifdef __cplusplus
extern "C" {
#endif
  
void detachoptions() {
  PIDKEY_LOCAL_DELETE();
  Ext_detachRFUoptions(prefixLlist, prefixLN);
}

  
SEXP LocalOptions(SEXP options) {
  return Ext_RFUoptions(options, (char*) pkg);
}

SEXP copyoptions() {
  //  printf("copy keyt\n");
  KEY_type *KT = KEYT_LOCAL();
  options_copy(KT, true);
  return R_NilValue;
}  

void loadoptions(int *n) {   
  MEMSET(PIDKEY_LOCAL, 0, PIDMODULUS * sizeof(KEY_type *));
#if defined DO_PARALLEL
  Uint simd_info =
    startLocal(*n != NA_INTEGER && *n > 0 ? *n : 1); // NA_INTEGER OK
 #else
  if (*n < 0) BUG;
  Uint simd_info =  startLocal(1);
#endif
   
  Ext_attachRFUoptions((char *) pkg, prefixLlist, prefixLN,
		       allLoptions, allLoptionsN,
		       setLoptions, getLoptions, finalizeLoptions, NULL,
		       setoptionsRFUlocal, getoptionsRFUlocal,
		       -10, false,
		       GPU_NEEDS, // from configure.ac
		       simd_info,
		       LOCAL_VERSION,
		       RFU_VERSION,
		       MEMisALIGNED_NaN
		       );
  // Ext_attachSetNGet((char*) "miraculix", (char *) "RandomFieldsUtils",
  //		    setoptionsRFU, getoptionsRFU);
  finalizeLoptions(false);
}


#ifdef __cplusplus
}
#endif


#endif
