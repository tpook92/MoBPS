/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/


#ifndef miraculix_2bit_H
#define miraculix_2bit_H 1

//#include "MX.h"



#define DeclareVersion2(NR,SU,SV,SM)					\
  Ulong scalar_2v##NR(cross_scalar_args(V)) SU \
    void multi_2v##NR(cross_multi_args(V)) SV		\
    void multi2x2_2v##NR(unit_t V *x, unit_t V *y, Long V cols, \
			 Long V blocks, Long V lda,			\
			 double V *ans) SV				\
    Ulong colSums2v##NR(colrowSums_args(V)) SU	\
    /* subsequently function working only under bigendian */		\
    void TwoBithaplo2geno##NR(unit_t V * Code, Long V rows, Long V cols, \
			      Long V ldH, int V cores,			\
			      unit_t V *A, Long V ldAns) SV		\
    void rowSums_2v##NR(colrowSums_args(V)) SV				\
  void coding_2v##NR(codingSEXP_args(V)) SV				\
  void coding_2v##NR##_4Byte(coding_args(V)) SV			\
  void coding_2v##NR##_1Byte(coding_args(V)) SV			     \
  void trafo2Geno1Geno##NR(unit_t V  *OLD, Long V rows, Long V cols, \
			     Long V oldLDA, unit_t V *ANS, Long V ldAns) SV \
      void TrafoFileValues_##NR(unit_t V *CodeFile, Long V blocks) SV


#define V 
#define NICHTS ;
DeclareVersion2(512,NICHTS,NICHTS,NICHTS)
DeclareVersion2(256,NICHTS,NICHTS,NICHTS)
DeclareVersion2(128,NICHTS,NICHTS,NICHTS)
DeclareVersion2(64,NICHTS,NICHTS,NICHTS)
#if defined V 
#undef V
#undef NICHTS
#endif

void Init2();

Long Lda2Bit(Long rows, Long ldAbitalign);
colSums_header(2);


coding_header(_4Byte, 2);
coding_header(_1Byte, 2);
coding_header(_4Byte, 2trans);
coding_header(_1Byte, 2trans);

bool coding_2v128_I(unit_t *pM, Long blocks, Long rest, uint32_t* ans);

get_matrix_header(_4Byte,2);
get_matrix_header(_1Byte,2);


genoVector_header(double, double, double, 2matrix256);
genoVector_header(double, double, double, 2v256);
vectorGeno_header(double, double, double, 2v256);

vector_fctn_header(LongDouble, LongDouble, 2);
vector_fctn_header(double, double, 2);
vector_fctn_header(Ulong, Ulong, 2);

void rowSums2(colrowSums_args());


void zeroGeno2(SEXP SxI, Uint *SnpsList, Uint lenSnps,
	       Uint *IndivList, Uint lenIndiv,
	       basic_options *opt);



void crossprod2v64(unit_t * M, Long rows, Long cols, Long lda,
		   int VARIABLE_IS_NOT_USED cores, double *A);
void crossprod2v32(unit_t * M, Long rows, Long cols, Long lda,
		   int VARIABLE_IS_NOT_USED cores, double *A);


void TwoBithaplo2geno2(unit_t * Code, Long rows, Long cols,
		       Long lda, int cores, unit_t *A, Long ldAns);

sparsevectorGeno_header(2Bit);

int BitsPerCode2Bit();
typedef void (*fill_t)(Uint *code, int shift, Uint *code2, Long totalbits);
void fillIn256(Uint *code, int shift, Uint *code2, Long totalbits);
void fillIn128(Uint *code, int shift, Uint *code2, Long totalbits);
void  fillIn64(Uint *code, int shift, Uint *code2, Long totalbits);

		   
#endif
