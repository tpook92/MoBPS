/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/


#define NO_OMP 1
#include "Basic_miraculix.h"
#include "xport_import.h"
#include "MXinfo.h"


bool debug = false;

#define START 0
#define END 1
#define LEVEL 2
#define IDX(N) (3 * (N))
#define DELETED 0

#define COLLECT(exclude_negative, DO, Check)				\
  int 								\
    nthr = *nthres,							\
    len = *length,							\
    *pos = positions,							\
    min = *minscan,							\
    max = *maxscan,							\
    perSNP = *PER_SNP							\
    ;									\
  double mass;								\
									\
 /* // printf("Len=%d %d %d perSNP=%d\n", len, min, max, perSNP);*/	\
  for (int i = 0 ; i<len; i++) {					\
    if (exclude_negative) for (; i<len; i++) if (freq[i] >= 0) break;  \
    if (i >= len) break;						\
    int pos_i = pos[i];							\
    mass = 0.0;								\
    for (int j=i; j<len; j++) {						\
       double freq_j = freq[j];						\
      mass += freq_j;							\
      Long laenge = perSNP ? j-i+1 : pos[j] - pos_i + 1;		\
      if (laenge < min) {						\
	continue;							\
      }									\
      if (max > 0 && laenge > max) {			\
        if (debug) { PRINTF("break %d %d\n", max, (int) laenge);}	\
	break;								\
      }									\
      DO;								\
    }									\
    Check;								\
    for (; i<len; i++) if (freq[i] < 0) break;				\
  }					

  
void scanC(int *positions, int *length, double  *freq, int *minscan,
	   int *maxscan, double *threshold, int *nthres, int *PER_SNP,
	   int *above_threshold,  double *maximum) {
  double maxi = -1e-40;
  int k;
  bool toomanyintervals = false;
  for (k=0; k<*nthres; above_threshold[k++] = 0);

  COLLECT(false,							
	  if (mass >= threshold[0]) {					\
	    int d=0;	/* // printf("%10g %d %10g\n", mass, d, threshold[d]);*/ \
	    while (nthr > d && mass >= threshold[d]) above_threshold[d++]++; \
	  }								\
	  if (mass > maxi) maxi = mass;					\
	  , if (above_threshold[0] < 0) toomanyintervals = true;);
  *maximum = maxi;
  if (toomanyintervals) above_threshold[0] = -1;
}

		

SEXP collect_scan(int *positions, int *length, double  *freq, int *minscan,
		  int *maxscan, double *threshold, int *nthres,
		  int *PER_SNP, 
		  // additional return values:
		  int *areas,  double *value) {
  int n = 0,
    *a = areas;
  SEXP Res;
  
  COLLECT(false,					  \
      if (mass >= threshold[0]) {			  \
	int d=1;					  \
	a[START] = pos[i];				  \
	a[END] = pos[j];				  \
	while (nthr>d && mass >= threshold[d]) d++;	  \
	a[LEVEL] = d; /* R referencing starting with 1 */ \
	value[n] = mass;				  \
	n++;						  \
	a += 3;						  \
      }							  \
      , {});
  
  PROTECT(Res = allocMatrix(INTSXP, 3, n));
  int *res = INTEGER(Res);
  MEMCOPY(res, areas, 3 * sizeof(*res) * n);

  for (int i=0; i<n; i++) {
    int level = res[IDX(i) + LEVEL];
    if (res[IDX(i) + LEVEL] == DELETED) continue; 
    for (int j=i+1; j<n; j++) {
      if (res[IDX(j) + START] == DELETED || level > res[IDX(j) + LEVEL])
	continue;  
      if (res[IDX(i) + END] < res[IDX(j) + START]) break;
      // NOTE that value of res[IDX(i) + END] is changing
      if (res[IDX(i) + END] < res[IDX(j) + END])
	res[IDX(i) + END] = res[IDX(j) + END];
      if (res[IDX(i) + LEVEL] == res[IDX(j) + LEVEL]) {
	res[IDX(j) + START] = res[IDX(j) + END] = res[IDX(j) + LEVEL] = DELETED;
      }
    }
  }

  UNPROTECT(1);
  return Res;
}



  

SEXP collect_scan2(int *positions, int *length, double  *freq, int *minscan,
		   int *maxscan, double *threshold, int *nthres,
		   int *PER_SNP, 
		   int max_intervals, int max_basepair_dist,
		   bool exclude_negative,
		   // additonal return values
		   int *above_threshold, double *maximum) {
  int n = 0, k,
    threemaxI = 3 * max_intervals;
  int *res = (int*) MALLOC(sizeof(int) * threemaxI);
  int *a = res;
  double maxi = -1e-40;
  bool not_exclude = !exclude_negative;

  for (k=0; k<*nthres; above_threshold[k++] = 0);

  COLLECT(exclude_negative,						\
	  if (j > i && pos[j] > pos[j-1] + max_basepair_dist) break;	\
	  if (mass >= threshold[0] && (not_exclude || freq_j>=0.0)) {	\
	    if (mass > maxi) maxi = mass;				\
	    int m;							\
	    int d=1;							\
	    a[START] = pos_i;						\
	    a[END] = pos[j];						\
	    while (nthr>d && mass >= threshold[d]) d++;			\
	    a[LEVEL] = d; /* R referencing starting with 1 */		\
	    bool del = false;						\
	    for (m=0; m<n; ) {						\
	      int idxm = IDX(m++);					\
	      assert(idxm + LEVEL < threemaxI && idxm + END < threemaxI); \
	      if (res[idxm + LEVEL] > a[LEVEL] ||			\
		  res[idxm + END] <  pos_i) continue;			\
	      if (res[idxm + END] < a[END]) res[idxm + END] = a[END];	\
	      if (res[idxm + LEVEL] == a[LEVEL]) {del=true; break;}	\
	    }								\
	    if (!del) {							\
	      for (k=0; k<d; above_threshold[k++]++);			\
	      n++;							\
	      if (n >= max_intervals) {					\
		ERR0("too many intervals found; analysis stopped.");	\
	      }								\
	      a += 3;							\
	    }								\
	  }								\
	  , {});
  
  *maximum = maxi;
  SEXP Res;
  PROTECT(Res = allocMatrix(INTSXP, 3, n));

  if (n>0) MEMCOPY(INTEGER(Res), res, 3 * n * sizeof(*res));
  FREE(res);
 
  UNPROTECT(1);
  return Res;
}


void sumscanC(int *positions, int *length, double  *freq, 
	     int *minscan,  int *maxscan, double *threshold, int *nthres,
	     int *PER_SNP,
	     int *above_threshold,  double *maximum) {
  double res = -1e-40;
  int k;
  for (k=0; k<*nthres; above_threshold[k++] = 0);
  if (!*PER_SNP) ERR0("sumscan only for 'perSNP=TRUE'");

  COLLECT(false,							\
     if (mass >= threshold[0]) {					\
       int *cp = above_threshold;					\
       for (int d=0; d<nthr; d++) {					\
	   if (mass < threshold[d]) break;				\
	   for (k=i; k<=j; cp[k++]++);					\
	   cp+=len;							\
       }								\
     }									\
     if (mass > res) res = mass;					\
     , {});
    *maximum = res;
}
							
  
