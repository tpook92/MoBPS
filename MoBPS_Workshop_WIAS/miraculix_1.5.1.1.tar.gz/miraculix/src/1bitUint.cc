/*
 Authors 
 Guido Moerkotto
 maintained and modified by Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Guido Moerkotte, Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/


#define MY_VARIANT 32
#include "1bitDef.h"

#include "haplogeno.h"
#include "TemplateUint.h"
#include "bitUint.h"
#include "1bit.h"



Long Lda1Bit(Long rows, Long LDAbitalign){
  return (LDAbitalign ? 2 : 1) * LDAalignBitSnps(rows * BitsPerCode);
}

int BitsPerCode1Bit() { return BitsPerCode; }

#define coding1_end(UINT) \
  for (Long i=0; i<deltaIndiv; i++) {\
    unit_t  *code = ans + i * ldAns, \
      *dode = Dode + i * ldAns;\
    UINT *mm = (UINT*) (((Uchar *) M) + i * LdMByte);	\
    bool w = false;\
    for (Long j=0; j<allUnits; j++) {\
      unit_t C = 0,\
	D=0;\
      int end = j == allUnitsM1 ? rest : BitsPerUnit;		\
      for (int shft = 0; shft < end; shft+=BitsPerCode) {	\
	w |= *mm > 2;\
	C |= (unit_t) ((*mm == 1) << shft);	\
	D |= (unit_t) ((*mm == 2) << shft);	\
	mm = (UINT *) (((Uchar*) mm) + EinsByte);	\
      }\
      code[j] = C;\
      dode[j] = D;\
    }\
    total += w;\
  }\
  if (total > 0) ERR0("1bit#64: values outside 0,1,2");\
}

coding_start(_4Byte,1)
unit_t  *Dode = ans + ldAns * cols;
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) reduction(+:total) schedule(static)
#endif
coding1_end(_4Byte)


coding_start(_1Byte,1)
unit_t  *Dode = Ans + ldAns * cols;
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) reduction(+:total) schedule(static)
#endif
coding1_end(_1Byte)



colSums_start(1)
  unit_t *T = code + lda * cols;
  for (Long i=0; i<cols; i++) {
    unit_t *c = code + i * lda;
    unit_t *TT = T + i * lda;
    Ulong sum = 0,
      twice = 0;
    for (Long j=0; j<units; j++) { 				
      unit_t s = c[j],
	t = TT[j];						
      for (Long u=0; u<CodesPerUnit; u++) {			
	sum += s & CodeMask;
	twice += t & CodeMask;
	s >>= BitsPerCode;					
	t >>= BitsPerCode;					
      }					
    }
    if (sums != NULL) sums[i] = sum + (twice << 1);
    total += sum + (twice << 1);
  }						  
  return total;			  
}


#define get_matrix1_end(UINT)			\
  for (Long i=0; i<cols; i++) {\
    UINT *a = (UINT*) (((Uchar *) Ans) + i * LDAnsByte);	\
    unit_t *C = code + i * lda,	       \
      *D = D0 + i * lda;				\
    for (Long j=0; j<=allUnitsM1; j++, C++, D++) {	\
      unit_t c = *C,					\
	d = *D;								\
      int end_k = j==allUnitsM1 ? rest_k : CodesPerUnit;		\
      for (int k=0; k < end_k; k++) {					\
	*a = (c & CodeMask) + ((d & CodeMask) << 1);		\
	a = (UINT *) (((Uchar*) a) + EinsByte);		\
	c >>= BitsPerCode;			    \
	d >>= BitsPerCode;			    \
      }						    \
    }						    \
  }						    \
  }


get_matrix_start(_4Byte,1)			   
  unit_t *D0= code + cols * lda;
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
get_matrix1_end(_4Byte)


get_matrix_start(_1Byte,1)			   
  unit_t *D0= code + cols * lda;
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
get_matrix1_end(_1Byte)



void zeroGeno1(SEXP SxI, Uint *SnpsList, Uint lenSnps,
	       Uint *IndivList, Uint lenIndiv,
	       basic_options *opt) {
  int  VARIABLE_IS_NOT_USED cores = GreaterZero(opt->cores);
  extractInfo(SxI);
  ASSERT_LITTLE_ENDIAN;
 if (transposed) {
    Uint tmp = lenSnps; lenSnps=lenIndiv; lenIndiv=tmp;
    Uint *Tmp = SnpsList; SnpsList=IndivList; IndivList=Tmp;
  }
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
   for (Long i=0; i<lenIndiv; i++) {
    if (IndivList[i] >= cols) continue;
    unit_t *C1 = code + IndivList[i] * lda,
      *C2 = C1 + lda * cols;
    for (Long s=0; s<lenSnps; s++) {
      if (SnpsList[s] >= rows) continue;
      Long j;
      unit_t blend;
      PositionCode(SnpsList[s], &j, &blend);
      C1[j] &= ~blend;
      C2[j] &= ~blend;
    }
  }
}


// LDA in Units!

