/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/

#ifndef miraculix_haplogeno_H
#define miraculix_haplogeno_H 1

#define IsExternal 0 // currently only for information
#define TotalSumIndex 1
#define RowFreqNorm2Index 2
#define RowSigmaSqIndex 3
#define RowSumFreqIndex 4
#define RowFreqIndex 5 // rows
// never change: see calculateFreq P + RowFreqIndex +r+dI:
#define RowSumIndex (RowFreqIndex + rows) // rows
#define RowFreqSxIIndex (RowFreqIndex + 2 * rows) // cols
#define startColIndices RowFreqIndex + 2 * rows + cols//NEVER USE OUTSIDE FILE!!
#define ColIndex (startColIndices)
#define ColIsExternal (IsExternal + startColIndices)
#define ColTotalSumIndex (TotalSumIndex + startColIndices)
#define ColFreqNorm2Index (RowFreqNorm2Index + startColIndices)
#define ColSigmaSqIndex (RowSigmaSqIndex + startColIndices)
#define ColSumFreqIndex (RowSumFreqIndex + startColIndices)
#define ColFreqIndex (RowFreqIndex + startColIndices) // cols
// never change: see calculateFreq P + RowFreqIndex +r+dI:
#define ColSumIndex (RowFreqIndex + startColIndices * 2) // cols
#define ColFreqSxIIndex (RowFreqIndex + startColIndices * 3) // rows
#define TotalLengthIndices (ColFreqSxIIndex + rows)

unit_t *Align(SEXP SxI, basic_options *opt);
Long GetLDA(Long rows, coding_type coding, Long ldbitalign);
Long GetNatLDA(Long rows, coding_type coding);
Long GetLDAbitalign(coding_type coding);
Long totalMem(Long cols, Long lda, coding_type coding);
Long totalMem(Long cols, Long lda, coding_type coding, bool OneHaploOnly);
Long totalMem(Long cols, Long lda, coding_type coding, 
	      bool OneHaploOnly, bool relaxed);
SEXP createSNPmatrix(Long snps, Long individuals, coding_type coding,
		     usr_bool transposed, bool add_transposed_matrix,
                     int variant, Long ldAbitalign,
		     bool OneHaploOnly, SEXP V,
                     option_type *global, utilsoption_type *utils);  
SEXP createSNPmatrix(Long snps, Long individuals,
		     coding_type coding,
		     usr_bool transposed, bool add_transposed_matrix,
		     int variant, Long LDAbitalign,
		     option_type *global, utilsoption_type *utils);
SEXP createSNPmatrix(Long snps, Long individuals, coding_type coding,
                     int variant, Long ldAbitalign,
                     option_type *global, utilsoption_type *utils);
SEXP CompleteCodeVector(Long snps, Long individuals, coding_type coding,
			usr_bool transposed, bool add_transposed_matrix,
			int variant, Long ldAbitalign, bool OneHaploOnly,
			option_type*global, utilsoption_type *utils,
			void* pointer, void* nextpointer, 
			SEXP SxI);

SEXP CreateEmptyCodeVector(Long snps, Long individuals, coding_type coding,
			   usr_bool transposed, bool add_transposed_matrix,
			   int variant, Long ldAbitalign, bool OneHaploOnly,
			   option_type *global, utilsoption_type *utils);


void allInfo(Long * info);
void allInfo(SEXP M);

Long calculateAlignedMem(Long memInU, coding_type coding);

Long GetBytesPerBlock(coding_type coding, int variant);
Long GetCodesPerBlock(coding_type coding, int variant);
Long GetCodesPerUnit(coding_type coding); // OK

Ulong allele_freq_double(SEXP SxI, bool col_freq,
			option_type *global, utilsoption_type *utils,
			double *sums, double *ans);

Ulong allele_freq_LongDouble(SEXP SxI, bool col_freq,
			    option_type *global, utilsoption_type *utils,
			    LongDouble *sums, LongDouble *ans);


LongDouble getTotalSum(SEXP SxI);
LongDouble *getRowFreq(SEXP SxI);
LongDouble *getRowSum(SEXP SxI);
LongDouble *getRowFreqSxI(SEXP SxI);
LongDouble getRowFreqNorm2(SEXP SxI);
LongDouble getRowSigmaSq(SEXP SxI);
LongDouble getRowSumFreq(SEXP SxI);
LongDouble *getColFreq(SEXP SxI);
LongDouble *getColSum(SEXP SxI);
LongDouble getColSumFreq(SEXP SxI);
LongDouble *getColFreqSxI(SEXP SxI);
LongDouble getColFreqNorm2(SEXP SxI);
LongDouble getColSigmaSq(SEXP SxI);

void calculateFreq(SEXP SxI, option_type *global, utilsoption_type *utils);
void calculateFreq(SEXP SxI, double *externalFreq,
		    option_type *global, utilsoption_type *utils);

void crossprod(unit_t * Code, Long rowsOrig, Long cols, Long lda,
	       coding_type coding, int variant,
	       Long logRowGroupSize, bool smoothRowGroupSize,
	       Long colGroupSize, basic_options *opt,
	       double *A);

void crossprodI(unit_t * Code, Long rows, Long cols,  Long lda,
		coding_type coding, int variant,
		centering_type centered, normalizing_type normalized,
		bool squared,
		LongDouble *Precision,
		basic_options *opt, tuning_options *tuning,
		double *A);

double *crossprod(unit_t * Code, Long rows, Long cols,  Long lda,
		  coding_type coding, int variant,		  
		  centering_type centered, normalizing_type normalized,
		  bool squared,
		  LongDouble *PP,
		  basic_options *opt, tuning_options *tuning);



int t_crossprodI(unit_t * Code, Long rows, Long cols, Long lda,
		 coding_type coding, int variant,
		 centering_type centered, normalizing_type normalized,
		 bool squared,
		  LongDouble *Prec,
		   basic_options *opt,
		 tuning_options *tuning,
		 double *A);


void sparsevectorGeno(SEXP SxI,
		      bool tSxI,
		      double *valueB,
		      int nIdx, // 2nd dimension of sparse; == length(rowIdxB)
		      int *rowIdxB,
		      int *colIdxB,
		      bool tSparse,
		      option_type *global, utilsoption_type *utils,
		      double *C,
		      Long Ldc);
void sparsevectorGeno(Uchar *code,
		      Long nrow_code,
		      Long ncol_code,
		      Long lda,
		      coding_type coding,
		      double *valueB,
		      int nIdx, // 2nd dimension of sparse; == length(rowIdxB)
		      int *rowIdxB,
		      int *colIdxB,
		      bool tSparse,
		      option_type *global, utilsoption_type *utils,
		      double *C, 
		      Long Ldc);

void SetMatrixClass(SEXP SxI, bool haplo, option_type *global);

SEXP SNPbind(SEXP S1, SEXP S2);

#endif

