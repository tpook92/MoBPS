
/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/




#ifndef miraculix_vector_matrix_templateUint_H
#define miraculix_vector_matrix_templateUint_H 1

#include "Template.h"


#define coding_start(UINT,NAME)						\
  coding_header(UINT,NAME) {						\
  if (start_row % CodesPerUnit != 0) BUG;				\
  Long  cur_rows = end_row - start_row,					\
    allUnits = Units(cur_rows),						\
    allUnitsM1 = allUnits - 1;						\
  unit_t *ans = Ans + start_row / CodesPerUnit + start_col * ldAns; \
  Long deltaIndiv = end_col - start_col;				\
  Ulong total = 0;							\
  int rest = (int) ((cur_rows - allUnitsM1 * CodesPerUnit) * BitsPerCode); \
  Long LdMByte = transposed == False ? ldM * BytesPerUnit : sizeof(UINT); \
  Long EinsByte = transposed == False ? sizeof(UINT) : ldM * BytesPerUnit;


#define coding_end(UINT,TRAFO)						\
  for (Long i=0; i<deltaIndiv; i++) {					\
    unit_t *code = ans + i * ldAns;					\
    UINT *mm = (UINT*) (((Uchar *) M) + i * LdMByte);	\
    bool w = false;							\
    for (Long j=0; j<allUnits; j++) {					\
      unit_t C = 0;							\
      int end = j == allUnitsM1 ? rest : BitsPerUnit;			\
      for (int shft = 0; shft < end;shft+=BitsPerCode) {	\
	w |= *mm > 2;							\
	if (w > 0) {							\
	  PRINTF("i=%ld<%ld %ld<%ld %d<%d : %u %ld\n",		\
		 ALONG i, ALONG deltaIndiv, ALONG j, ALONG allUnits, shft,end, (unsigned int) *mm, ALONG sizeof(UINT)); \
	  BUG;								\
	}								\
	C |= (unit_t) ((TRAFO) << shft);				\
	mm = (UINT *) (((Uchar*) mm) + EinsByte);			\
      }									\
      code[j] = C;							\
    }									\
    total += w;								\
    }									\
  if (total > 0) ERR1("2bit#32: at least %ld values outside 0,1,2",\
		      ALONG total);	/*// long OK */		   \
  }






#define get_matrix_start(UINT,NAME)					\
  get_matrix_header(UINT,NAME) {					\
  /* if transposed == True the transposed matrix is returned */		\
  if (false)printf("get_matrix_start %d %ld\n",transposed,ALONG sizeof(UINT)); \
  unit_t VARIABLE_IS_NOT_USED *maxa = Ans + ldAns * cols;		\
									\
  Long allUnitsM1 = Units(rows) - 1;					\
  int VARIABLE_IS_NOT_USED rest_k = (int) (rows - allUnitsM1 * CodesPerUnit);\
  Long LDAnsByte = transposed == False ? ldAns * BytesPerUnit : sizeof(UINT); \
  Long EinsByte = transposed == False ? sizeof(UINT) : ldAns * BytesPerUnit;

#define get_matrix_end(UINT,TRAFO)				\
  for (Long i=0; i<cols; i++) {				\
    UINT *a = (UINT*) (((Uchar *) Ans) + i * LDAnsByte);	\
    if (false) printf("i=%ld %ld; lda=%ld %ld\n", ALONG i, ALONG cols, ALONG lda, ALONG allUnitsM1); \
    unit_t *C = code + i * lda;				\
    for (Long j=0; j<=allUnitsM1; j++, C++) {		\
      if (false) printf("i=%ld %ld; j=%ld %ld\n", ALONG i, ALONG cols, ALONG j, ALONG allUnitsM1); \
      unit_t twobit = *C TRAFO;						\
      int end_k = j==allUnitsM1 ? rest_k : CodesPerUnit;		\
      if (false)  printf("i=%ld j=%ld end_k=%d\n", ALONG i, ALONG j, end_k); 	\
      for (int k=0; k < end_k; k++) {				\
	if ((unit_t*) a >= maxa) BUG;				\
	*a = twobit & CodeMask;					\
	a = (UINT *) (((Uchar*) a) + EinsByte);		\
	twobit >>= BitsPerCode;				\
      }							\
    }							\
  }							\
  }


#define vector_fctn_start(TYPE, NAME)\
  vector_fctn_header(TYPE, TYPE, NAME)  {  \
  vector_##TYPE##_t vD = NULL;


#define vector_fctn_end \
  return vD


#define vectorGeno_start(TYPE, TRDTYPE, ENDTYPE, NAME)	\
  vectorGeno_header(TYPE,TRDTYPE,ENDTYPE,NAME)	 {	\
  int VARIABLE_IS_NOT_USED cores = GreaterZero(opt->cores);	\
  Long unitsM1 = Units(rows) - 1;				\
  int VARIABLE_IS_NOT_USED rest = (int) (rows - unitsM1 * CodesPerUnit)	\


#define vectorGeno_fctn(TYPE, TRDTYPE, ENDTYPE, TRAFO)			\
  for (Long r=0; r < repetV; r++) {					\
    for (Long i=0; i<cols; i++) {	\
      TYPE *vv = V + r * ldV;						\
      unit_t *pC = code + i * lda;					\
      ENDTYPE *a = Ans + r * ldAns /* cols */;			\
      LongDouble *aPF = colFreq;				\
      TRDTYPE sum0 = 0;						\
      for (Long j=0; j<=unitsM1; j++, pC++) {				\
	unit_t twobit = *pC TRAFO;					\
	int end = j == unitsM1 ? rest : CodesPerUnit;			\
	if (aPF == NULL) {						\
	  for (int k=0; k<end; k++, twobit >>= BitsPerCode, vv++)	\
	    sum0 +=  (TRDTYPE) (*vv) * (TRDTYPE) (twobit & CodeMask);	\
	} else {							\
 	  for (int k=0; k<end; k++, twobit >>= BitsPerCode, vv++, aPF++) \
	    sum0 += (TRDTYPE) (*vv) *					\
	      ((TRDTYPE) (twobit & CodeMask) - (TRDTYPE) 2 * (TRDTYPE)(*aPF)); \
	}								\
      }									\
      a[i] = (ENDTYPE) sum0;						\
    }									\
  }									\
  }


#if defined colSums_start
#undef  colSums_start
#endif
#define colSums_start(NAME)			\
  colSums_header(NAME) {			\
  Ulong VARIABLE_IS_NOT_USED total = 0;		\
  Long VARIABLE_IS_NOT_USED units = Units(rows); 


#define colSums_fctn(TRAFO)						\
  for (Long i=0; i<cols; i++) { /* ok */				\
    unit_t *pcode=code + lda * i;					\
    Ulong sum = 0;							\
    for (Long j=0; j<units; j++) {					\
      unit_t s = pcode[j];						\
      for (Uint u=0; u<CodesPerUnit; u++) {				\
	const unit_t value = s & CodeMask;				\
	sum += TRAFO(value);						\
	s >>= BitsPerCode;						\
      }									\
    }									\
    if (sums != NULL) sums[i] = sum;					\
    total += sum;							\
  }									\
  return total;								\
  }



#define vector_start(TYPE, NAME)					\
  vector_header(TYPE, NAME) {						\
 
  
#define vector_end							\
  vD(code, rows, cols, coding, lda, variant, colFreq,		\
     V, repetV, ldV, opt, tuning, ans, ldAns)				\
  


#endif
