
/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/

/// sysconf (_SC_NPROCESSORS_ONLN) // number of cores available
// int get_nprocs (void) // dito

#ifndef Miraculix_def_H
#define Miraculix_def_H 1


//#define DO_FIXED_POSIX 1
//#define DO_POSIX 1
#define REPLACE_ME 1


//int WeakPerformance = 110;   // in %
//int HyperPerformance = 50;    // in %
//int HyperTurnedOn = 33;   // in %
//bool STICK= false;
//int RoughRowChunk = 35000;
//int maxSliceLen = 200;  // 100
//double coreFactor=2.5; // 5


/*

Wageningen/run_gcc snps=128000 indiv=1360 repetV=0 cores=-14 floatLoop=0 meanSubst=0 missingsFully0=1 centered=0 trials=3 variant=256 coding=2 SxInotVmean=0 mode=3 SNPmode=3 cmp=0 sparse=0 rowMode=-4 colMode=0 fillMode=0 weak=110 hyper=0 turnedon=33 stick=0 chunk=35000 slicelen=200 corefactor100=250 printlevel=1  ## posix


*/





//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#define STAND_ALONE 1

#if ! defined pkg
#define pkg "miraculix" // RFU DELETE
#endif

// #define this_file this_file_in_miraculix

#define MIRACULIX_VERSION 11
#define LOCAL_VERSION MIRACULIX_VERSION

#define MaxUnitsPerAddress 2U // OK
#define MY_LDABITALIGN_2BIT 512U
#define MY_LDABITALIGN_ONEBYTE 256U
#define MY_LDABITALIGN_PLINK 256U
#define MAX_LDABITALIGN 512U


#if defined BitsPerCode && ! defined MY_CODING
#if BitsPerCode == 1
#define MY_CODING OneBitGeno
#define MY_LDABITALIGN MY_LDABITALIGN_2BIT
#elif BitsPerCode ==  2
#define MY_CODING TwoBitGeno
#define MY_LDABITALIGN MY_LDABITALIGN_2BIT
#elif BitsPerCode ==  3
#define MY_CODING ThreeBit
#elif BitsPerCode ==  8
#define MY_CODING OneByteGeno
#define MY_LDABITALIGN MY_LDABITALIGN_ONEBYTE
#elif BitsPerCode == 32
#define MY_CODING FourByteGeno
#define MY_LDABITALIGN 32 
#else
#error unknown BitsPerCode
#endif
#endif

#include "Automiraculix.h"


//// 1
//
//#define.*SCHLATHER_DEBUGGING 1
//#define SHOWFREE true

#if defined  SCHLATHERS_MACHINE
//
#define INTEGERX INTEGER
//#define INTEGERX(A) __extension__ ({printf("int: %s line %d\n", __FILE__, __LINE__); INTEGER(A);})
//
//#u ndef INDIVIDUALS
//#define INDIVIDUALS  __extension__ ({printf("indiv: %s line %d\n", __FILE__, __LINE__); 2;})

//#u ndef LDA
//#define LDA __extension__ ({printf("ldat: %s line %d\n", __FILE__, __LINE__); 11;})

#else
#define INTEGERX INTEGER
#endif

// #define DEBUG 1
// #define GPU_STANDALONE 1




//// 1

// #define assert(X)  if (__extension__ (X)) {} else { int *x_x = (int*) ma lloc(1); fr ee(x_x); x_x[0] = 5; printf("%d\n", 1.0 / *x_x); }

#if ! defined assert
#define assert(X) if (__extension__ (X)) {} else 			\
    RFERROR4("'assert' failed in function '%.50s' (%.50s, line %d) %.200s.", \
	     __FUNCTION__, __FILE__, __LINE__, CONTACT)
#endif


extern bool debugging;


#endif
