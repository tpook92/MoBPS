
/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/

#include "Basic_miraculix.h"
#include "options.h"
#include "haplogeno.h"
#include "MXinfo.h"
#include "Template.h"
#include "5codes.h"
#include "plink.h"
#include "Vector.matrix.h"
#include "GPUapi.h"
#include "intrinsics_specific.h"
#include "transform.h"
#include "miraculixAPI.h"


#define MY_VARIANT 8



//#define CpByteplink 4
//#define CpByte 5
//#define BitsPerCodeplink 2



#if !defined CUDA
void plink2gpu(char VARIABLE_IS_NOT_USED  *plink, // including three-byte
	       // header, size in bytes: ceiling(indiv/4) * snps + 3
    char VARIABLE_IS_NOT_USED *plink_transposed, // @JV: If I remember correctly, you need to
                            // transpose the matrix anyway? so it should be
                            // easier to have this as an argument, and not
                            // transpose it again on the GPU
    int VARIABLE_IS_NOT_USED snps,
    int VARIABLE_IS_NOT_USED indiv, // actual number of individuals, not N/4 rounded up
	       double VARIABLE_IS_NOT_USED *f,  // vector guaranteed to be of length  dsnps
    int VARIABLE_IS_NOT_USED n, 
    void VARIABLE_IS_NOT_USED **GPU_obj) {
  BUG;
    }
void dgemm_compressed_gpu(
    bool VARIABLE_IS_NOT_USED trans, //
    void VARIABLE_IS_NOT_USED *GPU_obj,
    //    double *f,
    int VARIABLE_IS_NOT_USED n,     // number of columns of matrix B
    double VARIABLE_IS_NOT_USED *B,  // matrix of dimensions (nsnps, n) if trans =
                // "N" and (nindiv,n) if trans = "T"
    int VARIABLE_IS_NOT_USED ldb,
    int VARIABLE_IS_NOT_USED centered,
    int VARIABLE_IS_NOT_USED normalized,
    double VARIABLE_IS_NOT_USED *C,
    int VARIABLE_IS_NOT_USED ldc
			  ) {
  BUG;
}
void freegpu(void VARIABLE_IS_NOT_USED **GPU_obj){
  BUG;
}
#endif


void print_options(option_type *global, utilsoption_type *utils) {
  basic_options *opt = &(utils->basic);
  if (opt->Cprintlevel) {
#if defined LINUXCPUID
    if (false) {
      PRINTF("\ndebug info: addresses %ld %ld", ALONG global, ALONG utils);
    }
#endif
    const char *ft [] ={"false", "true", "tba", "tba"};
    int G = (int) global->tuning.gpu << 1;
    PRINTF("\n");     
    PRINTF("gpu      : %s\n", ft[global->tuning.gpu]);
    if (!global->tuning.gpu) {
      if ( global->genetics.centered != NoCentering)
	PRINTF("ignore missings: %s\n", ft[G + global->tuning.missingsFully0]);
      PRINTF("do center: %s\n", ft[G + (global->genetics.centered !=NoCentering)]);
      if (global->tuning.floatLoop >=0)
	PRINTF("float    : %s\n", ft[G + global->tuning.floatLoop > 0]);
      else PRINTF("precise  : true\n");
      PRINTF("meanV    : %s\n", ft[G + global->tuning.meanVsubstract]);
      PRINTF("meanSxI  : %s\n", ft[G + global->tuning.meanSxIsubstract]);
      PRINTF("normalize: %s\n", ft[G + (bool) global->genetics.normalized] );
      PRINTF("variant  : %d \n",   global->tuning.variant);
    }
    PRINTF("use fortran freq: %s\n", 
	   ft[G + global->genetics.prefer_external_freq] );
    PRINTF("cores    : %d \n",  opt->cores );
    PRINTF("print lvl: %d \n",  opt->Cprintlevel );
  }
}



void get_started(option_type **g, utilsoption_type **u) {
  static option_type *global = NULL;
  static utilsoption_type *utils = NULL;
  if (global == NULL) {
    startLocal(1);
    WhichOptionList(false, &global, &utils);
    
    //    printf(">>>>>>>>> global %ld\n", ALONG global);

    //printf("GPU setting options in get_started\n");
    setOptions5(
#if defined CUDA
		true,
#else
		false,
#endif
		0, // cores 
		false, // floatLoop
		false, // meanV
		false, // meanSxI
		false, // irgnore missings
		RowMeans, // centering
		NoNormalizing, // normalize
		true, // use Fortran freq
		128,
		false // print details
		);
    Ext_startRFU();
    //   printf(" >> "); //, ALONG (&OPTIONS), ALONG utils;
  }
  *g = global;
  *u = utils;
  assert(global != NULL);
  assert(utils != NULL);
  //  printf("getstarted_done %ld\n", ALONG global);
  basic_options *opt = &(utils->basic);
  if (opt->Cprintlevel > 10) {
#if defined LINUXCPUID
    PRINTF("<<<<< global %ld\n", ALONG global);
#endif
    print_options(global, utils);
  }
}

void getStartedOptions() {
  static option_type  VARIABLE_IS_NOT_USED *global = NULL;
  static utilsoption_type VARIABLE_IS_NOT_USED  *utils = NULL;
  void get_started(option_type **g, utilsoption_type **u);
}


void setOptions5(int gpu, int cores, int floatLoop,
		 int meanVsubstract, int meanSxIsubstract,
		 int missingsFully0,
		 int centered, int normalized,
		 int prefer_external_freq,
		 int variant, int print_details) {
  if (print_details > 10) PRINTF("entering setoptions cores = %d\n", cores);
  option_type *global;
  utilsoption_type *utils;   
  get_started(&global, &utils);
  basic_options *opt = &(utils->basic);
  tuning_options *tuning = &(global->tuning);
  genetics_options *genetics = &(global->genetics);
  if (cores == 0) {
    const char* s = getenv("OMP_NUM_THREADS");
    if (s != NULL) cores = (int) strtoimax(s, NULL, 10);
    if (cores <= 0) {
      if (print_details > 3)
	PRINTF("WARNING: seeing 'OMP_NUM_THREADS=%s' only -- #threads set to 4\n", s);
       cores = 4;
       //PRINTF("number of threads not positive");  BUG;
    }
    //   FREE(s);
  }
  opt->cores = cores;
  tuning->gpu = (bool) gpu;
  //printf("GPU set to %d\n", tuning->gpu);
  //  gpu: centered works
  if (gpu && (!prefer_external_freq || missingsFully0 || normalized))
    ERR0("in case of 'gpu' the Fortran frequency must always be used; missings/centering/normalizing cannot treated.");
  tuning->floatLoop = floatLoop;
  tuning->meanVsubstract = (bool) meanVsubstract;
  tuning->meanSxIsubstract = (bool) meanSxIsubstract;
  tuning->missingsFully0 = (bool) missingsFully0;
  genetics->centered = (centering_type) centered;
  genetics->prefer_external_freq = prefer_external_freq;
  genetics->normalized = (normalizing_type) normalized;
  tuning->variant = variant < 32 ? 32 : variant > 256 ? 256 : variant;
  opt->efficient = false;
  opt->Cprintlevel = print_details * 3;
  tuning->addtransposed = true;
  if (print_details > 10) {
    print_options(global, utils);
    PRINTF("setoptions5 done \n");
  }
}

		   
void plinkToSxI(char *plink, char *plink_tr, 
	      long snps, long indiv,
	      int Coding,
	      double *f, 
	      int max_n,
	      void**compressed) {
  assert(sizeof(long) == 8);

  option_type *global;
  utilsoption_type *utils;
  get_started(&global, &utils);
  basic_options *opt = &(utils->basic);
  coding_type coding = (coding_type) Coding;
  
  if (global->tuning.gpu) {
    plink2gpu((char*) plink, (char*) plink_tr, stopIfNotInt(snps),
	      stopIfNotInt(indiv), f,  max_n, compressed);
    return;
  }

  #define CodesPerByte 4
  SEXP SxI = PROTECT(transform(plink, plink_tr, snps, indiv, OrigPlink, True, 0,
		       NULL, 0, NULL, 0, Nan, true,
		       global, utils,
			       coding, False, 0));
  
  
  if (global->tuning.missingsFully0) {
    getPlinkMissings((Uchar*) plink_tr, true, SxI, opt);
    getPlinkMissings((Uchar*) plink, false, getAttribPointer(SxI, Next), opt);
  }

  if (global->genetics.prefer_external_freq) {
    calculateFreq(SxI, f, global, utils);
  }
  UNPROTECT(1);
}


void vectorSxI5api(void *compressed, double *V, long repetV, long LdV, 
		    double *ans, long LdAns) {
  assert(sizeof(long) == 8);
  option_type *global;
  utilsoption_type *utils;
  get_started(&global, &utils);
 if (global->tuning.gpu) {
   dgemm_compressed_gpu(false, compressed, stopIfNotInt(repetV), V,
			stopIfNotInt(LdV),
			 global->genetics.centered, 
			getNormalized(global->genetics), 
			ans, stopIfNotInt(LdAns));
 } else {
    vectorSxI_means_double((SEXP)compressed, V, repetV, LdV, global, utils,
			    ans, LdAns);
  }
}


void SxIvector5api(void *compressed, double *V, long repetV, long LdV, 
		    double *ans, long LdAns) {
  assert(sizeof(long) == 8);
  option_type *global;
  utilsoption_type *utils;
  get_started(&global, &utils);
  if (global->tuning.gpu) {
      dgemm_compressed_gpu(true, compressed, stopIfNotInt(repetV), V,
			   stopIfNotInt(LdV), 
			   global->genetics.centered, 
			   getNormalized(global->genetics), 
			   ans, stopIfNotInt(LdAns));
  } else {
    SxIvector_means_double((SEXP)compressed, V, repetV, LdV, global, utils,
			    ans, LdAns);
  }  
} 



void free5(void **compressed) {
  option_type *global;
  utilsoption_type *utils;   
  get_started(&global, &utils);
  if (global->tuning.gpu) {
    freegpu(compressed);
  } else {
    FREE_SEXP((SEXP*) compressed); // will crash?!!!
  }
}


void getFreq5(void *compressed,  double *f) {
  option_type *global;
  utilsoption_type *utils;
  get_started(&global, &utils);
  basic_options *opt = &(utils->basic);
  SEXP SxI = (SEXP) compressed;
  extractInfo(SxI);
  calculateFreq(SxI, global, utils);
  LongDouble *freq = transposed == False ? getRowFreq(SxI) : getColFreq(SxI);
  for (Long j=0; j<rows; j++) {
    f[j] = (double) freq[j];
   }
}


void sparsevectorGenoPlinkApi(char *compressed,
			      int rows, 
			      int col,
			      double *B,
			      int nIdx,// 2nd dim of sparse; == length(rowIdxB)
			      int *rowIdxB,
			      int *colIdxB,
			      int tSparse,
			      double *C,
			      int Ldc) {
  option_type *global;
  utilsoption_type *utils;
  get_started(&global, &utils);
  int CpB = (int) (BitsPerByte / BitsPerCodeplink);
  sparsevectorGeno((unsigned char*) compressed, rows, col, DIV_GEQ(rows, CpB), 
		   OrigPlink, 
		   B, nIdx, rowIdxB, colIdxB, (bool) tSparse, global, utils,
		   C, Ldc);
}


 
void vectorGenoPlinkApi(char *compressed,
			 int rows, 
			 int col,
			 double *f,
			 double *B,
			 int n,
			 int LdB,
			 double *C,
			 int Ldc) {
  option_type *global;
  utilsoption_type *utils;
  get_started(&global, &utils);
  basic_options *opt = &(utils->basic);
  tuning_options *tuning = &(global->tuning);
  int CpB = (int) (BitsPerByte / BitsPerCodeplink);
  if (col % 32 != 0) ERR0("currently, 1st dimension must be a multiple of 32");

  if (f != NULL) {
    BUG;
    //    plinkToSxI + allg VectorGeno-Mechanismus
  } else {  
    vectorGenoPlinkMatrix256_double((unit_t*) compressed, rows, col, OrigPlink,
				    DIV_GEQ(rows, CpB),
				    256, NULL,
				    B, n, LdB, 
				    opt, tuning,
				    C, Ldc);
  }
}
