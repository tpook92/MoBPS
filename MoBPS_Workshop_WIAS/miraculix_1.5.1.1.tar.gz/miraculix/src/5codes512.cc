/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/

   
  
#define MY_VARIANT 512
#include "5codesDef.h" 


#if defined AVX512


ASSERT_SIMD(5codes512, avx512f);

#include "MX.h"
#include "haplogeno.h" 
#include "intrinsics.sequences.h" 
#include "5codesIntern.h"
 
 


#else
#include "avx_miss.h"

   
gV5_header(512, floatD, LongDouble, float, double, VARIABLE_IS_NOT_USED) Sv
gV5_header(512, double, LongDouble, double, double, VARIABLE_IS_NOT_USED) Sv


SIMD_MISS(5codes512, avx512f);

#endif  // defined AVX
// trafo2Geno1Geno128
 
