/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/


#define BitsPerCode 2
#define MY_VARIANT 32


#include "Basic_miraculix.h"

#if defined compatibility_to_R_h
#include "intrinsics_specific.h"
#include "options.h"
#include "haplogeno.h"
#include "utils_miraculix.h"
#include "MX.h"
#include "Template.h"
#include "Haplo.h"
#include "miraculix.h"
#include "options_RFU.h"

SEXP rhaplomatrixPart2(SEXP Freq1, SEXP Freq2, SEXP SxI) {
  //  printf("length =%d %d\n", LENGTH(Freq1), LENGTH(Freq2));
  PROTECT(SxI);
  GetOptions;
  extractInfo(SxI);
  double *freq1 = REAL(Freq1),
    *freq2 = REAL(Freq2);
  assert(snps == LENGTH(Freq1) && LENGTH(Freq2) == LENGTH(Freq1));
 
  bool random = false;  
  for (Long s=0; s < snps; s++) {
    double f = freq1[s];
    if (f < 0 || f > 1) ERR0("frequencies not in [0,1]");
    random |= f != 0 && f != 1;
    f = freq2[s];
    if (!ISNA(f)) {
      if (f < 0 || f > 1) ERR0("frequencies not in [0,1]");
      random |= f != 0 &&  f != 1;
    }
  }

  if (random) {
    GetRNGstate();
    InnerRandomTwoBitHaplo(freq1, freq2, rows, cols, coding, code, lda);
    PutRNGstate();
  } else {
    InnerDetermTwoBitHaplo(freq1, freq2, rows, cols, coding, code, lda);
  }
  UNPROTECT(1);
  return SxI;
}

SEXP rhaplomatrix(SEXP Freq1, SEXP Freq2, SEXP Individuals, SEXP Coding) {
  GetOptions;
  Long individuals = INTEGER(Individuals)[0],
    snps = LENGTH(Freq1);
  coding_type coding = (coding_type) INTEGER(Coding)[0];
  // printf("coding = %d\n", coding);
  assert(coding == OneBitHaplo || coding == TwoBitHaplo);
  if (snps != (Long) LENGTH(Freq2))
    ERR0("'freq' and 'freq2' do not have the same length");
  usr_bool transposed = False;
  SEXP Ans = createSNPmatrix(snps, individuals, coding, // no PROTECT( needed;
			     transposed, global->tuning.addtransposed,
			     MY_VARIANT, MY_LDABITALIGN, global, utils);
  return rhaplomatrixPart2(Freq1, Freq2, Ans);
}

#endif
