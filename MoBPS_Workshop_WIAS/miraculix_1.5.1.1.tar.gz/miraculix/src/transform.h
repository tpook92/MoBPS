/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/


#ifndef miraculix_transform_H
#define miraculix_transform_H 1

typedef void (*coding_t)(unit_t *, Long, Long, Long, Long, Long,
			 int, double *, unit_t*, Long, usr_bool, Long);


void haplo2geno(SEXP SxI, option_type *global, basic_options *opt);
void haplo2geno(unit_t *M, Long rows, Long cols, Long lda,
		coding_type oldCoding, int variant, int cores);


void matrix_get_4Byte(unit_t *code, Long rows, Long cols, 
		      coding_type coding, Long lda,
		      int cores, unit_t *ans, Long ldAns, usr_bool transposed);

coding_t matrix_coding_1Byte(coding_type coding, usr_bool *transposed,
				int variant, bool bigendian);
coding_t matrix_coding_4Byte(coding_type coding, usr_bool *transposed,
				int variant, bool bigendian);


SEXP transpose(SEXP SxI,  option_type *global, utilsoption_type *utils);

SEXP Transform(SEXP SxI, unit_t* SxInt, coding_type codingInfo,
	       int* selSnps, int lenSnps, int *selIndiv, int lenIndiv,
	       option_type *global, utilsoption_type *utils);


SEXP transform(SEXP SxI,
	       int *selSnps, int lenSelSnps,
	       int *selIndiv, int lenSelIndiv,
	       usr_bool set1, bool add_transposed,
	       option_type *global, utilsoption_type *utils,
	       bool transformOnPlace,
	       coding_type ansCoding, usr_bool AnsTransposed,
	       int ansVariant);

SEXP transform(void *pointer, void *nextpntr,
	       Long snps, Long individuals,
	       coding_type coding, 
	       usr_bool pointer_is_transposed,
	       Long LDAbitalign,
	       int* selSnps, int lenSelSnps,
	       int *selIndiv, int lenSelIndiv,
	       usr_bool set1, bool add_transposed,
	       option_type *global, utilsoption_type *utils,
	       coding_type ansCoding,  usr_bool ansTransposed,
	       int ansVariant);

extern const Long CpByte, CpByteplink, BitsPerCodeplink;

void copyAttribInfos(SEXP To, SEXP From, bool unconditional, bool relaxed);


#endif


