/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/



#ifndef miraculix_MXINFO_H
#define miraculix_MXINFO_H 1



#define DIV_GEQ(X,R) (1 + ((X) - 1) / (R))
#define DIV_LESS(X,R) (((X) - 1) / (R))
#define DIV_LEQ(X,R) ((X) / (R))


#define ROUND_GEQ(X,R) (DIV_GEQ(X,R) * (R))
#define ROUND_LESS(X,R) (DIV_LESS(X,R) * (R))
#define ROUND_LEQ(X,R) (DIV_LEQ(X,R) * (R))


typedef int Rint;
typedef  char table_type;
				       

Uint Inti(SEXP X, Uint i);
#define Int0(X) Inti(X, 0U)

	

Long *GetInfoUnchecked(SEXP SxI);
Long *GetInfo(SEXP SxI);
Long *GetInfo(SEXP SxI, int nullOK);
void printINFO(SEXP S); // *rint



// ACHTUNG ! uintptr_t ist ein Zeiger auf Byte nicht auf uint!
#if defined BitsPerByte
static inline  uintptr_t algn_generalL(int *X, Long VARIABLE_IS_NOT_USED LDAbitalign) {
  return (uintptr_t) X; // new 12.6.24
  
  // printf("%ld %ld ", ALONG X, LDAbitalign);
  Long f = LDAbitalign / BitsPerByte;
  assert(ROUND_GEQ((uintptr_t) X, f) >= (uintptr_t) X);
  return ROUND_GEQ((uintptr_t) X, f);
}

static inline void *algn_generalS(SEXP Code, Long LDAbitalign) {
  return (void*) algn_generalL(INTEGER(Code), LDAbitalign); // new 12.6.24
  
  //  printf("algn_generalS at %s\n", __FILE__);
  //  return (void*) INTEGER(Code);
  Long *info = GetInfo(Code, true);
  //printSEXP(Code);
  //  if (getAttribPointer(Code, Information) != R_NilValue)   printf("%ld %ld\n", LONG(getAttribPointer(Code, Information))[LDABITALIGN], LDAbitalign);
  if (info != NULL) { assert(info[LDABITALIGN] == LDAbitalign);}
  //assert(getAttribPointer(Code, Information) == R_NilValue);
  return (void*) algn_generalL(INTEGER(Code), LDAbitalign);
}
#endif

#define FROMINPUT  ((int) (*(pM++)))
#define FROMHAPLO GetTwoBitHaplo(pM, s)


#define ASSERT_ENDIAN0(Bigendian)		\
  if ((Bigendian) == info[BIGENDIAN]) {} else				\
    ERR2("endians do not match in line %d if %s", __LINE__, __FILE__)

#define ASSERT_STORED_ENDIAN ASSERT_ENDIAN0(opt->bigendian)
 
#define ASSERT_LITTLE_ENDIAN ASSERT_STORED_ENDIAN; if (info[BIGENDIAN]) { BUG; } else { }



#define isRoughlyGeno(X) ((X) <= LastGenoCoding || (X) == CorrespondingGeno)
#define isNarrowGeno(X) (isRoughlyGeno(X) && (X) != AutoCoding)
#define isOneSet2G(X) ((X) == OneByteGeno || (X) == FourByteGeno)
#define anyByteGeno(X) ((X) == OneByteGeno || (X) == FourByteGeno)

#define isGeno(X) ((X) >= FirstGenoCoding && (X) <= LastGenoCoding)
#define isHaplo(X) ((X) >= FirstHaploCoding && (X) <= LastHaploCoding)

#define Haplo32(X) ((X) >= FirstHaplo32Coding && (X) <= LastHaplo32Coding)
  
#define anyByteHaplo(X) (Haplo32(X) || (X) == OneByteHaplo)

#define isUnCompressed(coding) (anyByteGeno(coding) || anyByteHaplo(coding))

#define isCompressedHaplo(X) (isHaplo(X) && !anyByteHaplo(X))

#define is2Bit(X) ((X)==OneBitGeno || \
		   (X)==TwoBitGeno ||	\
		   (X)==TwoBitHaplo||   \
		   (X)==OneBitHaplo)
#define isOneByte(X) ((X) == OneByteGeno || (X) == OneByteHaplo)
#define isOneByteHaplo(X, OneHaploOnly) \
  ((X) == OneByteHaplo || ((OneHaploOnly) && (X) == OneByteGeno ))
#define isFourByteHaplo(X, OneHaploOnly) \
  ((X) == FourByteHaplo || (X) == FourByteSingleBit ||	\
   ((OneHaploOnly) && (X) == FourByteGeno))

#define isCompressed(X) ( ((X) > AutoCoding && (X) <= OneByteGeno) ||	\
			  ((X) >= OneBitHaplo && (X) <= OneByteHaplo) \
			  )
#define uprightlyPacked(X) ((X) == FiveCodes)

#define is32BitAligned(X) ((X) == FourByteGeno || Haplo32(X))
#define isUnitAligned(X)\
  (GetLDAbitalign(X) == (Long) sizeof(unit_t) * BitsPerByte)

#define UnCompressedDoubledCols(X, RELAXED)			\
  ((X) == FourByteHaplo || (X) == OneByteHaplo || (X) == FourByteSingleBit || \
   ((RELAXED) && ((X) == FourByteGeno || (X) == OneByteGeno)))

#define UnCompressedDoubledRows(X, RELAXED) ((X) == EightByteHaplo)

#define doubledCols(X, RELAXED) ((X) == OneBitHaplo ||			\
				 ((RELAXED) && (X) == OneBitGeno) ||	\
				 UnCompressedDoubledCols(X, RELAXED) )

#define doubledRows(X, RELAXED) (UnCompressedDoubledRows(X, RELAXED))

#define has_ld_in_Byte(X) ((X) == OrigPlink)
#define is_raw_coding(X) ((X) == OrigPlink)

#define PLINK2HUMAN(X) ((X) <= 1 ? 0 : ((X) - 1))
#define HUMAN2PLINK(X) ((X) == 0 ? 0 : (X) == 1 ? CODE_ONE : (X) == 2 ? 3 : 1)
#define TWOBIT2HUMAN(X) ((X) <= 2 ? (X) : 0)
#define HUMAN2TWOBIT(X) ((X) <= 2 ? (X) : 0)

#define getNormalized(G) ((G.normalized)!=AccordingCentering ? (G.normalized) \
			  : (G.centered) == NoCentering || (G.centered)==User \
			  ? NoNormalizing				\
			  : (G.centered) == RowMeans ? RowNormalized	\
			  : (G.centered) == ColMeans ? ColNormalized	\
			  : AccordingCentering)


#define condExtractInfoIntern(SxI, COND, NAME)				\
  assert(SxI != R_NilValue && SxI != NULL);				\
  Long *info##NAME = GetInfo(SxI),					\
    snps##NAME = info##NAME[SNPS],					\
    individuals##NAME = info##NAME[INDIVIDUALS],			\
    VARIABLE_IS_NOT_USED lda##NAME = info##NAME[LDA];			\
  unit_t VARIABLE_IS_NOT_USED *code##NAME = Align(SxI, opt);		\
  coding_type VARIABLE_IS_NOT_USED coding##NAME =			\
    (coding_type) info##NAME[CODING];					\
  int VARIABLE_IS_NOT_USED variant##NAME = stopIfNotInt(info##NAME[VARIANT]); \
  usr_bool transposed##NAME = info##NAME[TRANSPOSED] == 0 ? False : True; \
  Long rows##NAME = snps##NAME,					\
    cols##NAME = individuals##NAME;					\
  if ((transposed##NAME == True) xor (COND)) {				\
    Long tmp = rows##NAME; rows##NAME = cols##NAME; cols##NAME = tmp;	\
  }


#define condReextractInfoIntern(SxI, COND, NAME)			\
  assert(SxI != R_NilValue && SxI != NULL);				\
  info##NAME = GetInfo(SxI);						\
  assert(snps##NAME == info##NAME[SNPS]);				\
  assert(individuals##NAME == info##NAME[INDIVIDUALS]);			\
  lda##NAME = info##NAME[LDA];			\
  code##NAME = Align(SxI, opt);						\
  assert(coding##NAME == (coding_type) info##NAME[CODING]);		\
  variant##NAME = stopIfNotInt(info##NAME[VARIANT]); \
  transposed##NAME = info##NAME[TRANSPOSED] == 0 ? False : True; \
  rows##NAME = snps##NAME;						\
  cols##NAME = individuals##NAME;					\
  if ((transposed##NAME == True) xor (COND)) {				\
    Long tmp = rows##NAME; rows##NAME = cols##NAME; cols##NAME = tmp;	\
  }								


#define condExtractInfo(SxI, COND) condExtractInfoIntern(SxI, COND, )
#define extractInfo(SxI) condExtractInfoIntern(SxI, false, )
#define reextractInfo(SxI) condReextractInfoIntern(SxI, false, )
#define extractNamedInfo(SxI) condExtractInfoIntern(SxI, false, SxI)


#define extractNamedBasicInfo(SxI, NAME)				\
  assert(SxI != R_NilValue && SxI != NULL);				\
  Long *info##NAME = GetInfo(SxI),					\
    snps##NAME = info##NAME[SNPS],					\
    individuals##NAME = info##NAME[INDIVIDUALS];			\
  unit_t VARIABLE_IS_NOT_USED *code##NAME = Align(SxI, opt);		\
  coding_type VARIABLE_IS_NOT_USED coding##NAME = \
    (coding_type) info##NAME[CODING];					\
  int VARIABLE_IS_NOT_USED variant##NAME = stopIfNotInt(info##NAME[VARIANT]); \
  Long VARIABLE_IS_NOT_USED lda##NAME = stopIfNotInt(info##NAME[LDA])

#define extractBasicInfo(SxI) extractNamedBasicInfo(SxI, )

/*
#define reextractBasicInfo(SxI)					\
  assert(SxI != R_NilValue && SxI != NULL);			\
  info = GetInfo(SxI);						\
  snps = info[SNPS];						\
  individuals = info[INDIVIDUALS];				\
  code = Align(SxI, opt);					\
  coding = (coding_type) info[CODING];				\
  variant = stopIfNotInt(info[VARIANT])
*/

#define GetOptions						\
  option_type *global;						\
  utilsoption_type *utils;					\
  WhichOptionList(true, &global, &utils);			\
  basic_options VARIABLE_IS_NOT_USED *opt = &(utils->basic)

#define GetCores \
  GetOptions;					\
  int  VARIABLE_IS_NOT_USED cores = GreaterZero(opt->cores)


coding_type OneSet2G(coding_type coding);
coding_type swapHaploGeno(coding_type coding, bool ToH);
coding_type swapHaploGeno(coding_type coding, bool ToH, bool ToG,
			  usr_bool stopOnError);

#endif
 
