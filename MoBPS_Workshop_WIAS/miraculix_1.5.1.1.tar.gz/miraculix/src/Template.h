/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/


#ifndef miraculix_vector_matrix_template_H
#define miraculix_vector_matrix_template_H 1

#include "options.h"


typedef double floatD;
typedef double longD;

#define cross_scalar_args(V)\
  unit_t V *x, unit_t V *y, Long V blocks, Long VARIABLE_IS_NOT_USED DeltaPart2

typedef Ulong (*scalar_t)(cross_scalar_args());


#define cross_multi_args(V)\
  unit_t V *x, unit_t V  *y,\
    Long VARIABLE_IS_NOT_USED cols, /* used in 2x2 only */	 \
    Long V blocks,						 \
    Long VARIABLE_IS_NOT_USED lda,	/* used in 2x2 only */	 \
    double V  *ans

typedef void (*multi_t)(cross_multi_args());



#define colrowSums_args(V)\
  unit_t V *code, Long V rows, Long V cols,			  \
    Long V lda, int VARIABLE_IS_NOT_USED cores,			  \
    Ulong V *sums


#define codingSEXP_args(V)				\
  unit_t V *M, Long V ldM,				\
    Long V  start_row, Long V end_row,			\
    Long V start_col, Long V end_col,			\
    basic_options V *opt, double V *G, SEXP  V Ans,	\
    usr_bool V transposed


#define coding_args(V)							\
  unit_t V *M,  Long V ldM,						\
    Long V start_row, Long V end_row,					\
    Long V start_col, Long V end_col,					\
    int VARIABLE_IS_NOT_USED cores,					\
    double VARIABLE_IS_NOT_USED *G,					\
    unit_t V *Ans,							\
    Long VARIABLE_IS_NOT_USED cols, /* for codes with 2 matrices (1bit)*/ \
    usr_bool V transposed,						\
    Long V ldAns //, int VARIABLE_IS_NOT_USED XXX

#define coding_header(UINT,NAME)  void coding##NAME##UINT(coding_args())

#define get_matrix_header(UINT,NAME)					\
  void get_matrix##NAME##UINT(unit_t *code, Long  rows, \
			      Long cols, Long lda,			\
			      int VARIABLE_IS_NOT_USED cores,		\
			      unit_t *Ans,			\
			      usr_bool transposed, Long ldAns) 	     

#define vector_raw_args(DOUBLE)						\
  SEXP SxI, DOUBLE *V, Long repetV, Long ldV,				\
    option_type *global, utilsoption_type *utils,			\
    DOUBLE *ans, Long ldAns

#define vector_raw_shortargs(DOUBLE)					\
  SEXP SxI, DOUBLE *V, Long repetV,		\
    option_type *global, utilsoption_type *utils,			\
    DOUBLE *ans

typedef void (*vector_raw_double_t) (vector_raw_args(double));
typedef void (*vector_raw_LongDouble_t) (vector_raw_args(LongDouble));


#define vector_args(TYPE, ENDTYPE, VV)				\
  unit_t VV *code, Long VV rows, Long VV cols,			\
    coding_type VARIABLE_IS_NOT_USED coding, Long VV lda,		\
    int VARIABLE_IS_NOT_USED variant,					\
    LongDouble VARIABLE_IS_NOT_USED * colFreq,				\
    TYPE VV *V, Long VV repetV, Long VV ldV,				\
    basic_options VARIABLE_IS_NOT_USED *opt,				\
    tuning_options VARIABLE_IS_NOT_USED *tuning,			\
    ENDTYPE VV *Ans, Long VV  ldAns

#define vector_header(TYPE, ENDTYPE, NAME)			\
  void vector##NAME##_##TYPE(vector_args(TYPE, ENDTYPE, ))


typedef void (*vector_double_t) (vector_args(double, double, ));
typedef void (*vector_LongDouble_t) (vector_args(LongDouble, LongDouble ,));
typedef void (*vector_longD_t) (vector_args(longD, double, ));
typedef void (*vector_Ulong_t) (vector_args(Ulong, Ulong, ));
typedef void (*vector_floatD_t) (vector_args(double, double ,));


#define vec_fctn_args(TYPE, ENDTYPE) \
  coding_type VARIABLE_IS_NOT_USED coding,	\
  int VARIABLE_IS_NOT_USED variant,		\
  bool VARIABLE_IS_NOT_USED SubstractMeanSxI,			\
  tuning_options VARIABLE_IS_NOT_USED *tuning,	\
  bool gV

typedef vector_double_t (*vector_fctn_double_t) (vec_fctn_args(double, double));
typedef vector_LongDouble_t (*vector_fctn_LongDouble_t) (vec_fctn_args(LongDouble, LongDouble));
typedef vector_longD_t (*vector_fctn_longD_t) (vec_fctn_args(longD, double));
typedef vector_Ulong_t (*vector_fctn_Ulong_t) (vec_fctn_args(Ulong, Ulong));
typedef vector_floatD_t (*vector_fctn_floatD_t) (vec_fctn_args(double, double));


 
#define vector_fctn_header(TYPE, ENDTYPE, NAME)			\
  vector_##TYPE##_t vector_fctn##NAME##_##TYPE(vec_fctn_args(TYPE, ENDTYPE))


#define vector_fctn_header_gV(TYPE)		\
  void vector_##TYPE(vector_args(TYPE, TYPE, ), bool gV)


#define vectorGeno_header(TYPE, TRDTYPE, ENDTYPE, NAME) \
  void vectorGeno##NAME##_##TYPE(vector_args(TYPE, ENDTYPE,))



#define genoVector_header(TYPE, TRDTYPE, ENDTYPE, NAME)		\
  void genoVector##NAME##_##TYPE(vector_args(TYPE, ENDTYPE,))



#define colSums_header0					\
  (unit_t *code, Long rows, Long cols, Long lda,	\
   int VARIABLE_IS_NOT_USED cores, Ulong *sums)
#define colSums_header(NAME) Ulong colSums##NAME colSums_header0	\

typedef Ulong (*colSums_t) colSums_header0;


#define colSums_start(NAME)			\
  colSums_header(NAME) {			\
  Ulong VARIABLE_IS_NOT_USED total = 0;


#define gV_vG_args(TYPE)						\
  (SEXP SxI, TYPE *V, Long repetV, Long ldV,				\
   bool orig_gV, bool SubstractMeanSxI, /* meanSxI in Vector.matrix.D.cc */ \
   option_type *global, utilsoption_type *utils,			\
   TYPE *ans, Long ldAns)

#define gV_vG_header(TYPE, NAME)					\
  void gV_vG##NAME##_##TYPE gV_vG_args(TYPE) 

typedef void (*gV_vG_double_t) gV_vG_args(double);
typedef void (*gV_vG_LongDouble_t) gV_vG_args(LongDouble);
typedef void (*gV_vG_Ulong_t) gV_vG_args(Ulong);


#define sparsevectorGeno_Header /* (sparse) %*% t(code) */		\
  (Uchar *code,								\
   Long nrow_code, Long ncol_code, Long ldaInByte,			\
   coding_type VARIABLE_IS_NOT_USED coding,				\
   double *valueB,							\
   int nIdx,/*2nd dimension of sparse; == len(rowIdxB)*/		\
   int *rowIdxB, int *colIdxB,						\
   bool VARIABLE_IS_NOT_USED tSparse,					\
   option_type VARIABLE_IS_NOT_USED *global,				\
   utilsoption_type VARIABLE_IS_NOT_USED *utils,			\
   double *Ans, Long ldAns)

#define sparsevectorGeno_header(NAME) /* (sparse) %*% t(code) */	\
  void sparsevectorGeno##NAME sparsevectorGeno_Header
  
  
#define CodesPerLong ((int) (sizeof(Long) * BitsPerByte / BitsPerCode)) // OK
#define sparsevectorGeno_start(NAME)					\
  sparsevectorGeno_header(NAME){					\
  if (nrow_code > (Long)MAXINT || ncol_code > (Long)MAXINT) BUG;	\
  const basic_options *opt = &(utils->basic);				\
  const int VARIABLE_IS_NOT_USED cores = GreaterZero(opt->cores);

// || nrow_code < (Long)CodesPerLong

  
typedef void (*sparsevectorGeno_t) sparsevectorGeno_Header;
		 

#endif
