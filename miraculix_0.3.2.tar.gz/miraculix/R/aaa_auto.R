# This file has been created automatically by 'rfGenerateConstants'


 ## from  src/AutoMiraculix.h
 AutoMiraculix_H 	<- as.integer(1)


 Shuffle 	<- as.integer(0)
 TwoBit 	<- as.integer(1)
 ThreeBit 	<- as.integer(2)
 Hamming2 	<- as.integer(3)
 Hamming3 	<- as.integer(4)
 NoSNPcoding 	<- as.integer(5)
 AutoCoding 	<- as.integer(6)
 Haplo 	<- as.integer(7)



 last_usr_meth 	<- as.integer(AutoCoding)
 nr_relship_meth 	<- as.integer((Haplo+1))




 HAPLO 	<- as.integer(0)
 GENO 	<- as.integer(1)
 GENOMATRIX 	<- as.integer(2)



 INFO_INFO 	<- as.integer(0)
 INFO_P 	<- as.integer(1)
 INFO_CODING 	<- as.integer(2)
 INFO_LAST 	<- as.integer(INFO_CODING)

 WHAT 	<- as.integer(0)
 SNPS 	<- as.integer(1)
 INDIVIDUALS 	<- as.integer(2)
 ADDR0 	<- as.integer(3)
 ADDR1 	<- as.integer(4)
 ADDR2 	<- as.integer(5)
 ADDR3 	<- as.integer(6)
 MEM 	<- as.integer(7)
 SNPxIND 	<- as.integer(8)
 INFO_BLOCKS 	<- as.integer(9)
 INFO_BITS 	<- as.integer(10)
 INFO_BITSPERBLOCK 	<- as.integer(11)
 SNPSPERCOMPRESSED 	<- as.integer(12)
 INFO_HEADER 	<- as.integer(13)
 INFO_DOUBLEINDIV 	<- as.integer(14)
 INFO_LEADINGCOL 	<- as.integer(15)
 INFO_INFO_LAST 	<- as.integer(INFO_LEADINGCOL)

 INFO_P_PPT 	<- as.integer(0)
 INFO_P_SUMPQ 	<- as.integer(1)
 INFO_P_SUMP 	<- as.integer(2)
 INFO_P_P 	<- as.integer(3)




 ## from  src/AutoMiraculix.cc


RELSHIP_METH_NAME <- 
  c("Shuffle", "TwoBit", "ThreeBit", "Hamming2", "Hamming3", "NoSNPcoding",
  "AutoCoding", "Haplo")








