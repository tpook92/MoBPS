
/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3
 of the License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/


/// sysconf (_SC_NPROCESSORS_ONLN) // number of cores available
// int get_nprocs (void) // dito

#ifndef RFUdefRFU_H
#define RFUdefRFU_H 1


//////////////////////////////////////////// 1  // for debugging only

//// 1
//// 1
//// 1


//

#define INCLUDE_FORTRAN 1
 

#if ! defined SCHLATHERS_MACHINE && defined SCHLATHER_DEBUGGING
#undef SCHLATHER_DEBUGGING
#else
////  1
#endif

// // 1

#if ! defined pkg
#define pkg "RandomFieldsUtils" // RFU DELETE
#endif

#endif
