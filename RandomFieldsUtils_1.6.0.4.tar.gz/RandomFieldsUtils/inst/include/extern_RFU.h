
/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3
 of the License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/


#ifndef randomfieldsutils_extern_H
#define randomfieldsutils_extern_H 1


#include "AutoRandomFieldsUtilsLocal.h"
#include "zzz_RFU.h"

extern int PLoffset, PL;
extern utilsoption_type OPTIONS; // OK

#define prefixN 3
extern const char * prefixlist[prefixN], **allOptions[prefixN];
extern int allOptionsN[prefixN];


// AutoRFU
extern const char *LA_NAMES[LA_LAST + 1], *PIVOT_NAMES[PIVOT_LAST + 1],
  *INSTALL_NAMES[INSTALL_LAST + 1];

//extern const char *basic[basicN];
extern const char * InversionNames[nr_InversionMethods];
//extern const char * solve[solveN];
// extern bool ToFalse[1];
//

extern int parentpid;


#endif
