'#
  Authors
Torsten Pook, torsten.pook@uni-goettingen.de

Copyright (C) 2017 -- 2018  Torsten Pook

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
'#

#' @name map_maize1
#' @title map_maize1
#' @description Ensembl
#' @usage map_maize1
#' @source Ensembl
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_chicken1
#' @title map_chicken1
#' @description Ensembl
#' @usage map_chicken1
#' @source Ensembl
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_chicken2
#' @title map_chicken2
#' @description Ensembl
#' @usage map_chicken2
#' @source Ensembl
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_chicken3
#' @title map_chicken3
#' @description Ensembl
#' @usage map_chicken3
#' @source Ensembl
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_cattle1
#' @title map_cattle1
#' @description Ensembl
#' @usage map_cattle1
#' @source Ensembl
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_cattle2
#' @title map_cattle2
#' @description Ensembl
#' @usage map_cattle2
#' @source Ensembl
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_cattle3
#' @title map_cattle3
#' @description Ensembl
#' @usage map_cattle3
#' @source Ensembl
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_cattle4
#' @title map_cattle4
#' @description Ensembl
#' @usage map_cattle4
#' @source Ensembl
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_pig1
#' @title map_pig1
#' @description Ensembl
#' @usage map_pig1
#' @source Ensembl
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_pig2
#' @title map_pig2
#' @description Ensembl
#' @usage map_pig2
#' @source Ensembl
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_pig3
#' @title map_pig3
#' @description Ensembl
#' @usage map_pig3
#' @source Ensembl
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_pig4
#' @title map_pig4
#' @description Ensembl
#' @usage map_pig4
#' @source Ensembl
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL


#' @name map_horse1
#' @title map_horse1
#' @description Ensembl
#' @usage map_horse1
#' @source Ensembl
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_goat1
#' @title map_goat1
#' @description Ensembl
#' @usage map_goat1
#' @source Ensembl
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_human1
#' @title map_human1
#' @description Ensembl
#' @usage map_human1
#' @source Ensembl
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_human2
#' @title map_human2
#' @description Ensembl
#' @usage map_human2
#' @source Ensembl
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL


#' @name map_human3
#' @title map_human3
#' @description Ensembl
#' @usage map_human3
#' @source Ensembl
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_sheep1
#' @title map_sheep1
#' @description Ensembl
#' @usage map_sheep1
#' @source Ensembl
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_sheep2
#' @title map_sheep2
#' @description Ensembl
#' @usage map_sheep2
#' @source Ensembl
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_sheep3
#' @title map_sheep3
#' @description Ensembl
#' @usage map_sheep3
#' @source Ensembl
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_wheat1
#' @title map_wheat1
#' @description Liu 2018
#' @usage map_wheat1
#' @source Liu 2018
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_wheat2
#' @title map_wheat2
#' @description Wen 2017
#' @usage map_wheat2
#' @source Wen 2017
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_sorghum1
#' @title map_sorghum1
#' @description Bekele 2013
#' @usage map_sorghum1
#' @source Bekele 2013
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_salmon1
#' @title map_salmon1
#' @description Tsai 2016 (male recombination rates)
#' @usage map_salmon1
#' @source Tsai 2016
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_salmon2
#' @title map_salmon2
#' @description Tsai 2016 (female recombination rates)
#' @usage map_salmon2
#' @source Tsai 2016
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL

#' @name map_tilapia1
#' @title map_tilapia1
#' @description Ensembl
#' @usage map_tilapia1
#' @source Penaloza 2020
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL
