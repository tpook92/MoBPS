/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather 

 COPYRIGHT_TEXT
*/

#define NO_SSE2 1

#include "def_rfu.h"
#include "zzz.h"

#if defined compatibility_to_R_h

#include "win_linux_aux.h"
#include "utils.h"
#include "zzz_RFU.h"
#include "RandomFieldsUtils.h"


#if defined(__clang__)
//# pragma clang diagnostic ignored "-Wcast-function-type"
#endif

#ifdef __GNUC__
// https://gcc.gnu.org/onlinedocs/gcc/Diagnostic-Pragmas.html
//#pragma GCC diagnostic ignored "-Wcast-function-type"
#endif
 

static R_NativePrimitiveArgType 
    int_arg[] = { INTSXP },
    host_arg[] = { STRSXP, INTSXP};
  //  static R_NativeArgStyle argin[] = {R_ARG_IN},
  //    argout[] = {R_ARG_OUT},
  //   hostarg[] = {R_ARG_OUT, R_ARG_OUT};


static const R_CMethodDef cMethods[]  = {
  cRFUMethods
  {NULL, NULL, 0, NULL}
};


static R_CallMethodDef callMethods[]  = {
  // in die respectiven C-Dateien muss RandomFieldsUtils.h eingebunden sein
  //  CALLDEF(),
  callRFUMethods
  {NULL, NULL, 0} 
};
 

 
static const R_ExternalMethodDef extMethods[] = {
  // in die respectiven C-Dateien muss RandomFieldsUtils.h eingebunden sein
  extRFUMethods
  {NULL, NULL, 0} 
};


void R_init_RandomFieldsUtils(DllInfo  *dll) {
  RFU_CALLABLE;
  //printf("****  zzz_RFU.c\n");
  R_registerRoutines(dll, cMethods, callMethods, NULL, // .Fortran
		     extMethods);
  R_useDynamicSymbols(dll, FALSE); //
}


#ifdef SCHLATHERS_MACHINE
#if defined __GNUC__ & defined __GCC__
// https://gcc.gnu.org/onlinedocs/gcc/Diagnostic-Pragmas.html
//#pragma GCC diagnostic push
//#pragma GCC diagnostic ignored "-Wcast-function-type"
#endif
#endif
void R_unload_RandomFieldsUtils(DllInfo VARIABLE_IS_NOT_USED *info) { }
#if defined __GNUC__ & defined __GCC__
//#pragma GCC diagnostic pop
#endif


#endif  // !standalone
