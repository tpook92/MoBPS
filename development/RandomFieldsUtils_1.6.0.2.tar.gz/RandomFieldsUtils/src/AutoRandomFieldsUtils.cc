/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#include "AutoRandomFieldsUtils.h"

const char

*R_TYPE_NAMES[LAST_R_TYPE_NAME + 1] = { // never change ! see kleinkram.cc
  "NILSXP" /* 0 */,
  "SYMSXP", "LISTSXP", "CLOSXP", "ENVSXP", "PROMSXP",
  "LANGSXP", "SPECIALSXP", "BUILTINSXP", "CHARSXP", "LGLSXP" /* 10 */,
  "??", "??", "INTSXP", "REALSXP", "CPLXSXP",
  "STRSXP", "DOTSXP", "ANYSXP", "ECSXP", "EXPRSXP" /*20 */,
  "BCODESXP", "EXTPTRSXP", "WEAKREFSXP", "RAWSXP", "S4SXP" /* 25 */,
  "", "", "", "", "NEWSXP" /* 30 */,
  "FREESXP", "??SXP"},

 *LA_NAMES[LA_LAST + 1] = { "intern", "R", "auto", "GPU", "query"},

*PIVOT_NAMES[PIVOT_LAST + 1] = {"no privoting",
  "do", "auto", "idx", "undefined"},

*INSTALL_NAMES[INSTALL_LAST + 1] = {"no installation", "install", "ask", 
				    "sse", "sse2", "sse3", "ssse3", "avx",
				    "avx2", "avx512f", "gpu"};
