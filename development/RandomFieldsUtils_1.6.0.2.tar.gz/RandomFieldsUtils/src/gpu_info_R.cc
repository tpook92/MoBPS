/*
 Authors 
 Alexander Freudenberg, afreuden@mail.uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather, Alexander Freudenberg

 COPYRIGHT_TEXT
*/


#include "def_rfu.h"
#include "Basic_RandomFieldsUtils.h"
#if defined compatibility_to_R_h
#include "RandomFieldsUtils.h"
#include "errors_messages.h"

#if defined USEGPU
SEXP gpu_info_61(SEXP DEVICES);
#endif


SEXP gpu_info(SEXP VARIABLE_IS_NOT_USED DEVICES){
#if defined USEGPU
  return gpu_info_61(DEVICES);
#else  
  ERR0("No CUDA devices found");
  return R_NilValue;
#endif
}

#endif
