/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


// Externals:


#include "def_rfu.h"
//#include "Basic_RandomFieldsUtils.h" // must be before anything else
#include "extern_RFU.h"

int PLoffset = 0,
  PL = C_PRINTLEVEL;


// end Externals
