/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/




#include "Basic_RFUlocal.h" // must be before anything else
#if defined compatibility_to_R_h

#include "RandomFieldsUtils.h"


#ifdef SCHLATHERS_MACHINE
//#include "kleinkram.h"


SEXP brdomain(SEXP Srf, SEXP Ssigma2, SEXP Sinstances, SEXP Smaxn) {
  double
    *rf = REAL(Srf),
    *sigma2 = REAL(Ssigma2);
  int
    instances = INTEGER(Sinstances)[0],
    maxn = INTEGER(Smaxn)[0],
    N = ncols(Srf);
  Long
    nloc = nrows(Ssigma2),
    total = instances * nloc;
  SEXP Ans;
  PROTECT(Ans = allocVector(REALSXP, total));
  double *ans = REAL(Ans);
  
  for (int i=0; i<total; ans[i++] = RF_NEGINF);
  GetRNGstate();
  for (int t=0; t<instances; t++, ans += nloc) {
    PRINTF("\nt=%d ", t);
    double pois = 0;
    for (int m=0; m<maxn; m++) {
      double e = rexp(1.0);
      pois += e;
      int
	x0 = (int) (UNIFORM_RANDOM * nloc);
      if (t == 1) { PRINTF(" pois=%10g e=%10g %d : ", pois, e, x0);}
      double
	*field = rf + nloc * (int) (UNIFORM_RANDOM * N),
	*s2 = sigma2 + x0 * nloc,
	uz0 = - LOG(pois) - field[x0];
      
      for (int j=0; j<nloc; j++) {
        if (j == x0 && field[j] != field[x0]) BUG;
	double w = uz0 + field[j] - s2[j];
	if (t==1 && j == 97-68 - 1 && (m <= 10)) {
	  PRINTF("j=%d %10g %10g u=%10g\n", j, w, ans[j], - LOG(pois));
	}
	if (t == 1 && j == 97-68 - 1 &&  x0 == j) {
	  PRINTF("\nGREAT j=%d %10g %10g u=%10g\n", j, w, ans[j], - LOG(pois));
	}
	if (w > ans[j]) ans[j] = w;
      }
    }
  }
  PutRNGstate();
  UNPROTECT(1);
  return Ans;
}


//
#endif // SCHLATHERS_MACHINE


#endif // compatibility_to_R
