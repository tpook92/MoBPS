
/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#ifndef randomfieldsutils_extern_H
#define randomfieldsutils_extern_H 1


#include "AutoRandomFieldsUtilsLocal.h"
#include "zzz_RFU.h"

extern int PLoffset, PL;
extern utilsoption_type OPTIONS; // OK

#define prefixN 3
extern const char * prefixlist[prefixN], **allOptions[prefixN];
extern int allOptionsN[prefixN];


// AutoRFU
extern const char *LA_NAMES[LA_LAST + 1], *PIVOT_NAMES[PIVOT_LAST + 1],
  *INSTALL_NAMES[INSTALL_LAST + 1];

//extern const char *basic[basicN];
extern const char * InversionNames[nr_InversionMethods];
//extern const char * solve[solveN];
// extern bool ToFalse[1];
//

extern int parentpid;


#endif
