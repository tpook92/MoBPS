
/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/



#ifndef rfutils_utils_H
#define rfutils_utils_H 1


void bes_k_simd (double *xv, double alpha, int sx, double *yv);
void set_num_threads(void);

void colMaxsI(double *M, Long r, Long c, double *ans, int cores);
void colMaxsIint(int *M, Long r, Long c, int *ans, int cores);
void rowProdI(double *M, Long r, Long c, double *ans);
void rowMeansI(void *M, int sexp, Long r, Long c, double *weight, double *ans);
void dbinormI(double *x, double *y, Long nrow, double *sigma, double *ans);
void dotXVI(double *M, Long r, Long c, double *V, double *Ans);
#if defined rfutils_options_H
void AtAInt(int *a, int *b,
	    Long nrow, Long ncol, // a and b have same size
	    Long ld, Long ldC,
	    Long *C, // result
	    int VARIABLE_IS_NOT_USED cores,
	    solve_options *options);


#endif

  
void sqrtRHS_Chol(double *U, int size, double* RHS, Long RHS_size,
  Long n, double *result, bool pivot, int act_size, int cores,
  int *pi);

void avx_scalarprodD4(double * x, double * y, Long len, Long ldY,
		      double *s0, double *s1, double *s2, double *s3);

#endif
