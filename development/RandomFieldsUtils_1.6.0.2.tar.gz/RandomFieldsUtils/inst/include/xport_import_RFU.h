/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/

#ifndef RandomFieldsUtilsxport_H
#define RandomFieldsUtilsxport_H 1

typedef
struct KEY_type KEY_type;
struct KEY_type {
  KEY_type *next;
  utilsoption_type global_utils;
  int pid,  visitingpid;
  bool ok, doshow, locked;
  errorstring_type error_location;

  int *ToIntDummy;
  int ToIntN, ToRealN ;
  double *ToRealDummy;

  whittle_work_type whittle;
};
extern KEY_type *PIDKEY[PIDMODULUS];
KEY_type *KEYT();

typedef
struct option_type option_type;
//utilsoption_type *WhichOption(bool local);
void PIDKEY_DELETE();

extern const char *R_TYPE_NAMES[LAST_R_TYPE_NAME + 1];

#endif
