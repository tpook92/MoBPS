## Authors 
## Martin Schlather, martin.schlather@uni-mannheim.de
##
##
## Copyright (C) 2015 -- 2021 Martin Schlather
##
## This program is free software; you can redistribute it and/or
## modify it under the terms of the GNU General Public License
## as published by the Free Software Foundation; either version 3
## of the License, or (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  


## optionsDelete <- function(RFopt, register=NULL) {}


## BEIM AUFRUF: entweder mit COPY = FALSE oder nachfolgend mit !hasArg("COPY")

iRFoptions <- function(local_, getoptions_) {
  if (length(getoptions_) == 0) .External(C_LocalOptions,local_=local_)
  else .External(C_LocalOptions,local_=local_, getoptions_=getoptions_)
}

internalRFoptions <- function(..., local_=TRUE, getoptions_=NULL,
                              saveoptions_=NULL, FORMER = FALSE, RETURN = TRUE){
  ## saveoptions_ darf nicht in ... auftauchen, da dann ...length() > 0
  ## um saveoptions_ nicht als Extrafall zu behalten, verschmelzung mit
  ## getoptions_:
   
  if (hasArg("saveoptions_"))
     getoptions_ <- unique(c(getoptions_, saveoptions_, "basic", "general"))

  if (FORMER) former <- iRFoptions(local_=local_, getoptions_=getoptions_)
 
  L <- list(...)
  docopy <- !hasArg("COPY")
  if (docopy) docopy <- length(L) > 0
  else {
    idx <- names(L) == "COPY"
    docopy <- all(unlist(L[idx]))
    L <- L[!idx]
  }
  if (docopy) {
    if (!hasArg("NAME")) stop("NAME not given.")
    idx <- which(names(L) == "NAME")
    stopifnot(length(idx) == 1)
    .Call(C_copyoptions, L[[idx]]) ## from global to KT (local)
  }
  L <- L[names(L) != "NAME"]
  
  ## sequence: local_, warnUnknown_, LIST / saveoptions_ / GETOPTION
  if (length(L) > 0) 
    do.call(.External, c(list(C_LocalOptions, local_=local_), L))

  if (RETURN) {
    new <- iRFoptions(local_=local_, getoptions_=getoptions_)
    if (FORMER) list(former, new) else new
  } else if (FORMER) former
  
}


