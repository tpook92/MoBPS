
/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/




#ifndef miraculix_Byte_H
#define miraculix_Byte_H 1




#define coding_Bytes_end(UINT,ANS_UINT)					\
  for (Long i=0; i<deltaIndiv; i++) {					\
    ANS_UINT *a = (ANS_UINT*) (ans + i * ldAns);			\
    UINT *mm = (UINT*) (((Uchar *) M) + i * LdMByte);			\
    bool w = false;							\
    for (Long j=0; j<cur_rows; j++) {					\
      w |= *mm > 2;							\
      a[j] = (ANS_UINT) *mm;						\
      mm = (UINT *) (((Uchar*) mm) + EinsByte);				\
    }									\
    total += w;								\
  }									\
  if (total>0) ERR1("coding: at least %ld values outside 0,1,2", \
		    ALONG total); /*// long OK */		 \
  }



#define get_matrix_Bytes(CODE_UINT,UINT,NAME)			\
  get_matrix_start(UINT,NAME) {					\
    Long bytes = MIN(lda, ldAns) * (BitsPerCode / BitsPerByte);		\
    if (transposed == False && sizeof(UINT) == sizeof(CODE_UINT)) {	\
      if (lda == ldAns) {						\
	if (code != Ans) MEMCOPY(Ans, code, (Long) cols * bytes);	\
      } else {								\
	for (Long i=0; i<cols; i++) {					\
	  unit_t *m = (code + i * lda),					\
	    *a =  Ans + i * ldAns;					\
	  MEMCOPY(a, m, bytes);						\
	}								\
      }									\
    } else {								\
      for (Long i=0; i<cols; i++) {					\
	CODE_UINT *m = (CODE_UINT*) (code + i * lda);			\
	UINT *a = (UINT*) (((Uchar *) Ans) + i * LDAnsByte);		\
	for(Long j=0; j<rows; j++) {					\
	  *a = (UINT) m[j];						\
	  a = (UINT *) (((Uchar*) a) + EinsByte);			\
	}								\
      }									\
    }									\
  }}


#define colSums_Bytes_end(UINT) \
  for (Long i=0; i<cols; i++) {					\
    /* printf("colSumsOneBute i=%d < %d\n", i, cols); */	\
    UINT *pcode = (UINT*) (code + i * lda);			\
    Long sum = 0L;						\
    for (Long j=0; j<rows; j++, pcode++) sum += *pcode;		\
    if (sums != NULL) sums[i] = sum;				\
    total += sum;						\
  }								\
  return total;							\
  }								\

#endif
