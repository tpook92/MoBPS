/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather 

 COPYRIGHT_TEXT
*/


#ifndef zzz_H
#define zzz_H 1

#ifndef __cplusplus
#include <stdbool.h>
#endif

#include "Basic_RandomFieldsUtils.h"


#if defined compatibility_to_R_h

#define none 0
#define CDEF(name, n, type) {#name, (DL_FUNC) &name, n, type}
#define CALLDEF(name, n) {#name, (DL_FUNC) &name, n}
#define EXTDEF(name, n)  {#name, (DL_FUNC) &name, n}
#define CALLABLE(FCTN)  R_RegisterCCallable(pkg, #FCTN, (DL_FUNC) FCTN)

#endif

#endif
