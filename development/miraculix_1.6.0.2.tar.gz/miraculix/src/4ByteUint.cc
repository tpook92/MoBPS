/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/



#define BitsPerCode 32
#define MY_VARIANT 32

#include "Basic_miraculix.h"
#include "intrinsics_specific.h"
#include "options.h"
#include "haplogeno.h"
#include "TemplateUint.h"
//#include "TwoBitHaplo.h"
#include "MX.h"
#include "Scalar.h"
#include "Haplo.h"
#include "Bytes.h"


Long LdaPlain(Long rows, Long LDAbitalign) {
  //   return rows * (LDAbitalign ? LDAbitalign : MY_LDABITALIGN) / MY_LDABITALIGN;
  return LDAalignBitSnps(rows * BitsPerCode); 
}

int BitsPerCodePlain() { return BitsPerCode; }

Long LdaPlainDoubled(Long rows, Long LDAbitalign) {
  //   assert(LDAbitalign || rows == 1);
  // return LDAbitalign ? 2 * rows * LDAbitalign / MY_LDABITALIGN : 1;
  return (LDAbitalign == 0 ? 1 : 2) * LDAalignBitSnps(rows * BitsPerCode); 
}


coding_start(_4Byte,Plain) {
  if (rest != 0) BUG;
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
  coding_Bytes_end(_4Byte,_4Byte);
}

coding_start(_1Byte,Plain) {			     
  if (rest != 0) BUG;
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
  coding_Bytes_end(_1Byte,_4Byte);
}



get_matrix_Bytes(_4Byte,_4Byte,Plain); 
get_matrix_Bytes(_4Byte,_1Byte,Plain);


colSums_start(Plain)
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) reduction(+:total) schedule(static)
#endif
colSums_Bytes_end(_4Byte);



void TwoBithaplo2genoPlain(unit_t *code, Long rows, Long cols, Long lda,
			   int VARIABLE_IS_NOT_USED cores,
			   unit_t *Ans, Long ldAns) {
  MEMSET(Ans, 0, totalMem(cols, lda, FourByteGeno) * BytesPerUnit);
  assert(BitsPerCode == 32);
#define ByteCodeMask 3

#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
  for (Long i=0; i<cols; i++) {
    unit_t
      *pC = code + lda * i,
      *a = Ans + i * ldAns;
    for (Long s = 0; s < rows; s++)
      a[s] = GetTwoBitHaplo(pC, s);
  }
}

void crossprod_Plain(unit_t * Code, Long rows, Long cols,
		     Long VARIABLE_IS_NOT_USED lda,
		     int cores, double *A){
  int indiv =  stopIfNotInt(cols);
  stopIfNotSame(_4Byte, int);
  matmulttransposedInt((int*) Code, (int*) Code, A,
		       stopIfNotInt(rows), indiv,
		       indiv, cores); 
}
