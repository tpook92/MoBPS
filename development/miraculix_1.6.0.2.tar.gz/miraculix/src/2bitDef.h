/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/

#define BitsPerCode 2
#define BytesPerPartUnit 2 // for 32 & 64 code only

#include "Basic_miraculix.h"
#include "intrinsics_specific.h"
#include "intrinsics.multi.h"
#include "options.h"
#include "MX.h"
#include "Files.h"
#include "bitBase.h"
