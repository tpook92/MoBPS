/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/

#ifndef miraculix_avx_miss_H
#define miraculix_avx_miss_H 1

// !defined appropriate AVX
void static AVXmissing() { ERR3("ERROR: '%sv%d' needs appropriate AVX features (%s).\n", CODING_NAMES[MY_CODING], MY_VARIANT, __FILE__ ); }
#define Sm { AVXmissing(); return R_NilValue; }
#define Su { AVXmissing(); return 0; }
#define Sv { AVXmissing(); }
#if defined V 
#undef V
#endif
#if defined VARIABLE_IS_NOT_USED
#define V VARIABLE_IS_NOT_USED
#else
#define V
#endif



#endif
