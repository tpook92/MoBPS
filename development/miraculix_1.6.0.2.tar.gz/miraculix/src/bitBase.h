
/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#ifndef miraculix_BitBase_H
#define miraculix_BitBase_H 1

#define loop_1bit 16
#define loop_2bit 15
#define TABLE2_SIZE  two_codingBitsPerPartUnit


#endif
