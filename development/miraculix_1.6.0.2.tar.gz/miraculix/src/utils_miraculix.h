
/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#ifndef miraculix_utils_H
#define miraculix_utils_H 1

int *ToIntI(SEXP X, bool *create, bool round);

#define ToIntDo(X, CREATE)					\
  bool create##X = CREATE;					\
  Uint *X##int = (Uint*) ToIntI(X, &create##X, false)

#define ToIntLocal(X) ToIntDo(X, true)	
#define ToIntGlobal(X) ToIntDo(X, false)	

#define FREEcreated(X) if (!create##X) {} else FREE(X##int)

#endif
