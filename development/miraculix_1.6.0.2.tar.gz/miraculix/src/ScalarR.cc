
/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#include "Basic_miraculix.h"

#if defined compatibility_to_R_h
#include "miraculix.h"
#include "options.h"
#include "Scalar.h"
#include "MXinfo.h"


SEXP crossprodInt(SEXP X, SEXP Y, SEXP mode) {
  GetCores;
  int n;
  Uint nrow,
    len,
    lenY,
    ncol;
  if (isMatrix(X)) {
    nrow = ncols(X);
    len = nrows(X);
  } else {
    nrow = 1;
    len = LENGTH(X);
  }
  if (isMatrix(Y)) {
    ncol = ncols(Y);
    lenY = nrows(Y);
  } else { 
    ncol = 1;
    lenY = LENGTH(Y);
  }
  if (lenY != len) ERR0("sizes of 'x' and 'y' do not match");
  if (LENGTH(mode) == 0) n = SCALAR_INT_DEFAULT;
  else {
    n = INTEGER(mode)[0];
    if (n < 0) n =  SCALAR_INT_DEFAULT;
  }

  
  SEXP Ans; 
  PROTECT(Ans = allocMatrix(INTSXP, nrow, ncol));
  int *x, *y,
    *ans =  INTEGER(Ans);
  if (TYPEOF(X) == INTSXP) x = INTEGER(X); else x=LOGICAL(X);
  if (TYPEOF(Y) == INTSXP) y = INTEGER(Y); else y=LOGICAL(Y);

  crossprod_Int(x, y, nrow, ncol, len, cores,  ans);
  
  UNPROTECT(1);
  return Ans;
}



#endif
