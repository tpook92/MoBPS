/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/




#ifndef miraculix_plink_H
#define miraculix_plink_H 1


Long LdaPlink(Long snps, Long LDAbitalign);
Long LdaOrigPlink(Long snps, Long LDAbitalign);

coding_header(_4Byte, Plink);
coding_header(_1Byte, Plink);
get_matrix_header(_4Byte,Plink);
get_matrix_header(_1Byte,Plink);

vectorGeno_header(Ulong, Ulong, Ulong, Plink);
vectorGeno_header(double, double, double, Plink);
vectorGeno_header(LongDouble, LongDouble, LongDouble, Plink);
vectorGeno_header(double, double, double, PlinkMatrix256);
colSums_header(Plink);

sparsevectorGeno_header(Plink);

void getPlinkMissings(Uchar* plink,  bool is_plink_tr, SEXP SxI,
		      basic_options *opt);

coding_header(_4Byte, Plinktrans);
coding_header(_1Byte, Plinktrans);

int BitsPerCodePlink();


#if defined CODE_ONE
#undef CODE_LASTZERO
#undef CODE_ONE
#undef CODE_TWO
#endif
#define CODE_LASTZERO 1
#define CODE_ONE 2
#define CODE_TWO 3

#endif
