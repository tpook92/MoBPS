
/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather 

 COPYRIGHT_TEXT
*/


#ifndef compatibility_general_h 
#define compatibility_general_h 1

#ifndef __cplusplus
#include <stdbool.h>
#endif
#include "compatibility.header.h"
#include <inttypes.h>

typedef unsigned int Uint;
typedef uint64_t Ulong;
typedef int64_t Long;
typedef unsigned char Uchar;


#ifdef __cplusplus
#define F77name extern "C" void F77_NAME // rename to control that USE_FC_LEN_T has been called
#else
//#warning not cplusplus
#define F77name void F77_NAME 
#endif
#define F77dgesdd F77call(dgesdd)
#define F77dgemv F77call(dgemv)
#define F77dsyrk F77call(dsyrk)

#if defined INCLUDE_FORTRAN
#define F77call F77_CALL // rename to control that USE_FC_LEN_T has been called
#define F77ddot F77call(ddot)
#else
#define F77call(...) FORTRAN_ERROR
#define FORTRAN_ERROR(...) ERR2("Fortran isn't currently implemented at line %d in %.50s",  __LINE__, __FILE__)
#define F77ddot(...) RF_NAN; FORTRAN_ERROR();
#endif

int stopIfNotIntI(Long i, Long line, const char *file);
#define stopIfNotInt(i) stopIfNotIntI(i, __LINE__, __FILE__)

Uint stopIfNotUIntI(Long i, Long line, const char *file);
#define stopIfNotUint(i) stopIfNotUIntI(i, __LINE__, __FILE__)

int stopIfNotAnyIntI(Long i, Long line, const char *file);
#define stopIfNotAnyInt(i) stopIfNotAnyIntI(i, __LINE__, __FILE__)

#define stopIfNotSame(i,j)\
  if (sizeof(i) == sizeof(j)) {} else { ERR6("'%s' (%ld) and '%s' (%ld) do not have the same size at line %d in '%s'\n", #i, ALONG sizeof(i), #j, ALONG sizeof(j), __LINE__, __FILE__) }


#if defined STAND_ALONE
//#warning STAND_ALONE
#include "compatibility.C.h"
#else
//#warning R_VERSION
#include "compatibility.R.h"
#endif


// #define SPRINTF(S, F, ...) SNPRINTF(S, sizeof(S), F, __VA_ARGS__)

#define SPRINTF(S, F, ...) SNPRINTF(S, sizeof(S), F, __VA_ARGS__)


void *notNull(void *X, int line, const char *file);
  
#endif
