/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#ifndef miraculix_transform_H
#define miraculix_transform_H 1

typedef void (*coding_t)(unit_t *, Long, Long, Long, Long, Long,
			 int, double *, unit_t*, Long, usr_bool, Long);


void haplo2geno(SEXP SxI, option_type *global, basic_options *opt);
void haplo2geno(unit_t *M, Long rows, Long cols, Long lda,
		coding_type oldCoding, int variant, int cores);


void matrix_get_4Byte(unit_t *code, Long rows, Long cols, 
		      coding_type coding, Long lda,
		      int cores, unit_t *ans, Long ldAns, usr_bool transposed);

coding_t matrix_coding_1Byte(coding_type coding, usr_bool *transposed,
				int variant, bool bigendian);
coding_t matrix_coding_4Byte(coding_type coding, usr_bool *transposed,
				int variant, bool bigendian);


SEXP transpose(SEXP SxI,  option_type *global, utilsoption_type *utils);

SEXP Transform(SEXP SxI, unit_t* SxInt, coding_type codingInfo,
	       int* selSnps, int lenSnps, int *selIndiv, int lenIndiv,
	       option_type *global, utilsoption_type *utils);


SEXP transform(SEXP SxI,
	       int *selSnps, int lenSelSnps,
	       int *selIndiv, int lenSelIndiv,
	       usr_bool set1, bool add_transposed,
	       option_type *global, utilsoption_type *utils,
	       bool transformOnPlace,
	       coding_type ansCoding, usr_bool AnsTransposed,
	       int ansVariant);

SEXP transform(void *pointer, void *nextpntr,
	       Long snps, Long individuals,
	       coding_type coding, 
	       usr_bool pointer_is_transposed,
	       Long LDAbitalign,
	       int* selSnps, int lenSelSnps,
	       int *selIndiv, int lenSelIndiv,
	       usr_bool set1, bool add_transposed,
	       option_type *global, utilsoption_type *utils,
	       coding_type ansCoding,  usr_bool ansTransposed,
	       int ansVariant);

extern const Long CpByte, CpByteplink, BitsPerCodeplink;

void copyAttribInfos(SEXP To, SEXP From, bool unconditional, bool relaxed);


#endif


