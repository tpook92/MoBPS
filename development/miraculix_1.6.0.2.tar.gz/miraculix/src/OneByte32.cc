
/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/

#define BitsPerCode 8 
#define MY_VARIANT 32
#define PlainInteger32 1

#include "Basic_miraculix.h"
#include "intrinsics_specific.h"
#include "options.h"
#include "haplogeno.h"
#include "Template.h"
#include "MXinfo.h"
#include "OneByte.h"


#define scalarA scalar // dummy, unused
#define scalarB scalar // dummy, unused


void OneByteHaplo2geno32(unit_t *H,
			 Long VARIABLE_IS_NOT_USED rows, Long cols,
			 Long lda,
			 int VARIABLE_IS_NOT_USED cores,
			 unit_t *Ans,
			 Long ldAns) {
  // works also for 128,256,512; to do
  assert((intptr_t) H % (64 / BitsPerByte) == 0 &&
	 (intptr_t) Ans % (64 / BitsPerByte) == 0);
  if (H == Ans && ldAns > lda) ERR0("1byteH to geno not possible"); // to do?
  const Long total = lda * cols;
  const Long blocks = total / UnitsPerBlock; // OK
  BlockType
    *H1 = (BlockType*) H,
    *H2 = (BlockType*) (H + total),
    *G = (BlockType*) Ans;

#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif  
  for (Long i=0; i<blocks; i++)
    STORE(G + i, ADD64(LOAD(H1 + i), LOAD(H2 + i)));
  for (Long i=blocks * CodesPerBlock; i<total; i++)
    Ans[i] = H[i] + H[i+total];
}


void FourHaplo2geno32(unit_t *H, Long rows, Long cols, Long lda,
		      int cores, unit_t *Ans, Long ldAns) {
  // alignment not garanteed!
  if ((intptr_t) H % (64 / BitsPerByte) == 0 &&
      (intptr_t) Ans % (64 / BitsPerByte) == 0) {
    OneByteHaplo2geno64(H, rows, cols, lda, cores, Ans, ldAns);
    return;
  }

if (H == Ans && ldAns > lda) ERR0("1byteH to geno not possible"); // to do?
 const Long total = lda * cols;
 const Long blocks = total / UnitsPerBlock; // OK
  BlockType
    *H1 = (BlockType*) H,
    *H2 = (BlockType*) (H + total),
    *G = (BlockType*) Ans;
  
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif  
  for (Long i=0; i<blocks; i++)
    STOREU(G + i, ADD64(LOADU(H1 + i), LOADU(H2 + i)));
  for (Long i=blocks * CodesPerBlock; i<total; i++)
    Ans[i] = H[i] + H[i+total];
}

