
/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#ifndef miraculix_2bitIntern_H
#define miraculix_2bitIntern_H 1


#if defined SHUFFLE8

const BlockType
to_scalar =  SETREV8( 0, 2, 1, 4,  2, 4, 3, 6,  1, 3, 2, 5,  4, 6, 5, 8);

static Ulong scalar(BlockType0 *x, BlockType0 *y, Long blocks,
		   Long VARIABLE_IS_NOT_USED Delta) {
  const BlockType zero = ZERO();
  Ulong ans = 0;

  Long bundles = blocks  / loop_2bit;
  int minibundle = loop_2bit;;
  for (char k=0; k<=1; k++) {
    if (k) { //
      minibundle = (int) (blocks % loop_2bit);
      x += bundles * loop_2bit;
      y += bundles * loop_2bit;
      bundles = minibundle > 0;
    } 
    
    for (Long i=0; i<bundles; i++) { 
      //printf("k=%d i=%d bundles=%d\n", k, i, bundles);
     BlockType
	sum = ZERO(),
	*xx = x + i * minibundle,
	*yy = y + i * minibundle;     
      for (int j=0; j<minibundle; j++) {
	//	printf("k=%d i=%d j=%d %d\n", k, i, j, minibundle);
	const BlockType a0 = LOAD(xx++);
	const BlockType b0 = LOAD(yy++);
	const BlockType z0 = AND(a0, b0);
	const BlockType z1 = XOR(a0, b0);
	
	const BlockType z2 = AND(z0, E1N1);
	const BlockType z3 = SHR32(z2, 1L);
	const BlockType z4 = OR(z3, z1);
	
	const BlockType z5 = AND(z4, z1); 
	const BlockType z7 = SUB(z0, z5); 
	
	const BlockType z8 = AND(z7, O1F1); 
	const BlockType z9 = SHR32(z7, 4);
	const BlockType z10 = AND(z9, O1F1); 
	
	const BlockType z11 = SHUFFLE8(to_scalar, z8); 
	const BlockType z12 = SHUFFLE8(to_scalar, z10); 
	sum = ADD8(sum, z11);
	sum = ADD8(sum, z12); 
      }
      const BlockType vsum = SAD8(sum, zero);
      ans += HORIZ_ADD64(vsum);
    }
  }
  return ans;
}


static void scalar_2x2(BlockType0 *x, BlockType0 *y,
		       BlockType0 *u, BlockType0 *v,
		       Long blocks,
		       Ulong *ansA, Ulong *ansB, Ulong *ansC, Ulong *ansD
		       ) {
  const BlockType zero = ZERO();
  Ulong a=0, b=0, c=0, d=0;
  //#define y15 (255L / 16L)  // 16L = 4 * 2^2 (a byte full of 1's)
  //#define y15 (255L / 16L)  // warum ist dies schneller ?????

  Long  bundles = blocks  / loop_2bit;
  int minibundle= loop_2bit;
  for (char k=0; k<=1; k++) {
    if (k) {//
      minibundle = (int) (blocks % loop_2bit);
      x += bundles * loop_2bit;
      y += bundles * loop_2bit;
      u += bundles * loop_2bit;
      v += bundles * loop_2bit;
      bundles = minibundle > 0;
    } 
    for (Long i=0; i<bundles; i++) { 
      BlockType
	asum = ZERO(),
	bsum = ZERO(),
	csum = ZERO(),
	dsum = ZERO(),    
	*xx = x + i * minibundle,
	*yy = y + i * minibundle,
	*uu = u + i * minibundle,
	*vv = v + i * minibundle;
      for (int j=0; j<minibundle; j++) {
	const BlockType aa = LOAD(xx++);
	const BlockType bb = LOAD(yy++);
	const BlockType cc = LOAD(uu++);
	const BlockType dd = LOAD(vv++);
	
	const BlockType a0 = AND(aa, bb); // x,y
	const BlockType b0 = AND(cc, dd); // u,v
	const BlockType a1 = XOR(aa, bb);
	const BlockType b1 = XOR(cc, dd);
	
	const BlockType c0 = AND(aa, dd); // x, v
	const BlockType d0 = AND(cc, bb); // u, y
	const BlockType c1 = XOR(aa, dd);
	const BlockType d1 = XOR(cc, bb);
	
	AND4_C(2, 0, E1N1); //
	SHR32_4(3, 2, 1L); //
	OR4(4, 3, 1); // 00 00 00\\ 00 11 11 \\ 00 11 11

	AND4(5, 4, 1); // 00 00 00 \\ 00 00 01 \\ 00 01 00
	SUB4(7, 0, 5); // 00 00 00 \\ 00 10 01 \\ 00 01 11
	
	AND4_C(8, 7, O1F1); 
	SHR32_4(9, 7, 4);//
	AND4_C(10, 9, O1F1); //
	
	SHUFFLE8_4(11, to_scalar, 8); //
	SHUFFLE8_4(12, to_scalar, 10);//
	
	ADDUP8_4(sum, 11);      
	ADDUP8_4(sum, 12); 
      }
      SAD8_4(vsum, sum, zero);
      HORIZ_ADD64_4(vsum);
     }
  }
  *ansA = a;
  *ansB = b;
  *ansC = c;
  *ansD = d;
}

#define SCALAR012(NR)						\
  Ulong scalar_2v##NR(unit_t *x, unit_t *y, Long blocks, Long Delta) {	\
    return scalar((BlockType0*) x, (BlockType0*) y, blocks, Delta);	\
  }									\
  void multi_2v##NR(unit_t *x, unit_t *y,				\
		    Long VARIABLE_IS_NOT_USED cols,		\
		    Long blocks, Long VARIABLE_IS_NOT_USED lda,	\
		   double *ans) {			\
    *ans += (double) scalar((BlockType0*) x, (BlockType0*) y, blocks, 0); \
  }									\
  void multi2x2_2v##NR(unit_t *x, unit_t *y, Long cols, \
		       Long blocks, Long lda,		   \
		       double *ans) {					\
    Ulong A=0, B=0, C=0, D=0;						\
    scalar_2x2((BlockType0 *) x, (BlockType0 *) y,			\
	       (BlockType0 *) (x + lda), (BlockType0 *) (y + lda),	\
	       blocks, &A, &B, &C, &D);					\
    *ans += (double) A;							\
    ans[cols + 1] += (double) B;					\
    ans[cols] += (double) C;					\
    ans[1] += (double) D;						\
}



#endif // plinkIntern.h
