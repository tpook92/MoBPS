
/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/



#ifndef rfutils_general_H
#define rfutils_general_H 1

#include "errors_messages.h"
#include "options_RFU.h"


#endif
