/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/

#define BitsPerCode 1

#include "Basic_miraculix.h"
#include "intrinsics_specific.h"
#include "intrinsics.multi.h"
#include "options.h"
#include "MX.h"
