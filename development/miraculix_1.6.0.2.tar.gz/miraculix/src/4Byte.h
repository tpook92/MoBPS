/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/

#ifndef miraculix_auto_H
#define miraculix_auto_H 1

Long LdaPlain(Long rows, Long ldAbitalign);
Long LdaPlainDoubled(Long rows, Long ldAbitalign);
colSums_header(Plain);
coding_header(_4Byte, Plain);
coding_header(_1Byte, Plain);
get_matrix_header(_4Byte,Plain);
get_matrix_header(_1Byte,Plain);

void TwoBithaplo2genoPlain(unit_t * Code, Long rows, Long cols, Long lda,
			   int cores, unit_t *A);
void crossprod_Plain(unit_t * Code, Long rows, Long cols, Long lda,
		     int cores, double *A);


int BitsPerCodePlain();
  
#endif

