/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/



#ifndef miraculix_Bit23Uint_H
#define miraculix_Bit23Uint_H 1


#define UNIT_CODING(UINT, M, ldM, start_row, end_row, \
		    start_col, end_col, Ans, ldAns, FROM)	\
  UINT *pM = (UINT*) (M + (i - start_col) * ldM);	\
  Uint shift = 0,						\
    counter = 0;							\
  unit_t compressed = 0;						\
  unit_t *pAns =  Ans + i * ldAns;					\
  for (Long s=start_row; s<end_row; s++) {				\
    compressed |= (unit_t) (geno_code[FROM] << shift);			\
    shift += BitsPerCode;						\
    if (++counter >= CodesPerPartUnit) {				\
      shift += deltaBitsPartUnit; /* 3bit */				\
      counter = 0;							\
    }									\
    if (shift >= BitsPerUnit) {						\
      *pAns = compressed;						\
      pAns++;								\
      shift = counter = 0;						\
      compressed = ZERO();						\
    }									\
  }									\
  if (shift > 0) {							\
    *pAns = compressed;							\
    pAns++;								\
  }									




typedef  char table_type; //  10.585 
//typedef unsigned char table_type; //  10.612
//typedef unsigned int table_type; //   10.325 
//typedef int table_type; //  10.217


void initiate_tableI(table_type **TABLE, int TABLESIZE,
		     int codesPerPartUnit, int bits,
		     Uint *result_code,
		     Uint *result_value, int NrResults);

inline static Uint ExtractCode(unit_t *M, Long S) {
  const unit_t MC = M[S / CodesPerUnit];
  const int s = (int) (S % CodesPerUnit);
  return (MC >> (BitsPerPartUnit * (s / CodesPerPartUnit) +
		 (s % CodesPerPartUnit) * BitsPerCode)) & CodeMask;
}

inline static void PositionCode(Long S,  Long *j, unit_t *mask) {
  *j = S / CodesPerUnit;
  int idx = (int) S % CodesPerUnit;	
  *mask = (unit_t) CodeMask << (BitsPerPartUnit * (idx / CodesPerPartUnit) +
				(idx % CodesPerPartUnit) * BitsPerCode);
}

/*
inline static void PositionCode(Long S, Uint codemask,  Long *j, Uint *mask) {
  *j = S / CodesPerUnit;
  int idx = (int) (S % CodesPerUnit);	
  *mask = codemask << ( BitsPerPartUnit * (idx / CodesPerPartUnit) +
			(idx % CodesPerPartUnit) * BitsPerCode);
}
*/



/* 2 Bit / Plink Transposed */
/* EXTREM LANGSAM !! */
#define coding2trans_start(UINT,NAME)				\
  coding_header(UINT, NAME##trans) {					\
  if (start_row != 0) BUG;						\
  if (start_col % CodesPerBlock != 0) BUG; /* // OK */		\
  if (transposed != False) BUG;					\
 unit_t *ans =Ans + start_col / CodesPerUnit;			\
  Long rows = end_row - start_row;					\
  Long deltaCol = end_col - start_col;			\
  Long end_colM4 = (deltaCol) / 4;				\
  Long ldAnsInByte = ldAns * sizeof(unit_t);


#define coding2trans_do(UINT,TRAFO)				\
  for (Long i=0; i<end_colM4; i++) {\
    Uchar *a = ((Uchar*) ans) + i;					\
    UINT *pM0 = (UINT*) (M + (4 * i + 0) * ldM);		\
    UINT *pM1 = (UINT*) (M + (4 * i + 1) * ldM);		\
    UINT *pM2 = (UINT*) (M + (4 * i + 2) * ldM);		\
    UINT *pM3 = (UINT*) (M + (4 * i + 3) * ldM);		\
    for (Long j=0; j<rows; j++) { \
      a[ldAnsInByte*j] = (Uchar)(TRAFO(pM0[j]) + (TRAFO(pM1[j]) << 2) + \
				 (TRAFO(pM2[j]) << 4) + (TRAFO(pM3[j]) << 6)); \
    }									\
  }									\
  Long i = end_colM4;							\
  Uchar *a = ((Uchar*) ans) + i;					\
  UINT *pM0 = (UINT*) (M + (4 * i + 0) * ldM);		\
  UINT *pM1 = (UINT*) (M + (4 * i + 1) * ldM);		\
  UINT *pM2 = (UINT*) (M + (4 * i + 2) * ldM);		\
  if (4 * i < deltaCol) {						\
    for (Long j=0; j<rows; j++) {					\
      Uchar a0 = (Uchar) TRAFO(pM0[j]);					\
      if (4 * i + 1 < deltaCol) {					\
	a0 = (Uchar) (a0 + (TRAFO(pM1[j]) << 2));			\
	if (4 * i + 2 < deltaCol) {					\
	  a0 = (Uchar) (a0 + (TRAFO(pM2[j]) << 4));			\
	}								\
      }									\
      a[ldAnsInByte * j] = a0;						\
      if (false) PRINTF("a[%ld, %ld] = %d; %ld %ld ldAnsInByte=%ld\n", ALONG i,ALONG j, a0, ALONG i, ALONG end_colM4, ALONG ldAnsInByte); \
    }									\
  }									\
  }



#endif
