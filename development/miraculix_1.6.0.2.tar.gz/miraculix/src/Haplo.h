/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#ifndef miraculix_Haplo_H
#define miraculix_Haplo_H 1



unit_t GetTwoBitHaplo(unit_t *code, Long snp);

typedef unit_t (*GetTwoBitHaploFun)(unit_t *code, Long snp);


void codeHaplo(unit_t *MM, Long rows, Long cols, Long lda, 	
	       coding_type coding,		
	       int *col_list, int col_list_N, 
	       basic_options *opt,
	       unit_t *Ans, Long NewCol, Long ldAns,
	       coding_type newCoding );


void decodeHaplo(unit_t *code, Long rows, Long cols ,Long lda,
		 coding_type coding,		      
		 int *col_list, int col_list_N,
		 usr_bool set1, int cores,
		 unit_t *Ans, Long NewCol, Long ldAns,
		 coding_type newCoding);


void getHaploIncr(Long rows, Long cols, Long lda, coding_type coding, 
		  Long compressed_lda, coding_type compressed_coding, 
		  Long requestedBits, // 1 or 2
		  Long *uIncr, Long *nextHaploIncr,  // all un-compressed
		  Long *deltaTo2ndUncompressedHaplo,
		  Long *deltaToNextUncompressedCol,     // all un-compressed
		  Long *bitsPerCodeCompr, Long *shiftIncrCompr,//compressed
		  Long *deltaCompressed, Long *CpUcompressed);

void getHaploIncr(Long cols, Long lda, coding_type coding, 
		  Long requestedBits,
		  Long *nextHaploIncr, Long *deltaTo2ndUncompressedHaplo,
		  Long *indivIncr);


coding_header(_4Byte,Haplo1Byte);

void InnerDetermTwoBitHaplo(double *freq1, double *freq2, Long rows, Long cols,
			    coding_type coding, 
			    unit_t *ans, Long ldAns);
void InnerRandomTwoBitHaplo(double *freq1, double *freq2, Long rows, Long cols,
			    coding_type coding,
			    unit_t *ans, Long ldAns);
#endif
