/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/

#define NO_OMP 1
#include "Basic_miraculix.h"

void intEV(int* x, int* z, int* Len, int *K, int *sumsq, int *n,
	   int* pos) {
  #define every 10000
  int h,diff,
    k = *K,
    len = *Len;

  for (int i=0; i<k; i++) sumsq[i] = n[i] =0;
  for (int i=0; i<len; pos[i++]=0);
  
  for (int i=0; i<len; i++) {
    if ((i % every) == 0) { PRINTF("%d (%d)\n", i / every, len / every); }
    //  print("%d %d\n", i, len);
    for (int j=i+1; j<len; j++) {      
      h = x[j] - x[i];
      if (h >= k) break;    
      diff = z[j] - z[i];
      diff *= diff;
      if (diff > 0) {
	(pos[i])++;
	(pos[j])++;
      }
      sumsq[h] += diff;
      n[h] ++;
    }
  }
  // printf("ok\n");
}
