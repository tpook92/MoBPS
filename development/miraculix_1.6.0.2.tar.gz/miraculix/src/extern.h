/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/



#ifndef miraculix_extern_H
#define miraculix_extern_H 1

extern int PL;
extern bool debugging;

#endif
