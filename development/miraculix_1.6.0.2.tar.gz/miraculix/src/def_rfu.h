
/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


/// sysconf (_SC_NPROCESSORS_ONLN) // number of cores available
// int get_nprocs (void) // dito

#ifndef RFUdefRFU_H
#define RFUdefRFU_H 1


////////////////////////////////////////////#define STAND_ALONE 1  // for debugging only

//// 1
//#define SCHLATHERS_MACHINE 1
//#define SCHLATHER_DEBUGGING 1


//

#define INCLUDE_FORTRAN 1
 

#if ! defined SCHLATHERS_MACHINE && defined SCHLATHER_DEBUGGING
#undef SCHLATHER_DEBUGGING
#else
////  1
#endif

// #define NO_OMP 1

#if ! defined pkg
#define pkg "RandomFieldsUtils" // RFU DELETE
#endif

#endif
