/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#ifndef miraculix_5codesDef_H
#define miraculix_5codesDef_H 1

#define BitsPerCode 1.6 // <= info; math: 1.58496250072115618145374
#define MY_CODING FiveCodes
#define MY_LDABITALIGN 64
#define CpB 5
#define BytesPerPartUnit 1 // defining it previous to "intrinsics_specific.h"

#include "def.h"
#include "Basic_miraculix.h"
#include "intrinsics_specific.h"
#include "options.h"
#include "Template.h"
#include "5codes.h"



#endif
