/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/



#ifndef miraculix_api_H
#define miraculix_api_H 1


#ifdef __cplusplus
extern "C" {
#endif
  
  void setOptions5(int gpu, int cores, int floatprecision,
		   int meanV, int meanSubstract,		   
		   int missingsFully0,
		   int centered, int normalized,
		   int use_miraculix_freq, 
		   int variant, int print_details);
  void plinkToSxI(char *plink, char *plink_transposed, 
		  long snps, long indiv, // long OK
		  int coding,
		  double *f, 
		  int max_n,
		  void**compressed);
  void free5(void **compressed) ;
  void SxIvector5api(void *SxI, double *V,
		      long repetV, long LdV, double *ans, long LdAns);// long OK
  void vectorSxI5api(void *SxI, double *V,
		      long repetV, long LdV, double *ans, long LdAns);// long OK
  
  void getFreq5(void *compressed,  double *f) ;

  void getStartedOptions(void);
  
  
  void sparsevectorGenoPlinkApi(char *compressed,
				int rows,
				int col,
				double *valueB,
				int nIdx,//2nd dim of sparse; == length(rowIdxB)
				int *rowIdxB,
				int *colIdxB,
				int tSp,
				double *C,
				int Ldc);
  
  void vectorGenoPlinkApi(char *compressed,
			   int rows, 
			   int cols,
			   double *f,
			   double *B,
			   int n,
			   int LdB,
			   double *C,
			   int Ldc);
    
  
  void check_started(void);
  void plink2compressed(char *plink, char *plink_transposed,
			int snps, int individuals,
			double *f, 
			int max_n,
			void**compressed);
  void dgemm_compressed(char t, // transposed?,
			void *compressed,
			int n, // number of columns of the matrix B
			//			double *f,
			double *B,
			int Ldb, 
			double *C, int Ldc);
  void free_compressed(void **compressed) ;
  
  void free5(void **compressed);
  
  void get_compressed_freq(void *compressed, double *f);
  
#ifdef __cplusplus
}
#endif


#endif
