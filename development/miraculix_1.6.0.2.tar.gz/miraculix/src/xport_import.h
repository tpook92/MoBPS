/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/



#ifndef Miraculixxport_H
#define Miraculixxport_H 1


#define UTILS_LOCAL \
  CALL(solve_NULL);				\
  CALL(solve_DELETE);				\
  CALL(orderingL);				\
  CALL(orderingInt);				\
  CALL(SolvePosDefSp);				\
  CALL(sleepMicro);				\
  CALL(scalarX);				\
  CALL(scalarXint);				\


#include "xport_import_default.h"



extern const char *R_TYPE_NAMES[LAST_R_TYPE_NAME + 1];





#endif
