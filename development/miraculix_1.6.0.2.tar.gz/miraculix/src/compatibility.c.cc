
/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#if !defined compatibility_to_R_h
#include <random>
#include <stdarg.h>
#endif


#include "def.h"
#include "Basic_RandomFieldsUtils.h"
#include "options_RFU.h"
#include "errors_messages.h"


#if defined compatibility_to_C_h

double ownNA = 0.0,
  ownNaN = 0.0;


double gauss_random(double mu, double sigma) {
  std::random_device rd{};
  std::mt19937 gen{rd()};
  std::normal_distribution<> d{mu,sigma};
  return (d(gen));
}

double uniform_random(double a, double b) {
  std::random_device rd{};
  std::mt19937 gen{rd()};
  std::uniform_real_distribution<> d{a, b};
  return (d(gen));
}

double poisson_random(double lambda) {
  std::random_device rd{};
  std::mt19937 gen{rd()};
  std::poisson_distribution<> d{lambda};
  return (d(gen));
}

#endif


int stopIfNotIntI(Long i, Long line, const char *file) {
  if (i > MAXINT || i < -MAXINT)
    ERR3("value (%ld) not an integer at line %ld in %s\n",
	 ALONG i, ALONG line, file); // long OK
  return (int) i;
}
  

Uint stopIfNotUIntI(Long i, Long line, const char *file) {
  if (i > UINT_MAX || i < 0)
    ERR3("value (%ld) not an unsigned integer at line %ld in %s\n",
	 ALONG i, ALONG line, file); // long OK
  return (Uint) i;
}
  

int stopIfNotAnyIntI(Long i, Long line, const char *file) {
  // INT_MIN == NA !
  if (i > INT_MAX || i < INT_MIN)
    ERR3("value (%ld) not an integer at line %ld in %s\n",
	 ALONG i, ALONG line, file); // long OK
  return (int) i;
}
  


void *notNull(void *X, int line, const char *file) {
  if (X!=NULL) return X;
  ERR2("No memory was allocated at line %d of %s.\n", line, file);
  return NULL;
}


//void myprintf(const char *x) {
//  fprintf(stderr, "%s", X);
//  printf("error: please contact author\n"); exit(EXIT_FAILURE);
//}
