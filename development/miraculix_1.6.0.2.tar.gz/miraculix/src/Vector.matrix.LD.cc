
/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/




#include "Basic_miraculix.h"
#include "compatibility.SEXP.h"
#include "miraculix.h"
#include "options.h"
#include "MXinfo.h"
#include "kleinkram.h"
#include "haplogeno.h"
#include "Template.h"
#include "Files.h"
#include "2bit.h"
#include "5codes.h"
#include "plink.h"
#include "Vector.matrix.h"
#include "OneByte.h"
#include "time.h"


void gV_vG_means_LongDouble(SEXP SxI, 
			LongDouble *V0, Long repetV, Long ldV, 
			bool gV, // else vG
			centering_type centered,
			normalizing_type normalized,
			bool meanV,
			bool meanSxI,
			option_type *global, utilsoption_type *utils,
			LongDouble *ans, Long ldAns) {
  //  // printf("yy\n");
  STARTCLOCK;

  basic_options *opt = &(utils->basic);
  const int VARIABLE_IS_NOT_USED cores = GreaterZero(opt->cores);
  bool PL = opt->Cprintlevel > 5;
  condExtractInfo(SxI, !gV); 
  ASSERT_LITTLE_ENDIAN;
  const Long missings = info[MISSINGS];

 
  if (centered != RowMeans && centered != ColMeans && centered != NoCentering) {
    PRINTF("only centering by rowmeans and colmeans programmed\n");
    BUG;
  }
  
  const LongDouble
    c = (LongDouble) meanSxI,
    nu = (LongDouble) meanV,
    z = (LongDouble) (centered == RowMeans),
    zeta = (LongDouble) (centered == ColMeans),
    cMinusZ = (c - (gV ? zeta : z)) ;
  LongDouble *V = V0;
  LongDouble cols_LD = (LongDouble) cols;
  
  LongDouble *freqV = (LongDouble*) CALLOC(repetV, sizeof(LongDouble));  
  LongDouble *mu = (LongDouble*) CALLOC(repetV, sizeof(LongDouble));

  LongDouble *freq = NULL, *sxiOne = NULL, *colfreq = NULL,
    *freqSxI = NULL, norm2 = -1, rowSumsFreq = -1, m = -1;
  
  //  // printf("yyab\n");
  printSEXP(SxI);
  //
  if (centered != NoCentering || meanV || meanSxI ||
      normalized != NoNormalizing) {
    CLOCK("before getFreq");
    calculateFreq(SxI, R_NilValue, global, utils);
    freq =         gV ? getRowFreq(SxI)         : getColFreq(SxI);
    sxiOne =       gV ? getRowSum(SxI)          : getColSum(SxI);
    colfreq =      gV ? getColFreq(SxI)         : getRowFreq(SxI);
    freqSxI =      gV ? getRowFreqSxI(SxI)      : getColFreqSxI(SxI);
    norm2 = (gV ? getRowFreqNorm2(SxI) : getColFreqNorm2(SxI)) *
      4.0 * cols_LD * cols_LD;
    rowSumsFreq =   gV ? getColSumFreq(SxI) : getRowSumFreq(SxI);
    m = getTotalSum(SxI);
    CLOCK("getFreq");
 }
  // // printf("yyab\n");

  

  bool meanOrCZ  = meanV || cMinusZ != 0.0;
  if (meanOrCZ) { 
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static) 
#endif
     for (Long r=0; r < repetV; r++) {
      LongDouble *vv0 = V0 + r * ldV;
      LongDouble f = 0.0;
      for (Long j=0; j<cols; j++) {
	f += colfreq[j]  * (LongDouble) vv0[j];	
      }
      freqV[r] = f;
    }
  }
	
  if (meanV) {
    V = (LongDouble*) MALLOC(repetV * ldV * sizeof(*V));
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static) 
#endif
    for (Long r=0; r < repetV; r++) {
      LongDouble *vv = V + r * ldV;
      LongDouble *vv0 = V0 + r * ldV;
      LongDouble mu0 = 0;
      for (Long i=0; i<cols; i++) mu0 += freqSxI[i] * (LongDouble) vv0[i];
      mu0 *= (LongDouble) 2.0 * cols_LD;
      mu0 += (LongDouble) 2.0 * m * c * (c - 2.0) * freqV[r];
      mu0 /= norm2 + c * (c - 2.0) *  m * m / (LongDouble) rows;
      mu[r] = mu0;
      //   LongDouble mu1 = (LongDouble) mu0;
      for (Long i=0; i<cols; i++) vv[i] = (LongDouble) ((LongDouble) vv0[i] - mu0);
    }
  }
  if (PL && meanOrCZ) CLOCK(meanV ? "meanV" : "cMinusZ");

  //  // printf("yya\n");
  gV_vG_LongDouble(SxI, V, repetV, ldV,
	       gV, meanSxI, global, utils, ans, ldAns);
  if (PL)
    CLOCK3("gV_vG (%s; %s; %s)", CODING_NAMES[info[CODING]],
	   gV ? "G * v" : "v * G",
	   z ? "row means" :  zeta ? "col means" : cMinusZ ? "cMinusZ"
	   : "no means");


  if (centered != NoCentering || meanV || meanSxI) {    
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static) 
#endif
    for (Long r=0; r < repetV; r++) {
      LongDouble *vv0 = V0 + r * ldV;
      LongDouble *a = ans + r * ldAns;
      LongDouble sxiOneFactor = nu * mu[r];
      LongDouble freqFactor = 0.0;
      if ( (gV ? z : zeta) != 0.0) {
	for (Long i=0; i<cols; i++) freqFactor += ((LongDouble) vv0[i]);
	freqFactor *= -2.0;
      }      
      LongDouble onesFactor = cMinusZ * freqV[r];
      onesFactor -= c * nu * mu[r] * rowSumsFreq;
      onesFactor *= 2.0;

      //      // printf("c-z=%4.3e frqV=%4.3e c=%4.3e nu=%4.3e mu=%4.3e pF=%4.3e factor=%4.3e,%4.3e \n",(LongDouble) cMinusZ, (LongDouble) freqV[r], (LongDouble) c , (LongDouble) nu , (LongDouble)  mu[r], (LongDouble) rowSumsFreq, (LongDouble) freqFactor, (LongDouble) onesFactor );
      
      for (Long j=0; j<rows; j++) {
	// hier geht gegenueber LongDouble die Genauigkeit verloren:
	// wenn in *LD.cc  (LongDouble) (LongDouble) ((LongDouble) (LongDouble) a[j]
	// gesetzt wird ist selbst bei Centered kein Unterschied mehr da!

	a[j] = (LongDouble) ((LongDouble) a[j] + sxiOneFactor * sxiOne[j] +
			 freqFactor * freq[j] + onesFactor);
      }
      // // printf("a[0]=%4.3f\n", (LongDouble) a[0]);
     }
    if (PL)  CLOCK("centering");
  }


  // Missings
  if (centered != NoCentering) {
     SEXP Miss = getAttribPointer(SxI, Missings);
     if (Miss != R_NilValue) {
       Long *mssngs = LONG(Miss);
       assert(missings > 0);
       Long end_i = 2 * missings ;
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static) 
#endif
      for (Long r=0; r < repetV; r++) { 
	 LongDouble *vv0 = V0 + r * ldV;
	 LongDouble *a = ans + r * ldAns;
	 LongDouble Z = gV ? z : zeta;
	 LongDouble Zeta = gV ? zeta : z;

	 for (Long i=0; i<end_i; i+=2) {
	   Long alpha = mssngs[i + 1 - gV];
	   Long beta = mssngs[i + gV];
	   //a[alpha] += 2.0 * freq[alpha] * vv0[ mssngs[i+1] ];
	   a[alpha] = (LongDouble) ((LongDouble) a[alpha] +
				(Z * freq[alpha] + Zeta * colfreq[beta])
				* 2.0L * (LongDouble) vv0[beta]);
	 }
	 //   // printf("(LongDouble) a[0]=%4.3f\n", (LongDouble) a[0]);
       }
      if (PL) CLOCK("missings");
    } else {
       assert(missings == 0);
     }
  }
  
  
  if (normalized == RowNormalized || normalized == ColNormalized) {
    LongDouble sigmaSq = normalized == RowNormalized ? getRowSigmaSq(SxI)
      : getColSigmaSq(SxI);
    LongDouble sigma = (LongDouble) sigmaSq; // oder besser (LongDouble) sqrtl(sigmaSq); ??
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static) 
#endif
    for (Long r=0; r < repetV; r++) {
      LongDouble *a = ans + r * ldAns;
      for (Long i=0; i < rows; i++) a[i] /= sigma;
    }
    if (PL) CLOCK("finalizing") else CLOCK("gV_vG");
  } else if (normalized == CorrNormalizing) {
    /*
      bei
      sum_j (a_{ij} / (\sqrt{ a_ii a_jj}) f_j 
      muessten die a_{ii} ausgerechnet werden
      Dann f_j durch f_j / \sqrt a_jj  ersetzt werden.
      Dann sum_j a_{ij} f_j  und schliesslich mit den /\sqrt a_ii korrigiert.
    */
    
    ERR0("'CorrNormalizing' not programmed yet as rather complicated to get it efficent");
  } else if (normalized != NoNormalizing) {
    ERR2("normalizing = %d %d \n", normalized, centered);
    BUG; // not programmed yet
  }

   //   // printf("leaving gv_meansx\n");

  if (meanV) {FREE(V);}
  FREE(mu);
  FREE(freqV);
}



void SxIvector_means_LongDouble(vector_raw_args(LongDouble)) {  
  gV_vG_means_LongDouble(SxI, V, repetV, ldV, 
		     GetInfo(SxI)[TRANSPOSED] == False ? false : true,
		     global->genetics.centered,
		     getNormalized(global->genetics), 
		     global->tuning.meanVsubstract,
		     global->tuning.meanSxIsubstract,
		     global, utils, ans, ldAns);
}



void SxIvector_means_LongDouble(vector_raw_shortargs(LongDouble)) {
  //  // printf("xx\n");
  Long *info = GetInfo(SxI);
  SxIvector_means_LongDouble(SxI, V, repetV, info[INDIVIDUALS], 
			  global, utils, ans, info[SNPS]);
}

void vectorSxI_means_LongDouble(vector_raw_args(LongDouble)) {
  gV_vG_means_LongDouble(SxI, V, repetV, ldV,
		     GetInfo(SxI)[TRANSPOSED] == False ? false : true, 
		     global->genetics.centered,
		     getNormalized(global->genetics),
		     global->tuning.meanVsubstract,
		     global->tuning.meanSxIsubstract,
		     global, utils, ans, ldAns);  
}


void vectorSxI_means_LongDouble(vector_raw_shortargs(LongDouble)) {
  Long *info = GetInfo(SxI);
  vectorSxI_means_LongDouble(SxI, V, repetV, info[SNPS],
			  global, utils, ans, info[INDIVIDUALS]);  
}

