/*
 Authors 
 Guido Moerkotto
 maintained and modified by Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Guido Moerkotte, Martin Schlather

 COPYRIGHT_TEXT
*/

#define MY_VARIANT 256
#include "1bitDef.h"

#include "bitBase.h"


#if defined AVX2

ASSERT_SIMD(1bit256, avx2);

#include "haplogeno.h"
#include "intrinsics.sequences.h"
#include "1bitIntern.h"


SCALAR012(256)



#else // !defined AVX
#include "Template.h"
#include "1bit.h"
#include "avx_miss.h"


  DeclareVersion1(256,Su,Sv)
  SIMD_MISS(1bit256, avx2);

#endif  // defined AVX2
