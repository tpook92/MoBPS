/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/

#define BitsPerCode 2
#define MY_VARIANT 32 // 


#include "Basic_miraculix.h"

#if defined compatibility_to_R_h


#include "intrinsics_specific.h"
#include "options.h"
#include "haplogeno.h"
#include "miraculix.h"

#include "MX.h"
#include "Template.h"
#include "Vector.matrix.h"
#include "utils_miraculix.h"
#include "2bit.h"
#include "transform.h"
#include "intrinsicsCheck.h"

//#define DO_FLOAT 1  // must be completely re-checked if defined




//
#define show(X)
// void show(const char *s) {  if (debugging) PRINTF("%.50s", s); }

 

Uint BitMaskStart[CodesPerUnit], BitMaskEnd[CodesPerUnit]; // of PlainInteger64!

bool MoBPSNotInit = true;
void InitMoBPS() {
  if (!MoBPSNotInit) BUG;
  MoBPSNotInit = false;
  Uint Einsen = 0xFFFFFFFF;
  BitMaskEnd[0] = 0x03;

  for (Uint k=1; k<CodesPerUnit; k++) {
    //    XOR(BitMaskStart[k], BitMaskEnd[k-1], Einsen); // not
    BitMaskStart[k] = BitMaskEnd[k-1] ^ Einsen; // not
    BitMaskEnd[k] = BitMaskEnd[k-1];
    BitMaskEnd[k] |= 0x03 << (BitsPerCode * k);
  }
  BitMaskStart[0] = Einsen;
}


coding_type assert_MoBPS() {
  if (MoBPSNotInit) InitMoBPS();
  GetOptions;
  coding_type coding = FirstMoBPScoding;
  // printf("coding assert_mobps %s %s\n", CODING_NAMES[coding], CODING_NAMES[swapHaploGeno(coding, true)]);
  if (coding < FirstMoBPScoding || coding > LastMoBPScoding) 
    ERR3("MoBPS works with '%.20s', not with '%.20s' [%d]\n",
	 CODING_NAMES[TwoBitGeno], CODING_NAMES[coding], (int) coding);
  return swapHaploGeno(coding, true);
}

SEXP getListElement(SEXP list, const char *name, int startwith) {
  SEXP names = getAttrib(list, R_NamesSymbol);
  for (int i = startwith; i < LENGTH(list); i++)
    if(STRCMP(CHAR(STRING_ELT(names, i)), name)==0) return VECTOR_ELT(list, i);
  return R_NilValue;
}




#define ORIGIN_GENERATION 0
#define ORIGIN_SEX 1
#define ORIGIN_NR 2
#define ORIGIN_HAPLO 3

#define BITS_GENE_INPUT 6
#define BITS_SEX 1
#define BITS_INDIVIDUALS 22
#define BITS_HAPLO 3

#define MAX_GENE_INPUT (1 << BITS_GENE_INPUT)
#define MAX_SEX (1 << BITS_SEX)
#define MAX_INDIVIDUALS (1 << BITS_INDIVIDUALS)
#define MAX_HAPLO (1 << BITS_HAPLO)

#define PATTERN_GENE_INPUT  (MAX_GENE_INPUT - 1)
#define PATTERN_SEX (MAX_SEX - 1)
#define PATTERN_INDIVIDUALS (MAX_INDIVIDUALS - 1)
#define PATTERN_HAPLO (MAX_HAPLO - 1)


void static inline decodeOrigin(Uint x, Uint *ans) {
  ans[ORIGIN_HAPLO] = (x & PATTERN_HAPLO);
  x >>= BITS_HAPLO;
  ans[ORIGIN_NR] = (x & PATTERN_INDIVIDUALS);
  x >>= BITS_INDIVIDUALS;  
  ans[ORIGIN_SEX] = (x & PATTERN_SEX);
  x >>= BITS_SEX;
  ans[ORIGIN_GENERATION] = x;
}


SEXP decodeOrigins(SEXP M, SEXP Line) {  
   assert_MoBPS();
  Uint line = Int0(Line);
  assert(line > 0); // R index
  //printf("decodeOrigin %d %d\n", line, LENGTH(M));
 SEXP Ans;
  PROTECT(Ans = allocVector(INTSXP, 4));
  Uint *ans = (Uint*) INTEGER(Ans);
  decodeOrigin(Inti(M, line - 1), ans);
  for (int j=0; j<4; ans[j++]++);
  UNPROTECT(1);
  return Ans;
}


SEXP codeOrigins(SEXP M) {
  //  printf("codeOrigin %d\n", LENGTH(M));
  
  assert_MoBPS();
  int nrow = nrows(M);
  assert(ncols(M) == 4);
  
  SEXP Ans;
  PROTECT(Ans = allocVector(INTSXP, nrow));
 
  Uint *ans = (Uint*) INTEGER(Ans);
  for (int j=0; j<nrow; j++) ans[j] = 0;  // unnoetig?!

#define DO1(TYPE, RTYPE)			\
  TYPE *gen = RTYPE(M),				\
    *sex = gen + nrow,				\
    *nr = sex + nrow,				\
    *haplo = nr + nrow					       

#ifdef SCHLATHERS_MACHINE  
#define CONTROL \
   Uint control[4];							\
    decodeOrigin(ans[j], control);					\
    if (control[0]+1 != g || control[1]+1 != s || control[2]+1 != n ||	\
	control[3]+1 != H) {						\
      /*	p rintf("i=%d: generation:%d->%d sex:%d->%d nr:%d->%d haplo:%d->%d\n", i, g, control[0], s, control[1], n, control[2], H, control[3]); */ \
      BUG;								\
    }
#else
  #define CONTROL
#endif  
  
#define DO2								\
  for (int j=0; j<nrow; j++) {						\
    Uint g = (Uint) gen[j],						\
      s = (Uint) sex[j],						\
      n = (Uint) nr[j],							\
      H = (Uint) haplo[j];						\
    if (g < 1 || g > MAX_GENE_INPUT|| s < 1 || s > MAX_SEX ||		\
	n < 1 || n > MAX_INDIVIDUALS ||	H < 1 || H > MAX_HAPLO)		\
      ERR1("some value in row %d out of bound", j + 1);			\
    ans[j] = ((((((g - 1) << BITS_SEX) +				\
		 s - 1) << BITS_INDIVIDUALS) +				\
	       n - 1) << BITS_HAPLO) +					\
      H - 1;								\
    CONTROL								\
  }

  
  if (TYPEOF(M) == REALSXP) {
    DO1(double, REAL);
    DO2   
      } else if (TYPEOF(M) == INTSXP) {
    DO1(int, INTEGER);
    DO2   
      } else BUG;
  
  UNPROTECT(1);
  return Ans;
}


// population
#define INFO 0
#define BREEDING 1

// info
#define INFO_INFOHAPLO 0
#define NSNPS 2
#define POSITION 3
#define SNP_POSITION 5
#define LENGTH_CHROM 6
#define LENGTH_TOTAL 7
#define EQUIDIST_SNPS 17
#define GENERATION_REFTABLE 18
#define QTL_SNP_POS 19
#define QTL_EQUIDIST_SNPS 20


// individual
#define RECOMBI1 0
#define RECOMBI2 1
#define MUTAT1 2
#define MUTAT2 3
#define ORIGIN1 4
#define ORIGIN2 5
//#define FATHER 6
//#define MOTHER 7
#define HAPLOTYP1 8 // in case of founder, otherwise empty
#define HAPLOTYP2 9
#define CODEDHAPLO HAPLOTYP1
#define CODEDQTL 40

#define MAX_CHROM 100


#define HaploCodeMask 0x00000001
static inline Uint GetTwoBitHaploCode(Uint *M, Uint S, Uint haplo) {
  assert(haplo <= 1 && sizeof(*M)==4 && BitsPerCode == 2);
  Uint idx = S % CodesPerUnit;
  //  printf("%u[%d] >> %u = %u\n", M[S / CodesPerUnit],S / CodesPerUnit,(idx * BitsPerCode + haplo),M[S / CodesPerUnit] >> (idx * BitsPerCode + haplo));
  return (M[S / CodesPerUnit] >> (idx * BitsPerCode + haplo)) & HaploCodeMask;
}


void static inline PutTwoBitHaploOne(Uint pos, Uint haplo, Uint *code) {
  Uint idx = pos % CodesPerUnit;
  Uint *c = code + pos / CodesPerUnit; 
  *c |= HaploCodeMask << (idx * BitsPerCode + haplo);
}


  
Uint getNrSNPposition(double cur_recomb, double *position, Uint Min, Uint Max) {
  // printf("getSNPpos\n");
  Uint min = Min,
    max = Max;
  //  print("%d %d\n", min, max);
  while (min < max) {
    Uint inbetween = (min + max + 1) / 2;
    if (position[inbetween] <= cur_recomb) min = inbetween;
    if (position[inbetween] > cur_recomb) max = inbetween - 1;
  }
  if (min > max) BUG;
  if (position[max] > cur_recomb) {
    if (max == Min) return max - 1; // links des ersten Markers auf dem
    //                                 Chromosom; somit wird letzter marker 
    //                                 vom Vor-Chromoosom zugeordnet
    BUG;
  }
  if (max < Max && position[max+1] <= cur_recomb) BUG;
  return max;
}


#define ASSERT(WHERE,WHAT,NAME)						\
  assert(STRCMP(CHAR(STRING_ELT(getAttribPointer(WHERE, R_NamesSymbol), WHAT)),\
		NAME) == 0);
SEXP IcomputeSNPS(SEXP population, SEXP Generation, SEXP Sex, SEXP Nr,
		  bool onlyQTL,
		  int From_SNP, int To_SNP, SEXP Select,
		  option_type *global, utilsoption_type *utils,
		  unit_t *ans){
  //  printf("IcomputeSNPS\n");
  // option_type *global;  
  basic_options *opt = &(utils->basic);
  Uint
    CODE = onlyQTL ? CODEDQTL : CODEDHAPLO,
    SNPPOS = onlyQTL ? QTL_SNP_POS : SNP_POSITION,
    EQUIDIST = onlyQTL ? QTL_EQUIDIST_SNPS : EQUIDIST_SNPS,
    cur_select = NA_INTEGER,
    individuals = LENGTH(Generation),
    len_sel = LENGTH(Select);
  bool do_select = len_sel > 0;
  if (individuals != (Uint) LENGTH(Sex) || individuals != (Uint) LENGTH(Nr))
    ERR0("'gen', 'gender' and 'nr' do not have same length");
  if (From_SNP <= 0) ERR0("'from_p' not valid.");

  ToIntLocal(Select);
   
  ASSERT(population, BREEDING, "breeding");
  SEXP breeding = VECTOR_ELT(population, BREEDING);

  ASSERT(population, INFO, "info")
    SEXP popinfo = VECTOR_ELT(population, INFO);
  Uint len_popinfo = LENGTH(popinfo);

  static Uint gen_ref[MAX_GENE_INPUT] = { 0 };

  ASSERT(popinfo, GENERATION_REFTABLE, "origin.gen");
  Long gene_ref_len = LENGTH(VECTOR_ELT(popinfo, GENERATION_REFTABLE));
  if (GENERATION_REFTABLE >= len_popinfo || gene_ref_len == 0) {
    if (gen_ref[MAX_GENE_INPUT - 1] == 0) { // should never happen except uninit
      for (Uint j=0; j<MAX_GENE_INPUT; j++) gen_ref[j] = j;
      PRINTF("Generation reference table now initialized.\n");
      BUG; // to check whether it appears somewhen and why
    }
  } else {
    Uint *p = (Uint*) INTEGER(VECTOR_ELT(popinfo, GENERATION_REFTABLE));
    if (gene_ref_len > MAX_GENE_INPUT) ERR0("gene_rel_len too large.");
    for (Uint j=0;
	 j < gene_ref_len;
	 // j<MAX_GENE_INPUT;
	 j++) {
      // printf("j=%d %d %ld\n", j, MAX_GENE_INPUT, gene_ref_len);
      gen_ref[j] = (Uint) (p[j] - 1);
    }
  }

  ASSERT(popinfo, LENGTH_TOTAL, "length.total");
  Uint n_chrom = LENGTH(VECTOR_ELT(popinfo, LENGTH_TOTAL)) - 1;
  if (n_chrom >= MAX_CHROM) ERR1("maximum chromosoms is %d", MAX_CHROM);
  double *length_total = REAL(VECTOR_ELT(popinfo, LENGTH_TOTAL));
  
  ASSERT(popinfo, LENGTH_CHROM, "length");
  double *LengthChrom = REAL(VECTOR_ELT(popinfo, LENGTH_CHROM));
  
  ASSERT(popinfo, NSNPS, "snp");
  Uint n_snps,
    n_protect = 0;
  SEXP InfoHaplo = VECTOR_ELT(popinfo, INFO_INFOHAPLO);
  coding_type coding = assert_MoBPS();
  
  Long infoUintLen = (INFO_LAST + 1) *  sizeof(Long) / sizeof(int); // OK
  if (TYPEOF(InfoHaplo) != INTSXP || LENGTH(InfoHaplo) != infoUintLen) {
    PROTECT(InfoHaplo = allocVector(INTSXP, infoUintLen));
    n_protect++;
    Long *infoHaplo = (Long*) INTEGER(InfoHaplo);
    for (int i=0; i<=INFO_LAST; infoHaplo[i++] = NA_LONG);
    infoHaplo[CODING] = coding;
    infoHaplo[VARIANT] =
      main_variant(check_variant((coding_type) infoHaplo[CODING],
				 VARIANT_DEFAULT,
				 opt->efficient));
    infoHaplo[LDABITALIGN] = MY_LDABITALIGN;
    SET_VECTOR_ELT(popinfo, INFO_INFOHAPLO, InfoHaplo);
  }
  Long *infoHaplo = (Long*) INTEGER(InfoHaplo);

  double length_prec_chroms[MAX_CHROM + 1];
  SEXP snps_perchrom = VECTOR_ELT(popinfo, NSNPS);
  ToIntLocal(snps_perchrom);
  Uint
    totalsnps_prec_chroms[MAX_CHROM + 1];
  length_prec_chroms[0] = 0;
  totalsnps_prec_chroms[0] = 0;
  for (Uint c=1; c<=n_chrom; c++) {
    length_prec_chroms[c] =  length_prec_chroms[c-1] + LengthChrom[c-1];
    totalsnps_prec_chroms[c] = totalsnps_prec_chroms[c-1] +
      snps_perchromint[c-1];
  }

  n_snps = totalsnps_prec_chroms[n_chrom];
  //  printf("n_snps %d\n", n_snps);
  assert(n_snps > 0);
  int fromSNP = From_SNP - 1,
    toSNP = To_SNP==NA_INTEGER || To_SNP >= (int) n_snps ? MAXINT : To_SNP -1;
  if (toSNP < fromSNP) ERR0("'to_p' smaller than 'from_p'");
  if (fromSNP % CodesPerUnit != 0)
    ERR1("(from_p-1) must be devisible by %u", CodesPerUnit);
  if (toSNP < MAXINT && (toSNP + 1)  % CodesPerUnit != 0)
    ERR1("'to_p' must be devisible by %u or 'NA'", CodesPerUnit);


  Long cur_nsnps = 0;
  if (do_select) {
    cur_select = Selectint[0] - 1;
    int toSNP_P1 = toSNP + 1;
    for (Uint k=0; k<len_sel; k++)
      cur_nsnps += Selectint[k] > (Uint) fromSNP && Selectint[k] <= (Uint) toSNP_P1;
  } else cur_nsnps = 1L + MIN(n_snps - 1L, (Uint) toSNP) - fromSNP;
  infoHaplo[CURRENT_SNPS] = stopIfNotInt(cur_nsnps);
  if (infoHaplo[LDABITALIGN] == 0) infoHaplo[LDABITALIGN] = MY_LDABITALIGN;
  Long ldAns =  GetLDA(cur_nsnps, coding, infoHaplo[LDABITALIGN]);
  infoHaplo[LDA] = stopIfNotInt(ldAns);
  if (ans == NULL) {
    if (n_protect) UNPROTECT(n_protect);
    return InfoHaplo;
  }
 
  ASSERT(popinfo, EQUIDIST, "snps.equidistant");
  bool equidist = (bool) LOGICAL(VECTOR_ELT(popinfo, EQUIDIST))[0];
  
  ASSERT(popinfo, POSITION, "position");
  SEXP position = VECTOR_ELT(popinfo, POSITION);

  ASSERT(popinfo, SNPPOS, "snp.position");
  double *snp_positions = REAL(VECTOR_ELT(popinfo, SNPPOS)),
    last_snp_position = snp_positions[n_snps - 1],
    first_snp_position = snp_positions[0];

  //  printf("len(generation) %d %d %d\n", LENGTH(Generation), LENGTH(Sex), LENGTH(Nr));
  ToIntLocal(Generation); 
  ToIntLocal(Sex);
  ToIntLocal(Nr);
  //  for (int i=0; i<LENGTH(Generation); i++)	 printf("     gen=%d sex=%d nr=%d\n", Generationint[i], Sexint[i], Nrint[i]);

  Uint NullEins[2] = { 0x55555555, 0xAAAAAAAA};


  bool check = !true; // debugging only    
  bool savehaplo = global->tuning.savegeno;
  //
  savehaplo = !true;
   
 

  //  printf(" IIIIIIIIIIIIIIIIIIIIIIIIIII %d \n", individuals);

  for (Long i=0; i<individuals; i++) {
    //
    Uint *haploAns = (Uint *) (ans + i * ldAns);    
    // printf("AC i=%ld indiv=%d haplo[%ld] %d\n", i, individuals, i * ldAns, haploAns[0]);
    //  if (i > 0) {*haploAns=15; continue;} else  {*haploAns=3; continue;}
    
   //    printf("i=%ld %d len(breeding)=%d\n", i, individuals, LENGTH(breeding));
    if (LENGTH(breeding) < (int) Generationint[i])
      ERR0("value of 'generation' too large.");
    SEXP g = VECTOR_ELT(breeding, Generationint[i]-1);
    if (TYPEOF(g) != VECSXP || LENGTH(g) < (int) Sexint[i])
      ERR0("'sex' out of range.");
    // printf("index = %d len(g)=%d %d\n", Generationint[i]-1, LENGTH(g),  (int) Sexint[i]-1);
    SEXP s = VECTOR_ELT(g, (int) Sexint[i]-1);
    if (TYPEOF(s) != VECSXP || LENGTH(s) < (int) Nrint[i])
      ERR4("Value of 'nr' too large. length(sex)=%ld < %d = nr[%ld] %d",
	   ALONG LENGTH(s), (int) Nrint[i], ALONG i , TYPEOF(g));   // 19
    SEXP Indiv = VECTOR_ELT(s, Nrint[i]-1);
    SEXP origin = VECTOR_ELT(Indiv, ORIGIN1);
    Long bytes = ldAns * BytesPerUnit;

    SEXP saved_coded_haplo = VECTOR_ELT(Indiv, CODE);
    bool do_save = savehaplo || check;       // || origin == Indiv; // set in R

    if (saved_coded_haplo != R_NilValue) {
      if (do_save) {
	void *aligned = algn_generalS(saved_coded_haplo, MY_LDABITALIGN);
	MEMCOPY(haploAns, aligned, bytes);
	if (!check) continue;
      }
    }

    if (do_save) {
      void *aligned = algn_generalS(saved_coded_haplo, MY_LDABITALIGN);
      if (saved_coded_haplo == R_NilValue) {
	Long mem = calculateAlignedMem(ldAns, coding);
	saved_coded_haplo = PROTECT(allocVector(INTSXP, mem));
	MEMCOPY(aligned, haploAns, bytes);
	SET_VECTOR_ELT(Indiv, CODE, saved_coded_haplo);
	UNPROTECT(1);
      } else {
	if (check) {
	  PROTECT(saved_coded_haplo);
	  if (MEMCMP(aligned, haploAns, bytes)) BUG;
	  UNPROTECT(1);
   	} else if (origin != Indiv) BUG;
      }
    } // else if (saved_coded_haplo != R_NilValue && origin != Indiv) BUG; // for checking; no harm to continue

    
    for (Uint hapnr=0; hapnr<=1; hapnr++) {
      if (TYPEOF(VECTOR_ELT(Indiv, RECOMBI1 + hapnr)) != REALSXP)
	ERR0("real valued vector for recombination information expected");
      double *recombi = REAL(VECTOR_ELT(Indiv, RECOMBI1 + hapnr));
      Uint
	n_recomb = LENGTH(VECTOR_ELT(Indiv, RECOMBI1 + hapnr)) - 1;
      origin = VECTOR_ELT(Indiv, ORIGIN1 + hapnr);
      ToIntLocal(origin);
      Uint
	n_mutat = LENGTH(VECTOR_ELT(Indiv, MUTAT1 + hapnr)),
	// separation of the following 3 allows for selection but also
	// for mutation error such as insertion and deletion
	p = 0, // position what is written if there is no selection
	q = 0, // position what is written actually
	psel = 0, pmutat = 0,
	till = 0,
	from = 0; // current recombination starting point
      bool mutations = n_mutat > 0;
      
      SEXP mutat = mutations ? VECTOR_ELT(Indiv, MUTAT1 + hapnr) : R_NilValue;
      ToIntLocal( mutat);
      
      for (Uint index=0; index <= n_recomb; index++) {
	
	double cur_recomb = recombi[index];
	Uint cur_chrom; // starting with number 0

	if (cur_recomb <= first_snp_position) {
	  from = 0;
	  continue;
	}
	
	for (cur_chrom=0; cur_chrom<n_chrom; cur_chrom++)
	  if (length_total[cur_chrom + 1] >= cur_recomb) break;
	if (equidist) {
	  if (cur_recomb > last_snp_position) till = n_snps - 1;
	  else {
	    double halfbetween = REAL(VECTOR_ELT(position, cur_chrom))[0];
	    till = totalsnps_prec_chroms[cur_chrom] +
	      (Uint) CEIL((cur_recomb - length_prec_chroms[cur_chrom] - halfbetween) /
			  (2.0 * halfbetween)) - 1;
	  }
	} else {
	  Uint min = cur_chrom == 0 ? 0 : totalsnps_prec_chroms[cur_chrom],
	    max = cur_chrom == n_chrom ? n_chrom - 1
	    : totalsnps_prec_chroms[cur_chrom + 1] - 1;
	  till = getNrSNPposition(cur_recomb, snp_positions, min, max);
	}

	if (index == 0) {
	  from = till + 1;
	  assert(from == 0);
	  continue;
	}
	
	assert(toSNP != NA_INTEGER && toSNP <= MAXINT);
	if (till >= from && from <= (Uint) toSNP && till >= (Uint) fromSNP) {
	  Uint von = MAX((Uint) fromSNP, from),
	    bis = MIN((Uint) toSNP, till),
	    o_info[4];
 	  decodeOrigin(originint[index-1], o_info);
	  //
	  assert(bis < n_snps);
	  assert(von <= bis);

	  //  SEXP Orig_gen = VECTOR_ELT(breeding, o_info[ORIGIN_GENERATION]),
	  if (false) { assert(o_info[ORIGIN_GENERATION] < gene_ref_len); }
	  SEXP Orig_gen = VECTOR_ELT(breeding,
				     gen_ref[o_info[ORIGIN_GENERATION]]), 
	    O2 = VECTOR_ELT(Orig_gen, o_info[ORIGIN_SEX]),
	    Orig = VECTOR_ELT(O2, o_info[ORIGIN_NR]);
	  Uint o_haplotype = o_info[ORIGIN_HAPLO];
	  SEXP coded_haplo = VECTOR_ELT(Orig, CODE);
	  if (LENGTH(coded_haplo) == 0) BUG;
	  // printf("herA\n");
	  Uint *o_haplo = (Uint*) algn_generalS(coded_haplo, MY_LDABITALIGN);
	 
	  for (Uint op=von; op<=bis; ) {	    
	    // printf("op %d [%d, %d]  %d==%d slct=%d mutat=%d\n", op, von , bis, op % CodesPerUnit, q % CodesPerUnit, do_select, mutations);
	    if ( (op % CodesPerUnit) == (q % CodesPerUnit) && !do_select) {
	      // unit-wise copying	      
	      Uint 
		bnr = q / CodesPerUnit, 
		start = q % CodesPerUnit,
		o_rest = 1 + bis - op,
		rest = CodesPerUnit - start;
	      // printf("rest = %d, %d; CPU=%d start=%d\n", rest, o_rest, CodesPerUnit, start);
	      if (rest > o_rest) rest = o_rest;
	      Uint o_code = o_haplo[op / CodesPerUnit];
	      // printf("\t\t\t      ocode_orig = %d\n", o_code *= 1);
	      
	      if (mutations) {
		Uint end = op + rest; // excluded, R-Coding !!
		if (mutatint[pmutat] <= end) { // mutat hat R codierung !!
		  // insbesondere bei select koennen Mutation uebersprungen
		  // werden. Somit muss zunaechst pmutat gegebenfalls erhoeht
		  // werden:
		  while (pmutat < n_mutat && mutatint[pmutat] <= op) pmutat++;
		  while (pmutat < n_mutat && mutatint[pmutat] <= end) {
		    Uint idx = (mutatint[pmutat] - 1) % CodesPerUnit;
		    //  AND(L1 , BitMaskStart[idx], BitMaskEnd[idx]);
		    //		    XOR(o_code, o_code, L1);
		    o_code ^= BitMaskStart[idx] & BitMaskEnd[idx];
		    pmutat++;
		  }
		  mutations = pmutat < n_mutat;
		}
	      }
	      //   AND(L1, BitMaskStart[start], BitMaskEnd[start + rest - 1]);
	      //   AND(L1, L1, NullEins[o_haplotype]);
	      // AND(o_code, o_code, L1);
	      o_code &= BitMaskStart[start] & BitMaskEnd[start + rest - 1] &
		NullEins[o_haplotype];

	      if (o_haplotype != hapnr) {		
		// if (o_haplotype > hapnr) { SHR32(o_code, o_code, 1); }
		// else SHL32(o_code, o_code, 1);
		if (o_haplotype > hapnr) o_code >>= 1; else o_code <<= 1;
	      }
	      
	      //OR(haplo[bnr], haplo[bnr], o_code);
	      // printf("o_code = %d bnr=%d\n", o_code, bnr);
	      haploAns[bnr] |= o_code;
	      op += rest;
	      p += rest; // p is now endpoint + 1 !
	      q += rest;
	    } else {
	      // bitwise copying
	      if (do_select) {
		if (psel >= len_sel || cur_select != p) {
		  op++;
		  p++;
		  continue;
		}
		cur_select = Selectint[psel++];
	      }
	      Uint H = GetTwoBitHaploCode(o_haplo, op, o_haplotype);
	      if (mutations) {
		// note mutat:R coding; op:C-Coding
		while (pmutat < n_mutat && mutatint[pmutat] <= op) pmutat++;
		if (mutatint[pmutat] == op + 1) {
		  H = 1- H;
		  pmutat++;
		}
		mutations = pmutat < n_mutat;
	      }
	      //  printf("hapnr = %d %d H=%d; %u[%d:%d]\n", hapnr, q, H, *o_haplo, op, o_haplotype);
	      if (H) PutTwoBitHaploOne(q, hapnr, haploAns);
	      op++;
	      p++;
	      q++;
	    }
	  }// for op von..bis  through all snps between two recombination points
	} // if space between two recombination points is not empty
	from = till + 1;
      } // for n_recomb
      FREEcreated(mutat);
      FREEcreated(origin);
    } // hapnr


  }

  FREEcreated(snps_perchrom);
  FREEcreated(Select);
  FREEcreated(Generation);
  FREEcreated(Sex); 
  FREEcreated(Nr);
  if (n_protect) UNPROTECT(n_protect);
   
  return R_NilValue;
}

    
SEXP computeSNPS(SEXP population, SEXP Generation, SEXP Sex, SEXP Nr,
		 SEXP OnlyQTL,
		 SEXP From_SNP, SEXP To_SNP, SEXP Select, SEXP Geno){
  GetOptions;
  assert_MoBPS();
  bool geno = LOGICAL(Geno)[0],
    onlyQTL = LOGICAL(OnlyQTL)[0];
  Long individuals = LENGTH(Generation);
  SEXP Popinfo;  
  PROTECT(Popinfo = IcomputeSNPS(population, Generation, Sex, Nr, onlyQTL,
				 INTEGER(From_SNP)[0], INTEGER(To_SNP)[0],
				 Select, global, utils, NULL));
  Long *popinfo = (Long*) INTEGER(Popinfo),
    snps = popinfo[CURRENT_SNPS];
  SEXP Ans;
  PROTECT(Ans = createSNPmatrix(snps, individuals, 
				(coding_type) popinfo[CODING],
				0, MY_LDABITALIGN, global, utils ));
  //  printf("*** miraculix startet \n");
  
  unit_t *ans = Align(Ans, opt); 
  ///printf("*** mopbs hierX\n");
  IcomputeSNPS(population, Generation, Sex, Nr, onlyQTL,
	       INTEGER(From_SNP)[0], INTEGER(To_SNP)[0], Select, global, utils,
	       ans);
  //  int *A = (int *) ans;
  //  A[0] = 255;
  //  ERR4
  // printf    (">> %d %d %d %d\n", A[0], A[1], A[2], A[3]);
  // printf("*** miraculix ended %d\n", geno);
  if (geno) haplo2geno(Ans, global, opt);

  //printf("mopbs hier done\n");
  UNPROTECT(2);
  return Ans;
}



SEXP compute(SEXP popul, SEXP Generation, SEXP Sex, SEXP Nr, SEXP OnlyQTL,
	     SEXP Tau, SEXP Vec, SEXP Betahat,
	     SEXP Select, SEXP Matrix_return) {
  GetCores;
  assert_MoBPS();
  bool onlyQTL = LOGICAL(OnlyQTL)[0];
  SEXP Popinfo;
  PROTECT(Popinfo = IcomputeSNPS(popul, Generation, Sex, Nr, onlyQTL,
				 1, NA_INTEGER, Select, global, utils, NULL));

  Long *popinfo = (Long *) INTEGER(Popinfo),
    snps = popinfo[CURRENT_SNPS],
    individuals = LENGTH(Generation);
  coding_type coding = (coding_type) popinfo[CODING];
  int variant = check_variant(coding, global->tuning.variant, opt->efficient);
  Long    
    ldaHPL = Lda2Bit(snps, MY_LDABITALIGN),
    memInUnits = (Long) individuals * ldaHPL,
    mem = calculateAlignedMem(memInUnits, coding);
  int *G = (int *) CALLOC(mem, BytesPerUnit);

  unit_t *g = (unit_t*) algn_generalL(G, MY_LDABITALIGN);
  if ((Uint) LENGTH(Vec) != individuals) ERR0("'vec' not of correct length");

  //  printf("mopbs hier compute\n");
  
  IcomputeSNPS(popul, Generation, Sex, Nr, onlyQTL,
	       1, NA_INTEGER, // R coded indices !!
	       Select, global, utils, g);
  haplo2geno(g, snps, individuals, ldaHPL, coding, variant, cores);
	   
  double *A = crossprod((unit_t*) G, // no PROTECT( needed;
			snps, individuals, GetLDA(snps, coding, MY_LDABITALIGN),
			coding, variant,		
			RowMeans, NoNormalizing, false,
			NULL,
			opt, &(global->tuning));
  
  FREE(G);

  SEXP Ans = IsolveRelMat(individuals, A, // no PROTECT( needed;
			  REAL(Tau), LENGTH(Tau),
			  REAL(Vec),
			  REAL(Betahat), LENGTH(Betahat),
			  2 + (int) LOGICAL(Matrix_return)[0],
			  true, cores);
  FREE(A);
  UNPROTECT(1);
  return Ans;
}

#endif
