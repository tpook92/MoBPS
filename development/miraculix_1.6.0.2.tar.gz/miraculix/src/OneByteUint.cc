/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#define BitsPerCode 8 
#define MY_VARIANT 32

#include "Basic_miraculix.h"
#include "intrinsics_specific.h"
#include "options.h"
#include "haplogeno.h"
#include "TemplateUint.h"
#include "MX.h"
#include "Bytes.h"


// LDA in Units!
Long LdaOneByte(Long rows, Long LDAbitalign){
  return LDAalignBitSnps(rows * BitsPerCode);
}

int BitsPerCodeOneByte() { return BitsPerCode; }


void OneByte2T(unit_t *tmp, Long rows, Long cols, Long lda,
	       unit_t *Ans, Long ldAns) {
  if (tmp == Ans) BUG;
  _1Byte *M = (_1Byte*) tmp;
  _1Byte *N = (_1Byte*) Ans;
  for (Long i= 0; i<cols; i++)
    for (Long j=0; j<rows; j++) N[i + j * ldAns] = M[j + i * lda];
}



coding_start(_4Byte,OneByte) {
  if (rest) BUG;
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
  coding_Bytes_end(_4Byte,_1Byte);
}

coding_start(_1Byte,OneByte) { // geht schneller nur mit MEMCOPY -- ToDo
  // bei gleichem LD !
  if (rest) BUG;
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
  coding_Bytes_end(_1Byte,_1Byte);
}


get_matrix_Bytes(_1Byte,_4Byte,OneByte); 
get_matrix_Bytes(_1Byte,_1Byte,OneByte);


colSums_start(OneByte)
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) reduction(+:total) schedule(static)
#endif
colSums_Bytes_end(_1Byte);




#define vectorGeno_startOneByte(TYPE, SNDTYPE, TRDTYPE, ENDTYPE, NAME)	\
  vectorGeno_start(TYPE, TRDTYPE, ENDTYPE, NAME);			\
  Long floatLoop = abs(tuning->floatLoop); /* // OK */			\
  floatLoop = floatLoop == 0 || floatLoop > rows ? rows : floatLoop;	\
  Long rowsMfloatLoop = (rows - 1) / floatLoop * floatLoop ;		\
  if (false) PRINTF("float = %ld fl=%d rMfl=%ld r=%ld %ld,%ld,%ld,%ld\n", \
		    ALONG floatLoop, tuning->floatLoop,ALONG rowsMfloatLoop, \
		    ALONG rows, ALONG sizeof(TYPE), ALONG sizeof(SNDTYPE), \
		    ALONG sizeof(TRDTYPE), ALONG sizeof(ENDTYPE));	\
  if (false) { for (Long j=0; j<rows; j++) { PRINTF(">%f ", (double) V[j]); } PRINTF("\n");}					\


// float = 1 1 5119 5120

#define vectorGeno_fctnOneByte(TYPE, SNDTYPE, TRDTYPE, ENDTYPE)		\
  for (Long r=0; r < repetV; r++) {					\
    for (Long i=0; i<cols; i++) {					\
      TYPE *vv = V + r * ldV;						\
      ENDTYPE *a = Ans + r * ldAns;					\
      TRDTYPE total = 0;						\
      unit_t *C = code + i * lda;						\
      if (colFreq == NULL) {						\
	for (Long k=0; k<=rowsMfloatLoop; k+=floatLoop) {		\
	  if (false) PRINTF("nocolfreq; i=%ld k=%ld < %ld\n", ALONG i, ALONG k, ALONG rowsMfloatLoop);	\
	  Long end_j = k < rowsMfloatLoop ?  k + floatLoop : rows;	\
	  SNDTYPE sum = 0;						\
	  for (Long j=k; j < end_j; j++) {				\
	    sum += (SNDTYPE) ((TRDTYPE) vv[j] * (TRDTYPE)(((_1Byte*) C)[j])); \
	  }								\
	  total += (TRDTYPE) sum;					\
	}								\
      } else {								\
	for (Long k=0; k<=rowsMfloatLoop; k+=floatLoop) {		\
	  Long end_j = k < rowsMfloatLoop ?  k + floatLoop : rows;	\
	  SNDTYPE sum = 0;						\
	  for (Long j=k; j < end_j; j++)				\
	    sum += (SNDTYPE) ((TRDTYPE) vv[j] *				\
			      ((TRDTYPE) (((_1Byte*) C)[j])		\
			       - (TRDTYPE) 2 * (TRDTYPE) colFreq[j])); \
	  total += (TRDTYPE) sum;					\
 	}								\
      }									\
      a[i] = (ENDTYPE) total;						\
    }									\
  }									\
}
 
#define sndtype double
#define trdtype double
//#define sndtype LongDouble
vectorGeno_startOneByte(double, sndtype, trdtype, double, OneByte);
 //   printf("YYY XXXXXXXXX\n"); BUG;
#ifdef DO_PARALLEL
  #pragma omp parallel for num_threads(cores) collapse(2) schedule(static)
#endif
vectorGeno_fctnOneByte(double, sndtype, trdtype, double)

  

#define sndtypeLD LongDouble
#define trdtypeLD LongDouble
 vectorGeno_startOneByte(longD, sndtypeLD, trdtypeLD, double, OneByte);
 // printf("XXXXXXXXX\n"); BUG;
#ifdef DO_PARALLEL
 //  #pragma omp parallel for num_threads(cores) collapse(2) schedule(static)
#endif
 vectorGeno_fctnOneByte(longD, sndtypeLD, trdtypeLD, double)


 
#define sndtypeD float
#define trdtypeD double
 vectorGeno_startOneByte(floatD, sndtypeD, trdtypeD, double, OneByte);
#ifdef DO_PARALLEL
  #pragma omp parallel for num_threads(cores) collapse(2) schedule(static)
#endif
 vectorGeno_fctnOneByte(floatD, sndtypeD, trdtypeD, double)
 
vectorGeno_startOneByte(LongDouble, LongDouble, LongDouble,LongDouble, OneByte);
#ifdef DO_PARALLEL
  #pragma omp parallel for num_threads(cores) collapse(2) schedule(static)
#endif
vectorGeno_fctnOneByte(LongDouble, LongDouble, LongDouble, LongDouble)

vectorGeno_startOneByte(Ulong, Ulong, Ulong, Ulong, OneByte);
#ifdef DO_PARALLEL
  #pragma omp parallel for num_threads(cores) collapse(2) schedule(static)
#endif
vectorGeno_fctnOneByte(Ulong, Ulong, Ulong, Ulong)


  
#define genoVectorOneByte_start(TYPE, SNDTYPE, TRDTYPE, ENDTYPE)	\
  genoVector_header(TYPE, TRDTYPE, ENDTYPE, OneByte) {			\
  int  VARIABLE_IS_NOT_USED cores = GreaterZero(opt->cores);		\
    Long floatLoop = abs(tuning->floatLoop); /* // OK */		\
    floatLoop = floatLoop == 0 || floatLoop > cols ? cols : floatLoop;	\
    Long colsMfloatLoop = (cols - 1) / floatLoop * floatLoop ;		\
    SNDTYPE   *Sum = (SNDTYPE *) CALLOC(rows * repetV, sizeof(SNDTYPE)); \
    TRDTYPE *Total = (TRDTYPE *) CALLOC(rows * repetV, sizeof(TRDTYPE)); \
    if (false) PRINTF("FLOATLOOOP = %ld (%ld, %ld) %ld\n",  ALONG floatLoop, ALONG sizeof(SNDTYPE), ALONG sizeof(TRDTYPE), ALONG colsMfloatLoop); \
 
 
#define genoVector_fctnOneByte(TYPE,  SNDTYPE, TRDTYPE, ENDTYPE)	\
  for (Long r=0; r < repetV; r++) {					\
    for (Long k=0; k<=colsMfloatLoop; k+=floatLoop) {			\
      SNDTYPE *sum = Sum + r * rows;			\
      Long end_i = k < colsMfloatLoop ?  k + floatLoop : cols;		\
      for (Long i=k; i < end_i; i++) {					\
	/*  printf("her\n");	*/					\
	TRDTYPE vv = (TRDTYPE) V[r * ldV + i];				\
        TRDTYPE aPF = 0;						\
	if (colFreq != NULL) { 			\
	  if (false) {PRINTF("colfreq\n"); }				\
	  aPF = (TRDTYPE)2 * vv * (TRDTYPE) colFreq[i];		\
	  if (false) PRINTF("%e ", (double) aPF);			\
	}								\
	_1Byte *c = (_1Byte*) (code + lda * i);				\
	for (Long j=0; j < rows; j++) {					\
	  sum[j] += (SNDTYPE) (vv * (TRDTYPE) c[j] - aPF);		\
  	}								\
      }									\
      TRDTYPE *total = Total + r * rows;		\
      for (Long j=0; j < rows; j++) {					\
        total[j] += (TRDTYPE) sum[j];					\
     }									\
    }									\
    ENDTYPE  *a = Ans + r * ldAns;					\
    TRDTYPE *total = Total + r * rows;					\
    for (Long j=0; j < rows; j++) {					\
      a[j] = (ENDTYPE) total[j];					\
    }			 						\
  }									\
  FREE(Sum);								\
  FREE(Total)

 


 
genoVectorOneByte_start(longD, sndtypeLD, trdtypeLD, double)
  if (false) PRINTF("double LONG LONG double\n");
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
genoVector_fctnOneByte(longD, sndtypeLD, trdtypeLD, double)
  }
 
genoVectorOneByte_start(double, double,  double, double)
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
genoVector_fctnOneByte(double, double, double, double)
  }

genoVectorOneByte_start(floatD, sndtypeD, trdtypeD, double)
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
genoVector_fctnOneByte(floatD, sndtypeD, trdtypeD, double)
  }

genoVectorOneByte_start(LongDouble, LongDouble, LongDouble, LongDouble)
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores)  schedule(static)
#endif
genoVector_fctnOneByte(LongDouble, LongDouble, LongDouble, LongDouble)
}
  
genoVectorOneByte_start(Ulong, Ulong, Ulong, Ulong)
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
genoVector_fctnOneByte(Ulong, Ulong, Ulong, Ulong)
}


#define gVOneByte_Select(TYPE)						\
  vector_fctn_start(TYPE, OneByte) {					\
    if (false) PRINTF("gVOneByte gV=%d %s \n", gV, "genoVectorOneByte_"#TYPE); \
    vD = gV ? genoVectorOneByte_##TYPE : vectorGenoOneByte_##TYPE;	\
    vector_fctn_end;							\
    if (false) PRINTF("end vector_fctn1B longD=%d\n", 1 );		\
  } }


gVOneByte_Select(LongDouble)
gVOneByte_Select(Ulong)


vector_fctn_start(double, OneByte) {
  if (false) PRINTF("++++ gVOneByte gV=%d %s loop=%d\n", gV, "genoVectorOneByte_double", tuning->floatLoop); 
  if (tuning->floatLoop < 0) {						
    vD = gV ? genoVectorOneByte_longD : vectorGenoOneByte_longD;	
  } else if (tuning->floatLoop == 0)					
    vD = gV ? genoVectorOneByte_double : vectorGenoOneByte_double;	
  else vD = gV ? genoVectorOneByte_floatD : vectorGenoOneByte_floatD;	
  vector_fctn_end;								
  //  printf("end vector_fctn1B longD=%d\n", vD == vectorGenoOneByte_longD || vD == genoVectorOneByte_longD );
}}


void rowSums_OneByte(colrowSums_args()) {
#define x127 127    
  unit_t *sumByte =  (unit_t*) CALLOC(lda, BytesPerUnit);// OK
  Uchar *s = (Uchar*) sumByte;
  Long units = Units(rows);
  for (Long i=0; i<cols; ) {
    unit_t *c = code + lda * i;
    for (Long j=0; j<units; j++) sumByte[j] += c[j]; // SIMD-bar
    i++;
    if (i % x127 == 0) { // somit egal ob Haplo oder Geno
      for (Long j=0; j<rows; j++) sums[j] += s[j];
      MEMSET(sumByte, 0, lda * BytesPerUnit); // OK
    }
  }
  if (cols % x127 != 0) for (Long j=0; j<rows; j++) sums[j] += s[j];
  FREE(sumByte);
}


sparsevectorGeno_start(OneByte)
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static) 
#endif   
  for (int r=0; r<nrow_code; r++) {
    double *a = Ans + r * ldAns;
    _1Byte *c = code + r;
    for (int k=0; k<nIdx; k++) {
      const int jEnd = rowIdxB[k+1];
      double tmp = 0;
      for (int j=rowIdxB[k]; j<jEnd; j++)
	tmp += valueB[j] * (double) c[colIdxB[j] * ldaInByte];
      a[k] = tmp;
    }
  }
}
