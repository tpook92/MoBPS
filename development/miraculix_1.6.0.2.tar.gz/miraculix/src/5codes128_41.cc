/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#define MY_VARIANT 128
#include "5codesDef.h"

 
#if defined SSE41

ASSERT_SIMD(5codes128, sse41);

#include "MX.h"
#include "haplogeno.h"
#include "intrinsics.sequences.h"
#include "5codesIntern.h"
 
 
 
void trafo2Geno5codes128(unit_t *OLD, Long rows, Long cols,
			Long oldLDA, coding_type coding,
			  int cores, 
			 unit_t *ANS, Long ldAns) {
  trafo2Geno5codes32(OLD, rows, cols,
		     oldLDA, coding, cores, ANS, ldAns);
}

void trafo2Geno5codestrans128(unit_t *OLD, Long rows, Long cols,
			      Long oldLDA, coding_type coding,
			      int cores,
			      unit_t *ANS, Long ldAns) {
   trafo2Geno5codestrans32(OLD, rows, cols,
		     oldLDA, coding, cores, ANS, ldAns);
 
}

    

 
#else // !defined AVX
#include "avx_miss.h"

 
void trafo2Geno5codes128(unit_t *OLD, Long rows, Long cols,
			 Long oldLDA, coding_type coding,
			 int cores, 
			 unit_t *ANS,  Long ldAns) Sv

void trafo2Geno5codestrans128(unit_t *OLD, Long rows, Long cols,
			      Long oldLDA, coding_type coding,
			      int cores,
			      unit_t *ANS, Long ldAns) Sv

  gV5_header(128, floatD, LongDouble, float,  double, ) Sv
  gV5_header(128, double, LongDouble, double, double, ) Sv
  


SIMD_MISS(5codes128, sse41); 
 
#endif  // defined AVX2
// trafo2Geno1Geno128
