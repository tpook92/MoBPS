/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/

#ifndef miraculix_3bit_H
#define miraculix_3bit_H 1


void Init3();
Long Lda3(Long rows, Long ldAbitalign);
colSums_header(3);

coding_header(_4Byte, 3);
coding_header(_1Byte, 3);
get_matrix_header(_4Byte,3);
get_matrix_header(_1Byte,3);

void haplo2geno3(unit_t * Code, Long rows, Long cols, Long ldH,
		 int cores, unit_t *A);
void rowSums3(unit_t *Code, Long rows, Long cols, Long lda,
	      int cores, Ulong *ans);
void zeroGeno3(SEXP SxI, Uint *SnpsList, Uint lenSnps,
	       Uint *IndivList, Uint lenIndiv,
	       basic_options *opt);

void TwoBithaplo2geno3(unit_t * Code, Long rows, Long cols,
		       Long lda, int cores, unit_t *A, Long ldAns);
void crossprod3(unit_t * Code, Long rows, Long cols, Long lda,
		int cores, double *A);



Long CodesPerBlock3();


#endif
