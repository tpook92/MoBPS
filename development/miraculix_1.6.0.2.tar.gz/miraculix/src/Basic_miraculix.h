/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/

#ifndef basic_miraculix_H
#define basic_miraculix_H 1

#include "def.h"
#include "intrinsics.h"

#include "compatibility.general.h"
#include "compatibility.SEXP.h"

#include "Basic_RandomFieldsUtils.h"

#endif
