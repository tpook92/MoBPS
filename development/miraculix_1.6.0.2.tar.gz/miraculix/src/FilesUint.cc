/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/

#define BitsPerCode 32
#define MY_VARIANT 32


#include "Basic_miraculix.h"
#include "options.h"
#include "haplogeno.h"
#include "Template.h"
#include "MXinfo.h"
#include "transform.h"

#include "Files.h"
#include "1bit.h"
#include "2bit.h"
#include "3bit.h"
#include "5codes.h"
#include "4Byte.h"
#include "OneByte.h"
#include "plink.h"
#include "Haplo.h"
#include "intrinsics_specific.h"
#include "intrinsicsCheck.h"
 
char EOL = '\n';

#define BitsPerCodeFile 8
#define CodeFileMask ((char) (1 << BitsPerCodeFile) - 1)
#define CodesPerByteFile (BitsPerByte / BitsPerCodeFile)



void file_dot_do(unit_t *M, Long ldM,
		 Long start_row, Long end_row, 
		 Long start_col, Long end_col,
		 int cores,
		 double *G, unit_t *Ans, Long colsAns, usr_bool transposed,
		 Long VARIABLE_IS_NOT_USED ldAns) {
  if (transposed != False)
    dot_file_do(M, ldM, start_col, end_col, start_row, end_row,
		cores, G, Ans, colsAns, False, ldAns);
  if (colsAns != 1) BUG;
  double *Fdot = (double*) Ans;
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
  for (Long i=start_col; i<end_col; i++) {
    unit_t *mm = M + (i - start_col) * ldM;
    double dummy = G[i];
    for (Long s=start_row; s<end_row; mm++) {
      Fdot[s++] += dummy * (double) *mm;
    }
  }
}



void dot_file_do(unit_t *M,Long ldM,
		 Long start_row, Long end_row, 
		 Long start_col, Long end_col, 
		 int cores,
		 double *G, unit_t *Ans, Long colsAns, usr_bool transposed,
		 Long VARIABLE_IS_NOT_USED ldAns) {

  if (transposed != False)
    file_dot_do(M, ldM, start_col, end_col, start_row, end_row,
		cores, G, Ans, colsAns, False, ldAns);
  if (colsAns != 1) BUG;  
  double *dotF = (double*) Ans;
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
  for (Long i=start_col; i<end_col; i++) {
    unit_t *mm = M + (i - start_col) * ldM;
    double dummy = 0;
    for (Long s=start_row; s<end_row; mm++) {
      dummy += G[s++] * (double) *mm;
    }
    dotF[i] = dummy;
  }
}


void CheckSnpsLessIndiv(Long snps, Long individuals, bool isSNPxInd,
			basic_options *opt) {

  if (snps <= 0 || individuals <= 0 ||
      (snps <= individuals && !opt->skipchecks && opt->helpinfo)) {
    char msg[200];
    SPRINTF(msg, "matrix is supposed to be a '%.20s' x '%.20s' matrix with %ld SNPs and %ld individuals and , which looks odd.\n", // ALONG
	    isSNPxInd ? "SNPs" : "individuals",
	    isSNPxInd ? "individuals" : "SNPs",
	    ALONG snps, ALONG individuals);
    if (snps > 0 && individuals > 0) { WARN0(msg); } else ERR0(msg);
  }
}



SEXP file_intern(SEXP file, coding_type coding, usr_bool transposed,
		 int variant,
		 option_type *global, utilsoption_type *utils,
		 bool only_complete,
		 SEXP G) {
  basic_options *opt = &(utils->basic);
  int efficient =  opt->efficient;
  int cores = GreaterZero(opt->cores);
  tuning_options *tuning = &(global->tuning);
  variant = check_variant(coding, variant, efficient);

  SEXP XX = getAttribPointer(file, Filecoding);
  char *file_coding = (char*) CHAR(STRING_ELT(XX, 0));
  Long n = STRLEN(file_coding); // kann 4 oder 5 sein
  char ch, oldch,
    A = file_coding[0], // coding 0
    B = file_coding[1], // coding 1
    C = file_coding[n-3], // coding 1 or 2
    NA = file_coding[n-2], // always last but one
    SEP = file_coding[n-1]; // always last
  bool haploFile = B == C;

  //  printf("%c.%c.%c.%c.%c.%d %d; %s \n", A, B, C, NA, SEP, n, haploFile,	 CODING_NAMES[coding]);

  // better: 1Byte!
  coding_t coding_sexp = matrix_coding_4Byte(coding, &transposed, variant, 
					     opt->bigendian);
  if (coding_sexp == NULL) BUG;
  
  Long *info = GetInfo(file, 2);
  if (info == NULL || info[FILE_LEADINGCOL] == NA_LONG) BUG;
  Long
    leadingcols = info[FILE_LEADINGCOL],
    isSNPxInd = info[FILE_SNPxIND_READ_BYROW],// = TRUE for plinkbinary
    snps = info[SNPS],
    individuals = info[INDIVIDUALS],
    doubledindividuals = info[FILE_DOUBLEINDIV];
  int header = stopIfNotInt(info[FILE_HEADER]); // can be indeed negative !!
  
  char *filename = (char*) CHAR(STRING_ELT(file, 0));

  if (header < 0 && !only_complete) {
    // only for plinkbinary: snps & individuals already known !! 
    return file_binary(filename,
		       file_coding, -header, isSNPxInd,
		       snps, individuals, coding, transposed, variant, 
		       global, utils,
		       G
		       );
  }

  Long
    LDAbitalign = coding > LastUserCoding ? NA_LONG : GetLDAbitalign(coding),
    codesperblock = GetCodesPerBlock(coding, variant); // OK


  if (tuning->missingsFully0) {
    ERR0("missings not programmed yet\n");
    // unklar wie der Stream am besten programmiert wird
    // getPlinkMissings(plink, file, opt); s. plink4Byte.cc
  }

 

  // BEAGLE 3 
  // beides: ani x snps und snps x individ
  // A B A B ?
  // ? als voraussetzung nicht vorhanden
  // 1 header-Zeile
  // 2 erste Spalten weg
  //
  // plink: kein header
  // 4 spalten, die nicht brauchen
  //
  // IndivPerCol = TRUE for plinkbinary, i,e,
  //   each row of plink contains all SNPS of an individual,
  //   i.e. 'rows' below equals the number of individuals

  FILE *fp;
  unit_t *matrix = NULL; // snps x individuals
  Long
    nrow_matrix, ncol_matrix,
    rows, // rowsM1, 
    cols, colsM1,
    plusrow,  haplorow, haplocol;
  if ((fp = fopen(filename, "r")) == NULL) {
    ERR1("file '%.50s' could not be opened", filename);
  }

  // determine number of rows and columns
  for (Long i=0; i<header; i++) while ((char) fgetc(fp) != EOL);

  // determine size of matrix:
  rows = 1;
  cols = 0;
  oldch = SEP;
  while ((ch  = (char) fgetc(fp)) != EOL) {
    //   printf("%c.%c. (%d %d) %d %d\n", ch, oldch, (int) ch, (int) SEP,  ch == SEP ,  oldch != SEP);
    if (ch == SEP && oldch != SEP) cols++;
    oldch = ch;
  }
  if (oldch != SEP) cols++;
  cols -= leadingcols;

  while ((ch  = (char) fgetc(fp)) != EOF) { 
    if (ch == EOL) rows++;
    oldch = ch;
  }
  if (oldch != EOL) rows++;
  fclose(fp);


  if (isSNPxInd) {
    individuals = cols;  
    snps = rows;
  } else {  
    individuals =  rows;
    snps = cols;    
  }
  
  if (haploFile) {
    // printf("infiv =%d %d %d; (%d x %d) %d\n", individuals, doubledindividuals, isSNPxInd, rows , cols, leadingcols);
    if (doubledindividuals) {
      Long dummy = individuals >> 1; 
      if (dummy << 1 != individuals) ERR0("odd number of values (individuals)");
      individuals = dummy;
    } else {
      Long dummy = snps >> 1; 
      if (dummy << 1 != snps) ERR0("odd number of values (SNPs)");
      snps = dummy;
    }
  }

  if (opt->Cprintlevel)
    CheckSnpsLessIndiv(snps, individuals, isSNPxInd, opt);

  if (info[CODING] == NA_LONG || info[CODING] == coding) {
    assert(transposed == False || transposed == True);
    CompleteCodeVector(snps, individuals, coding, transposed, false,
		       variant, LDAbitalign, false,
		       global, utils, NULL, NULL, file);
    if (only_complete) return file;
  }

  SEXP Ans = PROTECT(createSNPmatrix(snps, individuals, coding, transposed,
				     global->tuning.addtransposed,
				     variant, LDAbitalign, false,
				     G, global, utils));
  unit_t *aligned = Align(Ans, opt); // REALX(Ans)


  colsM1 = cols - 1;
  //rowsM1 = rows - 1;

  // read in table
  
  bool keepDirection = isSNPxInd xor (transposed == True);
  if (keepDirection) {
    plusrow = 1;
    nrow_matrix = codesperblock; // OK
    ncol_matrix = individuals;
  } else {
    // plusrow = snps;
    plusrow = codesperblock;// OK
    ncol_matrix = snps;
    nrow_matrix = 1;
  }
  if (haploFile) {
    if (isSNPxInd xor !doubledindividuals) {
      haplocol = 2;
      haplorow = 1;
    } else {
      haplocol = 1;
      haplorow = 2;    
    } 
  } else {
    haplocol = haplorow = 1;
  }

  // now, code matrix
  
  Long
    DeltaMatrix = 0,
    matrixLDA = GetNatLDA(nrow_matrix, MY_CODING),
    colsLDA = (1L + (ncol_matrix - 1L) / CodesPerByteFile) * CodesPerByteFile,
    idxIncr = keepDirection ? matrixLDA : 1,
    r=0,
    matrix_size = matrixLDA * colsLDA;
  double *dG = NULL;
  if (LENGTH(G) > 0) dG = REALX(G);

  rows /= haplorow;
  cols /= haplocol;

  if (isHaplo(coding)) {
    assert(CodesPerByteFile == 1);
    assert(colsLDA == ncol_matrix);
    assert(coding == OneByteHaplo);
    DeltaMatrix=matrix_size;
    matrix_size *= 2;
  }


  // printf("\n########### matrixLDA %d %d %d\n", matrixLDA, DeltaMatrix, isHaplo(coding));
  
  matrix = (unit_t*) CALLOC(matrix_size, BytesPerUnit);

  // jump header lines
  fp = fopen(filename, "r");
  for (Long i=0; i<header; i++) while ((ch=(char) fgetc(fp)) != EOL);
  
  for (Long rowidx=0; r<rows; r++, rowidx+=plusrow) {//# of (multiple) rows
    for (Long hr=0; hr<haplorow; hr++) { 
      unit_t *M = matrix + hr * DeltaMatrix;
      // genuine loop only if haplo types are given rowwise
      Long idx = rowidx;
      
      // jump unnecessary leading stuff
      while ((ch = (char) fgetc(fp)) == SEP);
      for (Long l=0; l<leadingcols; l++) {
	while ((ch=(char) fgetc(fp)) != SEP && ch!=EOF);
	if (ch == EOF) ERR0("unexpected end of file");
	while ((ch = (char) fgetc(fp)) == SEP);
      }

      for (Long l=0; l<cols; l++, idx+=idxIncr) { // # of (multiple cols
	for (Long hc=0; hc<haplocol; hc++) {
	  // genuine loop only if haplo types are given column wise
	  
	  if (ch != A) { // == 0
	    if (ch == B) {
	      M[idx + hc * DeltaMatrix]++;
	    } else if (ch == C) {
	      M[idx+ hc * DeltaMatrix] += 2;
	    } else if (ch == NA) ERR0("missing value detected.")
	    else {
	      PRINTF(">%c< row=%ld of %ld rows, col=%ld of %ld columns; plus=%ld hc=%ld haplocol=%ld\n", ch, ALONG r, ALONG rows, ALONG l, ALONG cols, ALONG nrow_matrix, ALONG hc, ALONG haplocol);
	      ERR0("Unknown character detected. Note that missings are not allowed here.");
	    }
	    //assert(matrix[idx] <=2);
	  } 
	  if (l<colsM1 || hc!=haplocol-1)
	    while((ch = (char) fgetc(fp)) == SEP); 
	}
      } // cols l
      
      // search for end of line
      if (ch != EOL && ch != EOF)
	while ((ch=(char) fgetc(fp)) != EOL && ch!=EOF);
    } // hr
   
    UPDATE;
    
  } // rows r
  
  CLOSE;
  
  UNPROTECT(1);

  return Ans;
}


