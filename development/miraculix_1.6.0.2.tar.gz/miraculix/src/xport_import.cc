/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/

#include "Basic_miraculix.h"
#include "options.h"
#include "MXinfo.h"
//#include "2bit.h"
//#include "3bit.h"
//#include "5codes.h"
#include "mmagpu.h"
#include "intrinsics_specific.h"
#include "win_linux_aux.h"


coding_type getAutoCodingIntern() { // used also in options.h
  return TwoBitGeno;
}



THIS_FILE_ANYSIMD;
EXTERN_SIMD_CHECK(2bit128);
EXTERN_SIMD_CHECK(2bit256);
EXTERN_SIMD_CHECK(2bit512);
EXTERN_SIMD_CHECK(mma_61);
EXTERN_SIMD_CHECK(mma_75);
Uint check_intrinsics() { 
  CHECK_THIS_FILE_ANYSIMD;
  CHECK_FILE(2bit128); // sufficient to check 2bit* only
  CHECK_FILE(2bit256);
  CHECK_FILE(2bit512);
  CHECK_FILE(mma_75);
  CHECK_FILE(mma_61);
  return SIMD_INFO;
}


void InitPlink();
void Init2();
void Init3();
void Init5();
void startUtils();
void load_utilsoptions(utilsoption_type *S, int local);

Uint startLocal(int cores) {
  //  printf("startlocal\n");
  startUtils();
  Uint simd_info = check_intrinsics();
  const bool local=false;
  option_type *global;
  //  printf("A\n");
  WhichOptionList(local, &global, NULL); 
  global->genetics.coding = getAutoCodingIntern();
  utilsoption_type S;
  //  printf("AB\n");
  load_utilsoptions(&S, local);
  S.solve.max_chol = 50000;
  S.solve.max_svd = 6555;
  S.solve.Methods[0]=S.solve.Methods[1]=Cholesky;
  S.solve.Methods[2]=NoFurtherInversionMethod;
  S.basic.cores = GreaterZero(cores);

  //  printf("\tAC cores=%d\n", cores);
  Ext_push_utilsoption(&S, local);
  Ext_del_utilsoption(&S);

  Init2();
  Init3();
  Init5();
  InitPlink();
  check_cuda(); // uses  KEY_M
  //  printf("end startlocal\n");
  return simd_info;
}
