/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#ifndef miraculix_check_H
#define miraculix_check_H 1


int check_variant(coding_type coding, int variant, bool effficient);
int check_variant(coding_type coding, int variant, bool efficient,
		  bool stopOnError);


#endif
