/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/

// Externals:

#include "def.h" // must be before anything else


#ifndef C_PRINTLEVEL
#define C_PRINTLEVEL 1
#endif


// end Externals
