/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather 

 COPYRIGHT_TEXT
*/

#ifndef compatibility_header_h 
#define compatibility_header_h 1

#if defined STAND_ALONE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <err.h>
#else
#include <R.h>
#include <Rmath.h>
#include <Rinternals.h>
#endif

#endif
