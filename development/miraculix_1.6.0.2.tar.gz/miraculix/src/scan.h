/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#ifndef miraculix_scan_h 
#define miraculix_scan_h 1

void scanC(int *positions, int *length, double  *freq, int *minscan,
	   int *maxscan, double *threshold, int *nthres, int *PER_SNP,
	   int *above_threshold,  double *maximum);

SEXP collect_scan(int *positions, int *length, double  *freq, int *minscan,
		  int *maxscan, double *threshold, int *nthres,
		  int *PER_SNP, 
		  // additional return values:
		  int *areas,  double *value);
SEXP collect_scan2(int *positions, int *length, double  *freq, int *minscan,
		   int *maxscan, double *threshold, int *nthres,
		   int *PER_SNP, 
		   int max_intervals, int max_basepair_dist,
		   bool exclude_negative,
		   // additonal return values
		   int *above_threshold, double *maximum);

void sumscanC(int *positions, int *length, double  *freq, 
	     int *minscan,  int *maxscan, double *threshold, int *nthres,
	     int *PER_SNP,
	      int *above_threshold,  double *maximum);

#endif
