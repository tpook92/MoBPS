/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/

   
  
#define MY_VARIANT 512
#include "5codesDef.h" 


#if defined AVX512


ASSERT_SIMD(5codes512, avx512f);

#include "MX.h"
#include "haplogeno.h" 
#include "intrinsics.sequences.h" 
#include "5codesIntern.h"
 
 


#else
#include "avx_miss.h"

   
gV5_header(512, floatD, LongDouble, float, double, VARIABLE_IS_NOT_USED) Sv
gV5_header(512, double, LongDouble, double, double, VARIABLE_IS_NOT_USED) Sv


SIMD_MISS(5codes512, avx512f);

#endif  // defined AVX
// trafo2Geno1Geno128
 
