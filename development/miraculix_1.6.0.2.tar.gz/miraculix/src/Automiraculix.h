/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#ifndef AutoMiraculix_H
#define AutoMiraculix_H 1


#define CURRENT_IMPLEMENTATION 8

// all are _4Byte ordered except OneByteGeno/OneByteHaplo which are on byte level
// So within _4Byte the big/little endian store differently, but not among _4Byte
// Hence, if little endian, the ordering in genoVector of geno and Vector do
// not match in the RAM, but only after 32-bit-loading.


// Ordering:  snps, indiv, lda, coding, variant, ldabitalign
// SEE RFoptions.Rd for EXPLANATIONS
typedef enum coding_type {AutoCoding,  // 0K
   OneBitGeno, // (256 or) 512 bit alignement
   TwoBitGeno, // (256 or) 512 bit alignm
   ThreeBit,   // 1 matrix with 5 x 3 bit geno
   Plink, // only uised in VectorGeno
   //  00 -> 00
   //  01 : missing
   //  10 -> 01
   //  11 -> 10
   FiveCodes, // 5; 1 matrix with 5 genos in 1 byte
   OrigPlink, // 2 bit geno all data in a vector; here, lda in Bytes!!
   
   unused7,
   unused8,
   unused9,

   FourBit,  // format implicitely used on GPU
   OneByteGeno, // 11; 0,1,2 in 1 Bytes. This is a mixture between the
   // user defined unaligned 32-bit representation & an sse representation
   // The leading orderering of the data is through vector/matrix _1Byte[].
   // This implies that on big endian machines, the data must be reordered
   // for the leading 32bit storing _4Byte for SSE.
   // it has a standard 256-bit alignment
   TwoByte, // unused
   FourByteGeno, // 13--- 4-Byte-(R i.e. non)-alignment

   unused14,
   unused15,
   unused16,
   unused17,
   unused18,
   unused19,

   
   OneBitHaplo,  // 20
   TwoBitHaplo,
   
   OneByteHaplo,
   FourByteHaplo,
   
   FourByteSingleBit, // 21; IndividualsPerColumn=TRUE, DoubledIndividuals=TRUE
   EightByteHaplo, // IndividualsPerColumn=TRUE, DoubledIndividuals=FALSE
   
   // technical Codings start:
   DotFile,// 26;  no coding, but read from the file
   FileDot,

   CorrespondingGeno, // 28; not a coding on its own

   UnknownSNPcoding // 29, SIEHE AUCH MSinfo.h!!!
} coding_type;

#define nr_coding_type (UnknownSNPcoding + 1)

#define FirstMoBPScoding TwoBitGeno
#define LastMoBPScoding TwoBitGeno

#define FirstUserGenoCoding OneByteGeno // constants needed in test/*R
#define LastUserGenoCoding FourByteGeno
#define FirstGenoCoding OneBitGeno
#define LastGenoCoding LastUserGenoCoding

#define FirstHaplo32Coding FourByteHaplo // used by user
#define LastHaplo32Coding EightByteHaplo
#define FirstHaploCoding OneBitHaplo
#define LastHaploCoding LastHaplo32Coding

#define FirstUserCoding AutoCoding
#define LastUserCoding LastHaploCoding // with many gaps inbetween, see options.cc

// Haplo nach geno!!


// CHECK haplogeno.cc VARIANTS when changing!
#define VARIANT_DEFAULT 0
#define VARIANT_GPU 768 // never change ! see options.cc
#define VARIANT_R 896 // dito
#define VARIANT_A 32 // see options.cc, variantsSHR5
#define VARIANT_B 64 
#define VARIANT_C 96 // maximum!! Otherwise change main_variant

typedef enum centering_type {NoCentering=0,
  RowMeans=1, // mean for each row
  ColMeans=2, // mean for each col
  User} centering_type;
#define nr_centering_type (User + 1)
#define SNPmeans RowMeans // mean for each snp
#define INDIVmeans ColMeans // mean for each indiv

typedef enum normalizing_type {NoNormalizing=0, 
  RowNormalized=1, ColNormalized=2,
  CorrNormalizing,
  AccordingCentering
}  normalizing_type;
#define nr_normalizing_type (AccordingCentering + 1)



// WHAT just doubles the information that is also available through
// the class information, but easier to access on the C level for
// historical reasons. To be deleted maybe somewhen.


// Coding of the attribute "information"
// !!!! ACHTUNG ZAHLEN MUESSEN DIE GLEICHEN BLEIBEN !!!!


#define IMPLEMENTATION 0
#define SNPS 1 // Wert darf auf keinen Fall geaendert werden
#define INDIVIDUALS 2 // Wert darf auf keinen Fall geaendert werden
#define CODING 3
#define TRANSPOSED 4 // true, false; for information transport also Nan meaning current value / oder unknown / oder irrelevant -- meist true oder false
#define VARIANT 5
#define LDABITALIGN 6
#define LDA 7
#define ORIGINALLY_HAPLO 8
#define MISSINGS 9
#define EXPECTED_REPET_V 10

#define ADDR 11
//
#define MEMinUNITS 13 // total genuine memory used to store all matrices --
//
#define BIGENDIAN 15

#define CURRENT_SNPS 16 // used in MOBPS
#define ISHAPLO 17
#define ONEHAPLOONLY 18

#define FILE_SNPxIND_READ_BYROW 19 // INFO_INDIV_PER_COL, i.e. 'percolumn'
#define FILE_HEADER 20
#define FILE_DOUBLEINDIV 21
#define FILE_LEADINGCOL 22

#define INFO_GENUINELY_LAST FILE_LEADINGCOL
#define BLOCKEDINFO 24 // my pid
#define ZAEHLER 25


#define INFO_LAST 26

#define FIRST_FILE_INFO FILE_SNPxIND_READ_BYROW
#define LAST_FILE_INFO FILE_LEADINGCOL 

#define GENOMICMATRIX "genomicmatrix"
#define HAPLOMATRIX "haplomatrix"
#define ORIGINVECTOR "origindata"

#define MAX_LDA_BITALIGN 1024


#define N_MIRACULIX_NAMES_OF_NAMES 4

extern const char *CODING_NAMES[nr_coding_type],
  *NORMALIZING_NAMES[nr_normalizing_type],
  *CENTERING_NAMES[nr_centering_type],
  *INFO_NAMES[INFO_LAST + 1],
  *MIRACULIX_NAMES_OF_NAMES[N_MIRACULIX_NAMES_OF_NAMES];

#endif

