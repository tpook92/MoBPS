/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather 

 COPYRIGHT_TEXT
*/

#ifndef compatibility_rfu_h 
#define compatibility_rfu_h 1

// #include "compatibility.rfu.h"

#if defined STAND_ALONE
#else
#include "RandomFieldsUtils.h"
#endif


#endif
