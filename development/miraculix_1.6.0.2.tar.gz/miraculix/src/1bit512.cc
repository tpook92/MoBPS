/*
 Authors 
 Guido Moerkotto
 maintained and modified by Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Guido Moerkotte, Martin Schlather

 COPYRIGHT_TEXT
*/


#define MY_VARIANT 512
#define  DO_AVX512F 1
#include "1bitDef.h"

#include "Template.h"
#include "1bit.h"

#if defined AVX512F


ASSERT_SIMD(1bit512, avx512f);

#include "haplogeno.h"
#include "intrinsics.sequences.h"
#include "1bitIntern.h"

SCALAR012(512)	


#else // !defined AVX
#include "avx_miss.h"

SIMD_MISS(1bit512, avx512f);

DeclareVersion1(512,Su,Sv)

 
#endif  // defined AVX2
