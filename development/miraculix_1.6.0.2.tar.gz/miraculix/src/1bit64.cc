/*
 Authors 
 Guido Moerkotto
 maintained and modified by Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Guido Moerkotte, Martin Schlather

 COPYRIGHT_TEXT
*/



#define MY_VARIANT 64
#include "1bitDef.h"

#include "intrinsics.sequences.h"
#include "haplogeno.h"
#include "1bitIntern.h"


#define scalarA scalar // dummy, unsused
#define scalarB scalar // dummy, unsused

SCALAR012(64)	


