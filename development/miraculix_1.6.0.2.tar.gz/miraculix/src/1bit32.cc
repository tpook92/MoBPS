
/*
 Authors 
 Guido Moerkotto
 maintained and modified by Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Guido Moerkotte, Martin Schlather

 COPYRIGHT_TEXT
*/


#define MY_VARIANT 32
#include "1bitDef.h"

#include "intrinsics.sequences.h"
#include "1bitIntern.h"



#define scalarA scalar // dummy, unused
#define scalarB scalar // dummy, unused

SCALAR012(32)	


