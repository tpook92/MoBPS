/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/



#include "Basic_miraculix.h"
#include "xport_import.h"
#include "MXinfo.h"




void windower_meanC(int *Init, int *Length, int* Step, int *start, int *ende,
		   double *data, int *Lendata, double *res, int *N){
  Long is, ie, j, win_n, k,
    win_ende = *Init + *Length,
    win_start = *Init,
    step = *Step, 
    lendata = *Lendata,
    n = *N
    ;									
  double mass = 0.0;
  
  for (win_n = is = ie = k = j = 0; j < n; j++) {
    while(ie < lendata && ende[ie] <= win_start) {
      mass -= data[ie++];
      win_n--;
    }
    while(is < lendata && start[is] < win_ende) { // <= win_ende??
      mass += data[is++];
      win_n++;
    }
    // printf("mass %10g %d \n", mass, win_n);
    res[k++] = (double) win_start;
    res[k++] = (double) win_ende;
    res[k++] = win_n == 0 ?  NA_REAL : mass / (double) win_n;
    res[k++] = (double) win_n;
 
    win_ende +=  step;
    win_start += step;
  }

}
  


void windower_minC(int *Init, int *Length, int* Step, int *start, int *ende,
		   double *data, int *Lendata, double *res, int *N){
  Long is, ie, j, win_n, k,
    win_ende = *Init + *Length,
    win_start = *Init,
    step = *Step, 
    lendata = *Lendata,
    n = *N
    ;									
  double min = RF_INF;
  
  for (win_n = is = ie = k = j = 0; j < n; j++) {
    while(is < lendata && start[is] < win_ende) { // <= win_ende??
      double dummy = data[is++];
      if (dummy < min) min = dummy;
      win_n++;
    }
    bool redo = false;
    while(ie < lendata && ende[ie] <= win_start) {
      if (data[ie++] == min) redo = true;
      win_n--;
    }
    if (redo) {
      // 'ie' erste Position; 'is' nach letzter Position
      Long i = ie;
      min = i < is ? data[i++] : RF_INF;
      for (; i < is; i++) if (data[i] < min) min = data[i];
    }
    res[k++] = (double) win_start;
    res[k++] = (double) win_ende;
    res[k++] = (double) min;
    res[k++] = (double) win_n;
 
    win_ende += step;
    win_start += step;
  }
}
  

void windower_maxC(int *Init, int *Length, int* Step, int *start, int *ende,
		   double *data, int *Lendata, double *res, int *N){
  Long is, ie, j, win_n, k,
    win_ende = *Init + *Length,
    win_start = *Init,
    step = *Step, 
    lendata = *Lendata,
    n = *N
    ;									
  double max = RF_NEGINF;
  
  for (win_n = is = ie = k = j = 0; j < n; j++) {
    while(is < lendata && start[is] < win_ende) { // <= win_ende??
      double dummy = data[is++];
      if (dummy > max) max = dummy;
      win_n++;
    }
    bool redo = false;
    while(ie < lendata && ende[ie] <= win_start) {
      if (data[ie++] == max) redo = true;
      win_n--;
    }
    if (redo) {
      // 'ie' erste Position; 'is' nach letzter Position
      Long i = ie;
      max = i < is ? data[i++] : RF_NEGINF;
      for (; i < is; i++) if (data[i] > max) max = data[i];
    }
    res[k++] = (double) win_start;
    res[k++] = (double) win_ende;
    res[k++] = (double) max;
    res[k++] = (double) win_n;
 
    win_ende += step;
    win_start += step;
  }
}



void windower_medianC(int *Init, int *Length, int* Step, int *start, int *ende,
		   double *data, int *Lendata, double *res, int *N){
  Long is, ie, j, win_n, k,
    win_ende = *Init + *Length,
    win_start = *Init,
    step = *Step, 
    lendata = *Lendata,
    n = *N
    ;									
  Long *pos = (Long*) MALLOC(sizeof(Long) * *Length);
  if (pos == NULL) ERR0("memory allocation error");
  
  for (win_n = is = ie = k = j = 0; j < n; j++) {
    while(ie < lendata && ende[ie] <= win_start) {
      ie++;
      win_n--;
    }
    while(is < lendata && start[is] < win_ende) { // <= win_ende??
      is++;
      win_n++;
    }
    Ext_orderingL(data + ie, win_n, 1, pos);
    res[k++] = (double) win_start;
    res[k++] = (double) win_ende;
    res[k++] = win_n % 2 == 1 ? data[ie + pos[(win_n - 1) / 2]] :
      0.5 * (data[ie + pos[win_n / 2 - 1]] + data[ie + pos[win_n / 2]]);
    res[k++] = (double) win_n;
 
    win_ende += step;
    win_start += step;
  }
  FREE(pos);
}

