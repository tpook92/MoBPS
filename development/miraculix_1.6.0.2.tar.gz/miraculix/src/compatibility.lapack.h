/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather 

 COPYRIGHT_TEXT
*/

#ifndef compatibility_lapack_h 
#define compatibility_lapack_h 1

#if defined STAND_ALONE
#include <math.h>
#else
#include <R_ext/Lapack.h>
#include <R_ext/Linpack.h>
#endif


#endif
