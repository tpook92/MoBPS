/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/

#define MY_VARIANT 64
#define PlainInteger64 1

#include "Basic_miraculix.h"
#include "intrinsics_specific.h"
#include "options.h"
#include "haplogeno.h"
#include "Template.h"
#include "utils_miraculix.h"
#include "MXinfo.h"
#include "Haplo.h"
#include "transform.h"

void getHaploIncr(Long cols, Long lda, coding_type coding,
		  Long requestedBits,
		  Long *nextHaploIncr, // in [UINT]
		  Long *deltaTo2ndUncompressedHaplo,         // in [unit_t] 
		  Long *deltaToNextUncompressedCol      // in [unit_t]    
		  ) {
  switch(coding) {
  case OneByteHaplo:
  case OneByteGeno :    
  case FourByteHaplo:
  case FourByteGeno : 
    *deltaToNextUncompressedCol = lda;    // next col in [unit_t]    
    *nextHaploIncr = 1L; // next haplo/geno;  in [UINT](!) steps
    *deltaTo2ndUncompressedHaplo = lda *cols;//jump to twin bit in [unit_t]
    break;
  case FourByteSingleBit:
    *deltaToNextUncompressedCol = lda * requestedBits;
    *nextHaploIncr = 1L; // == lda / sizeof(UINT); // 
    *deltaTo2ndUncompressedHaplo = lda  ;
    break;
  case EightByteHaplo: 
    *deltaToNextUncompressedCol = lda;
    *nextHaploIncr = requestedBits;
    *deltaTo2ndUncompressedHaplo = 1;
    break;
  default: BUG;
  }
  *deltaTo2ndUncompressedHaplo *= (requestedBits > 1);
}

void getHaploIncr(Long VARIABLE_IS_NOT_USED rows, Long cols, Long lda,
		  coding_type coding, 
		  Long compressed_lda, coding_type compressed_coding,
		  Long requestedBits, // 1 or 2
		  Long *unitIncr, Long *nextHaploIncr,  // all un-compressed
		  Long *deltaTo2ndUncompressedHaplo, Long *deltaToNextUncompressedCol,     // all un-compressed
		  Long *bitsPerCodeCompr, Long *shiftIncrCompr,// compressed
		  Long *deltaCompressed, Long *CpUcompressed) {// compressed
  //  printf("entering gethapoincr\n");

  assert(compressed_coding == OneBitHaplo ||
	 compressed_coding == TwoBitHaplo ||
	 compressed_coding == OneByteHaplo);
  bool doubled_cols = doubledCols(compressed_coding, true);
  *CpUcompressed = GetCodesPerUnit(compressed_coding);
  *bitsPerCodeCompr = BitsPerUnit /  *CpUcompressed;
  *shiftIncrCompr = (*bitsPerCodeCompr / 2) * (!doubled_cols);
  *deltaCompressed = compressed_lda * cols * doubled_cols;

  if (coding == UnknownSNPcoding) {
    //printf("RETURNING\n");
    assert(unitIncr == NULL);
    return;
  }
  assert(unitIncr != NULL);

  getHaploIncr(cols, lda, coding, requestedBits, // in 
	       nextHaploIncr, deltaTo2ndUncompressedHaplo, deltaToNextUncompressedCol); //out
  
  switch(coding) {
  case OneByteHaplo:
  case FourByteHaplo:
  case OneByteGeno :
  case FourByteGeno :
    // stepforward [unit_t] after a unit_t has 
    //      been completely filled with compressed code
    *unitIncr = *CpUcompressed / GetCodesPerUnit(coding);
    break;
  case FourByteSingleBit:
    *unitIncr = *CpUcompressed / GetCodesPerUnit(coding);
    break;
  case EightByteHaplo: 
    *unitIncr = *CpUcompressed * requestedBits;
    break;
  default: BUG;
  }
}


// Achtung!! BigEndian und LitteEndian: Uchar[] und 4-Byte-int
// sind nicht dasselbe!!. Somit kann Uchar NICHT gleichzeitig als
// internes (SSE) und externes (array) format interpretiert werden!!
// FESTLEGUNG: Uchar[] ist das fuehrende Format; soit wird bei
// interpretation 

void codeHaplo(unit_t *MM, Long rows, Long OldCol, Long lda,		
	       coding_type coding,					
	       int *col_list, int col_list_N,				
	       basic_options *opt,					
	       unit_t *Ans, Long NewCol, Long ldAns,			
	       coding_type newCoding/*2BitHaplo*/) {		
  if (opt->bigendian) ERR0("codeHaplo only work for little endian");	
  /* // printf("coding %s -> %sn", CODING_NAMES[coding], CODING_NAMES[newCoding]); */ 
  Long unitIncr, nextHaploIncr, deltaTo2ndUncompressedHaplo, deltaToNextUncompressedCol, shiftIncrCompr,	
    bitsPerCodeCompr, deltaCompressed, CpU;				
  Long  col_N = col_list_N > 0 ? NewCol : OldCol,		
    nCol = 0;								
  Long  total = 0;							
  getHaploIncr(rows, OldCol, lda, coding,		
	       ldAns, newCoding, 2,					
	       &unitIncr, &nextHaploIncr,
	       &deltaTo2ndUncompressedHaplo, &deltaToNextUncompressedCol,	
	       &bitsPerCodeCompr, &shiftIncrCompr, &deltaCompressed, &CpU); 
  if (Haplo32(coding)) nextHaploIncr *= 4;/* in Byte */		
  int BitsPCCompr = stopIfNotInt(bitsPerCodeCompr);			
  /* // printf("code lda=%u col=%u uincr=%ld nxtHaploIncr=%ld deltaTo2ndUncompressedHaplo=%ld nxtCol=%ldntldAns=%u bpcc=%ld shift=%ld deltaC=%ld CpU=%ld sizeUInt=%ldn", 
     lda, OldCol,						
     unitIncr, nextHaploIncr, deltaTo2ndUncompressedHaplo, deltaToNextUncompressedCol,			
     ldAns,							
     BitsPCCompr, shiftIncrCompr, deltaCompressed, CpU, sizeof(UINT)); */  
  Long allUnitsM1 = DIV_GEQ(rows, CpU) - 1;			
  int bigendianCorr = BitsPerUnit - BitsPCCompr;		
  int rest = (int) ((rows - allUnitsM1 * CpU) * BitsPCCompr);	
  bool bigendian = opt->bigendian & isOneByte(newCoding);	
  MEMSET(Ans, 0, totalMem(NewCol, ldAns, newCoding, false, true) * 
	 BytesPerUnit);
  
    //#ifdef DO_PARALLEL
    //#pragma omp parallel for num_threads(cores) reduction(+:total) schedule(static)
    //#endif
  for (Long i=0; i<col_N; i++) {  
    Long ii=i;								
    if (col_list_N > 0) {						
      ii = col_list[i];						
	if (ii >= OldCol) continue;					
    }									
    unit_t *pC = Ans + (nCol++) * ldAns;				
    unit_t *M = MM + ii * deltaToNextUncompressedCol;					
    Uchar check = 0;							
    for (Long j=0; j<=allUnitsM1; j++) {				
      unit_t dummy1 = 0;							
      unit_t dummy2 = 0;							
      Uchar *mm1 = (Uchar*) ( M + j * unitIncr);			
      Uchar *mm2 = (Uchar*) (((unit_t*) mm1) + deltaTo2ndUncompressedHaplo); /* // ((( OK */	
      int end = j==allUnitsM1 ? rest : BitsPerUnit;		
      for (int shift=0; shift < end;					
	   mm1+=nextHaploIncr, mm2 += nextHaploIncr) {			
	Long Shft = bigendian ? bigendianCorr - shift : shift;		
	check |= *mm1 | *mm2;						
	dummy2 |= ((unit_t) (*mm2)) << (Shft + shiftIncrCompr);		
 	dummy1 |= ((unit_t) (*mm1)) << Shft;				
	shift += BitsPCCompr;					
      }									
      if (shiftIncrCompr) {						
	pC[j] = dummy1 | dummy2;  /* // printf("n");BUG; */		
      } else {								
	pC[j] = dummy1;							
	pC[j + deltaCompressed] = dummy2;				
      }									
    }									
    total += check > 1;							
    // if (total > 0)	{ /*//printf("Bn");*/ BUG;}			
  }									
  if (total > 0) ERR0("values outside 0,1");				
}



void decodeHaplo(unit_t *code, Long rows, Long OldCol, Long lda,	
		 coding_type coding,					
		 int *col_list, int col_list_N,				
		 usr_bool usr_set1,					
		 int VARIABLE_IS_NOT_USED cores,			
		 unit_t *Ans, Long NewCol, Long ldAns,			
		 coding_type newCoding) {				
  const bool set1 = usr_set1 == Nan || usr_set1 == True;		
  Long unitIncr, nextHaploIncr, deltaTo2ndUncompressedHaplo,
    deltaToNextUncompressedCol, shiftIncrCompr,	
    bitsPerCodeCompr, deltaCompressed, CpUlong;				
  Long nCol = 0,							
    requestedBits =  1 + (usr_set1 == Nan),				
    col_N = col_list_N > 0 ? NewCol : OldCol;			
  Long totalUnits = totalMem(NewCol, ldAns, newCoding, usr_set1 != Nan);
  if (!isUnCompressed(newCoding) ||
      ((requestedBits == 2) xor (isHaplo(newCoding))))  BUG;	
  getHaploIncr(rows, OldCol, ldAns, newCoding, 		
	       lda, coding,						
	       requestedBits,						
	       &unitIncr, &nextHaploIncr, &deltaTo2ndUncompressedHaplo,
	       &deltaToNextUncompressedCol,		
	       &bitsPerCodeCompr, &shiftIncrCompr, &deltaCompressed, 
	       &CpUlong);						
  if (Haplo32(newCoding)) nextHaploIncr *= 4;/* in Byte */		
  MEMSET(Ans, 0, BytesPerUnit * totalUnits); /* avoids unset memory */	
  int CpU = (int) CpUlong;						
  Long allUnitsM1 = DIV_GEQ(rows, CpU) - 1;			
  int rest = (int) (rows - allUnitsM1 * CpU);				
  /* !! wg nCol: KEIN  # p r a g m a !!  */				
  for (Long i=0; i<col_N; i++) { 
    Long ii = i;							
    if (col_list_N > 0) {						
      ii = col_list[i];						
      if (ii >= OldCol) continue;					
    }									
    unit_t *pC = code + lda * ii;						
    unit_t *M =  Ans + (nCol++) * deltaToNextUncompressedCol;		
    for (Long j=0; j<=allUnitsM1; j++) {				
      Uchar *mm1 = (Uchar*) (M + j * unitIncr);			
      Uchar *mm2 =  (Uchar*) (((unit_t*) mm1) + deltaTo2ndUncompressedHaplo);
      unit_t C1 = pC[j],						
	C2 = pC[j + deltaCompressed];					
      int shift = 1,							
	end = j == allUnitsM1 ? rest : CpU;				
      for (int u=0; u<end; u++, mm1+=nextHaploIncr, mm2 += nextHaploIncr) { 
	/* ordering important !! as mm2 might be overwritten by mm!! */ 
	*mm2 = (C2 & (shift << shiftIncrCompr)) > 0; /* never change as mm */ 
	/* could be mm2!! */	
	if (set1) *mm1 = (C1 & shift) > 0;				
	/*// printf("(%u, %u) ", *mm1, *mm2);	*/			
	shift <<= bitsPerCodeCompr;					
      }									
      /*//printf("half donen");*/						
    }									
  } 								
}



#define coding_Haplo1Byte_start(UINT)				\
  coding_header(UINT,Haplo1Byte) {				\
  Long delta = ldAns * cols;					\
  Long DeltaM = ldM * (end_col - start_col + 1);		\
  if (transposed != False) BUG;

#define coding_Haplo1Byte_end(UINT)				\
  /* // printf("coding_Haplo1Byte\n"); */			\
  for (Long i=start_col; i<end_col; i++) {		\
    UINT *pM = (UINT*) (M + (i - start_col) * ldM);	\
    UINT *pM2 = (UINT*) (((unit_t*) pM) + DeltaM); /* // ((( OK */	\
    unit_t *A = Ans + i * ldAns;					\
    _1Byte *pAns = (_1Byte*) A;						\
    _1Byte *pAns2 = (_1Byte*) (A + delta);				\
    for (Long s=start_row; s<end_row; pM++, pM2++, s++) {		\
      pAns[s] = (_1Byte) *pM;						\
      pAns2[s] = (_1Byte) *pM2;						\
    }									\
  }									\
}


coding_Haplo1Byte_start(_4Byte)				     
//#ifdef DO_PARALLEL
  //#pragma omp parallel for num_threads(cores) schedule(static)
//#endif
coding_Haplo1Byte_end(_4Byte)	

coding_Haplo1Byte_start(_1Byte) // geht schneller nur mit MEMCOPY -- ToDo 
//#ifdef DO_PARALLEL
  //#pragma omp parallel for num_threads(cores) schedule(static)
//#endif
coding_Haplo1Byte_end(_1Byte)

