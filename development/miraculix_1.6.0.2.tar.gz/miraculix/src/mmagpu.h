/*
 Authors 
 Alexander Freudenberg, alexander.freudenberg@uni-mannheim.de
 
 COPYRIGHT_YEAR Alexander Freudenberg

 COPYRIGHT_TEXT
*/



#ifndef miraculix_mmagpu_H
#define miraculix_mmagpu_H 1

void crossprod_mmagpu(Uint* code, Long snps, Long individuals,
		      Uint Lda, int cores, double *ans);
void check_7_5();

void crossprod_PlainGPU(Uint* M, Long snps, Long individuals,
			Uint VARIABLE_IS_NOT_USED lda, int cores, double* A );

void err_check(const char* string);

#endif
