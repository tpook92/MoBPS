/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


// ACHTUNG: Reihenfolge nicht aendern!
//#include "Basic_miraculix.h"
#include "options.h"
#include "intrinsicsCheck.h"
#include "MXinfo.h"
//#include "mmagpu.h"
//#include "utils_miraculix.h"
//#include "kleinkram.h"



const char * prefixLlist[prefixLN] =
  {"genetics", "tuning_param", "genetics_messgaes"};

// IMPORTANT: all names of general must have at least 3 letters !!!

const char *genetics_names[geneticsN] = 
  {"digits", "snpcoding", "centered", "normalized", "squared",
   "haplo_set1", "interprete_as_is", "prefer_external_freq", "no_classes"};

const char *tuning_names[tuningN] = 
  {"savehaplo", // 0
   "oldversion", // for debugging only !
   "variant", //variant
   "logRowGroupSize", // min 12
   "colGroupSize", // min 1
   "smoothRowGroupSize",
   "meanVsubstract", "meanSxIsubstract",
   "floatPrecision",
   "missingsFully0", // 9
   "miniRows", "miniCols", "use_gpu_for_vector", "add_tranposed",
   "WeakPerformance",
   "HyperPerformance", // 15
   "HyperTurnedOn"
  };


const char *messages[messagesN] = 
  {"warn_address"}; 


option_type OPTIONS_LOCAL = { // OK
  genetics_START,
  tuning_START,
  messages_START
};


const char **allLoptions[prefixLN] = {genetics_names,tuning_names,messages};
int allLoptionsN[prefixLN] = {geneticsN,tuningN,messagesN};


int main_variant(int variant) {
  return variant < 128 ? variant: variant - variant % 128;
  //  return variant < 128 ? variant
  //  : variant - variant % (variant < VARIANT_GPU ? 256 : 128);
}
 
bool exists_variant(coding_type coding, 
		    int variant, bool indeed,
		    bool efficient) {
  if (variant == VARIANT_DEFAULT) return true;
  if (variant < 0 || variant > 32 *(NvariantsSHR5 - 1) || (variant % 32 != 0)
      || !variantsSHR5[variant >> 5])
    return false;
  
  bool ans;
  switch(coding) {
  case OneBitGeno : ans = variant < VARIANT_GPU; break;
  case TwoBitGeno :
    ans = variant <= 512 + VARIANT_A &&
      (variant <= 64 || (variant % 128) <= VARIANT_A)
#if defined USEGPU
      || variant == VARIANT_GPU 
#endif
      ; break;
  case ThreeBit : ans = variant == 64; break;
  case FourBit : ans = false; break;
  case OneByteGeno : ans = variant == 32;  break;
  case TwoByte : ans = false; break;
  case FourByteGeno : ans = variant == 32 || variant == VARIANT_R ||
      variant == VARIANT_R + VARIANT_A
#if defined USEGPU
      || variant == VARIANT_GPU 
#endif
      ; break;
  case OneBitHaplo : ans = false; break;
  case TwoBitHaplo: ans = variant == 32; break;
  case OneByteHaplo: ans = variant == 32; break;
  case FourByteHaplo: ans = variant == 32; break;
  case FourByteSingleBit: ans = variant == 32; break;
  case EightByteHaplo: ans = variant == 32; break;
   default : BUG;
  }

  //  printf("ok=%d (%d) %d %d\n", ans, efficient, coding, variant);

  // printf("%s %d indeed=%d: ans=%d -> %d; #!indeed=%d ok=%d\n",	 CODING_NAMES[coding], variant, indeed, ans,	 check_variant(coding, variant, efficient, false),  !ans || !indeed,	 (int) check_variant(coding, variant, efficient, false) >= (int) VARIANT_DEFAULT);
  
  if (!ans || !indeed) return ans;
  
  return check_variant(coding, variant, efficient, false) >= VARIANT_DEFAULT;
}


bool exists_tiling(coding_type coding, int variant, bool tiling) {
  // function assumes that combination coding/variant is valid!
  switch(coding) {
  case OneBitGeno : return true;
  case TwoBitGeno :
    return (variant >= 128 && variant < VARIANT_GPU) ||
      ((variant < 128 || variant == VARIANT_GPU) && !tiling);
  case ThreeBit : return !tiling;
  case FourByteGeno : return !tiling;
  default : return false; 
  }
  BUG;
  return false;  
 }
  

bool exists_crossprod(coding_type m) {
   assert(FourByteGeno == 13);
   return (m >= FirstGenoCoding && m <= ThreeBit) || m == FourByteGeno;
}

bool exists_allelefreq(coding_type m) {
  assert(FiveCodes == 5 && LastHaploCoding==25);
  return  (m >= TwoBitGeno && m <= FiveCodes) ||
    m == OneByteGeno || m == FourByteGeno || Haplo32(m);
}


bool exists_internal_coding(coding_type m) {
  assert(FourByteGeno == 13);
  return (m >= OneBitGeno && m <= FiveCodes) ||
    m == OneByteGeno || m == FourByteGeno ||	  
    (m >= OneBitHaplo && m <= OneByteHaplo);
}


bool exists_user_coding(coding_type m) {
  assert(LastHaploCoding==25);
  return isUnCompressed(m);
}

bool exists_coding(coding_type m) {
  return exists_internal_coding(m) || exists_user_coding(m);
}

