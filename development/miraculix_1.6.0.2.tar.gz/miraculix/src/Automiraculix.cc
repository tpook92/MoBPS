/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#include "Automiraculix.h"

const char // muss in separater Zeile sein
// nachfolgende Zeile eingerueckt um 0 oder 2 Zeichen

  *CODING_NAMES[nr_coding_type] = {
  "AutoCoding",
  "1bit", 
  "2bit",
  "3bit",
  "plink",
  "5codes8",
  "orig.plink",  
  "unused7","unused8", "unused9", 
  "2bit4",  // unused
  "2bit8",
  "2bit16", // unused
  "2bit32",
  "unused14","unused15", "unused16", 
  "unused17","unused18", "unused19", 
 
  "1bit-H", "2bit-H", "1bit8-H", "1bit32-H", "1-1-bit32", "2bit64-H",
 
  "dot.file", "file.dot", "anyGeno", 
  "unknown"},
    
  *INFO_NAMES[INFO_LAST + 1] = {
    "implementation", "snps", "individuals", "coding", "transposed", "variant",
    "ldaBitalign", "lda", "genuinehaplo", "missings","expected_size_V",  // 10
    "addr", "<unused>", "memInUnits", "<unsed>", "bigendian",   // 15
    "current_snps (MoBPS)", "<isHaplo>", "one haplo only"// 18
    "isSNPxInd", "header","DoubledIndividuals", "leadingcolumns", // 33
    "<unused>","BLOCKEDINFO", "Zaehler",
    "<Last>"},


  *CENTERING_NAMES[nr_centering_type] = {
    "no centering", "snp means", "indiv means",   "user"},

  *NORMALIZING_NAMES[nr_normalizing_type] = {
    "no normalizing", "RowNormalized", "ColNormalized",
    "correlation normalization", "according_centering"},
 
  *MIRACULIX_NAMES_OF_NAMES[N_MIRACULIX_NAMES_OF_NAMES] = {
    // add, but NEVER delete or change
    "coding", "centering", "info", "normalizing"
  }

; // 64

