/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#define MY_VARIANT 512
#include "2bitDef.h"

#include "Template.h"
#include "2bit.h"

#if defined AVX512

ASSERT_SIMD(2bit512, avx512f);

#include "haplogeno.h"
#include "intrinsics.sequences.h"
#include "2bitIntern.h"


void coding_2v512(unit_t *M, Long ldM,
		  Long start_individual, Long end_individual, 
		  Long start_snp, Long end_snp, 
		  basic_options VARIABLE_IS_NOT_USED  *opt,
		  double VARIABLE_IS_NOT_USED *G, SEXP Ans) {
  /*
    use 
__m256i _mm256_maskz_compress_epi8 (__mmask32 k, __m256i a)
void _mm512_mask_compressstoreu_epi8 (void* base_addr, __mmask64 k, __m512i a)
  
 */
  
  BUG;
}

FileBinary(512);
SCALAR012(512)

#else // !defined AVX
#include "avx_miss.h"


DeclareVersion2(512,Su,Sv,Sm)
SIMD_MISS(2bit512, avx512f);


#endif  // defined AVX2
// trafo2Geno1Geno128
