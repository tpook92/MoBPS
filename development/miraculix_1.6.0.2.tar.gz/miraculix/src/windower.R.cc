/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/





#include "Basic_miraculix.h"

#if defined compatibility_to_R_h
#include "miraculix.h"
#include "xport_import.h"
#include "MXinfo.h"



void windower_meanC(int *Init, int *Length, int* Step, int *start, int *ende,
		    double *data, int *Lendata, double *res, int *N);
void windower_minC(int *Init, int *Length, int* Step, int *start, int *ende,
		   double *data, int *Lendata, double *res, int *N);
void windower_maxC(int *Init, int *Length, int* Step, int *start, int *ende,
		   double *data, int *Lendata, double *res, int *N);
void windower_medianC(int *Init, int *Length, int* Step, int *start, int *ende,
		      double *data, int *Lendata, double *res, int *N);

SEXP windower_mean(SEXP Init, SEXP Length, SEXP Step, SEXP start, SEXP ende,
		   SEXP data, SEXP Lendata, SEXP N) {
  SEXP res;
  PROTECT(res=allocMatrix(REALSXP, 4,  INTEGER(N)[0]));
  windower_meanC(INTEGER(Init), INTEGER(Length), INTEGER(Step),
		INTEGER(start), INTEGER(ende), REAL(data), INTEGER(Lendata),
		REAL(res), INTEGER(N));
  UNPROTECT(1);
  return res;
}

  
SEXP windower_min(SEXP Init, SEXP Length, SEXP Step, SEXP start, SEXP ende,
		   SEXP data, SEXP Lendata, SEXP N) {
  SEXP res;
  PROTECT(res=allocMatrix(REALSXP, 4,  INTEGER(N)[0]));
  windower_minC(INTEGER(Init), INTEGER(Length), INTEGER(Step),
		INTEGER(start), INTEGER(ende), REAL(data), INTEGER(Lendata),
		REAL(res), INTEGER(N));
  UNPROTECT(1);
  return res;
}

SEXP windower_max(SEXP Init, SEXP Length, SEXP Step, SEXP start, SEXP ende,
		   SEXP data, SEXP Lendata, SEXP N) {
  SEXP res;
  PROTECT(res=allocMatrix(REALSXP, 4,  INTEGER(N)[0]));
  windower_maxC(INTEGER(Init), INTEGER(Length), INTEGER(Step),
		INTEGER(start), INTEGER(ende), REAL(data), INTEGER(Lendata),
		REAL(res), INTEGER(N));
  UNPROTECT(1);
  return res;
}


SEXP windower_median(SEXP Init, SEXP Length, SEXP Step, SEXP start, SEXP ende,
		   SEXP data, SEXP Lendata, SEXP N) {
  SEXP res;
  PROTECT(res=allocMatrix(REALSXP, 4,  INTEGER(N)[0]));
  windower_medianC(INTEGER(Init), INTEGER(Length), INTEGER(Step),
		INTEGER(start), INTEGER(ende), REAL(data), INTEGER(Lendata),
		REAL(res), INTEGER(N));
  UNPROTECT(1);
  return res;
}

SEXP windower(SEXP what, SEXP Init, SEXP Length, SEXP Step, SEXP start, SEXP ende,
	      SEXP data, SEXP Lendata, SEXP N) {
  switch(INTEGER(what)[0]) {
  case 1 : return windower_mean(Init, Length, Step, start, ende, data, Lendata, N);
  case 4 : return windower_min(Init, Length, Step, start, ende, data, Lendata, N);
  case 5 : return windower_max(Init, Length, Step, start, ende, data, Lendata, N);    
  case 6 : return windower_median(Init, Length, Step, start, ende, data, Lendata, N);
  default : BUG;
  }
  return R_NilValue;
}


#endif
