/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#define BitsPerCode 2
#define MY_CODING Plink
#define MY_LDABITALIGN MY_LDABITALIGN_PLINK

#define MY_VARIANT 32
#define BytesPerPartUnit 2


#include "Basic_miraculix.h"
#include "intrinsics_specific.h"
#include "options.h"
#include "haplogeno.h"
#include "TemplateUint.h"
#include "bitUint.h"
#include "plink.h"

#include "Haplo.h"
#include "MX.h"


#define RIGHT ((unit_t) 0x5555555555555555)
#define LEFT ((unit_t) 0xAAAAAAAAAAAAAAAA)
#define PLINKTRAFO							\
  , rPlink = twobit & RIGHT, lPlink = twobit & LEFT,			\
    mPlink=lPlink & rPlink << 1;			     \
  twobit = mPlink | ((mPlink xor lPlink) >> 1)

Uint SUM_MISSINGS[256];


Long LdaPlink(Long rows, Long LDAbitalign) {
  return LDAalignBitSnps(rows * BitsPerCode); 
}

int BitsPerCodePlink() { return BitsPerCode; }


Long LdaOrigPlink(Long rows, Long LDAbitalign) {
  if (LDAbitalign != BitsPerByte && LDAbitalign != 0) {
    PRINTF("lda %ld %u\n", ALONG LDAbitalign, BitsPerByte);
    BUG;
  }
  return ROUND_GEQ(rows * BitsPerCode, BitsPerByte);
}


void InitPlink() {
  assert(sizeof(unit_t) <= 8); // def RIGHT, LEFT
  for (Uint i3=0; i3<4; i3++) {
    Uint V3 = i3;
    Uint missings3 = (Uint) (i3 == 1U);
    for (Uint i2=0; i2<4; i2++) {
      Uint V2 = 4U * V3 + i2;
      Uint missings2 = missings3 + (Uint) (i2 == 1U);
      for (Uint i1=0; i1<4; i1++) {
	Uint V1 = 4U * V2 + i1;
	Uint missings1 = missings2 + (Uint) (i1 == 1U);
	for (Uint i0=0; i0<4; i0++) {
	  Uint V0 = 4U * V1 + i0;
	  Uint missings0 = missings1 + (Uint) (i0 == 1U);
	  SUM_MISSINGS[V0] = missings0;
	}
      }
    }
  }
}


get_matrix_start(_4Byte, Plink)
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
get_matrix_end(_4Byte,PLINKTRAFO)  

get_matrix_start(_1Byte, Plink)
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
get_matrix_end(_1Byte,PLINKTRAFO)   


coding_start(_4Byte,Plink)
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) reduction(+:total) schedule(static)
#endif
coding_end(_4Byte, HUMAN2PLINK(*mm) )
 
coding_start(_1Byte,Plink)
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) reduction(+:total) schedule(static)
#endif
coding_end(_1Byte, HUMAN2PLINK(*mm) )
 
 


coding2trans_start(_4Byte, Plink)
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif								
coding2trans_do(_4Byte, HUMAN2PLINK)

coding2trans_start(_1Byte, Plink)
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
coding2trans_do(_1Byte, HUMAN2PLINK)



vectorGeno_start(Ulong, Ulong, Ulong, Plink);
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) collapse(2) schedule(static)
#endif	
vectorGeno_fctn(Ulong, Ulong, Ulong, PLINKTRAFO)


vectorGeno_start(double, double, double, Plink);
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) collapse(2) schedule(static)
#endif	
vectorGeno_fctn(double, double, double, PLINKTRAFO)


vectorGeno_start(LongDouble, LongDouble, LongDouble, Plink);
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) collapse(2) schedule(static)
#endif	
vectorGeno_fctn(LongDouble, LongDouble, LongDouble, PLINKTRAFO)


colSums_start(Plink) 
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) reduction(+:total) schedule(static)
#endif
colSums_fctn(PLINK2HUMAN)



void getPlinkMissings(Uchar* plink, bool is_plink_tr,
		      SEXP SxI, basic_options *opt) {
  // either plink is given directly or as raw OrigPlink in SxI
  int  VARIABLE_IS_NOT_USED cores = GreaterZero(opt->cores);
  condExtractInfo(SxI, !is_plink_tr);
  Long ldaByte, eins, null;
  if (plink == NULL) {
    ldaByte = lda * BytesPerUnit;
    null = 0;
    eins = 1;
  } else {
    rows = is_plink_tr ? snps : individuals;
    cols = is_plink_tr ? individuals : snps;
    ldaByte = DIV_GEQ(rows, CodesPerByte);
    code = (unit_t *) plink;
    null = (transposed == False) xor is_plink_tr;
    eins = (int) (null == 0) ;    
  }

  Long *P = (Long*) code;
  Long totalLength = ldaByte * cols;// in Bytes
  Long lenLong = ROUND_LEQ(totalLength, sizeof(*P)); // OK
  Long missings = 0;
  Long i = 0;
  #define N1E1_L 0x5555555555555555

  for(; i<lenLong; i+=sizeof(*P), P++) { 
    Long anymiss = *P & N1E1_L & (~ *P >> 1);
    if (anymiss) {
      Uchar *p = (Uchar*) P;
      for (Ulong j=0; j<sizeof(*P); j++) missings += SUM_MISSINGS[p[j]];
    }
  }
  Uchar*p = (Uchar*) P;
  for(; i < totalLength; i++, p++) missings += SUM_MISSINGS[p[i]];
  
  SEXP Miss = R_NilValue;
  info[MISSINGS] = missings;
  if (missings) {
    Miss = PROTECT(allocMatrixExtra(LONGSXP, 2, stopIfRandNotInt(missings)));
    setAttrib(SxI, Missings, Miss);
    Long *pM = LONG(Miss);
    Long mc = 0;
  
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
    for (Long c=0; c < cols; c++) {
      Uchar *fourcodes = (Uchar*) (code + ldaByte * c);
      for (Long r=0; r<ldaByte; r++) {
	Uchar x = fourcodes[r];
	Uint m = SUM_MISSINGS[x]; // assuming only few missings ...
	if (m) {
	  for(Uint k=0; k<CodesPerByte; k++) {
	    if ((x & 0x03) == 0x01) {
	      pM[mc + null] = r * CodesPerByte + k; // c und r+... tauschen??
	      pM[mc + eins] = c;                    // ??
	      mc += 2;
	    }
	    x >>= BitsPerCode;
	  }
	} // m
      } // r
    } // c
    
    UNPROTECT(1);
  } // missings
}

// up to now miniIndivChunk 4 staticSize 32, mini 4


#define staticSize 32
#define miniRowChunkFactor 4

/*
// miniRowChunkFactor 4, row = -4
1 : 2.830 ( 26.899)
2 : 2.173 ( 20.304) 2.245 ( 20.924) 
4: 1.573 ( 14.349) 
8:1.115 (  9.757) 1.095 (  9.624) 1.138 (  9.957)
10:1.125 (  9.903)1.121 (  9.823) 1.182 ( 10.497)
16:0.953 (  8.185)0.992 (  8.488) 0.951 (  8.197) 
   0.977 (  8.337)0.955 (  8.188) 0.951 (  8.181)
   0.964 (  8.190)0.964 (  8.178) 0.964 (  8.214) 
32:0.888 (  7.484) 0.888 (  7.484) 
64: 0.922 (  7.862) 0.915 (  7.807)0.920 (  7.810) 
128: 0.917 (  7.774)
256: 0.907 (  7.65
512:1.782 ( 16.428) 
1024:2.193 ( 20.435)
 */

/*
 static 10: row =-4 
 1:1.200 ( 10.626) 1.158 ( 10.136) 1.196 ( 10.606)
 2: 1.063 (  9.152) 1.126 (  9.933)1.080 (  9.440)
 3: 1.065 (  9.321) 1.072 (  9.362)1.088 (  9.426
 4:  1.073 (  9.319)  1.058 (  9.250)1.053 (  9.065) 
 7:1.344 ( 11.291)  1.128 (  9.925)1.211 ( 10.645) 
 10:1.125 (  9.903)1.121 (  9.823) 1.182 ( 10.497)
 40:1.184 ( 10.375)1.297 ( 10.770) 1.195 ( 10.541)
 400: 1.548 ( 14.084)

 static 32: wait
 2: 0.902 (  7.619) 0.894 (  7.614)
 4:0.888 (  7.484) 0.888 (  7.484) 
 8: 0.958 (  8.172)
40:1.114 (  9.803)

*/



// row = -120
//#define miniIndivChunk 4
//#define MULTI(X,SZ) X(0) SZ X(1) SZ X(2) SZ X(3)
// 13.607 (134.684) 14.653 (145.047) 14.099 (139.495) 

//#define miniIndivChunk 8
//#define MULTI(X,SZ) X(0) SZ X(1) SZ X(2) SZ X(3) SZ X(4) SZ X(5) SZ X(6) SZ X(7)
//   11.578 (114.293)  12.328 (121.752)  13.067 (129.134)  12.592 (124.381)

//#define miniIndivChunk 12
//#define MULTI(X,SZ) X(0) SZ X(1) SZ X(2) SZ X(3) SZ X(4) SZ X(5) SZ X(6) SZ X(7) SZ X(8) SZ X(9) SZ X(10) SZ X(11)
//   9.854 ( 97.135) 11.074 (109.180)  11.075 (109.186) 11.128 (109.955) 


// row = -240
// #define miniIndivChunk 8
// 22.930 (227.752) 23.786 (236.256) 22.819 (226.631) 22.341 (221.874) 
// #define miniIndivChunk 12, 
// 19.811 (196.704) 24.043 (238.450) 22.760 (225.573)  22.548 (223.428) 20.150 (199.923)
// #define miniIndivChunk 16, 
// 21.602 (214.604)  20.087 (199.287) 21.612 (214.435) 20.586 (204.267)


//#define miniIndivChunk 24
//#define MULTI(X,SZ) X(0) SZ X(1) SZ X(2) SZ X(3) SZ X(4) SZ X(5) SZ X(6) SZ X(7) SZ X(8) SZ X(9) SZ X(10) SZ X(11) SZ X(12) SZ X(13) SZ X(14) SZ X(15) SZ X(16) SZ X(17) SZ X(18) SZ X(19) SZ X(20) SZ X(21) SZ X(22) SZ X(23)
// 9.524 ( 93.788)  11.823 (116.668)  11.172 (110.222) staticSize 32  mini 4
// 10.682 (105.412)  11.146 (109.841)staticSize 32  mini 8
//  10.891 (107.580)11.532 (113.978) 11.932 (117.855) staticSize 32  mini 2


#define POINTER_TO_CODE(N) \
  Ulong *row##N = (Ulong*) (c + colIdxB[iChunk + N] * ldaInByte)
#define ROW_POINTER_TO_CODE MULTI(POINTER_TO_CODE,;)

#define V_GET_FROM_B(N) const double v##N = valueB[iChunk + N]
#define GET_V_FROM_B MULTI(V_GET_FROM_B,;)

// the next could be improved by separate code or at least, apply to the last only (assuming that colIdxB is rowwise ordered
#define TMP_LEN 8
#define ROWS_GET_FROM_POINTER(N) Ulong rows##N;				\
  if (row##N + f + 1 <= rowsEnd) rows##N = row##N[f];		\
  else {					\
    Uchar *S = (Uchar*) (row##N + f);					\
    Uchar TMP[TMP_LEN] = { /* LittleEndian! */				\
      S + 0 < (Uchar*) rowsEnd ? S[0] : (Uchar) 0,			\
      S + 1 < (Uchar*) rowsEnd ? S[1] : (Uchar) 0,			\
      S + 2 < (Uchar*) rowsEnd ? S[2] : (Uchar) 0,			\
      S + 3 < (Uchar*) rowsEnd ? S[3] : (Uchar) 0,			\
      S + 4 < (Uchar*) rowsEnd ? S[4] : (Uchar) 0,			\
      S + 5 < (Uchar*) rowsEnd ? S[5] : (Uchar) 0,			\
      S + 6 < (Uchar*) rowsEnd ? S[6] : (Uchar) 0,			\
      S + 7 < (Uchar*) rowsEnd ? S[7] : (Uchar) 0			\
    };									\
    rows##N = ((Ulong*) TMP)[0];					\
  }								         

#define GET_ROWS_FROM_POINTER MULTI(ROWS_GET_FROM_POINTER,;)

#define PROD(N) ((rows##N & CodeMask) <= 1 ? 0.0		\
		 : (rows##N & CodeMask) == CODE_ONE ? v##N : (2.0 * v##N))
#define SUM_UP MULTI(PROD,+)

#define ROWS_SHR2(N) rows##N >>= BitsPerCode
#define SHR2_ROWS MULTI(ROWS_SHR2,;)

#define CALCULATE					\
  ROW_POINTER_TO_CODE;					\
  GET_V_FROM_B;						\
  for (int f=0; f<genuineMiniFactor; f++) {		\
    double *tmp0 = tmp + f * CodesPerLong;		\
    GET_ROWS_FROM_POINTER;					\
    for (int iCompr=0; iCompr < CodesPerLong; iCompr++) {	\
      tmp0[iCompr] += SUM_UP;					\
      SHR2_ROWS;						\
    }								\
  }								\
  iChunk+=miniColChunk;					\
  nonzeros-=miniColChunk

sparsevectorGeno_start(Plink)
  // sparse * t(code)
  // NOTE: for better readability only, redefine nrow & ncol by their 
  //       typical meaning in (sparse) %*% t(code), namely rows and individuals
  const Long rows = nrow_code;       
  const int max_switch = 8; // 16 has 5%-10% gain wrt 8 for "many" nonzeros
  
  const int chunkNrow = CodesPerLong * miniRowChunkFactor;
  const Ulong *rowsEnd = (Ulong*) (code + ncol_code * ldaInByte);
  for (Long iRchunk=0; iRchunk < rows; iRchunk += chunkNrow) {
    //    printf("%d ", iRchunk);
    const Long byteIdx_row = iRchunk / CodesPerByte;
    const int lenRchunk = chunkNrow <= rows - iRchunk ? chunkNrow
      : (int) (rows - iRchunk);
    const int genuineMiniFactor = DIV_GEQ(lenRchunk, CodesPerLong);
    const Uchar *c = code + byteIdx_row;
    double *ans = Ans + iRchunk * ldAns;
    assert(sizeof(Ulong) == TMP_LEN);
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) // schedule(static) // schedule(static,staticSize) ordered
#endif 
    for (int j=0; j<nIdx; j++) {
      int nonzeros = rowIdxB[j+1] - rowIdxB[j]; // CSR/CSR/Yale
      if (nonzeros == 0) continue;
      double *a = ans + j;     
      double tmp[chunkNrow] = {0};
      int iChunk=rowIdxB[j];      
      while (nonzeros > 0) {
	switch(nonzeros > max_switch ? max_switch : nonzeros) {
	case 1 : {
#if defined MULTI	  
#undef miniColChunk
#undef MULTI
#endif
#define miniColChunk 1
#define MULTI(X,SZ) X(0)
	  CALCULATE;
	}
	  break;
	case 2 : {
#if defined MULTI	  
#undef miniColChunk
#undef MULTI
#endif
#define miniColChunk 2
#define MULTI(X,SZ) X(0) SZ X(1)
	  CALCULATE;
	}
	  break;
	case 3 : {
#if defined MULTI	  
#undef miniColChunk
#undef MULTI
#endif
#define miniColChunk 3
#define MULTI(X,SZ) X(0) SZ X(1) SZ X(2)
	  CALCULATE;
	}
	  break;
	case 4 : case 7 : {
#if defined MULTI	  
#undef miniColChunk
#undef MULTI	
#endif
#define miniColChunk 4
#define MULTI(X,SZ) X(0) SZ X(1) SZ X(2) SZ X(3)
	  CALCULATE;
	}
	  break;
	case 5 :  { // 5% gain
#if defined MULTI	  
#undef miniColChunk
#undef MULTI	
#endif
#define miniColChunk 5
#define MULTI(X,SZ) X(0) SZ X(1) SZ X(2) SZ X(3) SZ X(4)
	  CALCULATE;
	}
	  break;
	case 6 :  { // 5% gain
#if defined MULTI	  
#undef miniColChunk
#undef MULTI	
#endif
#define miniColChunk 6
#define MULTI(X,SZ) X(0) SZ X(1) SZ X(2) SZ X(3) SZ X(4) SZ X(5)
	  CALCULATE;
	}
	  break;
	case 8 : case 9 : case 10 : case 11 :    {
#if defined MULTI	  
#undef miniColChunk
#undef MULTI	
#endif
#define miniColChunk 8
#define MULTI(X,SZ) X(0) SZ X(1) SZ X(2) SZ X(3) SZ X(4) SZ X(5) SZ X(6) SZ X(7)
	  CALCULATE;
	}
	  break;
	case 12 : case 13 : case 14 : case 15 :  {
#if defined MULTI	  
#undef miniColChunk
#undef MULTI	
#endif
#define miniColChunk 12
#define MULTI(X,SZ) X(0) SZ X(1) SZ X(2) SZ X(3) SZ X(4) SZ X(5) SZ X(6) SZ X(7) SZ X(8) SZ X(9) SZ X(10) SZ X(11)
	  CALCULATE;
	}
	  break;
	
	case 16 : {
#if defined MULTI	  
#undef miniColChunk
#undef MULTI	
#endif
#define miniColChunk 16
#define MULTI(X,SZ) X(0) SZ X(1) SZ X(2) SZ X(3) SZ X(4) SZ X(5) SZ X(6) SZ X(7) SZ X(8) SZ X(9) SZ X(10) SZ X(11) SZ X(12) SZ X(13) SZ X(14) SZ X(15)
	  CALCULATE;
	}
	break;
	default : BUG;
	} // switch	
      } // while
      for (int k=0; k < lenRchunk; k++) a[k * ldAns] = tmp[k];
    }// j
  }// iRchunk
}

