/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/



#ifndef miraculix_matrix_H
#define miraculix_matrix_H 1

// #include "MX.h"

SEXP IsolveRelMat(Long individuals, double *Atau, double *tau, int ntau,
		  double *Vec, double* beta, int nbeta,
		  int returns, bool destroy,
		  int cores);
  
void matrixvector012I(double * m, int r, int c,  SEXP vector, double *a);
void vector012matrixI(SEXP vector, double * m, int r, int c,  double *a);

void VectorCrossMatrix(SEXP SxI, SEXP SxI2, double *V, Long repetV, 
		     int cmp, 
		     option_type *global, utilsoption_type *utils,
		     double *ans);
void VectorCrossMatrix(SEXP SxI, double *V, Long repetV, 
		      option_type *global, utilsoption_type *utils,
		       double *ans);

// SxIvector garantiert dass Skalarprodukte ueber die Individuen genommen
// werden, waehrend genoVector irgendeine Matrix rechts mit einem Vector
// multipliziert wird
void SxIvector_raw_LongDouble(vector_raw_args(LongDouble));
void vectorSxI_raw_LongDouble(vector_raw_args(LongDouble));
void SxIvector_means_double(vector_raw_args(double));
void vectorSxI_means_double(vector_raw_args(double));
void SxIvector_means_LongDouble(vector_raw_args(LongDouble));
void vectorSxI_means_LongDouble(vector_raw_args(LongDouble));

void SxIvector_means_double(vector_raw_shortargs(double));
void vectorSxI_means_double(vector_raw_shortargs(double));
void SxIvector_means_LongDouble(vector_raw_shortargs(LongDouble));
void vectorSxI_means_LongDouble(vector_raw_shortargs(LongDouble));

gV_vG_header(Ulong,);
gV_vG_header(LongDouble,);
gV_vG_header(double,); 



vector_fctn_header_gV(double);
vector_fctn_header_gV(LongDouble);
vector_fctn_header_gV(Ulong);
  
#endif

