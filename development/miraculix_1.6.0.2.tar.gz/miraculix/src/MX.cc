/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#include "Basic_miraculix.h"
#include "options.h"
#include "MXinfo.h"
#include "intrinsicsCheck.h"
#include "intrinsics_specific.h"



coding_type OneSet2G(coding_type coding) {
  switch(coding) {
  case OneBitHaplo : coding = UnknownSNPcoding;
    // das sauberste waere ein eigener coding type OneBitHaploOneSet
    break;
  case TwoBitHaplo :  coding = TwoBitGeno; break;
  case OneByteHaplo : coding = OneByteGeno; break;
  case FourByteHaplo :coding = FourByteGeno; break;
  case FourByteSingleBit : coding = FourByteGeno; break;
  case EightByteHaplo:coding = FourByteGeno; break;
  default : coding = UnknownSNPcoding; // none
  }
  return coding;
} 

coding_type swapHaploGeno(coding_type coding, bool ToH, bool ToG,
			  usr_bool stopOnError) {
  switch(coding) {
  case OneBitGeno: if (ToH) coding = OneBitHaplo;
    break;
  case TwoBitGeno:   if (ToH) coding = TwoBitHaplo;
    break;
  case OneByteGeno:  if (ToH) coding = OneByteHaplo;
    break;
  case FourByteGeno: if (ToH) coding = FourByteHaplo;
    break;
  case OneBitHaplo:  if (ToG) coding = OneBitGeno;
    break;
  case TwoBitHaplo:  if (ToG) coding = TwoBitGeno;
    break;
  case OneByteHaplo: if (ToG) coding = OneByteGeno;
    break;
  case FourByteHaplo:if (ToG) coding = FourByteGeno;
    break;
  default :
    if (stopOnError == True || 
	(stopOnError == Nan && ( coding == AutoCoding ||
				 coding == UnknownSNPcoding ||
				 (ToH && !isHaplo(coding)) ||
				 (ToG && isHaplo(coding)) )))
      ERR2("no counterpart within %.20s-coding found for '%.20s'.",
	   ToH ? "haplo" : "geno", CODING_NAMES[coding]);
  }
  return coding;
}

coding_type swapHaploGeno(coding_type coding, bool ToH) {
  return swapHaploGeno(coding, ToH, !ToH, Nan);
}


Uint Inti(SEXP X, Uint i) {
  switch(TYPEOF(X)) {
  case INTSXP : return (Uint) INTEGER(X)[i];
  case LGLSXP : return (Uint) LOGICAL(X)[i];
  case REALSXP : return (Uint) REALX(X)[i];
  default : ERR0("not of numerical type");
  }
}


Long *GetInfoUnchecked(SEXP SxI) { // has negative integers included!!
  SEXP Info = getAttribPointer(SxI, Information);
  if (Info == R_NilValue) return NULL;
  //printf("length Infos=%d %d\n", LENGTH(Infos), TYPEOF(Infos));
#if defined compatibility_to_R_h
  if (TYPEOF(Info) != INTSXP)
#elif defined compatibility_to_C_h
    if (TYPEOF(Info) != LONGSXP)      
#endif
      ERR1("Obsolete storage mode %d", TYPEOF(Info));
  return LONG(Info);
}


Long *GetInfo(SEXP SxI, int nullOK) { // has negative integers included!!
  assert(SxI != R_NilValue);
  PROTECT(SxI);
  Long *info = GetInfoUnchecked(SxI);
  if (info == NULL || info[CODING] == NA_LONG) {//SxI=filename if NA_LONG
    if (nullOK) {
      UNPROTECT(1);
      return info == NULL || nullOK == 1 ? NULL : info;
    }
    BUG;
  }
  basic_options opt;
  Ext_get_utils_basic(&opt, false);
  coding_type coding = (coding_type) info[CODING];
  // int variant =
    check_variant(coding, (int) info[VARIANT], opt.efficient);
  if (info[IMPLEMENTATION] !=CURRENT_IMPLEMENTATION)
    ERR2("the stored data format (%ld) does not match the current format (%d).",
	 ALONG info[IMPLEMENTATION], CURRENT_IMPLEMENTATION ); // long OK
  UNPROTECT(1);
  return (Long*) info;
}

Long *GetInfo(SEXP SxI) {
   return GetInfo(SxI, false);
}

void printINFO(SEXP S) { // *rint
  // PRINTF("info:\n");
  const char *eq[]={"!=NULL", "=0"};
  if (S == R_NilValue) {
    PRINTF("This a R_NIlValue.\n");
    return;
  }
  SEXP Info = getAttribPointer(S, Information);
  PRINTF("SEXP: x%s len=%ld, dim=(%d,%d) type=%d dim=%d, Info%s File(%s,%s) prec=%s Class%s Next%s\n",eq[VOIDSXP(S)  == R_NilValue],
	 ALONG (LENGTH(S)), // long OK
	 (int) NROWS(S), (int) NCOLS(S),
	 TYPEOF(S),
	 getDimension(S),
	 eq[Info == R_NilValue],
	 eq[getAttribPointer(S, Filecoding)==R_NilValue],
	 eq[getAttribPointer(S, Filename)==R_NilValue],
	 eq[getAttribPointer(S, Precise)==R_NilValue],
	 eq[GET_CLASS(S) == R_NilValue],
	 eq[getAttribPointer(S, Next)==R_NilValue]);
  if (Info != R_NilValue) {
    //    PRINTF("info::\n");
    Long *info = LONG(Info);
    for (int K=0;
	 //	 K<=INFO_GENUINELY_LAST
	 K<=INFO_LAST
	   ; K++) {
      //   PRINTF("K=%d\n", K);
      if (K >= 10 && K <= INFO_GENUINELY_LAST && K!=MEMinUNITS) continue;
      if (K > INFO_GENUINELY_LAST) continue;
      if (STRCMP("unused", INFO_NAMES[K])) {
	PRINTF("%2d: %s=\t", K, INFO_NAMES[K]);
        if (STRLEN(INFO_NAMES[K]) <= 10) PRINTF("\t");
	if (K==MEMinUNITS) PRINTF("%ld", ALONG info[MEMinUNITS]); else
	  if (info[K]==NA_LONG) PRINTF("NA"); else
	    if (info[K]==0) PRINTF("FALSE"); else // OK
	      if (info[K]==1) PRINTF("TRUE"); else PRINTF("%ld", ALONG info[K]); // OK
	switch(K) {
	case CODING: PRINTF("\t[%s: %s]\n", CODING_NAMES[info[K]],
		       ((usr_bool) info[TRANSPOSED]) == False
		       ? "SxI" : "IxS(!)");
	  break;
	default: PRINTF("\n");
	}
      }
    }
    PRINTF("\n");
  } else PRINTF("Info = R_NilValue!\n");
  if (getAttribPointer(S, Next) != R_NilValue) {
    PRINTF("NEXT:\n");
    printINFO(getAttribPointer(S, Next)); // *rint
  }
}



// LDAbitalign == 0 requests the primitive alignment for Align
 // LDAbitalign > 0 calculates the space needed for a single individual
 //     in snp x individual storage
Long fctnLDAalignBitSnps(Long bits, Long LDAbitalign, Long my_LDABITALIGN,
		    coding_type my_CODING) {
  //  printf("ldabit: %ld %ld; bits=%ld\n", LDAbitalign, my_LDABITALIGN, bits);
  if (LDAbitalign != 0 && LDAbitalign < my_LDABITALIGN)		       
    ERR3("bit alignment for '%s' (%ld) too small (not >= %ld)",	      
	 CODING_NAMES[my_CODING], ALONG LDAbitalign, ALONG my_LDABITALIGN);
  Long newLDAbitalign = LDAbitalign ? LDAbitalign : my_LDABITALIGN;    
  assert(newLDAbitalign >= BitsPerUnit && newLDAbitalign % BitsPerUnit ==0);// OK
  return(ROUND_GEQ(bits, newLDAbitalign) / BitsPerUnit); // OK
}


