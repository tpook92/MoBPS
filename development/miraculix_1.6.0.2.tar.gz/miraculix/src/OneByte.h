/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/




#ifndef miraculix_OneByte_H
#define miraculix_OneByte_H 1


Long LdaOneByte(Long rows, Long ldAbitalign);
colSums_header(OneByte);

void OneByte2T(unit_t *tmp, Long rows, Long cols, Long lda,
	       unit_t *Ans, Long ldAns);
void OneByteHaplo2geno64(unit_t *H, Long rows, Long cols, Long lda,
		      int cores, unit_t *Ans, Long ldAns);

coding_header(_4Byte, OneByte);
coding_header(_1Byte, OneByte);

get_matrix_header(_4Byte,OneByte);
get_matrix_header(_1Byte,OneByte);

vector_fctn_header( LongDouble, LongDouble, OneByte);
vector_fctn_header( double, double, OneByte);
vector_fctn_header( Ulong, Ulong, OneByte);



void rowSums_OneByte(colrowSums_args());


sparsevectorGeno_header(OneByte);

int BitsPerCodeOneByte();

#endif
