/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#ifndef WIN_LINUX_AUX_H
#define WIN_LINUX_AUX_H 1



#define maxIdDomains 10

void cpuid_info(int *ground_freq, int *max_freq, bool *hyperthreader);
uint32_t cpuid_info_freq(unsigned int Blatt, unsigned int Register);

#ifdef __cplusplus
extern "C" {
#endif
  void sleepMilli(int *milli);
  void sleepMicro(int *milli);
  void pid(int *i);
  void hostname(char **h, int *i);
  bool
  parallel(void);
#ifdef __cplusplus
}
#endif


#endif /* WIN_LINUX_AUX_H */


