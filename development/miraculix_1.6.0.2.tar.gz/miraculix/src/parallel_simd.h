/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#ifndef parallel_omp__H
#define parallel_omp__H 1

// #define NEVER_OMP 1
#define DO_AVX512F 1
// #define NEVER_AVX 1
// #define NEVER_SSE 1

#include "parallel_base.h"


#endif
