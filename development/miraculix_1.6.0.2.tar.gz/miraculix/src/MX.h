/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/


#ifndef miraculix_MX_H
#define miraculix_MX_H 1

#include "MXinfo.h"

#if ! defined MY_VARIANT || ! defined MY_LDABITALIGN
#error MY_VARIANT / MY_LDABITALIGN undefined. Use MXinfo.h instead
#endif


Long fctnLDAalignBitSnps(Long bits, Long LDAbitalign, Long my_LDABITALIGN,
		     coding_type my_CODING);

#define LDAalignBitSnps(bits)						\
  fctnLDAalignBitSnps(bits, LDAbitalign, MY_LDABITALIGN, MY_CODING)


#define LDAalignBlocks(blocks) LDAalignBitSnps((blocks) * BitsPerBlock)


Long static inline Blocks(Long rows) {
  assert(MY_VARIANT <= MY_LDABITALIGN);
  return DIV_GEQ(rows, CodesPerBlock);
}

Long static inline Units(Long rows) { // OK
  return DIV_GEQ(rows, CodesPerUnit); // OK
}



#endif
