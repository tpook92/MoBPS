/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 COPYRIGHT_YEAR Martin Schlather

 COPYRIGHT_TEXT
*/

#include "Basic_miraculix.h"

#if defined compatibility_to_R_h
#include "miraculix.h"
#include "xport_import.h"
#include "MXinfo.h"
// #include "zzz_RFU.h"
#include "scan.h"


SEXP scan(SEXP positions, SEXP length, SEXP freq, 
	  SEXP minscan,  SEXP maxscan, SEXP threshold, SEXP nthres,
	  SEXP PER_SNP,
	  SEXP above_threshold, SEXP Maximum) {
  scanC(INTEGER(positions), INTEGER(length), REAL(freq), 
	INTEGER(minscan),  INTEGER(maxscan), REAL(threshold),
	INTEGER(nthres),
	INTEGER(PER_SNP),
	INTEGER(above_threshold), REAL(Maximum));
  return R_NilValue;
}


  
SEXP collect_scan(SEXP positions, SEXP length, SEXP freq, 
		  SEXP minscan,  SEXP maxscan, SEXP threshold, SEXP nthres,
		  SEXP PER_SNP, SEXP areas,  SEXP value
		  ) {
   return collect_scan(INTEGER(positions), INTEGER(length), REAL(freq), 
	   INTEGER(minscan), INTEGER(maxscan), REAL(threshold), INTEGER(nthres),
	   INTEGER(PER_SNP), INTEGER(areas), REAL(value));
 }



SEXP collect_scan2(SEXP positions, SEXP length, SEXP freq, 
		   SEXP minscan,  SEXP maxscan, SEXP threshold, SEXP nthres,
		   SEXP PER_SNP, SEXP max_intervals, SEXP max_basepair_dist, 
		   SEXP exclude_negative, 
		   SEXP above_threshold, SEXP maximum
		  ) {
   return collect_scan2(INTEGER(positions), INTEGER(length), REAL(freq), 
			INTEGER(minscan), INTEGER(maxscan), REAL(threshold), 
			INTEGER(nthres),
			INTEGER(PER_SNP), INTEGER(max_intervals)[0],
			INTEGER(max_basepair_dist)[0],
			(bool) INTEGER(exclude_negative)[0],
			INTEGER(above_threshold),
			REAL(maximum));
 }


SEXP sumscan(SEXP positions, SEXP length, SEXP freq, 
	     SEXP minscan,  SEXP maxscan, SEXP threshold, SEXP nthres,
	     SEXP PER_SNP,
	     SEXP above_threshold, SEXP Maximum) {
  sumscanC(INTEGER(positions), INTEGER(length), REAL(freq), 
	  INTEGER(minscan), INTEGER(maxscan), REAL(threshold), INTEGER(nthres),
	  INTEGER(PER_SNP),
	  INTEGER(above_threshold), REAL(Maximum));
  return R_NilValue;
}

#endif
