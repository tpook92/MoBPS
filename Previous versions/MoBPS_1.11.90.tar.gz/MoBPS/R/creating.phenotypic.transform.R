'#
  Authors
Torsten Pook, torsten.pook@uni-goettingen.de

Copyright (C) 2017 -- 2020  Torsten Pook

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
'#

#' Create a phenotypic transformation
#'
#' Function to perform create a transformation of phenotypes
#' @param population Population list
#' @param phenotypic.transform.function Phenotypic transformation to apply
#' @param trait Trait for which a transformation is to be applied
#' @param verbose Set to FALSE to not display any prints
#' data(ex_pop)
#' trafo <- function(x){ return(x^2)}
#' ex_pop <- creating.phenotypic.transform(ex_pop, phenotypic.transform.function=trafo)
#' @return Population-list with a new phenotypic transformation function
#' @export

creating.phenotypic.transform <- function(population, phenotypic.transform.function=NULL, trait=1,
                                          verbose = TRUE,
                                          h2 = seq(0.05,0.5, by = 0.05),
                                          n.sample = 1000){

  if(length(phenotypic.transform.function)>0){
    population$info$phenotypic.transform[trait] <- TRUE
    population$info$phenotypic.transform.function[[trait]] <- phenotypic.transform.function
  }

  if(verbose){

    h2_obs = rep(0, length(h2))
    for(index in 1:length(h2)){
      n = 0

      pheno = NULL
      bv = NULL

      n_pheno = rep(0, population$info$bv.nr)
      n_pheno[trait] = 1
      database = get.database(population, gen = get.ngen(population))

      database[  database[,4] > 1000,4] = n.sample
      while(n < n.sample){
        pop1 = breeding.diploid(population, n.observation = n_pheno,
                                heritability = h2[index],
                                phenotyping.database = database,
                                verbose = FALSE)

        pheno = c(pheno, get.pheno(pop1, database = database)[trait,])
        bv = c(bv, get.bv(pop1, database = database)[trait,])
        n = length(bv)
      }
      h2_obs[index] = cor(pheno, bv)^2
    }

    cat("Heritabilities provided downstream will be for underlying quantitative trait (not discrete phenotypes)\n")
    cat("Expected heritabilities:\n")
    tmp = cbind(h2, h2_obs)
    colnames(tmp) = c("Underlying Quantitative Trait", "Observed Phenotype")
    print(tmp)

  }
  return(population)

}
