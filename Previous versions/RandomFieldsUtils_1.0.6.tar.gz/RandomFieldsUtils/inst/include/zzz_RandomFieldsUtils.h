


/*
 Authors 
 Martin Schlather, schlather@math.uni-mannheim.de


 Copyright (C) 2015 -- 2021 Martin Schlather

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  
*/

#ifndef rfutils_init_H
#define rfutils_init_H 1


 /* 
!!!!! HIER NIE EIN SEXP OBJEKT ZURUECKGEBEN  !!!!  
  */

#include "General_utils.h"
#include "Utils.h"
#include "options.h"


#ifdef HAVE_VISIBILITY_ATTRIBUTE
  # define attribute_hidden __attribute__ ((visibility ("hidden")))
#else
  # define attribute_hidden
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define MY_PACKAGE "RandomFieldsUtils"
#define MY_ACRONYM XX
#include "zzz_calls.h"

  /* 
!!!!! HIER NIE EIN SEXP OBJEKT ZURUECKGEBEN  !!!!  
!!!!! auch kein mit MALLOC kreiertes Objekt  !!!!
  */

  
  DECLARE1(void, utilsoption_DELETE, utilsoption_type *, S)
  DECLARE1(void, utilsoption_NULL, utilsoption_type *, S)
  DECLARE1(void, solve_DELETE, solve_storage**, S)
  DECLARE1(void, solve_NULL, solve_storage*, x)
  DECLARE7(int, solvePosDef, double*, M, int, size, bool, posdef, 
	   double *, rhs, int, rhs_cols, double *, logdet, solve_storage *, PT)
  DECLARE8(int, solvePosDefSp, double *, M, int, size, bool, posdef,
	   double *, rhs, int, rhs_cols, double *,logdet,
	   solve_storage *, Pt, solve_options *,sp)
  //  DECLARE8(int, solvePosDefResult, double*, M, int, size, bool, posdef, 
  //	   double *, rhs, int, rhs_cols, double *, result, double*, logdet, 
  //	   solve_storage*, PT)
  DECLARE4(int, sqrtPosDefFree, double *, M, int, size, solve_storage *, pt,
	   solve_options *, sp)
  DECLARE3(int, sqrtRHS, solve_storage *, pt, double*, RHS, double *, res)
  DECLARE2(int, invertMatrix, double *, M, int, size)
  DECLARE2(double, StruveH, double, x, double, nu)
  DECLARE3(double, StruveL, double, x, double, nu, bool, expScale1d)
  DECLARE1(double, I0mL0, double, x)
  DECLARE3(double, WM, double, x, double, nu, double, factor)
  DECLARE3(double, DWM, double, x, double, nu, double, factor)
  DECLARE3(double, DDWM, double, x, double, nu, double, factor)
  DECLARE3(double, D3WM, double, x, double, nu, double, factor)
  DECLARE3(double, D4WM, double, x, double, nu, double, factor)
  DECLARE4(double, logWM, double, x, double, nu1, double, nu2, double, factor)
  DECLARE1(double, Gauss, double, x)
  DECLARE1(double, DGauss, double, x)
  DECLARE1(double, DDGauss, double, x)
  DECLARE1(double, D3Gauss, double, x)
  DECLARE1(double, D4Gauss, double, x)
  DECLARE1(double, logGauss, double, x)
  DECLARE0(int, cores1)
  DECLARE0(int, cpus)
  
  DECLARE1(void, getUtilsParam, utilsoption_type **, up)
  DECLARE13(void, attachRFoptions, char *, name,
	    const char **, prefixlist, int, N, 
	   const char ***, all, int *, allN, setoptions_fctn, set, 
	    finalsetoptions_fctn, final, getoptions_fctn, get,
	    deleteoptions_fctn, del, int, PLoffset, bool, basicopt,
	    install_modes, gpu_needs, Uint, avx_info)
  DECLARE2(void, detachRFoptions, const char **, prefixlist, int, N)

  DECLARE3(void, sorting, double*, data, int, len, usr_bool, NAlast)
  DECLARE3(void, sortingInt, int*, data, int, len, usr_bool, NAlast)
  DECLARE4(void, ordering, double*, data, int, len, int, dim, int *, pos)
  DECLARE4(void, orderingInt, int*, data, int, len, int, dim, int *, pos)
  DECLARE4(double, scalarX, double *, x, double *, y, int, len, int, n)
  //  DECLARE4(int, scalarInt, int *, x, int *, y, int, len, int, n)
  DECLARE2(double, detPosDef, double *, M, int, size) // destroys M!
  DECLARE3(double, detPosDefsp, double *, M, int, size, solve_options *, sp)
  DECLARE8(int, XCinvXdet,double*, M, int, size, double *,X, int, X_cols,
	  double *, XCinvX, double *, det, bool, log, solve_storage, *PT)
  DECLARE10(int, XCinvYdet,double*, M, int, size, bool, posdef,
	    double *, X, double *, Y, int, cols,
	    double *, XCinvY, double *, det, bool, log, solve_storage, *PT)
  //  DECLARE5(double, XCinvXlogdet, double *, M, int, size, double *, X,
  //	   int, X_cols, solve_storage *, PT)
  DECLARE2(bool, is_positive_definite, double *, C, int, dim)
  DECLARE2(void, chol2inv, double *, MPT, int, size)
  DECLARE2(int, chol, double *, MPT, int, size)
  DECLARE1(void, pid, int *, i)
  DECLARE1(void, sleepMicro, int *, i)
  // DECLARE7(int, cholGPU, bool, copy, double*, M, int, size, double*, rhs, int, rhs_cols, double *, LogDet, double *, RESULT); // entkommentieren
  

 /* 
!!!!! HIER NIE EIN SEXP OBJEKT ZURUECKGEBEN  !!!!  
  */
 
  /*

    See in R package RandomFields, /src/userinterfaces.cc 
          CALL#(...)
    at the beginning for how to make the functions available
    in a calling package

  */
#ifdef __cplusplus
}
#endif


/*

install.packages("RandomFieldsUtils_0.5.21.tar.gz", configure.args="CXX_FLAGS=-march=native", repo=NULL); library(RandomFieldsUtils, verbose=100); q()

*/

#ifdef DO_PARALLEL
#define HAS_PARALLEL true
#else
#define HAS_PARALLEL false
#endif
#if defined USEGPU
#define HAS_GPU true
#else
#define HAS_GPU false
#endif
#define USES_GPU (HAS_GPU && NEED_GPU)
#define MISS_GPU (!HAS_GPU && NEED_GPU)

#if defined NEED_SSE | defined SSE | defined NEED_SSE2 | defined HAS_SSE2 | defined USES_SSE2
  SSE_IS_ALWAYS_ASSUMED;
#endif


#define AttachMessageN 2000


#define noMISS 0
#define noUSE 0
#define anyrelevantUSE 0
#define gpuUSE 1
#define avx2USE 2
#define avxUSE 3 
#define ssse3USE 4
#define sse2USE 5
#define avx512fUSE 6
#define USEnMISS 10
#define gpuMISS 11
#define avx2MISS 12
#define avxMISS 13 
#define ssse3MISS 14
#define sse2MISS 15
#define avx512fMISS 16
#define anyMISS (1 << gpuMISS) | (1 << avx2MISS) | (1 << avxMISS) | \
  (1 << ssse3MISS) | (1 << sse2MISS) | (1 << avx512fMISS)
#define AVX_INFO					\
  allmiss | alluse | (HAS_PARALLEL || alluse != 0) * (1 << anyrelevantUSE) | \
  ((HAS_PARALLEL || alluse != noUSE) && !(HAS_PARALLEL && allmiss==noMISS)) * \
  (1 << USEnMISS)

#if defined WIN32
  #define GPU_NEEDS Inone
#else
  #define GPU_NEEDS (MISS_GPU ? Igpu : Inone)
#endif


#define EAX 0
#define EBX 1
#define ECX 2
#define EDX 3
#define sse Available(1, EDX,25)
#define sse2 Available(1, EDX,26)
#define sse3 Available(1, ECX,0)
#define ssse3 Available(1, ECX,9)
#define sse41 Available(1, ECX,19)
#define avx Available(1, ECX,28)
#define avx2 Available(7, EBX,5)
#define avx512f Available(7, EBX,16)
#define avx512df Available(7, EBX,26)
#define avx512ar Available(7, EBX,27)
#define avx512cd Available(7, EBX,28)

#ifdef _WIN32
#define AVAILABLE							\
  static inline bool Available(unsigned Blatt, int Register, int Bit) {	\
    uint32_t s[4];							\
    __cpuid((int *)s, (int) Blatt);					\
    return s[Register] & (1 << (Bit));					\
  }
#else 
#define AVAILABLE							\
static inline bool Available(unsigned Blatt, int Register, int Bit) {	\
  uint32_t s[4];							\
  asm volatile								\
    ("cpuid": "=a"(s[0]), "=b"(s[1]),"=c"(s[2]),"=d"(s[3]):"a"(Blatt),"c"(0)); \
  return s[Register] & (1 << (Bit));					\
}
#endif

#define WARN_PARALLELXX							\
  if (OPTIONS_UTILS->basic.warn_parallel && mypid == parentpid) 	\
    PRINTF("Do not forget to run 'RFoptions(storing=FALSE)' after each call of a parallel command (e.g. from packages 'parallel') that calls a function in 'RandomFields'. (OMP within RandomFields is not affected.) This message can be suppressed by 'RFoptions(warn_parallel=FALSE)'.") /*// ok */ \
    
#define WARN_PARALLEL 



#if defined USE_SPECIFIC_AVX
#define ASSERT_AVAILABILITY(V,W)  if (!(V)) {char msg[300]; SPRINTF(msg, "The program was compiled for '%.10s%.5s%.10s', but the CPU doesn't know about it. As 'server' has been chosen as compilation option, no SIMD/AVX flag should be given when compiling.", #V, STRCMP(#V, #W) ? " && " : "", STRCMP(#V, #W) ? #W : ""); RFERROR(msg); }
#else
#define ASSERT_AVAILABILITY(V,W)  if (!(V)) {char msg[300]; SPRINTF(msg, "The program was compiled for '%.10s%.5s%.10s', but the CPU doesn't know about it. Consider 'RFoptions(install.control=list(server=TRUE,force=TRUE))'", #V, STRCMP(#V, #W) ? " && " : "", STRCMP(#V, #W) ? #W : ""); RFERROR(msg); } // OK
#endif

#if defined AVX512F
#define ASSERT_SIMD_CONSISTENCY(V) ASSERT_AVAILABILITY(avx512f, V)
#elif defined AVX2
#define ASSERT_SIMD_CONSISTENCY(V) ASSERT_AVAILABILITY(avx2, V);
#elif defined AVX
#define ASSERT_SIMD_CONSISTENCY(V) ASSERT_AVAILABILITY(avx, V);
#elif defined SSSE3
#define ASSERT_SIMD_CONSISTENCY(V) ASSERT_AVAILABILITY(ssse3, V);
#elif defined SSE3
#define ASSERT_SIMD_CONSISTENCY(V) ASSERT_AVAILABILITY(sse3, V);
#elif defined SSE2
#define ASSERT_SIMD_CONSISTENCY(V) ASSERT_AVAILABILITY(sse2, V);
#else
#define ASSERT_SIMD_CONSISTENCY(V) ASSERT_AVAILABILITY(V, V)
#endif
  
#if defined AVX512F
#define ASSERT_SIMD_CONSISTENCY0 ASSERT_AVAILABILITY(avx512f, avx512f)
#elif defined AVX2
#define ASSERT_SIMD_CONSISTENCY0 ASSERT_AVAILABILITY(avx2, avx2)
#elif defined AVX
#define ASSERT_SIMD_CONSISTENCY0 ASSERT_AVAILABILITY(avx, avx)
#elif defined SSSE3
#define ASSERT_SIMD_CONSISTENCY0 ASSERT_AVAILABILITY(ssse3, ssse3)
#elif defined SSE3
#define ASSERT_SIMD_CONSISTENCY0 ASSERT_AVAILABILITY(sse3, sse3)
#elif defined SSE2
#define ASSERT_SIMD_CONSISTENCY0 ASSERT_AVAILABILITY(sse2, sse2)
#else
#define ASSERT_SIMD_CONSISTENCY0 
#endif

#define C_ASSERT_ANYSIMD(FILE)				\
    Uint alluse = noUSE,				\
      miss = noMISS,			\
      allmiss = noMISS;			\
    check_simd_##FILE()

#define C_ASSERT_SIMD(FILE, WHAT)		\
    allmiss |= (miss = check_simd_##FILE());\
    if (!miss) alluse |= 1 << WHAT##USE;
    
    
#define D_ASSERT_ANYSIMD(FILE) extern Uint check_simd_##FILE()
#define D_ASSERT_SIMD(FILE, WHAT) D_ASSERT_ANYSIMD(FILE)

#define ASSERT_ANYSIMD(FILE) Uint check_simd_##FILE() {ASSERT_SIMD_CONSISTENCY0; return noMISS;}
#define ASSERT_SIMD(FILE, WHAT) Uint check_simd_##FILE() { ASSERT_SIMD_CONSISTENCY(WHAT); return noMISS;}

#define ASSERT_SIMD_MISS(FILE, WHAT) Uint check_simd_##FILE() { return 1<<WHAT##MISS; }

#endif
