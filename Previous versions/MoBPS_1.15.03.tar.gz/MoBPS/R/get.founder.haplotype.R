## Function to compute from which Founder segment each SNP stems from

get.founder.haplotype <- function(population, gen= NULL, database = NULL, cohorts = NULL, id = NULL,
                     plot = FALSE, import.position.calculation=NULL, decodeOriginsU=decodeOriginsR,
                     use.id = TRUE, array = NULL){

  if(length(array)>0){
    temp1 <- which(population$info$array.name == array)
    if(length(temp1)==1){
      array <- temp1
    }
    if(!is.numeric(array)){
      stop("Input for array can not be assigned! Check your input!")
    }
  }

  database <- get.database(population, gen = gen, database = database,
                           cohorts = cohorts, id = id)

  nindi = sum(database[,4]-database[,3]+1)

  snp_temp = population$info$snp
  n.snps <- sum(snp_temp)
  equi = sum(population$info$snps.equidistant==TRUE)>0
  origin = population$info$origin.gen
  if(equi){
    lec = population$info$length.total
    n_chr = length(lec) -1
    between2_vec = length_chromo_vec = position_chromo_vec = numeric(n_chr)

    for(chr in 1:n_chr){
      between2_vec[chr] <- population$info$position[[chr]][1]
      length_chromo_vec[chr] <- sum(population$info$length[0:(chr-1)])
      position_chromo_vec[chr] <- sum(snp_temp[0:(chr-1)])
    }

  }
  last = population$info$snp.position[n.snps]
  segments = matrix(nrow=n.snps, ncol=nindi*2)



  cindex = 0
  for(index5 in 1:nrow(database)){
    gen = database[index5,1]
    sex = database[index5,2]
    for(nr in database[index5,3]:database[index5,4]){


        for(hapnr in 1:2){
          current.recombi <- population$breeding[[gen]][[sex]][[nr]][[hapnr]]
          current.ursprung <- population$breeding[[gen]][[sex]][[nr]][[hapnr+4]]

          keep = c(TRUE, diff(current.ursprung)!=0)
          current.ursprung = current.ursprung[keep]
          current.recombi = current.recombi[c( keep, TRUE)]

          pool = current.ursprung


          if(is.function(import.position.calculation)){
            till <- import.position.calculation(current.recombi)
          } else if(equi){
            till <- rep(0, length(current.recombi))
            for(index in 1:length(current.recombi)){
              current.chromo <- sum(current.recombi[index] >= lec)
              if(current.recombi[index]>last){
                till[index] <- n.snps
              } else{
                between2 <- between2_vec[current.chromo]
                length_chromo <- length_chromo_vec[current.chromo]
                position_chromo <- position_chromo_vec[current.chromo]
                till[index] <- ceiling((current.recombi[index] - length_chromo - between2) / (between2*2)) + position_chromo

              }
            }
          } else{
            till <- rep(0, length(current.recombi))
            for(index in 1:length(current.recombi)){
              till[index] <- find.snpbefore(current.recombi[index], population$info$snp.position)
              #        till[index] <- sum(population$info$snp.position <= current.recombi[index])
            }

          }

          ursprung_type = unique(current.ursprung) # due to clean up this needs to be recalculated

          for(index2 in 1:(length(ursprung_type))){
            ursprung <- ursprung_type[index2]
            relevant.snp.list = list()
            to_check = which(current.ursprung==ursprung_type[index2])
            for(index3 in 1:length(to_check)){
              tmp1 = to_check[index3]
              if((till[tmp1+1] >=(till[tmp1]+1))){
                relevant.snp.list[[index3]] <- (till[tmp1]+1):till[tmp1+1]
              }
            }
            relevant.snp = unlist(relevant.snp.list)

            segments[relevant.snp, hapnr + cindex] <- ursprung

          }

        }
      cindex = cindex + 2

      }

  }

  before = 0
  names <- numeric(nindi)
  for(row in 1:nrow(database)){
    animals <- database[row,]
    nanimals <- database[row,4] - database[row,3] +1
    if(nanimals>0){
      names[(before+1):(before+nanimals)] <- paste(if(animals[2]==1) "M" else "F", animals[3]:animals[4],"_", animals[1], sep="")
      before <- before + nanimals
    }
  }

  if(use.id){
    tmp1 <- get.id(population, database = database)
  } else{
    tmp1 <- names
  }

  tmp1 = paste0(rep(tmp1, each = 2), c("_1", "_2"))

  colnames(segments) = tmp1

  if(length(array)>0){
    segments = segments[population$info$array.markers[[array]],]

  }

  return(segments)
}

## Function to kinship matrix based on SNPs

get.kinship.snp <-  function(population=NULL, gen=NULL, database=NULL, cohorts=NULL, use.id=TRUE,
                             mode = 1, array = NULL){


  database <- get.database(population, gen, database, cohorts)

  founder_haplo = get.founder.haplotype(population, database = database, array = array)
  ids = names(get.id(population, database = database, use.id = use.id))

  n = ncol(founder_haplo) / 2




  tmp1 = founder_haplo[,(1:n)*2-1]
  tmp2 = founder_haplo[,(1:n)*2]


  if(mode == 1){

    kinship <- matrix(0, nrow=n, ncol=n)


    for(index in 1:n){

      haplo1_1 <- tmp1[, index]
      haplo2_1 <- tmp2[, index]

      # Haplo1 x Haplo1
      kinship[,index] = kinship[,index] + colSums(tmp1 == haplo1_1)
      # Haplo1 x Haplo2
      kinship[,index] = kinship[,index] + colSums(tmp1 == haplo2_1)

      # Haplo2 x Haplo1
      kinship[,index] = kinship[,index] + colSums(tmp2 == haplo1_1)
      # Haplo2 x Haplo2
      kinship[,index] = kinship[,index] + colSums(tmp2== haplo2_1)

    }
  }

  if(mode == 2){

    kinship = kinship_cpp(tmp1, tmp2)

  }

  kinship = kinship/4/nrow(tmp1)

  colnames(kinship) = rownames(kinship) = ids

  return(kinship)
}

if(FALSE){

  library(Rcpp)
  sourceCpp("kinship.cpp")


  # just some testing if its faster
  population = creating.diploid(nsnp = 10000, nindi = 100, chr.nr = 5, nqtl = 100, n.additive = 100)
  for(index in 1:10){
    population = breeding.diploid(population, breeding.size = c(1000,0))
  }
  population = clean.up(population, gen = 11)
  system.time({A1 = get.kinship.emp(population, database = cbind(11,1,1,200))})
  system.time({A2 = get.kinship.snp(population, database = cbind(11,1,1,200), mode = 1)})
  system.time({A3 = get.kinship.snp(population, database = cbind(11,1,1,200), mode = 2)})
  system.time({A4 = get.kinship.snp(population, database = cbind(11,1,1,200), mode = 1, array = "onlyQTL")})
  system.time({A5 = get.kinship.snp(population, database = cbind(11,1,1,200), mode = 2, array = "onlyQTL")})

  max(diff(A2-A1)) # inaccuracy recombination to snps
  max(diff(A3-A2)) # check
  max(diff(A5-A3)) # inaccuracy density reduction

}





