# This file has been created automatically by 'rfGenerateConstants'


 ## from  src/AutoRandomFieldsUtils.h



 MAXUNITS 	<- as.integer(4)
 MAXCHAR 	<- as.integer(18)
 RFOPTIONS 	<- "RFoptions"
 isGLOBAL 	<- as.integer(NA)





 ## from  src/AutoRandomFieldsUtilsLocal.h

 PIVOT_NONE 	<- as.integer(0)
 PIVOT_AUTO 	<- as.integer(1)
 PIVOT_DO 	<- as.integer(2)
 PIVOT_IDX 	<- as.integer(3)
 PIVOT_UNDEFINED 	<- as.integer(4)
 PIVOTLAST 	<- as.integer(PIVOT_UNDEFINED)

 PIVOTSPARSE_MMD 	<- as.integer(1)
 PIVOTSPARSE_RCM 	<- as.integer(2)



