/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/



#ifndef miraculix_5codes_H
#define miraculix_5codes_H 1


#define gV5_header(NR, TYPE, SNDTYPE, TRDTYPE, ENDTYPE, V)	\
  void genoVector5v##NR##_##TYPE(vector_args(TYPE, ENDTYPE, V))


#define ORIGBITSperFIVE 10 // 5 * 2bits

Long LdaFiveCodes(Long snps, Long ldAbitalign);
//Long LdaFiveTransCodes(Long snps, Long ldAbitalign);
void Init5(void);


coding_header(_4Byte, 5);
coding_header(_1Byte, 5);
coding_header(_4Byte, 5trans);
coding_header(_1Byte, 5trans);

void coding5(codingSEXP_args());


vector_fctn_header(LongDouble, LongDouble, 5);
vector_fctn_header(longD, longD, 5);
vector_fctn_header(double, double, 5);
vector_fctn_header(Ulong, Ulong, 5);


void trafo2Geno5codes32(unit_t *OLD, Long rows, Long cols, Long oldLDA,
			coding_type coding,
			int cores, 
			unit_t *ANS, Long ldAns);
void trafo2Geno5codestrans32(unit_t *OLD, Long rows, Long cols,
			     Long oldLDA, coding_type coding,
			     int cores, 
			     unit_t *ANS, Long ldAns);
void trafo2Geno5codes256(unit_t *OLD, Long rows, Long cols, Long oldLDA,
			 coding_type coding,
			 int cores,
			 unit_t *ANS, Long ldAns);
void trafo2Geno5codestrans256(unit_t *OLD, Long rows, Long col, Long oldLDA,
			      coding_type coding,
			      int cores,
			      unit_t *ANS, Long ldAns);



gV5_header(512, floatD, LongDouble, float, double,);
gV5_header(256, floatD, LongDouble, float, double, );
gV5_header(128, floatD, LongDouble, float, double, );
gV5_header(32, floatD, LongDouble, float, double, );

gV5_header(512, double, LongDouble, double, double, );
gV5_header(256, double, LongDouble, double, double, );
gV5_header(128, double, LongDouble, double, double, );
gV5_header(32, double, LongDouble, double, double, );

gV5_header(512, longD, LongDouble, Longdouble, double, );
gV5_header(256, longD, LongDouble, Longdouble, double, );
gV5_header(128, longD, LongDouble, Longdouble, double, );
gV5_header(32, longD, LongDouble, Longdouble, double, );


extern Uchar PLINK2FIVE[1024];

#endif
