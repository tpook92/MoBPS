
/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/


#ifndef miraculix_options_H
#define miraculix_options_H 1


#include "xport_import.h"


#define geneticsN 9
struct genetics_options {
  usr_bool haplo_set1;
  bool squared, interprete_coding_as_is, prefer_external_freq, no_class;
  normalizing_type normalized;
  centering_type centered;
  // internal:
  coding_type coding;
  double digits;
  double *pcentered;
  int ncentered;
};
extern const char *genetics_names[geneticsN];

#define genetics_START {					\
    Nan,							\
      false, false, false, false,					\
      AccordingCentering, RowMeans,					\
      UnknownSNPcoding,						\
      3.0,							\
      NULL, 0 /* internal */					\
      }


#define tuningN 17
struct tuning_options {
  bool savegeno, oldversion, smoothRowGroupSize, missingsFully0,
    meanVsubstract, meanSxIsubstract, gpu, addtransposed,
    stick // stick process to cpu, obsolete
    ;
  int variant, logRowGroupSize, colGroupSize, miniRows, miniCols,
    floatLoop, // 0 : no; > 0 : number of iterations befor summing up
    WeakPerformance, HyperPerformance, HyperTurnedOn, // in %
    RoughRowChunk5codes, // experimental 
    maxSliceLen5codes    // experimental
    ;
  double coreFactor5codes; // experimental
};
extern const char *tuning_names[tuningN];


#define tuning_START {				\
    false, false, false, false,				\
      true, true, true, false, false,			\
      VARIANT_DEFAULT, 0, 0, 0, 0, 0,\
      100, 00, 33, 35000, 200,	     \
      2.5			     \
      }


#define messagesN 1
extern const char * messages[messagesN];
struct messages_options{ 
  bool warn_address;
};
#define messages_START {			\
    true					\
      }

struct option_type {
  genetics_options genetics;
  tuning_options tuning;
  messages_options messages;
};
extern option_type OPTIONS_LOCAL;

#define prefixLN 3
extern const char * prefixLlist[prefixLN], **allLoptions[prefixLN];
extern int allLoptionsN[prefixLN];


typedef
struct KEY_type KEY_type;
struct KEY_type {
  KEY_type_default;
};


int main_variant(int variant);

bool exists_tiling(coding_type coding, int variant, bool tiling);
bool exists_variant(coding_type coding, int variant, bool indeed,
		    bool efficient);
bool exists_crossprod(coding_type coding);
bool exists_allelefreq(coding_type coding);


#define NvariantsSHR5 32
const bool variantsSHR5[NvariantsSHR5] = {
  /*<=64*/true, true, true, false, /*128*/true,  true,  true, false,//last:224
  /*256*/ true, true, true, false,       false, false, false, false,//last:480
  /*512*/ true, true, true, false,       false, false, false, false,//last:736
  /*GPU*/ true, false,false,false,  /*R*/true, true, false, false //last:992
};

typedef bool (*exists_coding_t) (coding_type );
bool exists_internal_coding(coding_type m) ;
bool exists_user_coding(coding_type m) ;
bool exists_coding(coding_type m);

#endif
  
