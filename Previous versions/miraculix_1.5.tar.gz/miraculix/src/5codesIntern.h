/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
 

#ifndef miraculix_5codesIntern_H
#define miraculix_5codesIntern_H 1


#define AtOnce 5
#define SumAtOnce 4
 

/* 

   RoughRowChunk:

Wageningen/run_gcc snps=150000 indiv=150000 repetV=32 cores=10 floatLoop=0 meanSubst=0 missingsFully0=1 centered=0 trials=10 variant=256 coding=5 SxInotVmean=0 mode=3 SNPmode=0 cmp=0 sparse=0 rowMode=-4 colMode=0 fillMode=0

150000   1 : 7.5
 75000   2 : 5.4
 50000   3 : 5.2
 37500   4 : 5.1
 30000   5 : 5.2
 20000   7 : 5.2
 15000  10 : 5.4
 10000  15 : 5.6


*/


/* 

Wageningen/run_gcc snps=128000 indiv=136900 repetV=32 floatLoop=0 meanSubst=0 missingsFully0=1 centered=0 variant=256 coding=5 SxInotVmean=0 mode=3 SNPmode=3 cmp=0 sparse=0 rowMode=-4 colMode=0 fillMode=0 trials=4 cores=1


weak=0, hyper=0, cores=1
OMP                35.281 ( 35.281)
NOT FIXED          33.031 ( 33.029)
FIXED, sticked     33.980 ( 33.974) 
FIXED, not sticked 32.764 ( 32.760)


weak=0, hyper=0, cores=6
OMP                6.995 ( 38.708) 
NOT FIXED          6.304 ( 35.684)
FIXED, sticked    11.625 ( 63.865)
FIXED, not sticked 7.571 ( 38.871)



weak=0, hyper=0, cores=7
OMP                
NOT FIXED         6.820 ( 39.122) 
FIXED, sticked    
FIXED, not sticked 


weak=0, hyper=0, cores=8
OMP                
NOT FIXED          6.842 ( 42.780)
FIXED, sticked     9.739 ( 64.767) 
FIXED, not sticked 6.733 ( 43.766)


weak=0, hyper=0, cores=10
OMP                
NOT FIXED          6.958 ( 43.134)  
FIXED, sticked     
FIXED, not sticked 


weak=0, hyper=0, cores=14
OMP                6.214 ( 61.795)
NOT FIXED          5.450 ( 55.027) //  !! niedrigste real time
                   3.957 ( 39.875) [coreF=2.5, SLICEL=200]
FIXED, sticked     6.580 ( 69.573)  
                   5.674 ( 60.173) [coreF=2.5, SLICEL=200]
FIXED, not sticked 5.928 ( 58.782) 
                   5.583 ( 52.929) [coreF=2.5, SLICEL=200]

weak=0, hyper=0, cores=15
OMP                
NOT FIXED         5.479 ( 59.530)
FIXED, sticked    
FIXED, not sticked 


weak=0, hyper=0, cores=16
OMP                
NOT FIXED         5.611 ( 66.778)
FIXED, sticked    
FIXED, not sticked 




weak=0, hyper=0, cores="20"
OMP                 6.820 (103.668)    
NOT FIXED           5.924 ( 98.023) s
FIXED, sticked     12.251 ( 68.422) (turned down to 6 cores)
FIXED, not sticked  8.677 ( 45.331) (turned down to 6 cores)


weak=20, hyper=0, cores="20"
FIXED, sticked    10.655 ( 72.201)

weak=50, hyper=0, cores="20"
FIXED, sticked      9.244 ( 75.376) (turned down to 14 cores)
FIXED, not sticked  7.329 ( 66.969) (turned down to 14 cores)

weak=80, hyper=0, cores="20"
FIXED, sticked     7.780 ( 75.421)

weak=100, hyper=0, cores="20"
FIXED, sticked     7.336 ( 76.575)

weak=105, hyper=0, cores="20"
FIXED, sticked     7.258 ( 77.766)

weak=110, hyper=0, cores="20"
FIXED, sticked      7.135 ( 77.092) 

weak=120, hyper=0, cores="20"
FIXED, sticked     7.536 ( 82.974)



weak=110, hyper=5, cores="20"
FIXED, sticked      7.299 ( 82.413)

weak=110, hyper=10, cores="20"
FIXED, sticked      6.787 ( 85.504)
    
weak=110, hyper=15, cores="20"
FIXED, sticked      6.811 ( 85.173)

weak=110, hyper=20, cores="20"
FIXED, sticked      6.798 ( 86.902)

weak=110, hyper=30, cores="20"
FIXED, sticked      6.850 ( 95.111) 

weak=110, hyper=40, cores="20"
FIXED, sticked      7.189 ( 97.978)  

weak=110, hyper=80, cores="20"
FIXED, sticked      7.291 (108.587)


weak=110, hyper=-40, cores="20"
FIXED,              6.949 ( 96.276)
     
weak=110, hyper=-30, cores="20"
FIXED,              6.844 ( 94.049)

weak=110, hyper=-20, cores="20"
FIXED,              6.835 ( 87.241)

weak=110, hyper=-10, cores="20"
FIXED,              6.992 ( 80.415)



// every second hyper CPU not used
weak=110, hyper=-10, cores="20"
FIXED, sticked      6.826 ( 78.266) 

weak=110, hyper=-30, cores="20"
FIXED, sticked      6.667 ( 81.538)

weak=110, hyper=-50, cores="20"
FIXED, sticked      6.884 ( 83.939) 


// only one of three hyper CPU used
weak=110, hyper=-30, cores="20"
FIXED               6.836 ( 79.310)

weak=110, hyper=-50, cores="20"
FIXED,              6.546 ( 79.075) 

weak=110, hyper=-70, cores="20"
FIXED,             6.846 ( 78.964)


// only one of 6 hyper CPU used
weak=110, hyper=-30, cores="20"
FIXED,             6.899 ( 78.398)

weak=110, hyper=-50, cores="20" 
FIXED,             6.785 ( 77.827) 

weak=110, hyper=-75, cores="20"
FIXED,             6.872 ( 77.759)



auf meiner Kiste sind
6 Performance-Kerne + 6 Hyperthreader
8 Efficient-Kerne

Ich bekomme bei gefuehlt optimaler Einstellung meiner Parameter
(sehr flaches Optimum):
* Gewinn real-Zeit von 3%
* Verlust  user-Zeit von 3%
Vergleichswert sind 14 posix-CPU-fixierte threads (also ganz ohne Hyperthreading).

Die Parameter fuer das Hyperthreading sind hierbei:
* diese threads sind nicht CPU-fixiert
* bei n Hyperkernen trete ich nur m = n / 3 threads los
* jeder dieser m threads bekommt 50% der Arbeit wie ein Performance-Kern.

Ich bin auf meinem Laptop mit posix-CPU-fixiert und
allen optimierten Einstellungen mit 6.7 real-time
immer noch langsamer als posix-nicht-fixiert
 (6.2sec  fuer 20 Kerne; 5.4 sec fuer 14 Kerne).


*/

//#define AlteVersion 1
#define AlteVersion 0
#define HashSize  243L


#include "win_linux_aux.h"


  



#define gV5_start0(NR, TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)	\
  int VARIABLE_IS_NOT_USED WeakPerformance = tuning->WeakPerformance;	\
  int VARIABLE_IS_NOT_USED HyperPerformance = tuning->HyperPerformance;	\
  int VARIABLE_IS_NOT_USED HyperTurnedOn = tuning->HyperTurnedOn;	\
  bool VARIABLE_IS_NOT_USED stick = tuning->stick;			\
  int RoughRowChunk = tuning->RoughRowChunk5codes;			\
  int maxSliceLen = tuning->maxSliceLen5codes;				\
  double coreFactor=tuning->coreFactor5codes;				\
  int cores = GreaterZero(opt->cores); /* NOT Long !! */      		\
  if ((opt->Cprintlevel && sizeof(TRDTYPE) == 8) || opt->Cprintlevel > 3) { \
    char msg[200];							\
    SPRINTF(msg, "%s Bit %s-%s required for %ld x %ld x %ld", 		\
	    #NR, #TRDTYPE, #ENDTYPE, ALONG rows, ALONG cols, ALONG repetV); \
    PRINTF("%s", msg); for (int i=(int) STRLEN(msg); i<57; i++) PRINTF(" "); \
    PRINTF(" -> %3ld Bit, %2d cores\n",					\
	   ALONG (sizeof(AVXTYPE) * BitsPerByte), cores);		\
  }									\
  MEMSET(Ans, 0, ldAns * repetV * sizeof(ENDTYPE));			\
  TRDTYPE *externalV = NULL;						\
  const Long colsCpB = DIV_GEQ(cols, CpB);				\
  const Long colsCpBm1 = colsCpB - 1;					\
  const Long colBlocks = DIV_GEQ(colsCpB,  AtOnce);			\
  Long blockSliceLen = (Long) (CEIL(colBlocks / ( cores * coreFactor)));	\
  if (false) printf("blockSliceLen=%ld %d\n", ALONG blockSliceLen, maxSliceLen); \
  blockSliceLen = MAX(1, MIN(maxSliceLen, blockSliceLen));		\
  Long blocks = DIV_GEQ(colBlocks, blockSliceLen); /* (ca. cores * 5) repetV */; \
  /* for large repetV, use repetV only for splitting */			\
  /* blocks = blocks > cores ? cores : blocks > 1 ? blocks : 1;	*/	\
  const Long blocksM1 = blocks - 1L;					\
  const Long blockRest = colBlocks - blockSliceLen * blocksM1;		\
  const Long sliceLen = blockSliceLen * AtOnce;				\
  const Long rest = blockRest * AtOnce;					\
  if (false) PRINTF("0 < rest =%ld blcokrest=%ld<=%ld ------%ld   cores=%d atOnce=%d blocks=%ld\n", ALONG rest, ALONG blockRest, ALONG blockSliceLen, ALONG colBlocks, cores, AtOnce, ALONG blocks); \
  assert(rest > 0 && blockRest <= blockSliceLen);			\
  const Long blocksXrows = blocks * rows;				\
  const Long Hash_BytesPcol = HashSize * sizeof(AVXTYPE);		\
  const Long HashSizePerV = (colBlocks * AtOnce) * HashSize;		\
  const Long NVblocks = DIV_GEQ(repetV, VatOnce);			\
  AVXTYPE *F = (AVXTYPE*) CALLOC(HashSizePerV * NVblocks, sizeof(AVXTYPE)); \
  const Long blocksP1Xrows = blocksXrows + rows;			\
  const Long TmpSize = blocksP1Xrows * NVblocks				\
    +  AlteVersion * (blocksP1Xrows * NVblocks);			\
  AVXTYPE *Tmp = (AVXTYPE*) CALLOC(TmpSize, sizeof(AVXTYPE));		\
  AVXTYPE *sum = Tmp + AlteVersion * (blocksP1Xrows * NVblocks);	\
  const Long VARIABLE_IS_NOT_USED nr_trds_in_avx =			\
    BytesPerBlock / sizeof(TRDTYPE);					\
  if (false) {PRINTF("rows=%ld, cols=%ld\n", ALONG rows, ALONG cols);} \
  if (true) if (repetV % VatOnce) ERR0("'VatOnce not a multiple of repetV"); \
  if (true) { assert(sizeof(AVXTYPE) % sizeof(TRDTYPE) == 0); }	\
  INITIALIZE_FIXED_THREADS(&cores, WeakPerformance,			\
			   HyperPerformance, HyperTurnedOn, opt->Cprintlevel); \
  int VARIABLE_IS_NOT_USED hashcores = MIN(8, cores);			\
  if (false) printf("blocksM1=%ld, repet = %ld cores=%d; colsCpBm1=%ld %s %ld %ld\n", ALONG blocksM1, ALONG repetV, cores, ALONG colsCpBm1, #NR, ALONG colBlocks, ALONG blockSliceLen);



#if defined AVX2 || defined AVX512F
#define gV5_start(NR, TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)	\
  gV5_header(NR, TYPE, SNDTYPE, TRDTYPE, ENDTYPE, ) {		\
  const Long VatOnce = (sizeof(AVXTYPE) / sizeof(TRDTYPE));	\
  const Long restV = repetV % VatOnce;				\
  if (restV > 0 &&						\
      ((VatOnce == 8 && restV <= 4) || (VatOnce == 4 && restV <= 2))) {	\
    vector_##TYPE##_t vD = restV == 1 ? genoVector5v32_##TYPE		\
      : restV == 2 ? genoVector5v128_##TYPE				\
      : genoVector5v256_##TYPE;						\
    vD(code, rows, cols, coding, lda, variant, colFreq,		\
       V, restV, ldV, opt, tuning, Ans, ldAns);				\
    repetV -= restV;							\
    V += restV * ldV;							\
    Ans += restV * ldAns;						\
  }									\
  gV5_start0(NR, TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)
#else

#define gV5_start(NR, TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)	\
  gV5_header(NR, TYPE, SNDTYPE, TRDTYPE, ENDTYPE, ) {			\
  const Long VatOnce = (sizeof(AVXTYPE) / sizeof(TRDTYPE));     	\
  gV5_start0(NR, TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE);
#endif

#define gV5_startX(NR,X) gV5_start(NR,X)



#define gV5_CreateHash(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)	\
  for (Long rr=0; rr < NVblocks; rr++) {				\
    AVXTYPE *f = F + rr * HashSizePerV;					\
    Long sEnd = MIN(VatOnce, repetV - rr * VatOnce);			\
    for (Long i=0; i<=colsCpBm1; i++) {					\
      TYPE *v_i = V + rr * VatOnce * ldV + i * CpB;			\
      AVXTYPE *hash0 = f + i * HashSize;				\
      int hastRest = CpB;						\
      SNDTYPE x[CpB] = {0, 0, 0, 0, 0};/* hier compiler fehler bei collapse!?! */ \
      if (i < colsCpBm1) {} else {					\
	hastRest = (int) (cols - colsCpBm1 * hastRest);			\
	assert(hastRest > 0);						\
	for (int k=hastRest; k<CpB; k++) x[k] = 0;			\
      }									\
      SNDTYPE mean = 0;							\
      for (Long s=0; s<sEnd; s++) {					\
	TYPE *v = v_i + ldV * s;					\
	TRDTYPE *hash = ((TRDTYPE*) hash0) + s;				\
	for (int k=0; k<hastRest; k++) {x[k] = (SNDTYPE) v[k]; }	\
	if (colFreq != NULL) {					\
	  SNDTYPE meanLD = 0.0;						\
	  for (int k=0; k<hastRest; k++)				\
	    meanLD += (SNDTYPE) colFreq[i * CpB + k] * (2 * x[k]); \
	  mean = meanLD;						\
	}								\
	if (externalV != NULL) {					\
	} else {							\
	  for (Uint i4=0; i4<3; i4++) {					\
	    Uint V4 = i4;						\
	    SNDTYPE fct4 = (SNDTYPE) i4 * x[4] - mean;			\
	    for (Uint i3=0; i3<3; i3++) {				\
	      Uint V3 = 3 * V4 + i3;					\
	      SNDTYPE fct3 = fct4 + (SNDTYPE) i3 * x[3];	\
	      for (Uint i2=0; i2<3; i2++) {				\
                Uint V2 = 3 * V3 + i2;					\
		SNDTYPE fct2 = fct3 + (SNDTYPE) i2 * x[2];	\
	   	for (Uint i1=0; i1<3; i1++) {				\
		  Uint V1 = 3 * V2 + i1;      				\
		  SNDTYPE fct1 = fct2 + (SNDTYPE) i1 * x[1];	\
		  							\
		  Uint V0 = 3 * V1 * (Uint) VatOnce;			\
		  SNDTYPE fct0 = fct1;			\
		  hash[V0] = (TRDTYPE) fct0;			\
		  V0+=VatOnce;						\
		  fct0 += x[0];						\
		  hash[V0] = (TRDTYPE) fct0;			\
		  hash[V0 + VatOnce] = (TRDTYPE) (fct0 + x[0]);	\
		}							\
	      }								\
	    }								\
	  }								\
	}								\
      }									\
    }									\
  }									\
  if (false) PRINTF("Hash end\n");					\
  const Long rowBlocks = MAX(1, DIV_LEQ(rows, RoughRowChunk));		\
  const Long RowChunk =  DIV_GEQ(rows, rowBlocks);			\
  if (false) PRINTF("RowChunk = %ld, rows=%ld, %f %d\n", ALONG RowChunk, ALONG rows, (double) rows / (double) RowChunk,RoughRowChunk); \
  for (Long bStart=0; bStart<rows; bStart+=RowChunk) {			\
    Long bEnd = MIN(bStart + RowChunk, rows);				\
    

#define Hashvariab(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)		\
  gV5Hash##TYPE, rr,							\
    AVXTYPE##_omp_P F,							\
    Long_omp HashSizePerV,						\
    Long_omp repetV,							\
    Long_omp VatOnce,							\
    Long_omp colsCpBm1,							\
    Long_omp cols,							\
    TYPE##_omp_P V,							\
    Long_omp ldV,							\
    TRDTYPE##_omp_P externalV,						\
    LongDouble_omp_P colFreq					\
    LEER10

#define HashvariabX(X) Hashvariab(X) 
  

#define gV5_CreateHashDef(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)	\
  FCTOMP(Hashvariab(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)) {	\
  AVXTYPE *f = F + rr * HashSizePerV;					\
    Long sEnd = MIN(VatOnce, repetV - rr * VatOnce);			\
    for (Long i=0; i<=colsCpBm1; i++) {					\
      TYPE *v_i = V + rr * VatOnce * ldV + i * CpB;			\
      AVXTYPE *hash0 = f + i * HashSize;				\
      int hastRest = CpB;						\
      SNDTYPE x[CpB] = {0, 0, 0, 0, 0};/* hier compiler fehler bei collapse!?! */ \
      if (i < colsCpBm1) {} else {					\
	hastRest = (int) (cols - colsCpBm1 * hastRest);			\
	assert(hastRest > 0);						\
	for (int k=hastRest; k<CpB; k++) x[k] = 0;			\
      }									\
      SNDTYPE mean = 0;							\
      for (Long s=0; s<sEnd; s++) {					\
	TYPE *v = v_i + ldV * s;					\
	TRDTYPE *hash = ((TRDTYPE*) hash0) + s;				\
	for (int k=0; k<hastRest; k++) {x[k] = (SNDTYPE) v[k]; }	\
	if (colFreq != NULL) {					\
	  SNDTYPE meanLD = 0.0;						\
	  for (int k=0; k<hastRest; k++)				\
	    meanLD += (SNDTYPE) colFreq[i * CpB + k] * (2 * x[k]); \
	  mean = meanLD;						\
	}								\
	if (externalV != NULL) {					\
	} else {							\
	  Uint UintVatOnce = (Uint) VatOnce;				\
	  for (Uint i4=0; i4<3; i4++) {					\
	    Uint V4 = i4;						\
	    SNDTYPE fct4 = (SNDTYPE) i4 * x[4] - mean;			\
	    for (Uint i3=0; i3<3; i3++) {				\
	      Uint V3 = 3 * V4 + i3;					\
	      SNDTYPE fct3 = fct4 + (SNDTYPE) i3 * x[3];	\
	      for (Uint i2=0; i2<3; i2++) {				\
                Uint V2 = 3 * V3 + i2;					\
		SNDTYPE fct2 = fct3 + (SNDTYPE) i2 * x[2];	\
	   	for (Uint i1=0; i1<3; i1++) {				\
		  Uint V1 = 3 * V2 + i1;      				\
		  SNDTYPE fct1 = fct2 + (SNDTYPE) i1 * x[1];	\
		  							\
		  Uint V0 = 3 * V1 * UintVatOnce;			\
		  SNDTYPE fct0 = fct1;			\
		  hash[V0] = (TRDTYPE) fct0;			\
		  V0+=UintVatOnce;						\
		  fct0 += x[0];						\
		  hash[V0] = (TRDTYPE) fct0;			\
		  hash[V0 + VatOnce] = (TRDTYPE) (fct0 + x[0]);	\
		}							\
	      }								\
	    }								\
	  }								\
	}								\
      }									\
    }									\
    ENDOMPFCT }  /* V */


#define gV5_CreateHashDefX(X) gV5_CreateHashDef(X)

#define gV5_CreateHashX(X)						\
  CALLOMP(stick, hashcores, Hashvariab(X))				\
  if (false) PRINTF("Hash end\n");					\
  const Long rowBlocks = MAX(1, DIV_LEQ(rows, RoughRowChunk));		\
  const Long RowChunk =  DIV_GEQ(rows, rowBlocks);			\
  if (false) PRINTF("RowChunk = %ld, rows=%ld, %f %d\n", ALONG RowChunk, ALONG rows, (double) rows / (double) RowChunk,RoughRowChunk); \
  for (Long bStart=0; bStart<rows; bStart+=RowChunk) {			\
    Long bEnd = MIN(bStart + RowChunk, rows);				\
  

/* 
Aufwand fuer Erstellung der Hashtabelle kann deutlich reduziert wreden,
wenn SNDTYPE==TRDTYPE
(i)  i = 0
     AVX-Vektor X0 mit Werten x[0] x VatOnce; 
(ii) 3 AVX-Vektoren: (a) 0  (b) Xi (c) 2 * Xi
(iii) i++
(iv) AVX-Vektor Xi mit Werten x[i] x VatOnce erstellen
(v)
     (a) alle Vektoren kopieren auf die direkt nachfolgenden Speicherplaetze
     (b) das Kopierte plus Xi
     (c) Ergebnis kopieren auf die direkt nachfolgenden Speicherplaetze
     (c) das Kopierte plus Xi
(vi) weiter mit (iii) bis i=4 erreicht

Von V lokal eine Kopie halten? 
V umsortieren, so dass in Reihenfolge ausgelesen wird?
*/



#define ccc 0


#define FF012(AVXTYPE)							\
  Uchar *pC0 = (Uchar*) (c + i * lda);					\
  AVXTYPE ff0[HashSize];						\
  if (true) MEMCOPY(ff0, ff + (i + 0L) * HashSize, Hash_BytesPcol);	\
  else MEMSET(ff0, ccc, Hash_BytesPcol);				\
  Uchar *pC1 = (Uchar*) (c + (i+1L) * lda);				\
  AVXTYPE ff1[HashSize];						\
  if (true) MEMCOPY(ff1, ff + (i+1L) * HashSize, Hash_BytesPcol);	\
  else MEMSET(ff1, ccc, Hash_BytesPcol);				\
  Uchar *pC2 = (Uchar*) (c + (i+2L) * lda);				\
  AVXTYPE ff2[HashSize];						\
  if (true) MEMCOPY(ff2, ff + (i+2L) * HashSize, Hash_BytesPcol);	\
  else MEMSET(ff2, ccc, Hash_BytesPcol) 				

  
#if AtOnce >= 4
#define FF3(AVXTYPE)							\
  Uchar *pC3 = (Uchar*) (c + (i+3L) * lda);				\
  AVXTYPE ff3[HashSize];						\
  if (true) MEMCOPY(ff3, ff + (i+3L) * HashSize, Hash_BytesPcol);	\
  else MEMSET(ff3, ccc, Hash_BytesPcol) 				
#else
#define FF3(AVXTYPE)
#endif

#if AtOnce >= 5
#define FF4(AVXTYPE)							\
  Uchar *pC4 = (Uchar*) (c + (i+4L) * lda);				\
  AVXTYPE ff4[HashSize];						\
  if (true) MEMCOPY(ff4, ff + (i+4L) * HashSize, Hash_BytesPcol);	\
  else MEMSET(ff4, ccc, Hash_BytesPcol) 			       
#else
#define FF4(AVXTYPE)
#endif



#if AtOnce == 5

#if defined AVX2
#define gV5_LoopB(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)		\
    const AVXTYPE fC0 = AVXLOAD((TRDTYPE*)(ff0 + (int) pC0[b]));	\
    const AVXTYPE fC1 = AVXLOAD((TRDTYPE*)(ff1 + (int) pC1[b]));	\
    const AVXTYPE fC2 = AVXLOAD((TRDTYPE*)(ff2 + (int) pC2[b]));	\
    const AVXTYPE fC3 = AVXLOAD((TRDTYPE*)(ff3 + (int) pC3[b]));	\
    const AVXTYPE fC4 = AVXLOAD((TRDTYPE*)(ff4 + (int) pC4[b]));	\
    AVXTYPE tb = AVXLOAD((TRDTYPE*)(t + b));				\
    const AVXTYPE g0 = AVXADD(fC0, fC1);				\
    const AVXTYPE g1 = AVXADD(fC2, fC3);				\
    const AVXTYPE g2 = AVXADD(g0, fC4);				\
    const AVXTYPE h  = AVXADD( g2,  g1);				\
    AVXSTORE((TRDTYPE*)(t + b),  AVXADD( tb,  h));	\
  }
#else
#define gV5_LoopB(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)	\
    t[b] +=  (ff0[(int) pC0[b]] + ff1[(int) pC1[b]])		\
      + (ff2[(int) pC2[b]] + ff3[(int) pC3[b]] + ff4[(int) pC4[b]]);	\
  }
#endif

#elif AtOnce == 4

#if defined AVX2
#define gV5_LoopB(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)		\
    const AVXTYPE fC0 = AVXLOAD((TRDTYPE*)(ff0 + (int) pC0[b]));	\
    const AVXTYPE fC1 = AVXLOAD((TRDTYPE*)(ff1 + (int) pC1[b]));	\
    const AVXTYPE fC2 = AVXLOAD((TRDTYPE*)(ff2 + (int) pC2[b]));	\
    const AVXTYPE fC3 = AVXLOAD((TRDTYPE*)(ff3 + (int) pC3[b]));	\
    AVXTYPE tb = AVXLOAD((TRDTYPE*)(t + b));				\
    const AVXTYPE g0 = AVXADD(fC0, fC1);				\
    const AVXTYPE g1 = AVXADD(fC2, fC3);				\
    const AVXTYPE h  = AVXADD( g0,  g1);				\
    AVXSTORE((TRDTYPE*)(t + b),  AVXADD( tb,  h));	\
  }
#else
#define gV5_LoopB(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)	\
    t[b] +=  (ff0[(int) pC0[b]] + ff1[(int) pC1[b]])		\
      + (ff2[(int) pC2[b]] + ff3[(int) pC3[b]]);		\
  }
#endif

#elif AtOnce == 3
#if defined AVX2
#define gV5_LoopB(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)		\
   const AVXTYPE fC0 = AVXLOAD((TRDTYPE*)(ff0 + (int) pC0[b]));	\
    const AVXTYPE fC1 = AVXLOAD((TRDTYPE*)(ff1 + (int) pC1[b]));	\
    const AVXTYPE fC2 = AVXLOAD((TRDTYPE*)(ff2 + (int) pC2[b]));	\
    AVXTYPE tb = AVXLOAD((TRDTYPE*)(t + b));				\
    const AVXTYPE g0 = AVXADD(fC0, fC1);				\
    const AVXTYPE h  = AVXADD(g0,  fC2);				\
    tb  = AVXADD( tb,  h);						\
    AVXSTORE((TRDTYPE*)(t + b), tb);					\
  }
#else
#define gV5_LoopB(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)		\
    t[b] += ff0[(int) pC0[b]] + ff1[(int) pC1[b]] + ff2[(int) pC2[b]];	\
  }
#endif

#else
#error AtOnce unsound
#endif // AtOnce



#define gV5_LoopA(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)		\
  for (Long C=0; C <= blocksM1; C++) {					\
    for (Long rr=0; rr < NVblocks; rr++) { /* all repetV, as size is small*/ \
      AVXTYPE *ff = F + rr * HashSizePerV + sliceLen * C * HashSize;	\
      AVXTYPE *t = Tmp + rr * blocksP1Xrows + rows * ( C);		\
      unit_t *c = code + lda * sliceLen * C;				\
      Long nrCols = C == blocksM1 ? rest : sliceLen;			\
      /* assert(nrCols > 0); */						\
      for (Long i = 0 ; i<nrCols; i+=AtOnce) {/* cols of compressed */	\
        FF012(AVXTYPE); FF3(AVXTYPE); FF4(AVXTYPE);			\
        for (Long b=bStart; b<bEnd; b++) { /* rows of compressed */	\




#define Mainvariab(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)	\
  gV5Main##TYPE, C,						\
    Long_omp NVblocks,						\
    AVXTYPE##_omp_P F,						\
    Long_omp HashSizePerV,						\
    Long_omp sliceLen,							\
    AVXTYPE##_omp_P Tmp, /* 5*/						\
    Long_omp blocksP1Xrows,						\
    Long_omp rows,							\
    unit_t_omp_P code,						\
    Long_omp lda,						\
    Long_omp blocksM1, /* 10 */						\
    Long_omp rest,							\
    Long_omp Hash_BytesPcol,						\
    Long_omp bStart, 					\
    Long_omp bEnd   /* 14 */				\
    LEER LEER LEER LEER LEER LEER

#define MainvariabX(X) Mainvariab(X)



#define gV5_LoopAX(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)		\
    for (Long rr=0; rr < NVblocks; rr++) { /* all repetV, as size is small*/ \
      AVXTYPE *ff = F + rr * HashSizePerV + sliceLen * C * HashSize;	\
      AVXTYPE *t = Tmp + rr * blocksP1Xrows + rows * ( C);		\
      unit_t *c = code + lda * sliceLen * C;				\
      Long nrCols = C == blocksM1 ? rest : sliceLen;			\
      /* assert(nrCols > 0); */						\
      for (Long i = 0 ; i<nrCols; i+=AtOnce) {/* cols of compressed */	\
        FF012(AVXTYPE); FF3(AVXTYPE); FF4(AVXTYPE);			\
 	for (Long b=bStart; b<bEnd; b++) { /* rows of compressed */	\
  


/*
  double bbb = i;							
  if (false) for (Long jjj=0; jjj<1000; jjj++) bbb += EXP((double) i * jjj); 
  char ccc = bbb > 0;							
*/



#if SumAtOnce == 4
#if defined AVX2
#define Sum4ColsUp(AVXTYPE, TRDTYPE);					\
  const AVXTYPE fC0 = AVXLOAD((TRDTYPE*)(t0 + j));			\
  const AVXTYPE fC1 = AVXLOAD((TRDTYPE*)(t1 + j));			\
  const AVXTYPE fC2 = AVXLOAD((TRDTYPE*)(t2 + j));			\
  const AVXTYPE fC3 = AVXLOAD((TRDTYPE*)(t3 + j));			\
  const AVXTYPE g0 = AVXADD(fC0, fC1);					\
  const AVXTYPE g1 = AVXADD(fC2, fC3);					\
  const AVXTYPE h  = AVXADD( g0,  g1);					\
  AVXSTORE((TRDTYPE*)(t0 + j), h)
#else
#define Sum4ColsUp(AVXTYPE, TRDTYPE);	\
  t0[j] = (t0[j] + t1[j]) + (t2[j] + t3[j])
#endif
#else
#error SumAtOnce unsound
#endif // AtOnce
    
    
#define gV5_MainLoop(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)	\
  gV5_LoopA(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)			\
    gV5_LoopB(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)		\
    }}									\
    }}									\
    if (false) PRINTF("calc end blocks=%ld\n", ALONG blocks);		\
    

#define gV5_MainLoopDef(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)	\
  FCTOMP(Mainvariab(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)) {	\
  gV5_LoopAX(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)			\
    gV5_LoopB(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)			\
    }} ENDOMPFCT }						       

#define gV5_MainLoopDefX(X) gV5_MainLoopDef(X)

#define gV5_MainLoopX(X)		\
  CALLOMP(stick,cores,Mainvariab(X))					\
    }									\
    if (false) PRINTF("calc end blocks=%ld\n", ALONG blocks);		\

#if AlteVersion == 0

#define gV5_SumUp(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)		\
  for (Long rr=0; rr < NVblocks; rr++) {				\
    AVXTYPE *tmp = Tmp + rr * blocksP1Xrows;				\
    Long level = rows;							\
    Long tmpCols = blocks;						\
    while (tmpCols > 1) {						\
      Long tmpC4 = DIV_GEQ(tmpCols - 1, SumAtOnce);			\
      for (Long k=0; k < tmpC4; k++) {					\
	const Long kS = k * SumAtOnce;					\
	AVXTYPE *t0 = tmp + MIN(blocksXrows, (kS + 0) * level);		\
	AVXTYPE *t1 = tmp + MIN(blocksXrows, (kS + 1) * level);		\
	AVXTYPE *t2 = tmp + MIN(blocksXrows, (kS + 2) * level);		\
	AVXTYPE *t3 = tmp + MIN(blocksXrows, (kS + 3) * level);		\
	for (Long j=0; j<rows; j++)  {					\
	  Sum4ColsUp(AVXTYPE, TRDTYPE);					\
	}								\
      } /* for k */							\
      level *= SumAtOnce;						\
      tmpCols = DIV_GEQ(tmpCols, SumAtOnce);				\
    } /* while */							\
  } /* for */								\
if (false) PRINTF("end sum up\n");				       


#define SumUpvariab(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)	\
  gV5SumUp##TYPE, rr,				\
    AVXTYPE##_omp_P Tmp,					\
    Long_omp blocksP1Xrows,					\
    Long_omp rows,						\
    Long_omp blocks,						\
    Long_omp blocksXrows					\
    LEER LEER LEER LEER LEER LEER10

#define SumUpvariabX(X) SumUpvariab(X)

#define gV5_SumUpDef(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)		\
  FCTOMP(SumUpvariab(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)) {	\
    AVXTYPE *tmp = Tmp + rr * blocksP1Xrows;				\
    Long level = rows;							\
    Long tmpCols = blocks;						\
    while (tmpCols > 1) {						\
      Long tmpC4 = DIV_GEQ(tmpCols - 1, SumAtOnce);			\
      for (Long k=0; k < tmpC4; k++) {					\
	const Long kS = k * SumAtOnce;					\
	AVXTYPE *t0 = tmp + MIN(blocksXrows, (kS + 0) * level);		\
	AVXTYPE *t1 = tmp + MIN(blocksXrows, (kS + 1) * level);		\
	AVXTYPE *t2 = tmp + MIN(blocksXrows, (kS + 2) * level);		\
	AVXTYPE *t3 = tmp + MIN(blocksXrows, (kS + 3) * level);		\
	for (Long j=0; j<rows; j++)  {					\
	  Sum4ColsUp(AVXTYPE, TRDTYPE);					\
	}								\
      } /* for k */							\
      level *= SumAtOnce;						\
      tmpCols = DIV_GEQ(tmpCols, SumAtOnce);				\
      } /* while */							\
    ENDOMPFCT }  /* V */						\

#define gV5_SumUpDefX(X) gV5_SumUpDef(X)

#define gV5_SumUpX(X)		\
  CALLOMP(stick,cores,SumUpvariab(X))		\
    if (false) PRINTF("end sum up\n");				       


#else

warning("sldnd part")

#define gV5_SumUp(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)		\
  for (Long rr=0; rr < NVblocks; rr++) {				\
    Long rowsVatonce = rows * VatOnce;					\
    TRDTYPE *s = (TRDTYPE*) (sum + rr * blocksP1Xrows);			\
    for (Long k =0; k < blocks; k+=SumAtOnce) {				\
      AVXTYPE *T = (Tmp + rr * blocksP1Xrows);				\
      TRDTYPE *t0 = (TRDTYPE*) (T + MIN(blocks, k + 0) * rows);		\
      TRDTYPE *t1 = (TRDTYPE*) (T + MIN(blocks, k + 1) * rows);		\
      TRDTYPE *t2 = (TRDTYPE*) (T + MIN(blocks, k + 2) * rows);		\
      TRDTYPE *t3 = (TRDTYPE*) (T + MIN(blocks, k + 3) * rows);		\
      assert((Uchar*) (t3 + rowsVatonce) <= (Uchar*) (T + blocksP1Xrows)); \
      for (Long j=0; j<rowsVatonce; j++) {				\
	s[j] += (TRDTYPE) ((ENDTYPE) t0[j] + (ENDTYPE) t1[j] +		\
			   (ENDTYPE) t2[j] + (ENDTYPE) t3[j]);		\
      }									\
    }									\
  }									\
  if (false) PRINTF("!!! Old version of summing up (%ld, %ld)!!!\n", ALONG sizeof(TRDTYPE), ALONG sizeof(TRDTYPE));	        
   BUG; // no bug at all, just do not use this SumUp

    
#endif


#define gV5_Sort(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)		\
  for (Long rr=0; rr < NVblocks; rr++) {				\
    AVXTYPE *tmp = sum + rr * blocksP1Xrows;		\
    Long sEnd = MIN(VatOnce, repetV-rr * VatOnce);			\
    for (Long b=0; b<rows; b++) {					\
      const TRDTYPE *ST= ((TRDTYPE *) tmp) + b * VatOnce;		\
      ENDTYPE *a = Ans + b;						\
      for (Long s=0; s<sEnd; s++) {					\
	a[ldAns * (rr * VatOnce + s)] = (ENDTYPE) ST[s];		\
      }									\
    }									\
  } /* V */								\
  if (false) PRINTF("final end\n");					\
  FREE(F);								\
  FREE(Tmp);								\
  } // end function



#define Sortvariab(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)	\
  gV5Sort##TYPE, rr,				\
    AVXTYPE##_omp_P sum,					\
    Long_omp blocksP1Xrows,					\
    Long_omp repetV,						\
    Long_omp VatOnce,						\
    Long_omp rows,						\
    ENDTYPE##_omp_P Ans,					\
    Long_omp ldAns						\
    LEER LEER LEER LEER10

#define SortvariabX(X) Sortvariab(X)

#define gV5_SortDef(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)		\
  FCTOMP(Sortvariab(TYPE, SNDTYPE, TRDTYPE, AVXTYPE, ENDTYPE)) {	\
    AVXTYPE *tmp = sum + rr * blocksP1Xrows;				\
    Long sEnd = MIN(VatOnce, repetV - rr * VatOnce);			\
    for (Long b=0; b<rows; b++) {					\
      const TRDTYPE *ST= ((TRDTYPE *) tmp) + b * VatOnce;		\
      ENDTYPE *a = Ans + b;						\
      for (Long s=0; s<sEnd; s++) {					\
	a[ldAns * (rr * VatOnce + s)] = (ENDTYPE) ST[s];		\
      }									\
    }									\
    ENDOMPFCT }  /* V */						\

#define gV5_SortDefX(X) gV5_SortDef(X)

#define gV5_SortX(X)		\
  CALLOMP(stick,cores,Sortvariab(X))					\
  if (false) PRINTF("final end\n");					\
  FREE(F);								\
  FREE(Tmp);								\
  } // end function
 
 


#if defined AVXLOAD
#undef AVXLOAD
#undef AVXSTORE
#undef AVXADD
#undef VRBLS
#endif
#define AVXLOAD LOADuFLOAT
#define AVXSTORE STOREuFLOAT
#define AVXADD ADDFLOAT
#define VRBLS floatD, LongDouble, float, Floats, double


#include "myOMP.h"
STRUCTOMP(HashvariabX(VRBLS))
STRUCTOMP(MainvariabX(VRBLS))
STRUCTOMP(SumUpvariabX(VRBLS))
STRUCTOMP(SortvariabX(VRBLS))

  
#include "myOMP.h"
gV5_CreateHashDefX(VRBLS)
gV5_MainLoopDefX(VRBLS)
gV5_SumUpDefX(VRBLS)
gV5_SortDefX(VRBLS)


gV5_startX(MY_VARIANT, VRBLS)
#include "myOMP.h"
  STARTOMP(0, NVblocks, hashcores, HashvariabX(VRBLS))
  STARTOMP(0, blocks, cores, MainvariabX(VRBLS))
  STARTOMP(0, NVblocks, cores, SumUpvariabX(VRBLS))
  STARTOMP(0, NVblocks, cores, SortvariabX(VRBLS))
#include "myOMP.h"
gV5_CreateHashX(VRBLS)
#include "myOMP.h"
gV5_MainLoopX(VRBLS)
#include "myOMP.h"
gV5_SumUpX(VRBLS)
#include "myOMP.h"
gV5_SortX(VRBLS)




#if defined AVXLOAD
#undef AVXLOAD
#undef AVXSTORE
#undef AVXADD
#undef VRBLS
#endif
#define AVXLOAD LOADuDOUBLE
#define AVXSTORE STOREuDOUBLE
#define AVXADD ADDDOUBLE
#define VRBLS double, LongDouble, double, Doubles, double

#if defined  OMP_COUNTER
#undef OMP_COUNTER
#endif
#define OMP_COUNTER 99
#include "myOMP.h"
STRUCTOMP(HashvariabX(VRBLS))
STRUCTOMP(MainvariabX(VRBLS))
STRUCTOMP(SumUpvariabX(VRBLS))
STRUCTOMP(SortvariabX(VRBLS))

#include "myOMP.h"
gV5_CreateHashDefX(VRBLS)
gV5_MainLoopDefX(VRBLS)
gV5_SumUpDefX(VRBLS)
gV5_SortDefX(VRBLS)


gV5_start(MY_VARIANT, double, LongDouble, double, Doubles, double)
#include "myOMP.h"
STARTOMP(0, NVblocks, hashcores, HashvariabX(VRBLS))
STARTOMP(0, blocks, cores, MainvariabX(VRBLS))
STARTOMP(0, NVblocks, cores, SumUpvariabX(VRBLS))
STARTOMP(0, NVblocks, cores, SortvariabX(VRBLS))
#include "myOMP.h"
gV5_CreateHashX(VRBLS)
#include "myOMP.h"
gV5_MainLoopX(VRBLS)
#include "myOMP.h"
gV5_SumUpX(VRBLS)
#include "myOMP.h"
gV5_SortX(VRBLS)



#endif
