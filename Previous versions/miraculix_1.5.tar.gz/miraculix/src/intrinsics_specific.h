/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/


#ifndef miraculix_initrinsics_H
#define miraculix_initrinsics_H 1



#ifndef UINT64_C
#define UINT64_C(X) X
#endif


#if defined BytesPerBlock
#if ! defined BytesPerPartUnit
  #define BytesPerPartUnit BytesPerUnit
#endif
#define BitsPerPartUnit (BitsPerByte * BytesPerPartUnit)
#define PartUnitsPerBlock (BytesPerBlock / BytesPerPartUnit)

#define PartUnitsPerUnit (BytesPerUnit / BytesPerPartUnit)
#if defined PartUnitsPerUnit && PartUnitsPerUnit < 1
#undef PartUnitsPerUnit
#endif

union block_compressed{
  uint16_t b[PartUnitsPerBlock]; // OK
  // uint32_t u32[2]; falsch
  BlockType x;
};
#endif


#if defined BitsPerCode  /// real valued in general!!

  // none of the divisions here are truncated, except, maybe, the following:
#define CodesPerPartUnit ((Uint)((BitsPerPartUnit / BitsPerCode)))//truncated in general
#define codingBitsPerPartUnit ((Uint) (CodesPerPartUnit * BitsPerCode + 0.99))
#define two_codingBitsPerPartUnit (((Ulong) 1) << codingBitsPerPartUnit)
#define deltaBitsPartUnit (BitsPerPartUnit - codingBitsPerPartUnit)
#define CodesPerBlock (PartUnitsPerBlock * CodesPerPartUnit)
#define CodesPerByte ((Uint)(BitsPerByte / BitsPerCode + 0.1))
#define CodeMask ((1U << ((Uint) BitsPerCode)) - 1U)

#if defined PartUnitsPerUnit
#define CodesPerUnit (PartUnitsPerUnit * CodesPerPartUnit)
#endif

#endif // defined BitsPerCode




// #if defined AVX || defined SSE2 || defined AVX2 || defined AVX512
#if defined SSE2 || defined AVX2
#define VI .vi
#define U128(X) .u128[X]
#endif


// needed for immitations of sse/ssse3 functions
#define X128F64none(Z,A) Z(A,0); Z(A,1); 
#define X128F64(Z,A,B) Z(A,B,0); Z(A,B,1); 
#define X128F32(Z,A,B) X128F64(Z,A,B); Z(A,B,2); Z(A,B,3); 
#define X128F16(Z,A,B) X128F32(Z,A,B); Z(A,B,4); Z(A,B,5); Z(A,B,6); Z(A,B,7);
#define X128F8(Z,A,B) X128F16(Z,A,B); Z(A,B,8); Z(A,B,9);Z(A,B,10); Z(A,B,11);Z(A,B,12); Z(A,B,13); Z(A,B,14); Z(A,B,15);
#define X128F64bi(Z,A,B,C) Z(A,B,C,0); Z(A,B,C,1); 
#define X128F32bi(Z,A,B,C) X128F64bi(Z,A,B,C); Z(A,B,C,2); Z(A,B,C,3);
#define X128F16bi(Z,A,B,C) X128F32bi(Z,A,B,C); Z(A,B,C,4); Z(A,B,C,5); Z(A,B,C,6); Z(A,B,C,7);
#define X128F8bi(Z,A,B,C) X128F16bi(Z,A,B,C); Z(A,B,C,8); Z(A,B,C,9);Z(A,B,C,10); Z(A,B,C,11);Z(A,B,C,12); Z(A,B,C,13); Z(A,B,C,14); Z(A,B,C,15);

/*
const BlockType F1O1 = SET32(0xF0F0F0F0);
const BlockType O1F1 = SET32(0x0F0F0F0F);

const BlockType N1E1 = SET32(0x55555555);
const BlockType E1N1 = SET32(0xAAAAAAAA);
const BlockType N2E2 = SET32(0x33333333);
const BlockType E2N2 = SET32(0xCCCCCCCC); 
*/


#if defined AVX512

#elif defined AVX

#elif defined SSE2

#else

#if defined PlainInteger64
  #define VI

#elif defined PlainInteger32
  #define VI
#endif


#endif // AVX512 ... PlainInteger

//# i nc lude "intrinsics.multi.h"



// #define Uint uint32 // Window




#endif




