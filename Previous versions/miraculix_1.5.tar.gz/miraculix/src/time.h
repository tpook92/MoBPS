/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/




#ifdef TIME_AVAILABLE
#include <time.h>
#include <sys/time.h>

#define MY_CLOCKS_PER_SEC CLOCKS_PER_SEC
// #define MY_CLOCKS_PER_SEC 750000
#define CLOCK_IN_SEC(X) ((double) (X) / (double) MY_CLOCKS_PER_SEC)
#define TIME_IN_SEC(X) ( (double) (X).tv_sec + (double) (X).tv_usec / 1000000.0 )


static double reference_time = 0.0;
static double reference_clock = 0.0;

#define MY_CLOCKS_PER_SEC CLOCKS_PER_SEC
// #define MY_CLOCKS_PER_SEC 750000
#define CLOCK_IN_SEC(X) ((double) (X) / (double) MY_CLOCKS_PER_SEC)
#define TIME_IN_SEC(X) ( (double) (X).tv_sec + (double) (X).tv_usec / 1000000.0 )
#define AVERAGE_CLOCK(X,T,C) { \
    clock_end = clock();						\
    gettimeofday(&TofD, NULL);	time_end = TIME_IN_SEC(TofD);		\
    double TT = T;							\
    double CC = C;							\
    if (TT != 0.0) {							\
      double delta_time = (time_end - time_inter) / TT;			\
      double delta_clock = (CLOCK_IN_SEC(clock_end - clock_inter)) / TT; \
      PRINTF("%7.3f%s%7.3f%s",						\
	     delta_time, \
	     (C) == 0 ? " (" : ", ",					\
	     delta_clock,						\
	     (C) == 0 ? ")" : "");					\
      if (CC >= 1) {							\
	if (CC == 1) {							\
	  reference_time = delta_time;					\
	  reference_clock = delta_clock;				\
	}								\
	PRINTF(", %5.3f, %5.3f",					\
	       reference_time / delta_time / CC,			\
	       reference_clock / delta_clock			\
	       );							\
      }									\
      if (STRLEN(X) > 0) {						\
	PRINTF(" sec for %s", X);				\
	if (CC>0 || TT > 1)  PRINTF(" (");				\
	if (CC> 0) {							\
	  PRINTF("%3d cores", C);					\
	  if (TT > 1) PRINTF(", ");					\
	}								\
	if (TT > 1) {PRINTF("loop %d", T);}				\
	if (CC>0 || TT > 1)  PRINTF(")");				\
      } else if (CC>0)PRINTF(", %3d", C);				\
      PRINTF("\n");							\
    }									\
    clock_inter = clock_end;						\
    time_inter = time_end;						\
  }



#define STARTCLOCK \
  clock_t clock_end, clock_start = clock(), clock_inter = clock_start;	\
  timeval TofD;								\
  gettimeofday(&TofD, NULL);						\
  double time_end, time_start = TIME_IN_SEC(TofD), time_inter = time_start; \

#define TOTALCLOCK(X) {							\
  CLOCK(X);								\
  PRINTF("%7.3f (%7.3f) sec total time\n",				\
	 time_end - time_start,  CLOCK_IN_SEC(clock_end - clock_start)); \
  }
#elif defined XXXXX99999
#define AVERAGE_CLOCK(X,T,C) PRINTF("%s\n", X);
#define STARTCLOCK PRINT("startclock in %s, %d\n", __FILE__, __LINE__);
#define TOTALCLOCK PRINT("totalclock in %s, %d\n", __FILE__, __LINE__);
#else
#define AVERAGE_CLOCK(X,T,C) { }
#define STARTCLOCK { }
#define TOTALCLOCK { }
#endif

#define AVERAGE_CLOCK1(X,Y,T,C) { char msg[100]; SPRINTF(msg, X, Y); AVERAGE_CLOCK(msg,T,C); }
#define AVERAGE_CLOCK2(X,Y,Z,T,C) { char msg[100]; SPRINTF(msg, X, Y, Z); AVERAGE_CLOCK(msg,T,C); }
#define AVERAGE_CLOCK3(X,Y,Z,A,T,C) { char msg[100]; SPRINTF(msg, X, Y, Z, A); AVERAGE_CLOCK(msg,T,C); }

#define SILENT_CLOCK(X,S) AVERAGE_CLOCK(X, !(bool)(S), 0)
#define SILENT_CLOCK1(X,Y,S) AVERAGE_CLOCK1(X,Y, !(bool)(S), 0)
#define SILENT_CLOCK2(X,Y,Z,S) AVERAGE_CLOCK2(X,Y,Z, !(bool)(S), 0)
#define SILENT_CLOCK3(X,Y,Z,A,S) AVERAGE_CLOCK3(X,Y,Z,A, !(bool)(S), 0)

#define CLOCK(X) AVERAGE_CLOCK(X, 1, 0)
#define CLOCK1(X,Y) AVERAGE_CLOCK1(X,Y, 1, 0)
#define CLOCK2(X,Y,Z) AVERAGE_CLOCK2(X,Y,Z, 1, 0)
#define CLOCK3(X,Y,Z,A) AVERAGE_CLOCK3(X,Y,Z,A, 1, 0)
