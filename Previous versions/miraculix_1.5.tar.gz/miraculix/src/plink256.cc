/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/

#define BitsPerCode 2
#define MY_CODING Plink
#define MY_LDABITALIGN MY_LDABITALIGN_PLINK

#define MY_VARIANT 256

#define CORE_FACTOR 2

#include "Basic_miraculix.h"
#include "intrinsics_specific.h"
#include "options.h"
#include "Files.h"
#include "Template.h"
#include "plink.h"
#include "MX.h"

#if defined AVX2

ASSERT_SIMD(plink256, avx2);

#include "haplogeno.h"
#include "intrinsics.sequences.h"


/*

IMPORTANT FUNCTIONS IN 2bit256.cc

 */




#define maxVPatonce 8
#define BaseM 4
// Vergleichszahlen BaseM
// 1: 8.0
// 2: 3.9
// 3: 3.3
// 4: 2.6
// 5: 2.5
// 8: 3.8 // somit code nicht auf richtigkeit ueberprueft!


vectorGeno_header(double, double, double, PlinkMatrix256) {
  // calculates  t(v) * geno  for some geno matrix given by "code"
  // In :    V : snps x repetV
  //      code : snps x indiv
  // Out:  Ans : indiv x repetV
  // most inner matrix: (m "doubles of V") x (indivAtOnce1 indiv)
  const int  VARIABLE_IS_NOT_USED cores = GreaterZero(opt->cores);
  //  const Long individuals = cols;
  //  const Long snps = rows;

  
 const Long VDoublesBlocks = DIV_GEQ(repetV, 4);  
  Long Vblocks[maxVPatonce + 1] = {0};
  switch(VDoublesBlocks) {
  case 0 : BUG;
  case 1 : case 2: case 3: case 4: Vblocks[VDoublesBlocks] = 1; break;
  case 5 : Vblocks[2] = Vblocks[3] = 1; break;
  default :
#if BaseM == 3 || BaseM == 4
#define notBaseM (3 + 4 - BaseM)
    Vblocks[notBaseM] = VDoublesBlocks % BaseM;
#if BaseM == 4
    if (Vblocks[notBaseM] > 0) Vblocks[notBaseM] = BaseM - Vblocks[notBaseM];
#endif
    Vblocks[BaseM] = (VDoublesBlocks - notBaseM * Vblocks[notBaseM]) / BaseM;
#else // not  BaseM == 3 || BaseM == 4
    Vblocks[BaseM] = VDoublesBlocks  / BaseM;
#endif
  }

  //printf("VDoublesBlocks = %ld\n", VDoublesBlocks);
  if (false) for (int m=0; m<=maxVPatonce; m++) PRINTF("%d: %ld\n", m, ALONG Vblocks[m]);

  //  if (Vblocks[0] > 0 || Vblocks[1] > 0 || Vblocks[2] > 0 || Vblocks[3] > 0) BUG;
  
  if (Vblocks[0] < 0 || Vblocks[1] < 0 || Vblocks[2] < 0 ||
      Vblocks[3] < 0 || Vblocks[4] < 0 ||
      1 * Vblocks[1] + 2 * Vblocks[2] + 3 * Vblocks[3] + 4 * Vblocks[4] +
      5 * Vblocks[5] + 6 * Vblocks[6] + 7 * Vblocks[7] + 8 * Vblocks[8]
      !=
      VDoublesBlocks) BUG;

  //make standalone &&  Wageningen/run_gcc rows=1280 ind=1369 cores=10 coding=4  mode=3 SNPmode=3 repetV=16 trials=100 centered=0 variant=257 cmp=7

 
#define lenROWtype1 8
#define lenROWtype2 8
#define lenROWtype3 8
#define lenROWtype4 8
#define lenROWtype5 8
#define lenROWtype8 8
#define rowType2 Ulong
#define rowType1 Ulong
#define rowType3 Ulong
#define rowType4 Ulong  // int schlechter als Long
#define rowType5 Ulong
#define rowType8 Ulong

#define colAtOnce1 8 // <= 15
#define colAtOnce2 7 // <= 7
#define colAtOnce3 4 // <= 4
#define colAtOnce4 3 // <= 3 
#define colAtOnce5 2 // <= 3
#define colAtOnce8 1 // <= 3
  const int colAtO[maxVPatonce + 1] =
    {0, colAtOnce1, colAtOnce2, colAtOnce3, colAtOnce4, colAtOnce5,
     0, 0, colAtOnce8};
  Long colAtO_blocks[maxVPatonce + 1] = { 0 };
  for (int m = 1; m <= maxVPatonce; m++) {
    if ( (colAtO[m] + 1) * m > 16) BUG;
    if (colAtO[m] == 0) continue;
    colAtO_blocks[m] = DIV_GEQ(cols, colAtO[m]);
    //   printf("m=%d, col %ld / %d = %ld\n", m, cols, colAtO[m],colAtO_blocks[m]);
  }


#define miniROW1 (lenROWtype1 * CodesPerByte)
#define miniROW2 (lenROWtype2 * CodesPerByte)
#define miniROW3 (lenROWtype3 * CodesPerByte)
#define miniROW4 (lenROWtype4 * CodesPerByte)
#define miniROW5 (lenROWtype5 * CodesPerByte)
#define miniROW8 (lenROWtype8 * CodesPerByte)
  const int miniROW[maxVPatonce + 1] = // guaranteed alignment of TV
    {0, miniROW1, miniROW2, miniROW3, miniROW4, miniROW5, 0, 0, miniROW8};
  
  Long miniROW_blocks[maxVPatonce + 1] = { 0 };
  Long doublesTV[maxVPatonce + 1] = { 0 };
  Long doublesAns[maxVPatonce + 1] = { 0 };
  Long bytesTV = 0,
    bytesTans =0;
  for (int m = 1; m <= maxVPatonce; m++) {
    if (colAtO[m] == 0) continue;
    miniROW_blocks[m] = DIV_GEQ(rows, miniROW[m]);
    doublesTV[m] = m * miniROW[m] * miniROW_blocks[m];
    doublesAns[m] = m * colAtO[m] * colAtO_blocks[m];
    //   printf("m=%d %ld %ld\n %d %ld %d %ld\n\n", m, doublesTV[m], doublesAns[m], miniROW[m],miniROW_blocks[m],colAtO[m],colAtO_blocks[m]);
    
    bytesTV = MAX(doublesTV[m], bytesTV);
    bytesTans = MAX(doublesAns[m], bytesTans);
  }
  bytesTV *= sizeof(Doubles);
  bytesTans *= sizeof(Doubles);
  //  printf("bytesTV = %ld %ld\n", bytesTV, bytesTans);
  Doubles *TV = (Doubles*) MALLOC(bytesTV);
  Doubles *Tans = (Doubles*) MALLOC(bytesTans);
 

#define miniCol1 8
#define miniCol2 8
#define miniCol3 8
#define miniCol4 8 // besser als 16 & 2
#define miniCol5 8
#define miniCol8 8


#define littleROW1 4
#define littleROW2 4
#define littleROW3 4
#define littleROW4 4 // 4 besser als 16 -- 1 moeglicerweise optimum
#define littleROW5 4
#define littleROW8 4


#define littleCol1 (4 * miniCol1)  
#define littleCol2 (4 * miniCol2)  
#define littleCol3 (4 * miniCol3)    
#define littleCol4 (4 * miniCol4) // 1 & 64 schlechter
#define littleCol5 (4 * miniCol5)  
#define littleCol8 (4 * miniCol8)  


#define BpC BitsPerCode
	
#define V_LOAD(VM,DUMMY) const Doubles V##VM = LOADuDOUBLE((double*) (pTV + VM)); if (false ) PRINTF("get %ld %f %f %f %f\n", ALONG ((double*) (pTV + VM) - (double*) TV), ((double*) &V##VM)[0],((double*) &V##VM)[1],((double*)& V##VM)[2], ((double*)& V##VM)[3]);
#define LOAD_V MULTI_V(V_LOAD,0,;)

#define JJ_CONDLOAD(IN) const ROW_TYPE c##IN = (ROW_TYPE*) (C + (IN) * lda) >= (ROW_TYPE*) codeEnd ? 0 : *((ROW_TYPE*) (C + (IN) * lda))
#define JJ_LOAD(IN) const ROW_TYPE c##IN = *((ROW_TYPE*) (C + (IN) * lda)); if (false) PRINTF("&c%s=%ld; %ld\n", #IN, ALONG ((Uchar*) (C+(IN) * lda) - (Uchar*) code), ALONG c##IN); 
  
#define JJ_SHR(IN) ROW_TYPE d##IN = c##IN >> miniJ
#define SHR_JJ MULTI_COL(JJ_SHR,;)

#define JJ_ANDMASK(IN) d##IN &= CodeMask
#define ANDMASK_JJ MULTI_COL(JJ_ANDMASK,;)

  //#define ANS_LOAD(VM,IN) if (false) PRINTF("&Ans[%s,%s] = %ld <= %ld; %ld\n", #VM, #IN, (Long) ((double*) (tAns + (VM) + (IN) * M) - (double*) Tans, ALONG (bytesTans / 8)), ALONG bytesTans);   if (false && (double*) (tAns + (VM) + (IN) * M) - (double*) Tans > bytesTans / 8) BUG; Doubles A##VM##_##IN = LOADuDOUBLE((double*) (tAns + (VM) + (IN) * M))

#define ANS_LOAD(VM,IN)  Doubles A##VM##_##IN = LOADuDOUBLE((double*) (tAns + (VM) + (IN) * M))
  
#define LOAD_ANS MULTI_ANS(ANS_LOAD,;)

#define ANS_STORE(VM,IN) STOREuDOUBLE((double*) (tAns + (VM) + (IN) * M), A##VM##_##IN)
#define STORE_ANS MULTI_ANS(ANS_STORE,;)


#define SCALAR_PROD_SINGLE(VM,IN) A##VM##_##IN += V##VM
#define SCALAR_PROD_MINI(IN, M, Z)					\
  if (false)  PRINTF("d%s=%d \n", #IN, (int) d##IN);			\
  if (d##IN <= CODE_LASTZERO) goto zero##Z##M##IN;			\
  MULTI_V(SCALAR_PROD_SINGLE,IN,;);					\
  if (d##IN == CODE_ONE) goto zero##Z##M##IN; 				\
  MULTI_V(SCALAR_PROD_SINGLE,IN,;);					\
 zero##Z##M##IN:							       


  #define MINI_SCALAR_PROD(X) MULTI_M(SCALAR_PROD_MINI,M,X,;)

      

#define LOOP(NR,MM)							\
  for (Long iB=0; iB<ColAtO_blocks; iB += LITTLE_COL) {   /* I indep*/\
    Long iLittleEnd = MIN(iB + LITTLE_COL, ColAtO_blocks);		\
    Doubles *tAns1 = Tans + ANS_MINI * iB; /* // LOADED */		\
    Doubles *pTV1 = TV;	/* // LOADED */					\
									\
    for (Long jjB=0; jjB<MiniROW_blocks; jjB += LITTLE_ROW,  /* S finish*/ \
	   pTV1 += TV_MINI * LITTLE_ROW) {				\
      unit_t* C2 = (unit_t*) (((ROW_TYPE*) code) + jjB);		\
      Doubles *tAns0 = tAns1;/* // LOADED */				\
      Doubles *pTV0end = pTV1 +	/* // LOADED */				\
	TV_MINICOL * MIN(LITTLE_ROW, MiniROW_blocks - jjB);		\
									\
      for (Long iLittle=iB; iLittle < iLittleEnd; iLittle+=MINI_COL,	\
	     tAns0 += ANS_MINICOL) {                       /* I interm*/ \
	ROW_TYPE *C1 = (ROW_TYPE*) (C2 + LdaAtonce * iLittle);		\
	Doubles *tAnsEnd = tAns0 + MIN(ANS_MINICOL, ANS_MINI */* // LOADED */ \
				       (int) (ColAtO_blocks - iLittle));\
									\
	if (iLittle+MINI_COL <= iLittleEnd){				\
	  if (false) PRINTF("iB=%ld<%ld jjB=%ld<%ld litt=%ld,%ld<%ld; ", \
			    ALONG iB, ALONG ColAtO_blocks, ALONG jjB, \
			    ALONG MiniROW_blocks,ALONG iLittle,	\
			    ALONG iLittle+MINI_COL, ALONG iLittleEnd); \
	  if (false)							\
	  PRINTF("tAns: %ld %ld end= %ld / %d = %ld; min=%d<=%d\n",	\
		 ALONG ((double*) tAns1 - (double*) Tans), /*// long OK */ \
		 ALONG ((double*) tAns0 - (double*) Tans),/*// long OK */ \
		 ALONG ((double*) tAnsEnd - (double*) Tans),/*// long OK */ \
		 ANS_MINI,						\
		 ALONG (((double*) tAnsEnd - /*// long OK */		\
			  (double*) Tans) / ANS_MINI),			\
		   MIN(ANS_MINICOL,ANS_MINI*(int)(ColAtO_blocks-iLittle)),\
		   ANS_MINICOL);					\
	  INNERLOOP##NR(,MM);						\
	} else {							\
	  INNERLOOP##NR(COND,MM);						\
	}								\
      }									\
    }									\
  }
  
  

#define INNERLOOP(COND,MM)						\
  for (Doubles *pTV0 = pTV1; pTV0 < pTV0end;  /* // LOADED */ /*S: interm*/ \
       pTV0 += TV_MINICOL,						\
	 C1 ++) {							\
    unit_t* C = (unit_t*) C1;						\
    for (Doubles *tAns = tAns0; tAns < tAnsEnd;/* // LOADED */ /* I: V recyl*/ \
	 tAns += ANS_MINI, C += LdaAtonce	) {			\
      /* Umsortieren von code so dass C += MINI_ROW o.ae. */		\
      /* bringt ca 5%; lohnt Aufwand nicht */				\
      MULTI_COL(JJ_##COND##LOAD,;); /* C[e + (IN) * lda] */		\
      Doubles *pTV = pTV0;						\
      LOAD_ANS; /* tAns + (VM) + (IS) * M) */				\
      /* memory addressed  below is guaranteed to exist */		\
      /* no matter what the user input is */				\
      for (int miniJ=0; miniJ < (int)(BpC * MINI_ROW);  /*S no Ans*/	\
	   miniJ += BpC) { /*unroll bringt nix*/			\
	LOAD_V;/* (pTV + VM) */						\
	pTV += M;							\
	SHR_JJ;/* >> miniJ */						\
	ANDMASK_JJ;							\
	MINI_SCALAR_PROD(COND##MM);/*(repetV x ROWS) +=LOAD_V %*% t(LOAD_JJ)*/ \
      }									\
      STORE_ANS;							\
    }									\
  }




#define INNERLOOP1(COND,MM)						\
  for (Doubles *pTV0 = pTV1; pTV0 < pTV0end; /* // LOADED */ /*S: interm*/ \
       pTV0 += TV_MINICOL,						\
	 C1 ++) {							\
    unit_t* C = (unit_t*) C1;						\
    for (Doubles *tAns = tAns0; tAns < tAnsEnd;/* // LOADED */ /* I: V recyl*/ \
	 tAns += ANS_MINI, C += LdaAtonce	) {			\
       MULTI_COL(JJ_##COND##LOAD,;); /* C[e + (IN) * lda] */		\
       Doubles *pTV = pTV0;						\
       LOAD_ANS; /* tAns + (VM) + (IS) * M) */				\
       for (int miniJ=0; miniJ < (int)(BpC * MINI_ROW);  /*S no Ans*/	\
	   miniJ += BpC, pTV += M) { /*unroll bringt nix*/		\
	SHR_JJ;/* >> miniJ */						\
	ANDMASK_JJ;							\
	LOAD_V;/* (pTV + VM) */	/*repetV  +=LOAD_V */			\
	if (d0 <= CODE_LASTZERO) continue;				\
	MULTI_V(SCALAR_PROD_SINGLE,0,;);				\
	if (d0 == CODE_ONE) continue;					\
	MULTI_V(SCALAR_PROD_SINGLE,0,;);				\
       }								\
      STORE_ANS;							\
    }									\
  }

  
#define TV_MINI (M * COL_ATONCE)
#define TV_MINICOL  (TV_MINI * MINI_COL)

#define ANS_MINI (M * COL_ATONCE)
#define ANS_MINICOL (ANS_MINI * MINI_COL)
#define ANS_LITTLECOL (ANS_MINI * LITTLE_COL)

  BUG; //nachfolgend fueyhrt zu grossen abweichungen:
  //  make standalone &&  Wageningen/run_gcc rows=1280 ind=1369 cores=10 coding=4  mode=3 ROWmode=3 repetV=16 trials=100 centered=0 variant=257 cmp=7
  
  MEMSET(Ans, 0, sizeof(*Ans) * ldAns * repetV);
  Long cum_m = 0;
  double *pV = V;
  double *pA = Ans;

  unit_t *codeEnd = code + lda * cols;
  
  assert(ldAns == cols);
	
  for (int m = 1; m <= maxVPatonce; m++) {
    if (colAtO[m] == 0) continue;

    const int M4      =  m * doubles;
    //    const int MiniROW = miniROW[m];
    const Long MiniROW_blocks  = miniROW_blocks[m];
    const Long ColAtO_blocks = colAtO_blocks[m];
    const int  Col_atonce    = colAtO[m];
    const Long LdaAtonce       = lda * Col_atonce;
   
    for (int iVB=0; iVB < Vblocks[m]; iVB++,
	   pV += M4 * ldV, pA += M4 * ldAns, cum_m += M4) {
      
       /// set TV
      MEMSET(TV, 0, bytesTV);
      MEMSET(Tans, 0, bytesTans);     
      const int m4 = MIN(M4, (int) (repetV - cum_m));
      //      printf("B m=%d iVB=%d M4=%d m4=%d\n", m, iVB, M4, m4);
      
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static) 
#endif 
     for (int r = 0; r < m4; r++) {
	double *rrV = pV + r * ldV;
	double *pTV = ((double*) TV) + r;
	for (int j=0; j<rows; j++) {
	  //	  if (false)  printf("rrV[%d + %ld = %ld]=%f -> %d max=%ld\n", j, ALONG (r * ldV), ALONG (j + r * ldV), rrV[j], m4 *j+r, ALONG (bytesTV/8));
	  pTV[m4* j] = rrV[j];
	}
      }
     
      
      switch(m) {
      case 0: BUG; break;
      case 1: {
#if defined M
#undef M
#undef LEN_ROW_TYPE 
#undef ROW_TYPE     
#undef COL_ATONCE 
#undef MINI_ROW
#undef MINI_COL
#undef LITTLE_ROW   
#undef LITTLE_COL
#undef MULTI_V
#undef MULTI_COL
#undef MULTI_M
#undef MULTI_ANS
#endif

#define M 1
#define LEN_ROW_TYPE  lenROWtype1
#define ROW_TYPE         rowType1
#define COL_ATONCE colAtOnce1
#define MINI_ROW         miniROW1
#define MINI_COL     miniCol1
#define LITTLE_ROW     littleROW1
#define LITTLE_COL littleCol1
#define MULTI_V(X,N,SZ) X(0,N) 
#define MULTI_COL(X,SZ) X(0) SZ X(1) SZ X(2) SZ X(3) SZ X(4) SZ X(5) SZ X(6) SZ X(7) SZ X(8) 
#define MULTI_M(X,M,Z,SZ) X(0,M,Z) SZ X(1,M,Z) SZ X(2,M,Z) SZ X(3,M,Z) SZ X(4,M,Z) SZ X(5,M,Z) SZ X(6,M,Z) SZ X(7,M,Z) SZ X(8,M,Z)
#define MULTI_ANS(X,SZ) MULTI_V(X,0,SZ) SZ  MULTI_V(X,1,SZ) SZ MULTI_V(X,2,SZ) SZ MULTI_V(X,3,SZ) SZ MULTI_V(X,4,SZ) SZ MULTI_V(X,5,SZ) SZ MULTI_V(X,6,SZ) SZ  MULTI_V(X,7,SZ) SZ MULTI_V(X,8,SZ) 
    
#ifdef DO_PARALLEL
	#pragma omp parallel for num_threads(cores) schedule(static)
#endif
	LOOP(,M);
       
	
      }	break;
      case 2: {
#if defined M
#undef M
#undef LEN_ROW_TYPE 
#undef ROW_TYPE     
#undef COL_ATONCE 
#undef MINI_ROW
#undef MINI_COL
#undef LITTLE_ROW   
#undef LITTLE_COL
#undef MULTI_V
#undef MULTI_COL
#undef MULTI_M
#undef MULTI_ANS
#endif
	
#define M 2
#define LEN_ROW_TYPE  lenROWtype2
#define ROW_TYPE         rowType2
#define COL_ATONCE colAtOnce2
#define MINI_ROW         miniROW2
#define MINI_COL     miniCol2
#define LITTLE_ROW     littleROW2
#define LITTLE_COL littleCol2
#define MULTI_V(X,N,SZ) X(0,N) SZ X(1,N) 
#define MULTI_COL(X,SZ) X(0) SZ X(1) SZ X(2) SZ X(3)  SZ X(4) SZ X(5) SZ X(6) 
#define MULTI_M(X,M,Z,SZ) X(0,M,Z) SZ X(1,M,Z) SZ X(2,M,Z) SZ X(3,M,Z) SZ X(4,M,Z) SZ X(5,M,Z) SZ X(6,M,Z)
#define MULTI_ANS(X,SZ) MULTI_V(X,0,SZ) SZ  MULTI_V(X,1,SZ) SZ MULTI_V(X,2,SZ) SZ MULTI_V(X,3,SZ) SZ MULTI_V(X,4,SZ) SZ MULTI_V(X,5,SZ) SZ MULTI_V(X,6,SZ)

#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
	LOOP(,M);
 	

      }	break;
      case 3: {
	
#if defined M
#undef M
#undef LEN_ROW_TYPE 
#undef ROW_TYPE     
#undef COL_ATONCE 
#undef MINI_ROW     
#undef MINI_COL
#undef LITTLE_ROW   
#undef LITTLE_COL
#undef MULTI_V
#undef MULTI_COL
#undef MULTI_M
#undef MULTI_ANS
#endif

#define M 3
#define LEN_ROW_TYPE  lenROWtype3
#define ROW_TYPE         rowType3
#define COL_ATONCE colAtOnce3
#define MINI_ROW         miniROW3
#define MINI_COL     miniCol3
#define LITTLE_ROW     littleROW3
#define LITTLE_COL littleCol3
#define MULTI_V(X,N,SZ) X(0,N) SZ X(1,N) SZ X(2,N) 
#define MULTI_COL(X,SZ) X(0) SZ X(1) SZ X(2) SZ X(3) 
#define MULTI_M(X,M,Z,SZ) X(0,M,Z) SZ X(1,M,Z) SZ X(2,M,Z) SZ X(3,M,Z) 
#define MULTI_ANS(X,SZ) MULTI_V(X,0,SZ) SZ  MULTI_V(X,1,SZ) SZ MULTI_V(X,2,SZ) SZ MULTI_V(X,3,SZ)

    
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
	LOOP(,M)
       
      }	break;
      case 4: {

#if defined M
#undef M
#undef LEN_ROW_TYPE
#undef ROW_TYPE     
#undef COL_ATONCE 
#undef MINI_ROW     
#undef MINI_COL
#undef LITTLE_ROW   
#undef LITTLE_COL
#undef MULTI_V
#undef MULTI_COL
#undef MULTI_M
#undef MULTI_ANS
#endif
      
#define M 4
#define LEN_ROW_TYPE  lenROWtype4
#define ROW_TYPE         rowType4
#define COL_ATONCE colAtOnce4
#define MINI_ROW         miniROW4
#define MINI_COL     miniCol4
#define LITTLE_ROW     littleROW4
#define LITTLE_COL littleCol4
#define MULTI_V(X,N,SZ) X(0,N) SZ X(1,N) SZ X(2,N) SZ X(3,N)
#define MULTI_COL(X,SZ) X(0) SZ X(1) SZ X(2) 
#define MULTI_M(X,M,Z,SZ) X(0,M,Z) SZ X(1,M,Z) SZ X(2,M,Z) 
#define MULTI_ANS(X,SZ) MULTI_V(X,0,SZ) SZ  MULTI_V(X,1,SZ) SZ MULTI_V(X,2,SZ)
	

	assert(sizeof(ROW_TYPE) == LEN_ROW_TYPE);
	
	// printf("cores=%d colAtO_blocks=%ld\n", cores, ColAtO_blocks);

	// NOTE:
	// * col is treated in col-miniblocks
	// * rows  is treated in ROW-miniblocks (except most inner loop)
	// * repetV is fixes as a m-block of Doubles

	// loop character:
	// I block (independent Ans blocks)
	// S block (finishes Ans block)
	//   I block (intermediate)
	//   S block (intermediate)	
	//       I block avoids too many V loads; need load of Ans
	//        S block without load of Code nor Ans; needs load of V only
	//                load Ans / load V efficient
	
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
	// schedule(static, n), n < 25 ist wurscht
	//ordered // ist wurscht
#endif
	LOOP(,M)
 	
      } break;
      case 5: {

#if defined M
#undef M
#undef LEN_ROW_TYPE
#undef ROW_TYPE     
#undef COL_ATONCE 
#undef MINI_ROW     
#undef MINI_COL
#undef LITTLE_ROW   
#undef LITTLE_COL
#undef MULTI_V
#undef MULTI_COL
#undef MULTI_M
#undef MULTI_ANS
#endif

#define M 5
#define LEN_ROW_TYPE  lenROWtype5
#define ROW_TYPE         rowType5
#define COL_ATONCE colAtOnce5
#define MINI_ROW         miniROW5
#define MINI_COL     miniCol5
#define LITTLE_ROW     littleROW5
#define LITTLE_COL littleCol5
#define MULTI_V(X,N,SZ) X(0,N) SZ X(1,N) SZ X(2,N) SZ X(3,N) SZ X(4,N)
#define MULTI_COL(X,SZ) X(0) SZ X(1) 
#define MULTI_M(X,M,Z,SZ) X(0,M,Z) SZ X(1,M,Z) 
#define MULTI_ANS(X,SZ) MULTI_V(X,0,SZ) SZ  MULTI_V(X,1,SZ) 
    
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
	LOOP(,M);
 	
      } break;
  

      case 8: {
  
#if defined M
#undef M
#undef LEN_ROW_TYPE
#undef ROW_TYPE     
#undef COL_ATONCE 
#undef MINI_ROW     
#undef MINI_COL
#undef LITTLE_ROW   
#undef LITTLE_COL
#undef MULTI_V
#undef MULTI_COL
#undef MULTI_M
#undef MULTI_ANS
#endif
     
#define M 8
#define LEN_ROW_TYPE  lenROWtype8
#define ROW_TYPE         rowType8
#define COL_ATONCE colAtOnce8
#define MINI_ROW         miniROW8
#define MINI_COL     miniCol8
#define LITTLE_ROW     littleROW8
#define LITTLE_COL littleCol8
#define MULTI_V(X,N,SZ) X(0,N) SZ X(1,N) SZ X(2,N) SZ X(3,N) SZ X(4,N) SZ X(5,N) SZ X(6,N) SZ X(7,N) 
#define MULTI_COL(X,SZ) X(0) 
#define MULTI_M(X,M,Z,SZ) X(0,M,Z) 
#define MULTI_ANS(X,SZ) MULTI_V(X,0,SZ) 

#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif 
	LOOP(1,M);

      } break;
  
	
      default: BUG;
      }

      //      printf("Near end\n");

      // transpose back to Ans
      const int M4Col = M4 * Col_atonce;
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif 
      for (int i=0; i<cols; i++) {
	int iAtonceBlock = i / Col_atonce;
	int iAtO = i % Col_atonce;
	double *rrAns = pA + i;
	double *pTans = ((double*) Tans) + iAtonceBlock * M4Col + iAtO * M4;
	for (int r = 0; r < m4; r++) {
	  assert(ldAns * r + i < repetV * cols);
	  rrAns[ldAns * r] = pTans[r];
	}
      } // i

      //printf("end iVB\n");
      
    } // iVB
  } // m
   
  
  FREE(TV);
  FREE(Tans);
 

  // printf("Plink matrix done\n");
}



#else // !defined AVX
#include "avx_miss.h"

vectorGeno_header(double, double, double, PlinkMatrix256) Sv



// DeclareVersion(256,Su,Sv,Sm)
SIMD_MISS(plink256, avx2);
#endif  


// 4 & 5 : 5codes und plink ungefaehr gleichgut. Darunter 5codes besser.

// make standalone && Wageningen/run_gcc snps=128000 ind=136960 cores=10 coding=5   mode=3 SNPmode=3 repetV=32 trials=1 centered=0 variant=257
// 5codes : 7.136 ( 54.504)
// plink  : 4.153 ( 37.615)
// 4, SNPmode=0,2 : gleich. Schraeg.

//make standalone && Wageningen/run_gcc snps=128000 ind=136960 cores=20 coding=5   mode=3 SNPmode=3 repetV=32 trials=1 centered=0 variant=257
// 5 : 7.709 (109.217)
// 4 : 3.192 ( 57.394) 

//  make standalone && Wageningen/run_gcc snps=128000 ind=136960 cores=20 coding=4   mode=3 SNPmode=3 repetV=8 trials=1 centered=0 variant=257
// 5 : 1.892 ( 25.512)
// 4 : 0.739 ( 12.754) sec for gV_vG (plink; G * v; no means)

//  make standalone && Wageningen/run_gcc snps=128000 ind=136960 cores=20 coding=4   mode=3 SNPmode=3 repetV=6 trials=1 centered=0 variant=257
// 5 : 1.458 ( 19.341)
// 4 : 0.990 ( 16.696)


//  make standalone && Wageningen/run_gcc snps=128000 ind=136960 cores=20 coding=4   mode=3 SNPmode=3 repetV=5 trials=1 centered=0 variant=257
// 5 : 1.177 ( 15.924)
// 4 : 0.996 ( 16.743)


//  make standalone && Wageningen/run_gcc snps=128000 ind=136960 cores=20 coding=4   mode=3 SNPmode=3 repetV=4 trials=1 centered=0 variant=257
// 5 : 0.955 ( 12.762) 
// 4 : 0.762 ( 13.330)


//  make standalone && Wageningen/run_gcc snps=128000 ind=136960 cores=20 coding=4   mode=3 SNPmode=3 repetV=2 trials=1 centered=0 variant=257
// 5 : 0.511 (  6.419)
// 4 : 0.942 ( 16.091) 
