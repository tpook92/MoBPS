

#if defined double_omp
#undef double_omp
#undef Doubles_omp
#undef LongDouble_omp
#undef Floats_omp
#undef float_omp
#undef floatD_omp
#undef int_omp
#undef long_omp
#undef Long_omp
#undef double_omp_P
#undef Doubles_omp_P
#undef LongDouble_omp_P
#undef Floats_omp_P
#undef float_omp_P
#undef floatD_omp_P
#undef int_omp_P
#undef long_omp_P
#undef Long_omp_P
#undef unit_t_omp
#undef unit_t_omp_P
#undef LEER
#undef LEER10
#if OMP_COUNTER == 0
  #error programming error
#endif
#elif DO_PARALLEL == DO_POSIX || DO_PARALLEL == DO_FIXED_POSIX
  #if OMP_COUNTER == 1 || OMP_COUNTER == 2
    #pragma message CNVT2STR(OMP_COUNTER)
    #error("definition error in OMP.h")  
  #endif
#endif


//#pragma message CNVT2STR(OMP_COUNTER)


#if OMP_COUNTER > 3
#if defined OMP_COLLAPSE
#undef OMP_COLLAPSE
#undef OMP_COUNTER
#endif
#endif


#if defined SET_OMP_COLLAPSE
  #if defined OMP_COLLAPSE
    #undef OMP_COLLAPSE
  #endif
  #define OMP_COLLAPSE SET_OMP_COLLAPSE
#endif

#define OMPSTART_GEN(LOOP, Name, VIRT_CORES)				\
  if (cores >  max_number_of_cores)					\
    ERR2("number of cores (%d) larger than the allowed one (%d)",	\
	 cores, max_number_of_cores);					\
  if (false) printf("loop = %ld\n", ALONG LOOP);			\
  Long VARIABLE_IS_NOT_USED  LOOP_##Name = LOOP;			\
  double VARIABLE_IS_NOT_USED blocklaenge_##Name = ((double)(LOOP)) / (double) VIRT_CORES

#if DO_PARALLEL == DO_FIXED_POSIX

#define OUTERLOOP_OMP(Name, rr, Cores)					\
  static Long start_##Name[max_number_of_cores + 1];			\
  initialize_thread_to_core(LOOP_##Name, &Cores, start_##Name);		\
  if (false) printf("%s\n", #Name);					\
  for (int thread = 0; thread < Cores; thread++) {			\
    Long rr##start = start_##Name[thread];		       		\
    Long rr##end = start_##Name[thread + 1];

#else // DO_PARALLEL != DO_FIXED_POSIX

#define OUTERLOOP_OMP(Name, rr, Cores)					\
  for (int thread = 0; thread < Cores; thread++) {			\
  Long rr##start = (Long) (blocklaenge_##Name * thread + 0.9);		\
  Long rr##end = (Long) (blocklaenge_##Name * (thread + 1) + 0.9);	\
    rr##end = MIN(rr##end, LOOP_##Name);				\
    if (false) printf("rr=%d %f %ld\n", thread, blocklaenge_##Name, ALONG rr##start); \

#endif






#if DO_PARALLEL == DO_POSIX || DO_PARALLEL == DO_FIXED_POSIX

// #pragma message "using  posix pthread"

#if OMP_COUNTER == 3 // ********** OMP_COUNTER == 3, POSIX 

#define double_omp  argvar->,=,
#define Doubles_omp double_omp
#define LongDouble_omp double_omp
#define Floats_omp double_omp
#define float_omp double_omp
#define floatD_omp double_omp
#define int_omp double_omp
#define long_omp double_omp
#define Long_omp double_omp
#define double_omp_P double_omp
#define Doubles_omp_P double_omp
#define LongDouble_omp_P double_omp
#define Floats_omp_P double_omp
#define float_omp_P double_omp
#define floatD_omp_P double_omp
#define int_omp_P double_omp
#define long_omp_P double_omp
#define Long_omp_P double_omp
#define unit_t_omp double_omp
#define unit_t_omp_P double_omp
#define LEER ,,,
#define LEER10 LEER LEER LEER LEER LEER   LEER LEER LEER LEER LEER
#define OMPCALL(sticking, Cores, Name, rr,				\
  op0, qr0, var0,							\
  op1, qr1, var1,							\
  op2, qr2, var2,							\
  op3, qr3, var3,							\
  op4, qr4, var4,							\
  op5, qr5, var5,							\
  op6, qr6, var6,							\
  op7, qr7, var7,							\
  op8, qr8, var8,							\
  op9, qr9, var9,							\
  op10, qr10, var10,							\
  op11, qr11, var11,							\
  op12, qr12, var12,							\
  op13, qr13, var13,							\
  op14, qr14, var14,							\
  op15, qr15, var15,							\
  op16, qr16, var16,							\
  op17, qr17, var17,							\
  op18, qr18, var18,							\
  op19, qr19, var19)							\
  { if (false)	printf(" \n\ncores=%d\n", Cores);			\
  OUTERLOOP_OMP(Name, rr, Cores);					\
  struct struct_##Name *argvar = arg_thread_##Name + thread;		\
    argvar->rr##start = rr##start;					\
    argvar->rr##end = rr##end;						\
    argvar->thread = thread;						\
    argvar->stick = sticking;						\
    argvar->cores=Cores;						\
    argvar->loop=LOOP_##Name;						\
    op0 var0 qr0 var0;							\
    op1 var1 qr1 var1;							\
    op2 var2 qr2 var2;							\
    op3 var3 qr3 var3;							\
    op4 var4 qr4 var4;							\
    op5 var5 qr5 var5;							\
    op6 var6 qr6 var6;							\
    op7 var7 qr7 var7;							\
    op8 var8 qr8 var8;							\
    op9 var9 qr9 var9;							\
    op10 var10 qr10 var10;						\
    op11 var11 qr11 var11;						\
    op12 var12 qr12 var12;						\
    op13 var13 qr13 var13;						\
    op14 var14 qr14 var14;						\
    op15 var15 qr15 var15;						\
    op16 var16 qr16 var16;						\
    op17 var17 qr17 var17;						\
    op18 var18 qr18 var18;						\
    op19 var19 qr19 var19;						\
    if (false) printf("s=%ld e=%ld\n", ALONG rr##start, ALONG rr##end);	\
    if (rr##start < rr##end) pthread_create(threads_##Name + thread, NULL, \
					    ompfct_##Name, (void *)argvar); \
  }									\
  for (int thread = 0; thread < Cores; thread++) {			\
    if (arg_thread_##Name[thread].rr##start<arg_thread_##Name[thread].rr##end) \
      pthread_join(threads_##Name[thread], NULL);			\
  }									\
  }



#elif OMP_COUNTER == 2 // ********** OMP_COUNTER == 2, POSIX 

#if ! defined OMP_COLLAPSE
#define OMP_COLLAPSE 1
#endif


#define OMPSTART(F, LOOP, Cores, Name, ...)				\
  OMPSTART_GEN(LOOP, Name, Cores);					\
  struct struct_##Name arg_thread_##Name[max_number_of_cores];	\
  pthread_t threads_##Name[max_number_of_cores];			\
  MEMSET(arg_thread_##Name, 0,sizeof(*arg_thread_##Name)*max_number_of_cores); \
  MEMSET(threads_##Name, 0, sizeof(*threads_##Name) * max_number_of_cores);

#elif OMP_COUNTER == 1 // ********** OMP_COUNTER == 1, POSIX 

#define double_omp  double,=argvar->,
#define Doubles_omp  Doubles,=argvar->,//
#define LongDouble_omp  LongDouble,=argvar->,
#define Floats_omp  Floats,=argvar->,//
#define float_omp  float,=argvar->,
#define floatD_omp  floatD,=argvar->,
#define int_omp  int,=argvar->,
#define long_omp  long,=argvar->,
#define Long_omp Long,=argvar->,
#define double_omp_P  double*,=argvar->,
#define Doubles_omp_P  Doubles*,=argvar->,//
#define LongDouble_omp_P  LongDouble*,=argvar->,
#define Floats_omp_P  Floats*,=argvar->,//
#define float_omp_P  float*,=argvar->,
#define floatD_omp_P  floatD*,=argvar->,
#define int_omp_P  int*,=argvar->,
#define long_omp_P  long*,=argvar->,
#define Long_omp_P Long*,=argvar->,
#define unit_t_omp unit_t,=argvar->,
#define unit_t_omp_P unit_t*,=argvar->,
#define LEER ,,,
#define LEER10 LEER LEER LEER LEER LEER   LEER LEER LEER LEER LEER


#include "win_linux_aux.h"

#define OMPFCT(Name, rr,			\
  type0, op0, var0,					\
  type1, op1, var1,					\
  type2, op2, var2,					\
  type3, op3, var3,					\
  type4, op4, var4,					\
  type5, op5, var5,					\
  type6, op6, var6,					\
  type7, op7, var7,					\
  type8, op8, var8,					\
  type9, op9, var9,					\
  type10, op10, var10,					\
  type11, op11, var11,					\
  type12, op12, var12,					\
  type13, op13, var13,					\
  type14, op14, var14,					\
  type15, op15, var15,					\
  type16, op16, var16,					\
  type17, op17, var17,					\
  type18, op18, var18,					\
  type19, op19, var19					\
)						\
static void *ompfct_##Name(void *arg_void) {\
 struct struct_##Name *argvar = (struct_##Name*) arg_void;	\
  int VARIABLE_IS_NOT_USED thread = argvar->thread;		\
  if (argvar->stick) { STICK_THIS_THREAD_TO_CORE(thread); }		\
  Long rr##start =argvar-> rr##start;					\
  Long rr##end =argvar-> rr##end;					   \
  if (false) printf("%d:%ld,%ld\t",  argvar-> thread, ALONG rr##start, ALONG rr##end); \
  type0 var0 op0 var0;\
  type1 var1 op1 var1;\
  type2 var2 op2 var2;\
  type3 var3 op3 var3;\
  type4 var4 op4 var4;\
  type5 var5 op5 var5;\
  type6 var6 op6 var6;\
  type7 var7 op7 var7;\
  type8 var8 op8 var8;\
  type9 var9 op9 var9;\
  type10 var10 op10 var10;\
  type11 var11 op11 var11;\
  type12 var12 op12 var12;\
  type13 var13 op13 var13;\
  type14 var14 op14 var14;\
  type15 var15 op15 var15;\
  type16 var16 op16 var16;\
  type17 var17 op17 var17;\
  type18 var18 op18 var18;\
  type19 var19 op19 var19;\
  for (Long rr=rr##start; rr<rr##end; rr++) 


#define ENDOMPFCT } pthread_exit((void *)arg_void);        





#else // ********** OMP_COUNTER == 0, POSIX  *******


#define double_omp double,;,
#define Doubles_omp Doubles,;,
#define LongDouble_omp LongDouble,;,
#define Floats_omp Floats,;,
#define float_omp float,;,
#define floatD_omp floatD,;,
#define int_omp int,;,
#define long_omp long,;,
#define Long_omp Long,;,
#define double_omp_P double*,;,
#define Doubles_omp_P Doubles*,;,
#define LongDouble_omp_P LongDouble*,;,
#define Floats_omp_P Floats*,;,
#define float_omp_P float*,;,
#define floatD_omp_P floatD*,;,
#define int_omp_P int*,;,
#define long_omp_P long*,;,
#define Long_omp_P Long*,;,
#define unit_t_omp unit_t,;,
#define unit_t_omp_P unit_t*,;,
#define LEER ,,,
#define LEER10 LEER LEER LEER LEER LEER   LEER LEER LEER LEER LEER

#define OMPSTRUCT(Name,	rr,					\
		  type0, op0, var0,					\
		  type1, op1, var1,					\
		  type2, op2, var2,					\
		  type3, op3, var3,					\
		  type4, op4, var4,					\
		  type5, op5, var5,					\
		  type6, op6, var6,					\
		  type7, op7, var7,					\
		  type8, op8, var8,					\
		  type9, op9, var9,					\
		  type10, op10, var10,					\
		  type11, op11, var11,					\
		  type12, op12, var12,					\
		  type13, op13, var13,					\
		  type14, op14, var14,					\
		  type15, op15, var15,					\
		  type16, op16, var16,					\
		  type17, op17, var17,					\
		  type18, op18, var18,					\
		  type19, op19, var19					\
    )								\
  struct struct_##Name {					\
    Long rr##start, rr##end, loop;					\
    int thread, cores;							\
    bool stick;								\
    type0 var0 op0							\
    type1 var1 op1							\
    type2 var2 op2							\
    type3 var3 op3							\
    type4 var4 op4							\
    type5 var5 op5							\
    type6 var6 op6							\
    type7 var7 op7							\
    type8 var8 op8							\
    type9 var9 op9							\
    type10 var10 op10							\
    type11 var11 op11							\
    type12 var12 op12							\
    type13 var13 op13							\
    type14 var14 op14							\
    type15 var15 op15							\
    type16 var16 op16							\
    type17 var17 op17							\
    type18 var18 op18							\
    type19 var19 op19							\
  };								
  
#define STRUCTOMP(X) OMPSTRUCT(X)



  

#endif  //  ********** OMP_COUNTER == 0, END POSIX *******
#else // NOT POSIX


#if OMP_COUNTER == 3// ********** OMP_COUNTER == 3, OMP

 
#define double_omp  
#define Doubles_omp
#define LongDouble_omp
#define Floats_omp
#define float_omp 
#define floatD_omp 
#define int_omp 
#define long_omp
#define Long_omp
#define double_omp_P  
#define Doubles_omp_P
#define LongDouble_omp_P
#define Floats_omp_P
#define float_omp_P 
#define floatD_omp_P 
#define int_omp_P 
#define long_omp_P
#define Long_omp_P
#define unit_t_omp
#define unit_t_omp_P
#define LEER 
#define LEER10 LEER LEER LEER LEER LEER   LEER LEER LEER LEER LEER

#define OMPCALL(stick, Cores, Name, rr, ...)				\
  OUTERLOOP_OMP(Name, rr, virtual_cores_##Name);			\
    ompfct_##Name(rr##start, rr##end, __VA_ARGS__);			\
  }



#if DO_PARALLEL == DO_OMP
#pragma omp parallel for num_threads(cores) schedule(static) collapse(OMP_COLLAPSE)
#endif



#elif OMP_COUNTER == 2// ********** OMP_COUNTER == 2, OMP

#if ! defined OMP_COLLAPSE
#define OMP_COLLAPSE 1
#endif

#define OMPSTART(F, LOOP, Cores, Name,...)				\
  Long virtual_cores_##Name = (F) == 0 ? LOOP : (F) * Cores;		\
  OMPSTART_GEN(LOOP, Name, virtual_cores_##Name);			\
   


#elif OMP_COUNTER == 1// ********** OMP_COUNTER == 1, OMP

#define double_omp double
#define Doubles_omp Doubles
#define LongDouble_omp LongDouble
#define Floats_omp Floats
#define float_omp float
#define floatD_omp floatD
#define int_omp int
#define long_omp long
#define Long_omp Long
#define double_omp_P double*
#define Doubles_omp_P Doubles*
#define LongDouble_omp_P LongDouble*
#define Floats_omp_P Floats*
#define float_omp_P float*
#define floatD_omp_P floatD*
#define int_omp_P int*
#define long_omp_P long*
#define Long_omp_P Long*
#define unit_t_omp unit_t
#define unit_t_omp_P unit_t*
#define LEER
#define LEER10 LEER LEER LEER LEER LEER   LEER LEER LEER LEER LEER
#define OMPFCT(Name, rr, ...)					\
static void ompfct_##Name(Long rr##start, Long rr##end, __VA_ARGS__) {	\
   for (Long rr=rr##start; rr<rr##end; rr++) 

#define ENDOMPFCT }	       




#else // ********** OMP_COUNTER == 0, OMP *******
  //#pragma message "using OMP"
#define STRUCTOMP(X) 
#endif





#endif // not posix, not omp






//  ****************** INCREMENT COUNTER 

#if OMP_COUNTER == 3// ********** OMP_COUNTER == 3
#if defined SET_OMP_COLLAPSE
  #undef SET_OMP_COLLAPSE
#endif

#define CALLOMP(S,C,X) OMPCALL(S,C,X)
 //#warning("3 done")

#elif OMP_COUNTER == 2 // ********** OMP_COUNTER == 2
  #if defined OMP_COUNTER
    #undef OMP_COUNTER
  #endif
  #define OMP_COUNTER 3
#define STARTOMP(F, LOOP, C, X) OMPSTART(F, LOOP, C, X)
 //#warning("2 done")

#elif OMP_COUNTER == 1 // ********** OMP_COUNTER == 1
  #if defined OMP_COUNTER
    #undef OMP_COUNTER
  #else
    #error("definition error in OMP.h")
  #endif
  #define OMP_COUNTER 2
#define FCTOMP(X) OMPFCT(X)
//#define FCTOMP(X) XX X XX

  //#warning("1 done")

#else                  // ********** OMP_COUNTER == 0
  #if defined OMP_COUNTER 
    #error("definition error in OMP.h")
  #endif 
  #define OMP_COUNTER 1
   //#warning("0 done")
#endif
