/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/




#include "Basic_miraculix.h"
#include "compatibility.SEXP.h"
#include "options.h"
#include "haplogeno.h"
#include "Template.h"
#include "utils_miraculix.h"
#include "MXinfo.h"
#include "intrinsicsCheck.h"
#include "Files.h"
#include "Haplo.h"
#include "1bit.h"
#include "2bit.h"
#include "3bit.h"
#include "5codes.h"
#include "4Byte.h"
#include "OneByte.h"
#include "plink.h"
#include "intrinsics_specific.h"
#include "transform.h"


#define MY_VARIANT 32


void copyAttribInfos(SEXP To, SEXP From, bool unconditional, bool relaxed) {
  copySEXPattrib(To, From, unconditional);
  if (GetInfo(From, true) == NULL) return;
  GetOptions;
  extractInfo(From);
  extractNamedBasicInfo(To, To);
  // printf("%ld %ld %ld %ld\n", snpsTo, snps, individualsTo ,individuals);
  if (!relaxed && (snpsTo != snps || individualsTo != individuals)) BUG;
  infoTo[MISSINGS] = info[MISSINGS];
  
  if (info[TRANSPOSED] != infoTo[TRANSPOSED]) {
    Long missings = 2 * infoTo[MISSINGS];
    if (missings != 0) {
      SEXP Miss = getAttribPointer(To, Missings);
      Long *mssngs = LONG(Miss);    
      for (Long i=0; i<missings; i+=2) {
	Long tmp = mssngs[i]; mssngs[i] = mssngs[i+1]; mssngs[i+1] = tmp;
      }
    }

    SEXP PrecFrom = PROTECT(getAttribPointer(From, Precise)),
      PrecTo = PROTECT(getAttribPointer(To, Precise));
    if (PrecFrom != R_NilValue) {
      LongDouble *PFrom  = LONGREAL(PrecFrom),
	*PTo = LONGREAL(PrecTo);   
      Long LengthCol = (TotalLengthIndices - ColIndex) * sizeof(*PFrom);
      MEMCOPY(PTo, PFrom + ColIndex, LengthCol);
      MEMCOPY( ((Uchar *) PTo) + LengthCol, PFrom, ColIndex * sizeof(*PFrom));
    }
    UNPROTECT(2);
  }
}


int CompressedTranspose(unit_t * Code, Long rows, Long cols,
			coding_type coding, Long lda,
			unit_t *Ans, Long ldAns) {
  //
  int bitPerCode, loops;
  switch(coding) {
  case TwoBitGeno: case TwoBitHaplo: case Plink:
    bitPerCode = 2;
    loops = 1;
    break;
  case OneBitGeno: case OneBitHaplo:
     bitPerCode = 1;
     loops = 2;
     break;
  default:
    return 1;
    // ERR1("transposing for %.50s not programmed yet.", CODING_NAMES[coding]);
    //BUG;
  }
  
  const int
    bitPerCode2 = 2 * bitPerCode,
    bitPerCode3 = 3 * bitPerCode,
    bitPerCode4 = 4 * bitPerCode,
    bitPerCode5 = 5 * bitPerCode,
    bitPerCode6 = 6 * bitPerCode,
    bitPerCode7 = 7 * bitPerCode,
    codePerByte_default = BitsPerByte / bitPerCode,
    codePerUnit_default = BytesPerUnit * codePerByte_default;
  if (codePerByte_default * bitPerCode != BitsPerByte || codePerByte_default<=1)
    BUG;
  
  Long
    real_units[2] = {rows / codePerUnit_default, 1};
  assert((Long) rows - real_units[0] * codePerUnit_default >= 0);
  Long
    real_CpU[2] = {codePerUnit_default,
                   rows - real_units[0] * codePerUnit_default},
    end_ll = rows % codePerUnit_default > 0;
  Long ansLdaBytes = ldAns * BytesPerUnit;


  int ans_rows = (int) (cols / codePerByte_default); // +1 fuer rest
  int rest_cols = (int) (cols % codePerByte_default);
  Long ldaCpB = lda * codePerByte_default;
  unit_t *zeros = rest_cols == 0 ? NULL
    : (unit_t*) CALLOC(real_units[0] + 1, BytesPerUnit);

  for (int L=0; L<loops; L++) {
    // printf("loops=%d %d\n", loops, rest_cols);
    int codePerByte = codePerByte_default;
    int cur_ans_rows = ans_rows;
    unit_t *CodeX[BitsPerByte];
    unit_t *Code0 = Code + L * lda * cols;
    unsigned char *ans0 = (unsigned char *) (Ans + L * ansLdaBytes * rows);
   
    for (Long k=0; k<=(rest_cols > 0); k++) {
      //     printf("k=%ld %d\n", k, rest_cols > 0);
      if (k) {
	cur_ans_rows = 1;
	codePerByte = rest_cols;
      }

      {
	int b = 0;
	for ( ; b<codePerByte; b++) CodeX[b] = Code0 + b * lda;
	for ( ; b<codePerByte_default; b++) CodeX[b] = zeros;
      }


      for (Long j = 0; j<cur_ans_rows; j++) {
	// printf("j=%ld < %d r/s=%ld/%ld %ld/%ld\n", j, cur_ans_rows, rows, cols, ldAns, ansLdaBytes);
	
	unit_t *SXX[BitsPerByte];
	for (int b=0; b<codePerByte_default; b++)
	  SXX[b] = CodeX[b] + j * lda * codePerByte_default;
      //printf("%u %u %u %u bPc=%d %d\n", S0, S1, S2, S3, bitPerCode, N6E1);
	unsigned char *ans2 = ans0 + j;
	for (Long ll = 0; ll <= end_ll; ll++) { // steuert S N P S
	  Long units = real_units[ll],
	    CpU = real_CpU[ll];
	  for (Long m=0; m<units; m++) {
	    unit_t
	      S0 = *(SXX[0]),
	      S1 = *(SXX[1]);
	    if (codePerByte_default == 2) {
#define N4E4 0x0F
	      for (int i=0; i<CpU; i++, ans2 += ansLdaBytes) {
		*ans2 = (S0 & N4E4) | ((S1 & N4E4) << bitPerCode);
		S0 >>= bitPerCode;
		S1 >>= bitPerCode;
	      } // i
	    } else {
	      unit_t
		S2 = *(SXX[2]),
		S3 = *(SXX[3]);
	      if (codePerByte_default == 4) {
#define N6E2 0x03
		for (int i=0; i<CpU; i++, ans2 += ansLdaBytes) {
		  *ans2 = (S0 & N6E2) |
		    ((S1 & N6E2) << bitPerCode) |
		    ((S2 & N6E2) << bitPerCode2) |
		    ((S3 & N6E2) << bitPerCode3);
		  S0 >>= bitPerCode;
		  S1 >>= bitPerCode;
		  S2 >>= bitPerCode;
		  S3 >>= bitPerCode;
		} // i
	      } else {
		unit_t
		  S4 = *(SXX[4]),
		  S5 = *(SXX[5]),
		  S6 = *(SXX[6]),
		  S7 = *(SXX[7]);
#define N7E1 0x01
		for (int i=0; i<CpU; i++, ans2 += ansLdaBytes) {
		  *ans2 = (S0 & N7E1) |
		    ((S1 & N7E1) << bitPerCode) |
		    ((S2 & N7E1) << bitPerCode2) |
		    ((S3 & N7E1) << bitPerCode3) |
		    ((S4 & N7E1) << bitPerCode4) |
		    ((S5 & N7E1) << bitPerCode5) |
		    ((S6 & N7E1) << bitPerCode6) |
		    ((S7 & N7E1) << bitPerCode7);
		  S0 >>= bitPerCode;
		  S1 >>= bitPerCode;
		  S2 >>= bitPerCode;
		  S3 >>= bitPerCode;
		  S4 >>= bitPerCode;
		  S5 >>= bitPerCode;
		  S6 >>= bitPerCode;
		  S7 >>= bitPerCode;
		} // i
	      } // else: codePerByte_default == 8
	    } // else: odePerByte_default == 4
	    for (int b=0; b<codePerByte_default; b++) (SXX[b])++;
	  } // m
	} // ll
      } // j
      Code0 += cur_ans_rows * ldaCpB;
      ans0 += cur_ans_rows;
    } // k
  } // L
  FREE(zeros);
  return 0;
}

    
int uncompressedTranspose(unit_t * Code, Long rows, Long cols, 
			   coding_type coding, Long lda,
			   unit_t *Ans, coding_type codingAns, Long ldAns) {

  Long ldAnsByte = ldAns * sizeof(unit_t);
 
#define FORLOOP(UINT,UINT_ANS) {					\
    Long ldAnsUINT = ldAnsByte / sizeof(UINT_ANS);			\
    assert(ldAnsUINT * (Long) sizeof(UINT_ANS) == ldAnsByte);		\
    UINT_ANS *A = (UINT_ANS*) Ans;					\
    for (int o=0; o<outer; o++) {					\
      for (Long j=0; j<cols; j++) {					\
	UINT *code = (UINT*) (Code + j * lda);				\
	UINT_ANS *ans = A + j;						\
	for (Long i=0; i<rows; i++) ans[i * ldAnsUINT] = (UINT_ANS) code[i]; \
      }									\
      A += rows * ldAnsUINT;						\
      Code += cols * lda;						\
    }									\
  }
  

  if (coding == FourByteSingleBit) return 1;
  int outer =
    1 + (int) (anyByteHaplo(coding) && !UnCompressedDoubledRows(coding, false));
  
  switch(coding) {
  case FourByteHaplo :
  case FourByteGeno :
     switch(codingAns) {
     case OneByteHaplo:
     case OneByteGeno : FORLOOP(uint32_t, uint8_t); break;
     case FourByteHaplo :
     case FourByteGeno : FORLOOP(uint32_t, uint32_t); break;
     default : return 1; //ERR0("unknown new coding");
     }
     break;
  case OneByteHaplo : 
  case OneByteGeno :
    switch(codingAns) {
    case OneByteHaplo:
    case OneByteGeno : FORLOOP(uint8_t, uint8_t); break;
    case FourByteHaplo:
    case FourByteGeno : FORLOOP(uint8_t, uint32_t); break;
    default : return 1; //ERR0("unknown new coding");
    }
    break;
  case EightByteHaplo:
    switch(codingAns) {
    case EightByteHaplo : FORLOOP(uint64_t, uint64_t); break;
    default : return 1; //ERR0("unknown new coding");
    }
    break;
  default : return 1; //ERR0("not programmed yet / unknown new coding");
  }
  return 0;
}
  
int transpose(unit_t *Code, Long rows, Long cols, coding_type coding, Long lda,
	      bool bigendian,
	      unit_t *Ans, coding_type codingAns, Long ldAns) {
  // printf("coding = %s\n", CODING_NAMES[coding]);
  if (Code == Ans) ERR0("transposing cannot be performed on place");
  if (bigendian) ERR0("transposing not programmed for big endian.");
  if (coding == FiveCodes) {
    return 1;
    // ERR0("t(5codes) To do\n");
  }
  if (isUnCompressed(coding) && isUnCompressed(codingAns)) 
    return uncompressedTranspose(Code, rows, cols, coding, lda,
				 Ans, codingAns, ldAns);      
  else if (coding == codingAns) 
    return CompressedTranspose(Code, rows, cols, coding, lda,  Ans, ldAns);
 
  return 1;
 }


SEXP transpose(SEXP SxI, coding_type CodingAns,
	       option_type *global, utilsoption_type *utils) { 
  basic_options *opt = &(utils->basic);
  int efficient =  opt->efficient;
  extractInfo(SxI);
  variant = check_variant(coding, variant, efficient);

  SEXP Ans = PROTECT(createSNPmatrix(snps, individuals,
			    CodingAns == AutoCoding ? coding : CodingAns,
			    transposed==False ? True : False,
			    false,
			    variant,
			    0, global, utils));
  
  extractNamedBasicInfo(Ans, Ans);
  if (snps != snpsAns || individuals != individualsAns) BUG;
  int err = transpose(code, rows, cols, coding, lda,
		      info[BIGENDIAN], codeAns, codingAns, ldaAns);

  if (err) {
    UNPROTECT(1);
    return R_NilValue;
  }
  
  copyAttribInfos(Ans, SxI, false, false); 
  
  UNPROTECT(1);
  return Ans;
}


SEXP transpose(SEXP SxI, option_type *global, utilsoption_type *utils) {
  Long *info = GetInfo(SxI);
  coding_type coding = (coding_type) info[CODING];
  SEXP Ans = PROTECT(transpose(SxI, coding, global, utils));
  if (Ans == R_NilValue)
    ERR1("transposition of coding '%20.s' is not programmed yet.",
	CODING_NAMES[coding]);
  UNPROTECT(1);
  return Ans;
}



const Long CpByte = GetCodesPerUnit(FiveCodes) / BytesPerUnit;  // 5; OK
const Long CpByteplink = GetCodesPerUnit(Plink) / BytesPerUnit; // 4; OK
const Long BitsPerCodeplink = BitsPerByte / CpByteplink; // 2



#define TBM 0x03
void origplink2Geno5codes32(Uchar *M, Long oldRows, Long oldCols, 
			     int VARIABLE_IS_NOT_USED cores,
			     unit_t *Ans, Long ldAns) { 
  assert(CpByteplink == 4);
  assert(CpByte == 5);
  assert(BitsPerCodeplink == 2);
 // printf("p25T enter\n");
  if (sizeof(Uchar) * BitsPerByte != MY_VARIANT) BUG;
  Uchar *table = PLINK2FIVE;
  
  Long
    ldM = 1L + (oldRows - 1L) / CpByteplink, // in bytes!!!
    end_oldColsM1_CpB = (oldCols - 1L) / CpByte;
  
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
  for (Long i=0; i<=end_oldColsM1_CpB; i++) {
    int rest = (int) CpByte;
    Uchar *pM =  M + ldM * CpByte * i;
    Uchar *a0 = ((Uchar*) (Ans + ldAns * i)); 
    Uchar h[BitsPerByte]; // CpByte <= BitsPerByte !
    
    if (i < end_oldColsM1_CpB) {} else {
      rest = (int) (oldCols - end_oldColsM1_CpB * rest);
      assert(rest > 0);
      for (int ll=rest; ll<CpByte; ll++) h[ll] = 0;
    }
    
    for (Long j=0; j<ldM; j++, pM++) {
      Uchar *a = a0 + j * CpByteplink;
      for (int z=0; z<rest; z++) h[z] = pM[z * ldM];
      for (int k=0; k<CpByteplink; k++) {
	const Uint m = ((Uint) (h[0] & TBM)) |
	  (((Uint) (h[1] & TBM)) << 2) |
	  (((Uint) (h[2] & TBM)) << 4) |
	  (((Uint) (h[3] & TBM)) << 6) |
	  (((Uint) (h[4] & TBM)) << 8);
	a[k] = table[m];
	//	printf("%d ", (int) a[k]);
	for (Long ll=0; ll<CpByte; ll++) h[ll] >>= BitsPerCodeplink;
      }
    }
  }
  //  printf("p25T done\n"); BUG;
}




#if defined LONG_HANGING_TYPE
#undef LONG_HANGING_TYPE
#endif
//#define LONG_HANGING_TYPE Long
//#define HTT_BITS 64
#define LONG_HANGING_TYPE Ulong
#define HTT_BITS 64
#define ORIGBITS_TRANS_MASK 0x00000000000003FFL
// irgendwo fehler drin -- sollte eigentlich bisschen schneller gehen

void origplink2Geno5codestrans32(Uchar *M, Long oldRows, Long oldCols, 
			int VARIABLE_IS_NOT_USED cores,
			unit_t *Ans, Long ldAns) {
  //  printf("p25 enter\n");
  Uchar *table = PLINK2FIVE;
  const Long ldM = 1L + (oldRows - 1L) / CpByteplink; // in bytes!!!
  const Long end_indiM1_CpB = (oldRows -1L) / CpByte;
  const Long ldaByte = ldAns * BytesPerUnit; // OK
  const Long totalBytes = ldM * oldCols;

  if (MY_LDABITALIGN_2BIT < sizeof(Long)) BUG; // OK
  if (HTT_BITS != sizeof(LONG_HANGING_TYPE) * BitsPerByte) BUG; // OK
  
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
  for (Long i=0; i<oldCols; i++) {
    //    printf("i=%ld %d\n", i, oldCols);
    int availableBits = 0;
    LONG_HANGING_TYPE hanging = 0;
    LONG_HANGING_TYPE m = 0;
    int hangingBits = 0;
    Uchar *a0 = ((Uchar*) Ans) + i; // !!
    Long byteNr = i * ldM;
    LONG_HANGING_TYPE *pM = (LONG_HANGING_TYPE*) (M + byteNr);
    for(Long j=0; j<=end_indiM1_CpB; j++) {      
      //  printf("i=%ld %d j=%ld %d ldM=%d %d\n", i, oldCols, j,end_indiM1_CpB, ldM, oldRows);
      // i=127 128 j=224 225 ldM=282 1128
      Uchar *a = a0 + ldaByte * j;					
      while (availableBits < ORIGBITSperFIVE) {
	if (hangingBits == 0) {
	  byteNr += sizeof(LONG_HANGING_TYPE); // endpoint after loading
	  // printf("hanging %d <= %d \n", byteNr,totalBytes );
	  if (byteNr <= totalBytes) {
	    // printf(".");
	    // inbetween just (non-annoying) nonsense is additionally loaded
	    // if ldM is passed by *pM
	    hanging = *(pM++);
	    hangingBits = HTT_BITS;
	  } else {
	    // at the very end, instead of nonsense loading, we would have
	    // a segmenation fault
	    byteNr -= sizeof(LONG_HANGING_TYPE);
	    int left =  (int) (totalBytes - byteNr);
	    for (int k=0; k < left; k++) {
	      //     printf("k=%d left = %d %d\n", k, left, (int) (((Uchar*) pM)[k]));
	      //	  printf("k=%d left = %d %d\n", k, left, (int) ( ((Uchar*) (&hanging))[k]));

	      ((Uchar*) (&hanging))[k] = ((Uchar*) pM)[k];
	      
	    }
	    hangingBits = left * BitsPerByte;
	  }
	}
	//	printf("%d < %d\n", availableBits ,  ORIGBITSperFIVE);
	m |= hanging << availableBits;
	int movedBits = hangingBits <= HTT_BITS-availableBits
	  ? hangingBits : HTT_BITS - availableBits;
	//	printf("i=%ld j=%ld %d %ld %d  %d<%d-%d\n", i, j, hangingBits, ALONG M - ALONG pM, movedBits, hangingBits, sizeof(LONG_HANGING_TYPE), availableBits);
	availableBits += movedBits;
	hangingBits -= movedBits;
	hanging >>= movedBits;
      }
      *a = table[m & ORIGBITS_TRANS_MASK];
       m >>= ORIGBITSperFIVE;
       availableBits -= ORIGBITSperFIVE;
    }
  }
  //  printf("p25 done\n");
  // BUG;
}





typedef void (*get_uint_t )(unit_t *, Long rows, Long cols, Long lda,
			    int cores,
			    unit_t *ans, usr_bool transposed, Long ldAns);

#define matrix_get_fctn(BYTE, Coding)				\
  void matrix_get##BYTE(unit_t *Code, Long rows, Long cols,	\
			 coding_type coding, Long lda,			\
			 int cores,					\
			 unit_t *ans, Long ldAns,  usr_bool transposed){ \
    /* if (false)  printf("     matrix_get_%s, haplogeno.cc\n", #BYTE); */ \
    /* if (false)  printf("rows %ld %ld %ld %d %ld\n", ALONG rows, ALONG cols, ALONG lda, BytesPerUnit, ALONG totalMem(cols, ldAns, Coding));	*/ \
  MEMSET(ans, 0, totalMem(cols, ldAns, Coding) * BytesPerUnit); /* // OK */ \
  if (false)  printf("ok\n"); /* rows 10 100 16 4 1600 */		\
  get_uint_t get = NULL;						\
  switch (coding) {							\
  case OneBitGeno : get = get_matrix1##BYTE; break;			\
  case TwoBitGeno : get = get_matrix2##BYTE ; break;			\
  case ThreeBit : get = get_matrix3##BYTE; break;			\
  case Plink : get = get_matrixPlink##BYTE; break;			\
  case FourByteGeno:  get = get_matrixPlain##BYTE; break;		\
  case OneByteGeno:  get = get_matrixOneByte##BYTE; break;		\
  default :								\
  PRINTF("%s\n", CODING_NAMES[coding]);					\
  BUG;									\
  }									\
  if (false)   printf("ok2 %d %d %d\n", Coding, coding, TwoBitGeno);	\
   get(Code, rows, cols, lda, cores, ans, transposed, ldAns);		\
   if (false)  printf("ok3\n");						\
}

matrix_get_fctn(_4Byte, FourByteGeno)
matrix_get_fctn(_1Byte, OneByteGeno)


#define matrix_coding_fctn(BYTE)					\
  coding_t matrix_coding##BYTE(coding_type coding, usr_bool *transposed, \
				int variant, bool bigendian) {		\
    coding_t matrix_coding;						\
    if (bigendian) BUG;							\
    if (*transposed == False) {						\
      switch (coding) {							\
      case OneBitGeno : matrix_coding = coding1##BYTE; break;		\
      case TwoBitGeno :							\
	switch(variant) {						\
	case 512:							\
	case VARIANT_GPU:						\
	case 256 : /* matrix_coding = coding_2v256##BYTE; break; -- Fehler */ \
	case 128 :if (bigendian) {matrix_coding = coding_2v128##BYTE; break;} \
	  FALLTHROUGH_OK;						\
	default:matrix_coding = coding2##BYTE;				\
	}								\
	break;								\
      case ThreeBit : matrix_coding = coding3##BYTE; break;		\
      case OneByteGeno : matrix_coding = codingOneByte##BYTE; break;	\
      case FourByteGeno: matrix_coding = codingPlain##BYTE; break;	\
      case Plink :							\
	switch(variant) {						\
	case 512:							\
	case VARIANT_GPU:						\
	case 256 : /* matrix_coding = coding_2v256; break; -- Fehler */	\
	case 128 :							\
	  FALLTHROUGH_OK;						\
	default:matrix_coding = codingPlink##BYTE;			\
	}								\
	break;								\
      case FiveCodes : matrix_coding = coding5##BYTE; break;		\
      case OneByteHaplo : matrix_coding = codingHaplo1Byte_4Byte; break; \
      case FileDot :  matrix_coding = file_dot_do; break;		\
      case DotFile :  matrix_coding = dot_file_do; break;		\
      default : matrix_coding =  NULL;					\
      }									\
    } else {								\
      switch (coding) {							\
      case TwoBitGeno : matrix_coding = coding2trans##BYTE;		\
	*transposed = False;						\
	break;								\
      case Plink : matrix_coding = codingPlinktrans##BYTE;		\
	*transposed = False;						\
	break;								\
      case FiveCodes : matrix_coding = coding5trans##BYTE; 		\
	*transposed = False;						\
	break;								\
      case OneByteGeno : matrix_coding = codingOneByte##BYTE; break;	\
      case FourByteGeno : matrix_coding = codingPlain##BYTE; break;	\
      case FileDot :matrix_coding = dot_file_do; break;			\
      case DotFile : matrix_coding = file_dot_do; break;		\
      default : matrix_coding = NULL;					\
      }									\
    }									\
    return matrix_coding;						\
  }									\
  
matrix_coding_fctn(_4Byte)
matrix_coding_fctn(_1Byte)




#define SelectGeno(UINT,UCHAR)						\
  void SelectGeno##UINT##UCHAR(unit_t *Old, Long OldRows, Long OldCols, \
			       Long OldLDA,				\
			       int *snp_list, int snp_list_N,		\
			       int *cols_list, int cols_list_N,	\
			       unit_t *Ans, Long ldAns, usr_bool transposed) { \
    Long cols_N = cols_list_N > 0 ? cols_list_N : OldCols;		\
    Long nCols = 0;							\
    Long Bytes = ldAns * BytesPerUnit;					\
    Long LDAnsByte = transposed == False ? Bytes : sizeof(UCHAR);	\
    Long EinsByte  = transposed == False ? sizeof(UCHAR) : Bytes;	\
    for (Long i=0; i<cols_N; i++) {					\
      Long ii=i;							\
      if (cols_list_N > 0) {						\
	ii = cols_list[i];						\
	if (ii >= OldCols) continue;					\
      }									\
      if (false)    printf("%ld %ld %ld %ld\n", ALONG nCols, ALONG (nCols * LDAnsByte), ALONG LDAnsByte, ALONG sizeof(UCHAR)); \
      UCHAR *a = (UCHAR*) (((Uchar*) Ans) + (nCols++) * LDAnsByte);	\
      MEMSET(a, 0, LDAnsByte); /* avoids undefined memory */		\
      if (ii < 0)  continue;						\
      UINT *old = (UINT*) (Old + OldLDA * ii);				\
      if (snp_list_N == 0) {						\
	if (sizeof(UCHAR) == sizeof(UINT) && transposed == False) {	\
	  /* lda may differ !! */					\
	  MEMCOPY(a, old, sizeof(UINT) * OldRows);			\
	} else {							\
	  for (Long j=0; j<OldRows; j++) {				\
	    *a = (UCHAR) old[j];					\
	    a = (UCHAR *) (((Uchar*) a) + EinsByte);			\
	  }								\
	}								\
	continue;							\
      }									\
      for (Long j=0; j<snp_list_N; j++) {				\
	if (snp_list[j] >= OldRows) continue;				\
	if (snp_list[j] >= 0) *a = (UCHAR) old[snp_list[j]];		\
	a = (UCHAR *) (((Uchar*) a) + EinsByte);			\
      }									\
    }									\
  }

SelectGeno(_4Byte,_4Byte)
SelectGeno(_1Byte,_1Byte)
SelectGeno(_4Byte,_1Byte)
SelectGeno(_1Byte,_4Byte)



#define SelectHaplo(UINT,UCHAR)						\
  void SelectHaplo##UINT##UCHAR(unit_t *Old, Long OldRows, Long OldCols, \
				Long OldLDA, coding_type OldCoding,	\
				int *snp_list, int snp_list_N,		\
				int *cols_list, int cols_list_N,	\
				usr_bool set1,				\
				unit_t *Ans, Long AnsRows,		\
				Long ldAns, coding_type AnsCoding, \
				usr_bool transposed) {			\
    /* currently, always cols_list=NULL as cols already selected */	\
    if (transposed != False) BUG;					\
    const bool both = set1 == Nan,					\
      doubled = both & UnCompressedDoubledCols(OldCoding, true);	\
    /*//    printf("yX %s %s \n",CODING_NAMES[OldCoding], CODING_NAMES[AnsCoding]); */ \
    if (false) printf("SH %s:%d %s:%d %d %d\n", CODING_NAMES[OldCoding], anyByteHaplo(OldCoding) , CODING_NAMES[AnsCoding], \
	   anyByteHaplo(AnsCoding),					\
	   anyByteGeno(AnsCoding), set1 != Nan);			\
    assert(anyByteHaplo(OldCoding) &&					\
	   (anyByteHaplo(AnsCoding) ||					\
	    (anyByteGeno(AnsCoding) && set1 != Nan)));			\
    assert(UnCompressedDoubledCols(OldCoding, true) ==			\
	   UnCompressedDoubledCols(AnsCoding, true));			\
    Long oldIncr, oldSndIncr, ansIncr, ansSndIncr, oldNext, ansNext,	\
      cols_N = cols_list_N > 0 ? cols_list_N : OldCols,			\
      rows_N = snp_list_N > 0 ? AnsRows : OldRows;			\
    if ((sizeof(UINT)==1) xor (OldCoding == OneByteHaplo)) BUG;		\
    if ((sizeof(UCHAR)==1) xor						\
	(AnsCoding == OneByteHaplo || AnsCoding == OneByteGeno)) BUG;	\
    getHaploIncr(OldCols, OldLDA, OldCoding, 2, /* in UINT ! */		\
		 &oldNext, /* in UINT */				\
		 &oldSndIncr, /* in unit_t */				\
		 &oldIncr /* in unit_t */				\
		 );							\
    getHaploIncr(cols_N, ldAns, AnsCoding, 1 + both,			\
		 &ansNext, &ansSndIncr, &ansIncr);			\
    if (set1 == False) {						\
      Old += oldSndIncr;						\
      ansSndIncr = 0;							\
    }									\
     									\
    Long min = MIN(OldLDA, ldAns) * BytesPerUnit,			\
      nCols = 0;							\
    for (Long i=0; i<cols_N; i++) {					\
      Long ii = i;							\
      if (cols_list_N > 0) {						\
	ii = cols_list[i];						\
	if (ii >= OldCols) continue;					\
      }									\
      UCHAR *neu = (UCHAR*) (Ans + (nCols++) * ansIncr);		\
      UCHAR *neu2 = (UCHAR*) (((unit_t*) neu) +  ansSndIncr)	;	\
      MEMSET(neu, 0, ldAns * BytesPerUnit);				\
      if (doubled) MEMSET(neu2, 0, ldAns * BytesPerUnit);		\
      if (ii < 0) continue;						\
      UINT *old = (UINT*) (Old + oldIncr * ii);				\
      UINT *old2 = (UINT*) (((unit_t*) old) + oldSndIncr); /* // ((( OK */ \
      if (snp_list_N == 0) {						\
	if (sizeof(UCHAR) == sizeof(UINT)) {				\
	  MEMCOPY(neu, old, min);					\
	  if (doubled) MEMCOPY(neu2, old2, min);			\
	} else for (Long j=0; j<rows_N; j++) {				\
	    /*// printf("j=%d %d %d \n", j, old[j], old2[j]);	*/	\
	    neu[j] = (UCHAR) old[j];					\
	    if (both) neu2[j] = (UCHAR)	old2[j];			\
	  }								\
	continue;							\
      }									\
      for (Long j=0; j<snp_list_N; j++) {				\
	if (snp_list[j] >= OldRows) continue;				\
	if (snp_list[j] >= 0) {						\
	  Long idx = oldNext * snp_list[j];				\
	  *neu =  (UCHAR) old[idx];					\
	  if (both) *neu2 = (UCHAR) old2[idx];				\
	} 								\
	neu += ansNext;							\
 	neu2 += ansNext;						\
      }									\
    }									\
  }

SelectHaplo(_1Byte,_1Byte)
SelectHaplo(_4Byte,_1Byte)
SelectHaplo(_1Byte,_4Byte)
SelectHaplo(_4Byte,_4Byte)


coding_type haplo2geno(unit_t *X, Long rows, Long cols, Long lda,
		       coding_type coding,
		       int main_var, int cores,
		       unit_t *ans, Long ldAns, coding_type anscoding) {
  // endian need not be considered
  switch (coding) {
  case OneBitHaplo :
    switch (main_var) {
    case 512 :
    case 256 :
      OneBithaplo2geno256(X, rows, cols, lda, cores, ans, ldAns);
      break;
    case 128 :
      OneBithaplo2geno128(X, rows, cols, lda, cores, ans, ldAns);
      break;
    case 64:
      OneBithaplo2geno64(X, rows, cols, lda, cores, ans, ldAns);
      break;
    case 32:
      OneBithaplo2geno32(X, rows, cols, lda, cores, ans, ldAns);
      break;
    default: BUG;
    }
    return OneBitGeno;
	
  case TwoBitHaplo :
    if (anscoding == ThreeBit) {
      TwoBithaplo2geno3(X, rows, cols, lda, cores, ans, ldAns);
      return ThreeBit;
    }  
    switch (main_var) {
    case 512 :
    case 256 :      
      TwoBithaplo2geno256(X, rows, cols, lda, cores, ans, ldAns);
      break;
    case 128 :
      TwoBithaplo2geno128(X, rows, cols, lda, cores, ans, ldAns);
      break;
    case 64:
    case 32:
      TwoBithaplo2geno2(X, rows, cols, lda, cores, ans, ldAns);
      break;
    default: BUG;
    }
    return TwoBitGeno;
  default:
    PRINTF("coding '%s' (%d) in haplo2geno\n", CODING_NAMES[coding], coding);
    BUG;
  }
}


void haplo2geno(unit_t *code, Long rows, Long cols, Long lda,
		coding_type oldCoding, int variant,int cores) {//MoBPS
  Long CpB = GetCodesPerBlock(oldCoding, variant); // OK
  haplo2geno(code, ROUND_GEQ(rows, CpB),
	     cols, lda, oldCoding, main_variant(variant),
	     cores,
	     code, lda,
	     oldCoding == TwoBitHaplo ? TwoBitGeno : UnknownSNPcoding);
}


void haplo2geno(SEXP SxI, option_type *global, basic_options *opt) { //MoBPS
  extractInfo(SxI);
  haplo2geno(code, rows, cols, lda, coding, variant, GreaterZero(opt->cores));
  // info[ORIGINALLY_HAPLO] = false;
  info[CODING] = swapHaploGeno(coding, false);
  SetMatrixClass(SxI, false, global);
}


void transform(unit_t *Old, Long OrigOldRows, Long OrigOldCols,
	       Long OrigOldLDA,
	       coding_type OrigOldCoding,
	       int *row_list, int row_list_N,
	       int *col_list, int col_list_N,
	       usr_bool set1, basic_options *opt, 
	       unit_t *Ans, Long AnsRows, Long AnsCols, Long ldAns,
	       coding_type AnsCoding, int AnsVariant, usr_bool transposed) {
 
  // idea is that for matrix multiplication the ordering
  // need not be kept if the reordering is the same for each column
  // then faster algorithms might be possible

  //printf("   start trafo %s -(%d)> %s\n", CODING_NAMES[OrigOldCoding], 1 + (set1 == Nan), CODING_NAMES[AnsCoding]);

  const bool OneHaploOnly = set1 != Nan;
  bool any_selection = (row_list_N > 0 || col_list_N > 0 ||
			(OneHaploOnly && isHaplo(OrigOldCoding)));

  if (transposed == True && !any_selection) {
    assert(OrigOldRows==AnsRows && OrigOldCols==AnsCols);
    if (transpose(Old, OrigOldRows, OrigOldCols, OrigOldCoding, OrigOldLDA,
		  opt->bigendian,
		  Ans, AnsCoding, ldAns) == 0) return;
  }
  
  // printf("   genuiner Start trafo\n");

  const coding_type selCoding =
    OneHaploOnly &&  OneSet2G(OrigOldCoding) != UnknownSNPcoding
    ? OneByteGeno : OneByteHaplo;


  // printf("selCoding = %s %d %d\n", CODING_NAMES[selCoding], set1, OneHaploOnly);
  
  const Long selLDA = GetNatLDA(AnsRows, selCoding),
    safety = 3 * MAX_LDA_BITALIGN / BitsPerUnit;
  const int main_ansvar = main_variant(AnsVariant);
  const Long selMemInUnits= totalMem(AnsCols, selLDA, selCoding, OneHaploOnly);

  // printf("   LDA = %ld %ld sel=%s:%ld %ld\n",  OrigOldLDA, ldAns,  CODING_NAMES[selCoding], AnsRows, selLDA );

  coding_type tmpCoding = UnknownSNPcoding,  
    oldCoding = OrigOldCoding;
  Long
    tmp_units = 0,
    tmpLDA = 0,
    oldCols = OrigOldCols,
    oldRows = OrigOldRows,
    oldLDA = OrigOldLDA;
  int cores = GreaterZero(opt->cores);
  unit_t *old = Old,
    *neu = Ans;
   
  unit_t *tmp_unaligned = NULL,  *tmp = NULL,
    *sel_unaligned = NULL, *sel = NULL;

  bool explicit_selection_necessary = false; // dummy!

  if (Old == Ans) {
    if (oldLDA != ldAns) 
      ERR0("transformation on place impossible (different storing length)");
    if (any_selection) ERR0("selection on place never possible");
    if (set1 != Nan) ERR0("haplo selection on place never possible");
  }

  //  printf("%s -> %s %d\n", CODING_NAMES[oldCoding], CODING_NAMES[AnsCoding], explicit_selection_necessary);  
  if (AnsCoding == oldCoding && !any_selection && !transposed) {
    Long cols = oldCols * (1 + (int) doubledCols(oldCoding, false));
    Long bytes = MIN(ldAns, oldLDA) * BytesPerUnit;
    if (ldAns != oldLDA) {
     for (Long i=0; i<cols; i++)
	MEMCOPY(Ans + i * ldAns, Old + i * oldLDA, bytes);
    } else if (Old != Ans)
      MEMCOPY(Ans, Old, cols * bytes);
    goto ende;
  }


  //  printf("transform %s -> %s h=%d\n", CODING_NAMES[OrigOldCoding], CODING_NAMES[AnsCoding], isHaplo(oldCoding));
  
#define ALIGN_MALLOC(tmp, inUnits)					\
  tmp = (unit_t*) algn_generalL( (int*)(tmp##_unaligned = (unit_t*)	\
				      CALLOC((inUnits)+safety, BytesPerUnit)), \
			       MAX_LDA_BITALIGN )

  if (isHaplo(oldCoding)) {
    if (transposed == True) ERR0("trnspoed of haplo not programmed yet.\n");;
    //   printf("!!haplo %d %d %d\n", row_list_N, col_list_N, any_selection);
     
    // Special cases, already coded directly
    if (!any_selection &&
	((oldCoding == OneBitHaplo && AnsCoding == OneBitGeno) ||
	 (oldCoding == TwoBitHaplo && ( AnsCoding == TwoBitGeno ||
					AnsCoding == ThreeBit)))) {
      haplo2geno(old, oldRows, oldCols, oldLDA, oldCoding, main_ansvar, 
		 cores, Ans, ldAns, AnsCoding);
      goto ende;
    }

    if (anyByteHaplo(oldCoding) &&
	(anyByteHaplo(AnsCoding) || (anyByteGeno(AnsCoding) && set1 != Nan)) &&
	UnCompressedDoubledCols(oldCoding, false) ==
	 UnCompressedDoubledCols(AnsCoding, true) ) {
      if (isOneByteHaplo(oldCoding, false))
	SelectHaplo_1Byte_4Byte(Old, oldRows, oldCols, oldLDA, oldCoding,
				row_list, row_list_N, col_list, col_list_N,
				set1, Ans, AnsRows, ldAns, AnsCoding,
				transposed);
      else 
	SelectHaplo_4Byte_4Byte(Old, oldRows, oldCols, oldLDA, oldCoding,
			      row_list, row_list_N, col_list, col_list_N,
			      set1, Ans, AnsRows, ldAns, AnsCoding,
				transposed);
      goto ende;   
    }

    if (oldCoding == OneByteHaplo) {
      //printf("EQUAL\n");
      
      tmp = Old;        
      tmpCoding = oldCoding;
      tmpLDA = oldLDA;
    } else {
      // general case
      tmp = Ans;        // corresponds to AnsCoding
      tmpCoding = AnsCoding;
      tmpLDA = ldAns;
      if (anyByteHaplo(oldCoding)) {
	// printf("UnCompressedDoubledCols(oldCoding, true)=%d\n", UnCompressedDoubledCols(oldCoding, true));
	if (UnCompressedDoubledCols(oldCoding, true) && any_selection) {
	  if (!isOneByteHaplo(tmpCoding, OneHaploOnly)) {
	    tmpCoding = selCoding;
	    tmpLDA = selLDA;
	    ALIGN_MALLOC(tmp, selMemInUnits);
	  }
	  SelectHaplo_4Byte_1Byte(Old,
				  oldRows, oldCols, oldLDA, oldCoding,
				  row_list, row_list_N, col_list, col_list_N,
				  set1,
				  tmp, AnsRows, tmpLDA,
				  tmpCoding,
				  transposed);
	  transposed = False;
	  explicit_selection_necessary = false;
	  /// set1 = set1 == False ? True : set1; WARUM?!
	  // Stattdessen?!:
	  set1 = Nan;
	  row_list_N = 0;
	} else {
	  explicit_selection_necessary = row_list_N > 0 || OneHaploOnly;
	  if (explicit_selection_necessary || !isCompressedHaplo(AnsCoding)) {
	    tmpCoding = selCoding;
	    tmpLDA = GetNatLDA(oldRows, tmpCoding); // not selRows!
	    Long mem1ByteInUnits = totalMem(oldCols, tmpLDA, tmpCoding,
					    OneHaploOnly);
	    ALIGN_MALLOC(tmp, mem1ByteInUnits); ////// !!!!!!!!
	  }
	  codeHaplo(Old, oldRows, oldCols, oldLDA, oldCoding, 
		    col_list, col_list_N,
		    opt, tmp, AnsCols, tmpLDA, tmpCoding);
	}	
      } else { // ! anyByteHaplo(oldCoding)
	explicit_selection_necessary = row_list_N > 0;
 	if (isUnCompressed(AnsCoding) && !explicit_selection_necessary) {
	  //	  printf("immediate\n");
	  decodeHaplo(Old, oldRows, oldCols, oldLDA, oldCoding,
		      col_list, col_list_N, set1, cores,
		      tmp, AnsCols, tmpLDA, tmpCoding);
	} else {// !nyByteHaplo(oldCoding) && (row_list_N > 0 || ...)
	  tmpCoding = selCoding;
	  tmpLDA = GetNatLDA(oldRows, tmpCoding); // not selRows!
	  //	  printf("slow %s %d; %d %d\n", CODING_NAMES[AnsCoding], anyByteHaplo(AnsCoding),  row_list_N , explicit_selection_necessary);
	  Long mem1ByteInUnits = totalMem(oldCols, tmpLDA, tmpCoding,
					  OneHaploOnly);
	  ALIGN_MALLOC(tmp, mem1ByteInUnits);	////// !!!!!!!!  
	  decodeHaplo(Old, oldRows, oldCols, oldLDA, oldCoding,
		      col_list, col_list_N, set1, cores,
		      tmp, AnsCols, tmpLDA, tmpCoding);
	}
	/// set1 = set1 == False ? True : set1;
	// Stattdessen?!:
	  set1 = Nan;
      } // !anyByteHaplo(oldCoding)
      col_list_N = 0;
    } // oldCoding != OneByteHaplo
    
    if (tmp == Ans) {
      assert(!explicit_selection_necessary);
      goto ende;
    }
    
    if (!OneHaploOnly) { // OneHaploOnly may or may not be true
      assert(tmpCoding == OneByteHaplo);
  
      if (isFourByteHaplo(AnsCoding, OneHaploOnly)) {
	SelectHaplo_1Byte_4Byte(tmp,
			       oldRows, AnsCols, tmpLDA, tmpCoding,
			       row_list, row_list_N, col_list, col_list_N,
				set1, Ans, AnsRows, selLDA, selCoding,
			       transposed);	
	goto ende;
      }

      if (explicit_selection_necessary) { // i.e., row_list_N > 0
	if (isOneByteHaplo(AnsCoding, OneByteHaplo)) sel = Ans;
	else ALIGN_MALLOC(sel, selMemInUnits);
	
	SelectHaplo_1Byte_1Byte(tmp,
				oldRows, AnsCols, tmpLDA, tmpCoding,
				row_list, row_list_N, col_list, col_list_N,
				set1,
				sel, AnsRows,  selLDA,
				selCoding,transposed);	
	if (sel == Ans) goto ende;
	transposed = False;
	assert(set1 == Nan);
 	row_list_N = col_list_N = 0;
        explicit_selection_necessary = false;
	FREE(tmp_unaligned);
	tmp_unaligned = sel_unaligned;
	tmp = sel;
	sel_unaligned = NULL;
	tmpCoding = selCoding;
	tmpLDA = selLDA;	
      }
      
      //      printf("here %d %d %s -> %s -> %s\n", tmp == Ans, tmp == Old, CODING_NAMES[oldCoding], CODING_NAMES[tmpCoding],  CODING_NAMES[AnsCoding]);
      
      if (isHaplo(AnsCoding)) {
	decodeHaplo(tmp, AnsRows, AnsCols, tmpLDA,  tmpCoding, 
		    col_list, col_list_N, set1, cores,
		    Ans, AnsCols, ldAns, AnsCoding);
	goto ende;
      }

      // halplo --> geno !
      OneByteHaplo2geno64(tmp, AnsRows, AnsCols, tmpLDA, cores, tmp, tmpLDA);
      oldRows = AnsRows;
    } else { // OneHaploOnly      
      if (set1==False)
	MEMCOPY(tmp, tmp + tmpLDA * AnsCols, tmpLDA * AnsCols * BytesPerUnit);
      explicit_selection_necessary = row_list_N > 0; 
      oldRows = explicit_selection_necessary ? oldRows : AnsRows; // note:
      // row_list_N may have changed value !
    }
    
    old = tmp;
    oldCoding = OneByteGeno;
    oldLDA = GetNatLDA(oldRows, oldCoding);
    oldCols = col_list_N;
    oldRows = row_list_N;
    any_selection = explicit_selection_necessary;
  }
  
  //////////////////// END HAPLO //////////////////////


  //  printf("start geno %s %s\n", CODING_NAMES[OrigOldCoding], CODING_NAMES[oldCoding]);

  //////////////////// START GENO /////////////////////
  assert(!isHaplo(oldCoding));
  assert(sel_unaligned==NULL); 
  if (isHaplo(AnsCoding))
    ERR0("Genotype matrix cannot be transformed into a haplotype matrix");

  
  if (oldCoding == FourByteGeno && AnsCoding == FourByteGeno) {
    // either selection or different lda
    SelectGeno_4Byte_4Byte(old, oldRows, oldCols, oldLDA,
			   row_list, row_list_N, col_list, col_list_N,
			   Ans, ldAns, transposed // eigene Zeile wg findallM
			 );
    goto ende;
  }
  
  if (any_selection) {
    //    printf("%s --> %s\n", CODING_NAMES[oldCoding], CODING_NAMES[AnsCoding]);
    
    if (AnsCoding == OneByteGeno || AnsCoding == FourByteGeno) sel = Ans;
    else ALIGN_MALLOC(sel, selMemInUnits);
    if (oldCoding == FourByteGeno) {
      assert(tmp_unaligned==NULL); // as tmp_unaligned is set only if Haplo
      SelectGeno_4Byte_1Byte(old, oldRows, oldCols, oldLDA,
			     row_list, row_list_N, col_list, col_list_N,
			     sel, selLDA, transposed);
    } else {
      coding_type TempCoding= oldCoding;
      Long TempLDA = oldLDA;
      unit_t *Temp_unaligned = tmp_unaligned,
	*Temp = old;
      // printf("TempNULL = %d %s \n", Temp_unaligned==NULL, CODING_NAMES[oldCoding] );
      if (oldCoding == OneByteGeno) {
	assert((tmp_unaligned == NULL) xor (old == sel)); // coming from Haplo?
	tmp_unaligned = NULL;
      } else {
	assert(tmp_unaligned == NULL);
	if (!isCompressed(oldCoding)) BUG;
	TempCoding = OneByteGeno;
	TempLDA = GetNatLDA(oldRows, TempCoding);
	Long memInUnitsTemp = totalMem(oldCols, TempLDA, TempCoding);
	ALIGN_MALLOC(Temp, memInUnitsTemp);
	assert(Temp_unaligned != NULL);
	matrix_get_1Byte(old, oldRows, oldCols, oldCoding, oldLDA, 
			 cores, Temp, TempLDA, False);
      }
      if (AnsCoding == FourByteGeno) {
	assert(sel != NULL);
	//assert(sel == Ans);
	
	SelectGeno_1Byte_4Byte(Temp, oldRows, oldCols, TempLDA,
			       row_list, row_list_N, col_list, col_list_N,
			       sel, ldAns, transposed);
	FREE(Temp_unaligned);
 	goto ende;
      } else {
	SelectGeno_1Byte_1Byte(Temp, oldRows, oldCols, TempLDA,
			       row_list, row_list_N, col_list, col_list_N,
			       sel,  selLDA, transposed);
      }
      FREE(Temp_unaligned);
    } // oldCoding != FourByteGeno
    if (sel == Ans) goto ende;    
    transposed = False;
    old = sel;
    oldRows = AnsRows;
    oldCols = AnsCols;
    oldCoding = OneByteGeno;
    oldLDA = selLDA;
  }

  ///// no selection ////

  if (anyByteGeno(AnsCoding)) {
    //    printf("ans = 4Byte (%s->%s)\n", CODING_NAMES[oldCoding], CODING_NAMES[AnsCoding]);
    
    if (AnsCoding == FourByteGeno)
      matrix_get_4Byte(old, oldRows, oldCols, oldCoding, oldLDA,
		       cores, Ans, ldAns, transposed);
    else if (AnsCoding == OneByteGeno)
      matrix_get_1Byte(old, oldRows, oldCols, oldCoding, oldLDA,
		       cores, Ans, ldAns, transposed);
    else BUG;
    
    goto ende;
  }

  //  printf("reaching switch oldCoding\n");
  assert(tmp_unaligned == NULL);
  tmpCoding = OneByteGeno;
  tmpLDA = GetNatLDA(transposed == False ? oldRows : oldCols, tmpCoding);
  tmp_units = totalMem(transposed == False ? oldCols : oldRows,
		       tmpLDA, tmpCoding, OneHaploOnly);

  switch(oldCoding) {
  case OneBitGeno:{
    if (transposed == True) goto via_1Byte;
    switch (AnsCoding) {
    case TwoBitGeno:
      switch (main_ansvar) {
      case 512 : case 256 : case 128 :
	if (opt->bigendian) {
	  if (old == Ans) {
	    ALIGN_MALLOC(tmp, tmp_units); 
	    neu = tmp;
	  }
	  trafo1Geno2Geno128(old, oldRows, oldCols, oldLDA, neu, ldAns);
	  goto copy;
 	}
	FALLTHROUGH_OK;
      case 64: case 32: 
	MEMCOPY(Ans, old, oldLDA * oldCols * BytesPerUnit);
	old = Ans;
	goto via_1Byte; 	
      default: BUG;
      }
      break;
    case ThreeBit:
      if (ldAns < oldLDA) ERR0("transformation to 3bit not possible");
      MEMCOPY(Ans, old, oldLDA * oldCols * BytesPerUnit);  
      old = Ans;
      goto via_1Byte;
    default: BUG;
    }
  }
    break;
    
  case Plink:
  case TwoBitGeno:
    if (transposed == False) {
      switch (AnsCoding) {
      case OneBitGeno:
	if (oldCoding == Plink) BUG;
	switch (main_ansvar) {
	case 512 : case 256 : case 128 :
	if (opt->bigendian) {
	  if (old == Ans) {
	    ALIGN_MALLOC(tmp, tmp_units);    
	    neu = tmp;
	  }
	  trafo2Geno1Geno128(old, oldRows, oldCols, oldLDA, neu, ldAns);
	  goto copy;
	}
	FALLTHROUGH_OK;
	case 64: case 32:
	  MEMCOPY(Ans, old, oldLDA * oldCols * BytesPerUnit);
	old = Ans;
	goto via_1Byte;
	default: BUG;
	}
	break;
      case FiveCodes:
	//  printf("bigendian = %d\n", opt->bigendian);
	if (opt->bigendian) BUG;
	if (old == Ans) BUG;
	switch (main_ansvar) {
	case 512 : case 256 : case 128 :
	  trafo2Geno5codes256(old, oldRows, oldCols, oldLDA, oldCoding,
			      cores,
			      neu, ldAns);
	  goto copy;
      case 64: case 32:
	trafo2Geno5codes32(old, oldRows, oldCols, oldLDA, oldCoding,
			   cores, neu, ldAns);
	goto copy;
	default: BUG;
	}
	break;
      case ThreeBit:
	if (oldCoding == Plink) BUG;
	if (ldAns < oldLDA) ERR0("transformation to 3bit not possible");
	MEMCOPY(Ans, old, oldLDA * oldCols * BytesPerUnit);
	old = Ans;
	goto via_1Byte;
      default: BUG;
      }
    } else {
      switch (AnsCoding) {
      case FiveCodes: 
	if (opt->bigendian) BUG;
	if (old == Ans) BUG;
	switch (main_ansvar) {
	case 512 : case 256 : case 128 :
	  trafo2Geno5codestrans256(old, oldRows, oldCols, oldLDA, oldCoding,
				   cores, 
				   neu, ldAns);
	  goto copy;
	case 64: case 32:
	  trafo2Geno5codestrans32(old, oldRows, oldCols, oldLDA, oldCoding,
				  cores,
				  neu, ldAns);
	  goto copy;
	default: BUG;
      }
	break;
      default: goto via_1Byte;
      }
    }
    break;
    
  case ThreeBit :
  case OneByteGeno:
    //    printf("onebyte via 1Byte");
    goto via_1Byte;
    
  case FourByteGeno : {
     coding_t
      coding_uint = matrix_coding_4Byte(AnsCoding, &transposed,
					AnsVariant, opt->bigendian);
     if (coding_uint == NULL) goto via_1Byte;

     //    printf("ldAns=%ld\n", ldAns);
    
    coding_uint(old , oldLDA, 0, oldRows, 0, oldCols, 
		cores, NULL, Ans, oldCols, transposed, ldAns);
    goto ende;
  }

  case OrigPlink :
    switch (AnsCoding) {
    case FiveCodes:
      if (transposed == False) 
	origplink2Geno5codes32((Uchar*) old, oldRows, oldCols, cores,
			    Ans, ldAns);
      else
	origplink2Geno5codestrans32((Uchar*) old, oldRows, oldCols, cores,
				    Ans, ldAns);	  
      goto ende;
    default : BUG;
    }

  
  case FourBit :
  case TwoByte :
  case FiveCodes :
	   
  case DotFile:
  case FileDot:
  case CorrespondingGeno :
  case UnknownSNPcoding :
  default: // programming error
    //
    PRINTF("Unknown coding %s (%d)\n", CODING_NAMES[oldCoding], oldCoding);
    BUG;
  }

 via_1Byte :
  tmpCoding = OneByteGeno;
  if (oldCoding == tmpCoding) {
    tmp = old;
    tmpLDA = oldLDA;
  } else {
    tmpLDA = GetNatLDA(transposed == False ? oldRows : oldCols, tmpCoding);
    if (tmp_unaligned == NULL) ALIGN_MALLOC(tmp, tmp_units);
    matrix_get_1Byte(old, oldRows, oldCols, oldCoding, oldLDA,
		     cores, tmp, tmpLDA, transposed);
    transposed = False;
  }
  if (tmp == Ans) BUG;
  coding_t matrix_coding;
  matrix_coding = matrix_coding_1Byte(AnsCoding, &transposed,
				      AnsVariant, opt->bigendian);
  if (matrix_coding == NULL) BUG;
  matrix_coding(tmp, tmpLDA,
		0, oldRows, 0, oldCols,
		cores, NULL,
		Ans, oldCols, transposed, ldAns);
  assert(neu == Ans);
  
 copy :  
  if (neu != Ans) {
    Long memInUnits = totalMem(AnsCols, ldAns, AnsCoding, set1);
    MEMCOPY(Ans, neu, memInUnits * BytesPerUnit);
  }
			
 ende :
  FREE(sel_unaligned);
  FREE(tmp_unaligned);
}


SEXP AnsParam(Long snps, Long individuals, usr_bool transposed,
	      int *selSnps, int lenSelSnps,
	      int *selIndiv, int lenSelIndiv,
	      usr_bool set1, bool add_transposed,
	      option_type *global, utilsoption_type *utils,
	      SEXP reusedSxI,
	      coding_type ansCoding, 
	      usr_bool ansTransposed,
	      int variant,
	      int **selRows, int *lenSelRows,
	      int **selCols, int *lenSelCols
	      ) {
  Long AnsSnps = snps;
  Long AnsIndiv = individuals;
  
  if (lenSelSnps > 0) {
    // comfortable to give "to the end" by 1:n where n is just
    // as large as than the genuine size!
    // So, at the end, values exceeding the genine size are expected:
    while (lenSelSnps >= 0 && selSnps[lenSelSnps -1] >= snps)
      lenSelSnps--;    
    AnsSnps = 0;
    for (Long i=0; i<lenSelSnps; i++) AnsSnps += selSnps[i] < snps;
    if (AnsSnps == 0) ERR0("SNP selection out of range");
  }
  if (lenSelIndiv > 0) {
    while (lenSelIndiv >= 0 && selIndiv[lenSelIndiv-1] >= individuals)
      lenSelIndiv--;
    AnsIndiv = 0;
    for (Long i=0; i<lenSelIndiv; i++)
      AnsIndiv += selIndiv[i] < individuals; 
    if (AnsIndiv == 0) ERR0("individual selection out of range");
  }
  
  bool OneHaploOnly = set1 != Nan;
  
  *lenSelRows = lenSelSnps;
  *lenSelCols = lenSelIndiv;
  *selRows = selSnps;
  *selCols = selIndiv;
  
  if (transposed == True) {
    int tmp= *lenSelRows; *lenSelRows= *lenSelCols; *lenSelCols=tmp;
    int *tmpList = *selRows; *selRows = *selCols; *selCols=tmpList;
  }

  assert(ansTransposed == False || ansTransposed == True);
  SEXP Ans = PROTECT(CompleteCodeVector(AnsSnps, AnsIndiv, ansCoding,
					ansTransposed, add_transposed,
					variant, 0, OneHaploOnly,
					global, utils,
					NULL,
					NULL,
					reusedSxI));
  UNPROTECT(1);
 
  return Ans;
}


SEXP transform(SEXP SxI,
	       int *selSnps, int lenSelSnps,
	       int *selIndiv, int lenSelIndiv,
	       usr_bool set1, bool add_transposed,
	       option_type *global, utilsoption_type *utils,
	       bool transformOnPlace,
	       coding_type ansCoding, usr_bool AnsTransposed,
	       int ansVariant) {
  basic_options *opt = &(utils->basic);
  extractInfo(SxI);
  
  //  printf("XXXAA %ld %ld\n", snps, individuals);
  int *selRows, lenSelRows, *selCols, lenSelCols;
  SEXP Ans = PROTECT(AnsParam(snps, individuals, transposed,
			      selSnps, lenSelSnps,
			      selIndiv, lenSelIndiv,
			      set1, add_transposed,
			      global, utils,
			      transformOnPlace ? SxI : R_NilValue,
			      ansCoding, AnsTransposed, ansVariant,
			      &selRows, &lenSelRows,
			      &selCols, &lenSelCols
			      ));
  
  SEXP Out = Ans,
    In = SxI;
  while (Out != R_NilValue) {
     extractNamedInfo(In);
     extractNamedInfo(Out);
     // printf("looping in while %ld %ld %ld %ld\n",snpsIn, individualsIn, snpsOut, individualsOut);
   bool transposition_needed = transposedIn != transposedOut;
    transform(codeIn, rowsIn, colsIn, ldaIn, codingIn, 
	      selRows, lenSelRows, selCols, lenSelCols,
	      set1, opt,
	      codeOut, rowsOut, colsOut, ldaOut, codingOut,variantOut,
	      transposition_needed ? True : False);    
    Out = getAttribPointer(Out, Next);
    SEXP orig = getAttribPointer(In, Next);
    if (orig != R_NilValue) In = orig;
  }

  UNPROTECT(1);
  //  printf("ende transform XXXAA\n");
  return Ans;  
}


int zaehler = 0;
 
SEXP transform(void *pointer, void *nextpntr,
	       Long snps, Long individuals,
	       coding_type coding, 
	       usr_bool pointer_is_transposed,
	       Long LDAbitalign,
	       int* selSnps, int lenSelSnps,
	       int *selIndiv, int lenSelIndiv,
	       usr_bool set1, bool add_transposed,
	       option_type *global, utilsoption_type *utils,
	       coding_type ansCoding,  usr_bool ansTransposed,
	       int ansVariant) {
  // printf("enterin\n");
  basic_options *opt = &(utils->basic);
  bool check_included = ansCoding == TwoBitGeno ||
    ansCoding == OneBitGeno || ansCoding == Plink ||
    anyByteHaplo(coding);
  if (!opt->skipchecks && !check_included &&
      (isUnitAligned(coding) || is32BitAligned(coding))) {
    bool ok = true;
    Long total = snps * individuals;
    if (is32BitAligned(coding)) {            
      Uint *SxIU = (Uint*) pointer;
      for (Long i=0; i<total; i++) ok &= SxIU[i] <= 2;
    } else {
      unit_t *SxIU = (unit_t*) pointer;
      for (Long i=0; i<total; i++) ok &= SxIU[i] <= 2;
    }
    if (!ok)  ERR0("SNP matrix nay have only the values 0,1,2");
  }

  //  printf  ("XXX\n");
  bool no_select = lenSelSnps == 0 && lenSelIndiv == 0;
  if (coding == ansCoding && pointer_is_transposed == ansTransposed &&
     no_select && set1 == Nan) {
    // printf("completing\n");
    assert(ansTransposed == False || ansTransposed == True);
   return CompleteCodeVector(snps, individuals, coding,
			     ansTransposed, add_transposed,
			     ansVariant, LDAbitalign, false,
			     global, utils,
			     pointer, nextpntr,
			     R_NilValue);
  }

  //  printf("creatins\n");

  if ( ((pointer_is_transposed==False) xor (ansTransposed==False)) &&
       nextpntr != NULL) {    pointer_is_transposed =
      pointer_is_transposed == False ? True : False;
    void *tmp = pointer; pointer = nextpntr; nextpntr = tmp;
  }

  int *selRows, lenSelRows, *selCols, lenSelCols;
  SEXP Ans = PROTECT(AnsParam(snps, individuals, pointer_is_transposed,
			      selSnps, lenSelSnps,
			      selIndiv, lenSelIndiv,
			      set1, add_transposed,
			      global, utils, R_NilValue,
			      ansCoding, ansTransposed, ansVariant,
			      &selRows, &lenSelRows,
			      &selCols, &lenSelCols
			     ));

  

  Long rowsIn = pointer_is_transposed == False ? snps : individuals,
    colsIn = pointer_is_transposed != False ? snps : individuals;
  
  if (LDAbitalign == NA_LONG || LDAbitalign == 0)
    LDAbitalign = GetLDAbitalign(coding);
  
  SEXP Out = Ans;
  while (Out != R_NilValue) {
    extractNamedInfo(Out);

    
    bool transposition_needed = pointer_is_transposed!=transposedOut;
    transform((unit_t*) pointer, rowsIn, colsIn,
	      GetLDA(rowsIn, coding, LDAbitalign), coding, 
	      selRows, lenSelRows, selCols, lenSelCols,
	      set1, opt,
	      codeOut, rowsOut, colsOut, ldaOut, codingOut,variantOut,
	      transposition_needed ? True : False);

    zaehler++;
   if (zaehler==1) {
     /* printf("%ld %d ", ALONG codeOut, zaehler);
     // for (int ii=0; ii<5; ii++) printf("%u ", codeOut[ii]); printf("\n");
     */
    }
    
    Out = getAttribPointer(Out, Next);
    if (nextpntr != NULL) {
      pointer_is_transposed =
	pointer_is_transposed == False ? True : False;
      Long tmpIn = rowsIn; rowsIn = colsIn; colsIn = tmpIn;
      int tmp = lenSelRows; lenSelRows=lenSelCols; lenSelCols=tmp;
      int *tmpList = selRows; selRows = selCols; selCols=tmpList;
      pointer = nextpntr;
      nextpntr = NULL;
    }
  }
  
  UNPROTECT(1);
  return Ans;
}





  
