/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/


#ifndef miraculix_scan_h 
#define miraculix_scan_h 1

void scanC(int *positions, int *length, double  *freq, int *minscan,
	   int *maxscan, double *threshold, int *nthres, int *PER_SNP,
	   int *above_threshold,  double *maximum);

SEXP collect_scan(int *positions, int *length, double  *freq, int *minscan,
		  int *maxscan, double *threshold, int *nthres,
		  int *PER_SNP, 
		  // additional return values:
		  int *areas,  double *value);
SEXP collect_scan2(int *positions, int *length, double  *freq, int *minscan,
		   int *maxscan, double *threshold, int *nthres,
		   int *PER_SNP, 
		   int max_intervals, int max_basepair_dist,
		   bool exclude_negative,
		   // additonal return values
		   int *above_threshold, double *maximum);

void sumscanC(int *positions, int *length, double  *freq, 
	     int *minscan,  int *maxscan, double *threshold, int *nthres,
	     int *PER_SNP,
	      int *above_threshold,  double *maximum);

#endif
