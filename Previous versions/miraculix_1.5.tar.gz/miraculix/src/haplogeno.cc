/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/


// _MM_ALIGN16 Uint ccc;

#include "Basic_miraculix.h"
#include "compatibility.general.h"
#include "Template.h"
#include "haplogeno.h"
#include "utils_miraculix.h"
#include "extern.h"
#include "mmagpu.h"
#include "transform.h"


#include "MXinfo.h"
#include "intrinsicsCheck.h"
#include "intrinsics_specific.h"
#include "Haplo.h"
#include "Files.h"
#include "1bit.h"
#include "bitBase.h"
#include "2bit.h"
#include "3bit.h"
#include "5codes.h"
#include "OneByte.h"
#include "4Byte.h"
#include "plink.h"
#include "Vector.matrix.h" 
#include "kleinkram.h"




void allInfo(Long *info) { // ok
  for (int j=0; j<=INFO_GENUINELY_LAST; j++) {
    PRINTF("%s=", INFO_NAMES[j]);
    switch(j) {
    case CODING : PRINTF("%s", CODING_NAMES[info[CODING]]); break;
    case TRANSPOSED : PRINTF("%s", info[TRANSPOSED] == 0 ? "False"
			     : info[TRANSPOSED] == 1 ? "True" : "NaN"); break;
    case VARIANT : PRINTF("implementation %ld", ALONG info[VARIANT]); break;
    case ADDR : PRINTF(" %ld",  ALONG info[ADDR]); break;
    case MEMinUNITS : PRINTF("%ld", ALONG info[MEMinUNITS]); break; // OK
    default:
      if (info[j] == NA_LONG) PRINTF("NA"); else PRINTF("%ld", ALONG info[j]);// OK
    }
    PRINTF("\n");
  }
}
void allInfo(SEXP M) { // ok
  Long *info = GetInfoUnchecked(M);
  if (info == NULL) BUG;
  allInfo(info); // ok
}
 

Long GetBytesPerBlock(coding_type coding, int variant) {
  variant = main_variant(variant);
  if (variant <= 1024) return variant >> 3;
  if (variant == VARIANT_GPU)
    return coding == FourByteGeno ? 4 : (256 >> 3);
  if (variant == VARIANT_R) return 4; 
  BUG; 
  return 0;
}


Long GetCodesPerBlock(coding_type coding, int variant) {
#define twobits 2  
  Long BpB = GetBytesPerBlock(coding, variant);
  Long codes;
  switch (coding) {
  case OneBitGeno: case OneBitHaplo: codes = BpB * BitsPerByte; break;
  case TwoBitGeno: case Plink: case OrigPlink: case TwoBitHaplo:   
    codes = BpB * BitsPerByte / twobits; break;
  case ThreeBit : codes = CodesPerBlock3(); break;
  case FourBit : BUG; break;
  case OneByteGeno :  codes = BpB; break;
  case TwoByte : BUG; break;
  case FiveCodes : codes = 5 * BpB; break;
  case FourByteGeno : codes = BpB / 4; break;
  case OneByteHaplo: codes = BpB; break;
  case FourByteHaplo: codes = BpB / 4; break;
  case FourByteSingleBit: codes = BpB / 4; break;    
  case EightByteHaplo: codes = BpB / 8; break;
  case FileDot:
  case DotFile : codes = 100; break; // arbitrary number
  default : BUG;
  }
  return codes;
}


Long GetCodesPerUnit(coding_type coding) { // OK
  // ACHTUNG: EightHaplo braucht 2 U n i t  per Code
  int variant = 64;
  Long zaehler = GetCodesPerBlock(coding, variant) * BytesPerUnit, // OK
    nenner = GetBytesPerBlock(coding, variant);
  //printf("zaehler /nenneer %ld %ld %ld\n", ALONG zaehler, ALONG nenner, ALONG GetCodesPerBlock(coding, variant));
  if (zaehler % nenner) BUG;
  return  zaehler / nenner; // OK
}


Long GetLDA(Long rows, coding_type coding, Long LDAbitalign) {
  // LDA in Einheiten von unit_t
  assert(rows == 1 || LDAbitalign > 0);
  if (LDAbitalign % BitsPerUnit != 0) // OK
    ERR1("bit alignment not multiple of %d", BitsPerUnit); // OK
  Long lda;
  switch(coding) {
  case OneBitGeno : case OneBitHaplo : lda = Lda1Bit(rows, LDAbitalign); break;
  case TwoBitGeno : case TwoBitHaplo : lda = Lda2Bit(rows, LDAbitalign); break;
  case ThreeBit : lda = Lda3(rows, LDAbitalign); break;
  case FourBit : BUG;
  case OneByteGeno :
  case OneByteHaplo : lda = LdaOneByte(rows, LDAbitalign); break;
  case TwoByte: BUG;
  case FourByteGeno : lda = LdaPlain(rows, LDAbitalign); break;
   case FourByteHaplo : lda = LdaPlain(rows, LDAbitalign); break;
  case Plink : lda = LdaPlink(rows, LDAbitalign); break;
  case OrigPlink : lda = LdaOrigPlink(rows, LDAbitalign); break; // ldaInByte
  case FiveCodes : lda = LdaFiveCodes(rows, LDAbitalign); break;
  case FourByteSingleBit : lda = LdaPlain(rows, LDAbitalign); break;
  case EightByteHaplo : lda = LdaPlainDoubled(rows, LDAbitalign); break;
    break;
  default :
    PRINTF("unknown '%s' %d\n", CODING_NAMES[coding],coding);
    BUG;
  }
  if (lda == 0) BUG;
  // printf("lda=%ld\n",ALONG  lda);
  return lda;
}


  
Long GetLDAbitalign(coding_type coding) {
  // assuming that rows=1 behaves adequately
  return GetLDA(1L, coding, 0) * BitsPerUnit;  // OK
}

Long GetNatLDA(Long rows, coding_type coding) { // LDA in unit_t
  return GetLDA(rows, coding, GetLDAbitalign(coding));
}


Long totalMem(Long cols,
	      Long lda, // in units  unit_t  except OrigPlink
	      coding_type coding,
	      bool OneHaploOnly, bool relaxed) {
  assert(lda > 0);
  
  if (has_ld_in_Byte(coding)) lda = DIV_GEQ(lda, sizeof(unit_t));
  if (isHaplo(coding) && OneHaploOnly) {
    //printf("%s \n", CODING_NAMES[coding]);
    coding_type new_coding = OneSet2G(coding);
    if (new_coding == UnknownSNPcoding)
      ERR2("one haplo for '%s [%d]' unknown", CODING_NAMES[coding], coding);
    coding = new_coding;
  }
  if (coding == FiveCodes) cols = (1L + (cols - 1L) / 20L) << 2;
  else if (doubledCols(coding, relaxed) && (!isHaplo(coding) || !OneHaploOnly))
    cols <<= 1;
  //  printf("total mem=%ld\n", lda * cols);
  return lda * cols;
}

Long totalMem(Long cols, Long lda, coding_type coding, bool OneHaploOnly) {
  // in units unit_t  !!!
  return totalMem(cols, lda, coding, OneHaploOnly, false);
}

Long totalMem(Long cols, Long lda, coding_type coding) {
  // in units unit_t  !!!
  return totalMem(cols, lda, coding, false, false);
}

Long calculateAlignedMem(Long memInUnits, coding_type coding) {
  if (isUnitAligned(coding)) {
    // R is 32bit-aligned. So no additional alignment considerations
    // necessary. Do not add safe byte either, since vector/matrix
    // returned in readable form to user
    return memInUnits;
  }

  Long UPB = MAX_LDABITALIGN / (sizeof(unit_t) * BitsPerByte); // MAX_LDABITALIGN always save 
  Long mem = ROUND_GEQ(memInUnits, UPB);

  return mem; // 27.5.24 all loads/stores are unaligned!

  // printf("%d mem = %ld %ld %ld\n",MAX_LDABITALIGN,  mem, UPB, UPB << 1);
   
  // + 1 UPB : starting point for alignedmem 
  // + 1 UBP : safely at the end
  mem += UPB << 1;
  
  return mem;
}


void SetMatrixClass(SEXP SxI, bool haplo, option_type *global) {
  //  printf("class: haplo=%d\n", haplo);
  Long *info = GetInfo(SxI);
  info[ISHAPLO] = haplo;  
  if (global->genetics.no_class) return;
  
  // 200 bytes:
  SEXP Klasse;
  PROTECT(Klasse = allocVector(STRSXP, 1));
  SET_STRING_ELT(Klasse, 0, mkChar(haplo ? HAPLOMATRIX : GENOMICMATRIX));
  SET_CLASS(SxI, Klasse);
  UNPROTECT(1);
}


Long  CECV = 0;
inline static void swap(Long *A, Long *B) { Long tmp = *A; *A = *B; *B=tmp; }
SEXP CompleteCodeVector(Long snps, Long individuals, coding_type coding,
			usr_bool transposed, bool add_transposed_matrix,
			int variant, Long LDAbitalign, bool OneHaploOnly,
			option_type *global, utilsoption_type *utils,
			void* pointer, // to some existing memory
			void* nextpointer, // to some existing memory
			SEXP SxI) {
  //  printf("CompleteCV coding = %.50s %d %ld 1haploOnly=%d\n", CODING_NAMES[coding], variant, LDAbitalign, OneHaploOnly);
  
  Long rows = snps,
    cols = individuals;
  if (transposed != False) {
    if (transposed != True) BUG;
    Long tmp = rows; rows = cols; cols = tmp;
  }
  basic_options *opt = &(utils->basic);
  SEXP Info = R_NilValue;
  Long *info;
  Long
    lda = 0,
    memInUnits =0,
    alignedMem = 0;
  bool SxIGiven = SxI != R_NilValue,
    IsHaplo = false;
  if (SxIGiven && pointer != NULL) BUG;
  if (pointer == NULL && nextpointer != NULL) BUG;
  //  coding_type newcoding = UnknownSNPcoding;
  if (SxIGiven) {
#if defined compatibility_to_R_h
    PROTECT(SxI);
#endif  
    Info = getAttribPointer(SxI, Information);
  }
  bool info_new = Info == R_NilValue;
  if (info_new) {
    PROTECT(Info = allocVectorExtra(LONGSXP, (INFO_LAST + 1) ));
    info = LONG(Info);
    for (int j=0; j<=INFO_LAST; j++) info[j] = NA_LONG; // OK
    info[MISSINGS] = 0;
  } else {
#if defined compatibility_to_R_h
    PROTECT(Info);
#endif  
    info = LONG(Info);
  }
  
  if (info[BIGENDIAN] == NA_LONG)// happens also in case of filename  
    info[BIGENDIAN] = opt->bigendian;
  else if (info[BIGENDIAN] != opt->bigendian) 
    ERR2("big/little endian do not match (info=%ld; param=%d)",
	 ALONG info[BIGENDIAN], opt->bigendian);// long OK
 

  if (info[IMPLEMENTATION] == NA_LONG)
    info[IMPLEMENTATION] = CURRENT_IMPLEMENTATION;
  else if (info[IMPLEMENTATION] != CURRENT_IMPLEMENTATION) 
    ERR0("SNP matrix in obsolete format cannot be read");
  
  
  if (info[SNPS] == NA_LONG) info[SNPS] = snps;
  else if (info[SNPS] != snps) ERR0("number of snps has changed");
  
  if (info[INDIVIDUALS] == NA_LONG) info[INDIVIDUALS] = individuals;
  else if (info[INDIVIDUALS] != individuals)
    ERR0("number of individ has changed");
  
  if (info[ONEHAPLOONLY] == NA_LONG) info[ONEHAPLOONLY] = OneHaploOnly;
  else if (info[ONEHAPLOONLY] != OneHaploOnly)
    ERR0("'one haplo information' has changed");  
 
  if (info[ZAEHLER] == NA_LONG) info[ZAEHLER] = ++CECV;
  
  if (LDAbitalign == 0) LDAbitalign = NA_LONG;
  if (LDAbitalign != NA_LONG && coding == UnknownSNPcoding) BUG;
  if (coding == UnknownSNPcoding) {
    if (!SxIGiven) BUG;
    goto ende;
  }

  assert(coding != AutoCoding);
  IsHaplo = isHaplo(coding);
  if (info[ORIGINALLY_HAPLO] == NA_LONG) info[ORIGINALLY_HAPLO] = IsHaplo;
  else if (info[ORIGINALLY_HAPLO] != IsHaplo) ERR0("haplo/geno has changed");
  //if (OneHaploOnly == NA_IN TEGER && !info[ORIGINALLY_HAPLO])
  // Achtung, info[] koennte auch NA sein -- passt trotzdem
  //  OneHaploOnly = false;
  if (IsHaplo && OneHaploOnly) {
    coding = OneSet2G(coding);
    if (coding == UnknownSNPcoding)
      ERR1("one haplo for '%20.s' unknown", CODING_NAMES[coding]);
  }
  
   
  if (LDAbitalign == NA_LONG) LDAbitalign = GetLDAbitalign(coding);
  assert(LDAbitalign != 0);
  if ((LDAbitalign > MAX_LDA_BITALIGN) &&
      LDAbitalign != NA_LONG) ERR0("alignment out of range");
  if (info[LDABITALIGN] == NA_LONG) info[LDABITALIGN] = LDAbitalign;
  else if (info[LDABITALIGN] != LDAbitalign) ERR0("'LDAbitalign' has changed");
  
  
  if (opt->Cprintlevel > 7) 
    PRINTF(" coding = %ld x %ld : %.50s v=%d lda_align=%ld\n", ALONG snps,
	   ALONG individuals, CODING_NAMES[coding],  variant, ALONG
	   LDAbitalign);
 
  if (snps == NA_LONG || (int) individuals == NA_LONG ||
      LDAbitalign == NA_LONG // || OneHaploOnly == NA_INTE GER
      ) {
    if (!SxIGiven) BUG;
    goto ende;
  }

  if (info[TRANSPOSED] == NA_LONG) info[TRANSPOSED] = (Long) transposed;
  else if (info[TRANSPOSED] != (Long) transposed)
    ERR0("'transposed' has changed");

  lda = GetLDA(rows, coding, LDAbitalign);
  
  if (info[LDA] == NA_LONG) info[LDA] = lda;
  else if (info[LDA] != lda) {
    if (info[CODING] != coding) {
      ERR2("'coding' has changed incompatibly from '%.50s' to '%.50s'.",
	   CODING_NAMES[info[CODING]], CODING_NAMES[coding]);
    } else {
#if defined MSDOS_WINDOWS
      ERR0("'LDA' has changed");
#else
      ERR2("'LDA' has changed from %ld to %ld", ALONG info[LDA], ALONG lda);// long OK
#endif
    }
  }
    
  memInUnits = totalMem(cols, lda, coding);
  if (info[MEMinUNITS] == NA_LONG) info[MEMinUNITS] = memInUnits;
  else if (info[MEMinUNITS] != memInUnits)
    ERR0("memory requirement changed");
  alignedMem = calculateAlignedMem(memInUnits, coding);
  // printf("allignedMem %ld, %ld, %s; %ld x %ld\n", alignedMem, memInUnits, CODING_NAMES[coding], snps, individuals);
  
 
  if (isUnitAligned(coding)) {
    Long Row = rows * (1 + (int) UnCompressedDoubledRows(coding, false)),
    Col = cols * (1 + (int) UnCompressedDoubledCols(coding, false));
    if (Row * Col != memInUnits || alignedMem != memInUnits) BUG;
    if (pointer == NULL)
      PROTECT(SxI = allocMatrix(INTSXP,stopIfRandNotInt(Row),
				stopIfRandNotInt(Col)));
    else PROTECT(SxI = allocMatrixPointer(INTSXP, stopIfRandNotInt(Row),
					  stopIfRandNotInt(Col),
					  pointer));
  } else {
    if (snps > 1000 && snps * individuals <= memInUnits) {
      PRINTF("%s %ld * %ld <= %ld\n",  CODING_NAMES[coding],
	     ALONG snps, ALONG individuals, ALONG memInUnits);
      BUG;
    }
    if (SxI == R_NilValue) {
      if (pointer == NULL) PROTECT(SxI = allocVector(INTSXP, alignedMem));
      else PROTECT(SxI = allocVectorPointer(INTSXP, alignedMem, pointer));
    }
  }
  
  if (!SxIGiven) MEMSET(INTEGER(SxI), 0, BytesPerUnit * alignedMem); // OK
  
  //  printf("xxxx\n");  return R_NilValue;
  if (info[CODING] == NA_LONG) info[CODING] = coding;
  else if (info[CODING] != coding) ERR0("internal coding has changed");
  
  //  printf("Dxxxx %s variant = %d\n", CODING_NAMES[coding], variant);
    //     printf("xxxx\n");  return R_NilValue;
  info[VARIANT] = check_variant(coding, variant, opt->efficient);
  if (TYPEOF(SxI) != STRSXP) {
    // printf("complete %d %s\n", coding, CODING_NAMES[coding]);
    info[ADDR] = (Long) INTEGER(SxI);
  }
  

 ende:

  //  printf("ende: %ld\n", ALONG SxI);
  if (SxI == R_NilValue) BUG;
  //  printf("info_new %d\n", info_new);  
  if (info_new) setAttrib(SxI, Information, Info); // install("information")
  //  printf("info_new end %d\n", info_new);  
  
   if (info[ORIGINALLY_HAPLO] != NA_LONG // && OneHaploOnly != NA_INTE GER
       &&  GET_CLASS(SxI) == R_NilValue) {
     SetMatrixClass(SxI, info[ORIGINALLY_HAPLO] && !OneHaploOnly, global);
  }

  if (add_transposed_matrix) {
    //    printf("MATRIX ADDED\n");
    if (pointer != NULL && nextpointer == NULL) BUG;
    SEXP NewNext = PROTECT(CompleteCodeVector(snps, individuals,
					      coding,
					      transposed==False ? True : False,
					      false,
					      variant,
					      info[LDABITALIGN],
					      OneHaploOnly,
					      global, utils,
					      nextpointer, NULL,
					      getAttribPointer(SxI, Next)));
    setAttrib(SxI, Next, NewNext);
    UNPROTECT(1);
  }
      
  //  printf("done Completing add=%d %ld\n", add_transposed_matrix, P2LONG SxI);
  UNPROTECT(2);
  return SxI;
}


SEXP CreateEmptyCodeVector(Long snps, Long individuals, coding_type coding,
			   usr_bool transposed, bool add_transposed_matrix,
			   int variant, Long LDAbitalign, bool OneHaploOnly,
			   option_type *global, utilsoption_type *utils) {
  return CompleteCodeVector(snps, individuals, coding, transposed,
			    add_transposed_matrix,
			    variant, LDAbitalign, OneHaploOnly,
			    global,utils, NULL, NULL, R_NilValue);
}


void start_info(SEXP SxI) {
  assert(SxI != R_NilValue && SxI != NULL);
  basic_options *opt = NULL;
  extractBasicInfo(SxI);

  Long mem =info[MEMinUNITS];
  bool inMB = mem > 5000000;
  PRINTF("Data:  %ld SNPs for each of %ld individuals\nStorage mode: (approx) %ld block(s) of %ld codes\nSize of M: %ld %sB.", 
	 ALONG snps, ALONG individuals, ALONG (mem / lda),
	 ALONG GetCodesPerBlock(coding, variant), 
	 ALONG (1 + (mem - 1) / (inMB ? 1048576 : 1024)),
	 inMB ? "M" : "k");	       
}



SEXP createSNPmatrix(Long snps, Long individuals,
		     coding_type coding, usr_bool transposed,
		     bool add_transposed_matrix,
		     int variant, Long LDAbitalign,
		     bool OneHaploOnly, SEXP V,
		     option_type *global, utilsoption_type *utils) {  
  basic_options *opt = &(utils->basic);
  SEXP SxI;
  if (coding == FileDot || coding == DotFile) {  
    // NOTE! no attr(Filename) created, no attr(Info) created, as
    // "SNP matrix" is only a virtual one
    Long len = coding == FileDot ? snps : individuals;
    if (V != R_NilValue) {
      if (ALONG LENGTH(V) != (coding != FileDot ? snps :  individuals))
	ERR1("vector must have length equal to number of %.20s.",
	     coding == FileDot ? "individuals" : "snps");
    }
    if (opt->Cprintlevel > 6) {
      PRINTF("Data: %ld SNPs for each of %ld individuals read from file\n",
	     ALONG snps, ALONG individuals);
    }
    SxI = PROTECT(allocVector(REALSXP, len));
    MEMSET(REALX(SxI), 0, len * Memory(REALSXP));
  } else {
    if (variant == VARIANT_GPU) check_7_5();      
    SxI = PROTECT(CreateEmptyCodeVector(snps, individuals, coding,
					 transposed, add_transposed_matrix,
					 variant,
					 LDAbitalign, OneHaploOnly,
					 global,utils));
    if (opt->Cprintlevel > 6) start_info(SxI);
  }
  
  UNPROTECT(1);
  return SxI;
}

SEXP createSNPmatrix(Long snps, Long individuals,
		     coding_type coding,
		     usr_bool transposed, bool add_transposed_matrix,
		     int variant,
		     Long LDAbitalign,
		     option_type *global, utilsoption_type *utils) {
  return createSNPmatrix(snps, individuals, coding, transposed,
			 add_transposed_matrix,
			 variant,
			 LDAbitalign, false, R_NilValue, global, utils);
}

SEXP createSNPmatrix(Long snps, Long individuals,
		     coding_type coding, int variant, Long LDAbitalign,
		     option_type *global, utilsoption_type *utils) {
  return createSNPmatrix(snps, individuals, coding, False,
			 global->tuning.addtransposed,
			 variant,
			 LDAbitalign, false, R_NilValue, global, utils);
}


void showInfo(Long *info) {
  PRINTF("information variant=%ld\n", ALONG info[IMPLEMENTATION]);
  PRINTF("snps=%d\n", SNPS);
  PRINTF("indiv=%d\n", INDIVIDUALS);
  PRINTF("Addr=%d\n", ADDR);
  PRINTF("coding=%d\n", CODING);
  PRINTF("transposed=%d\n", TRANSPOSED);
  PRINTF("implementation=%d\n", VARIANT);
  PRINTF("LDAbitalign=%d\n", LDABITALIGN);
  PRINTF("snpXind=%d\n", FILE_SNPxIND_READ_BYROW);
  PRINTF("header=%d\n", FILE_HEADER);
  PRINTF("doubleindiv=%d\n", FILE_DOUBLEINDIV);
  PRINTF("leading=%d\n", FILE_LEADINGCOL);
  PRINTF("mem=%d\n", MEMinUNITS);
  PRINTF("LDA=%d\n", LDA);
}

void showInfoShort(Long *info) {
  PRINTF("V=%ld, ", ALONG info[IMPLEMENTATION]);
  PRINTF("S/I=%d %d, ", SNPS, INDIVIDUALS);
  PRINTF("Ad=%d, ", ADDR);
  PRINTF("M=%d, ", CODING);
  PRINTF("T=%d, ", TRANSPOSED);
  PRINTF("I=%d\n", VARIANT);
  PRINTF("LDAbitalign=%d, ", LDABITALIGN);
  PRINTF("LDA=%d \n", LDA);
}

unit_t *Align(SEXP SxI, basic_options VARIABLE_IS_NOT_USED *opt) {
  assert(SxI != R_NilValue);
  int *address = INTEGER(SxI);
  Long *info = GetInfo(SxI);
  coding_type coding = (coding_type) info[CODING];
  if (coding == OrigPlink) return (unit_t *) address;
  Long bitalign = info[LDABITALIGN];
  int*algnaddress = (int*) algn_generalL(address, bitalign);
  return (unit_t*) algnaddress; // 27.5.24 all loads/stores are unaligned!
  /*
  
  //  printf("Align\n");
      
  option_type *global;
  utilsoption_type *utils;
  WhichOptionList(true, &global, &utils);
  if (opt == NULL) opt = &(utils->basic);

  int cores = GreaterZero(opt->cores);
  ASSERT_STORED_ENDIAN;
 
  int *infoaddress = (int*) info[ADDR];
    
  bool aligned= algnaddress - address ==
    (int*) algn_generalL(infoaddress, bitalign) - infoaddress;
      
  if (global->messages.warn_address && infoaddress != address) {
    int *recentaddress = (int*) info[RECENTALIG NADDR];
    if (recentaddress != address) {
      PRINTF("Address has changed in a coded object%s (*%u->*%u). %s\n",
	     aligned ?  ", but same modulus" : " by 'gc' or disk saving",
	     (Uint) (uintptr_t) infoaddress, (Uint) (uintptr_t) address,
	     recentaddress == NULL
	     ? "[This messages can be suppressed by 'RFoptions(warn_address=FALSE)']"// OK
	     : "");
      info[RECENTALIG NADDR] = (Long) address;
    }
  }
  
  if (aligned){
    assert((uintptr_t) algnaddress % (bitalign / BitsPerByte) == 0);
    return  (unit_t*) algnaddress;
  }

  Long bytes = info[MEMinUNITS] * BytesPerUnit; // OK
#ifdef DO_PARALLEL
  // prevent two processes to move data at the same time
  if (cores > 1) {
    int mypid, sleep = 1;
    Ext_pid(&mypid);
    if (!info[BLOCKEDINFO]) {
      info[BLOCKEDINFO] = mypid;
      Ext_sleepMicro(&sleep); // wait. Other processes may access simulatenously
    }
    if ((Long) mypid != info[BLOCKEDINFO]) { // other process has been
      // doing the job, maybe simultaneously
      sleep = (int) ((bytes / 1000 + mypid) % MAXINT); // some randomness in sleeping
      for (int i=0; i<10; i++) {
	if (!info[BLOCKEDINFO]) return Align(SxI, opt);
 	Ext_sleepMicro(&sleep);
      }
      if (opt->warn_parallel) 
	WARN0("Simultaneous write access: there is some risk of loosing data. You can suppress this message by 'RFoptions(warn_parallel=FALSE)', or avoid any risk by 'RFoptions(cores=1)'."); // ok
      info[BLOCKEDINFO] = 0; 
      return Align(SxI, opt);
    }
  }
#endif
  
  int *OldInNew =
    address + ((Long) info[ALIGNA DDR] - (Long) infoaddress);
  MEMMOVE(algnaddress, OldInNew, bytes);
  info[ADDR] = (Long) address;
  info[ALIGNA DDR] = (Long) algnaddress;
#ifdef DO_PARALLEL
  info[BLOCKEDINFO] = 0;
#endif

  return (unit_t*) algnaddress;
    */
}


   
#define ASSERT_NO_TILING(coding, variant)			\
  assert(exists_crossprod(coding) &&				\
	 exists_variant(coding, variant, false, false) &&	\
	 exists_tiling(coding, variant, false));
#define ASSERT_TILING(coding, variant)				\
  assert(exists_crossprod(coding) &&				\
	 exists_variant(coding, variant, false, false) &&	\
	 exists_tiling(coding, variant, true));

/*

#define crossvariab		\
  crossfct, iGroup,							\
    AVXTYPE##_omp_P F,							\
    Long_omp HashSizePerV,						\
    Long_omp repetV,							\
    Long_omp VatOnce,							\
    Long_omp colsCpBm1,							\
    Long_omp cols,							\
    TYPE##_omp_P V,							\
    Long_omp ldV,							\
    TRDTYPE##_omp_P externalV,						\
    LongDouble_omp_P colFreq					\
    LEER10

#define crossvariabX(X) crossvariab(X) 

#include "myOMP.h"
STRUCTOMP(

	  
#include "myOMP.h"
*/

void crossprod(unit_t * Code, Long rowsOrig, Long cols, Long lda,
	       coding_type coding, int variant,
	       Long logRowGroupSize, bool smoothRowGroupSize,
	       Long indivGroupSize, basic_options *opt,
	       double *A) {

  // if (opt->Cprintlevel) printf("crossprod 1\n");

  
  Long
    BpB = GetBytesPerBlock(coding, variant),
    CpB = GetCodesPerBlock(coding, variant),
    blocks = DIV_GEQ(rowsOrig, CpB),
    rows = blocks * CpB,
    UpB = BpB / BytesPerUnit, // OK
    minigroupsize = 1,
    BlockSizeFactor = 0,
    DeltaPart2 = 0;
 
  Long rowGroupSize = 1U << logRowGroupSize;
  int cores =  GreaterZero(opt->cores);
  if (rowGroupSize <= 1) rowGroupSize = 1 - rowGroupSize; // switch 0 and 1
  indivGroupSize = indivGroupSize > 0 ? indivGroupSize :
    cores == 1 ? cols : 1;

  if (opt->Cprintlevel > 6) 
    PRINTF("cross: %ld/%ld x %ld : %.50s,%d lda=%ld; tiling=%ld x %ld.\n",
	   ALONG rowsOrig, ALONG rows, ALONG cols,
	   CODING_NAMES[coding], variant,
	   ALONG lda, ALONG rowGroupSize, ALONG indivGroupSize);
  
  assert(cols > 0);
  //double nSq = (double) cols * (double) cols;      
  // if ((double) rowsOrig * nSq * 4.0 > 4.5035996e+15) // 2^{manissen-bits = 52}    ERR0("matrix too large to calculate the relationship matrix -- pls contact maintainer of 'miraculix'");
      
  
 
  //  printf("crossprod %s %d %d \n", CODING_NAMES[coding], variant, rows);

  scalar_t scalar = NULL;
  multi_t multi = NULL;
  switch (coding) {
  case OneBitGeno : 
    ASSERT_TILING(coding, variant);   
    DeltaPart2 = lda * cols / UpB;
    BlockSizeFactor = loop_1bit;
    switch(variant) {
    case 512 + VARIANT_B :
      multi  = multi_1v512B;
      scalar = scalar_1v512B;
      break;
    case 512 + VARIANT_A : 
      multi  = multi_1v512A;
      scalar = scalar_1v512A;
      break;
    case 512 :
      multi  = multi_1v512;
      scalar = scalar_1v512;
      break;
    case 256 + VARIANT_B :
      multi  = multi_1v256B;
      scalar = scalar_1v256B;
      break;
    case 256 + VARIANT_A : 
      multi  = multi_1v256A;
      scalar = scalar_1v256A;
      break;
    case 256 :
      multi  = multi_1v256;
      scalar = scalar_1v256;
      break;
    case 128 + VARIANT_B :
      multi  = multi_1v128B;
      scalar = scalar_1v128B;
      break;
    case 128 + VARIANT_A : 
      multi  = multi_1v128A;
      scalar = scalar_1v128A;
      break;
    case 128 :
      multi  = multi_1v128;
      scalar = scalar_1v128;
      break;
    case 64 :
      multi  = multi_1v64;
      scalar = scalar_1v64;
      break;
    case 32 :
      multi  = multi_1v32;
      scalar = scalar_1v32;
      break;
    default: BUG;
    }
    break;
  case TwoBitGeno :
    BlockSizeFactor = loop_2bit;
    switch(variant) {
    case 512  + VARIANT_A:
      ASSERT_TILING(coding, variant);
      minigroupsize = 2;      
      multi =  multi2x2_2v512;
      scalar = scalar_2v512;
      break;
    case 512 :
      ASSERT_TILING(coding, variant);
      multi =  multi_2v512;
      scalar = scalar_2v512;
      break;
    case 256  + VARIANT_A:
      ASSERT_TILING(coding, variant);
      minigroupsize = 2;      
      multi  =  multi2x2_2v256;
      scalar = scalar_2v256;
      break;
    case 256 :
      ASSERT_TILING(coding, variant);
      multi =  multi_2v256;
      scalar = scalar_2v256;
      break;
    case 128  + VARIANT_A:
      ASSERT_TILING(coding, variant);
      minigroupsize = 2;      
      multi =  multi2x2_2v128;
      scalar = scalar_2v128;
      break;
    case 128 :
      ASSERT_TILING(coding, variant);
      multi  =  multi_2v128;
      scalar = scalar_2v128;
      break;
    case 64 :
      ASSERT_NO_TILING(coding, variant);
      crossprod2v64(Code, rows, cols,lda, cores, A); return;
    case 32 :
      ASSERT_NO_TILING(coding, variant);
      crossprod2v32(Code, rows, cols,lda, cores, A); return;
    case VARIANT_GPU :
      crossprod_mmagpu((Uint*) Code, rows, cols,
		       stopIfNotUint(lda), cores, A);  return;
    default: BUG;
    }
    break;
  case ThreeBit:
    ASSERT_NO_TILING(coding, variant);
    switch(variant) {
    case 64: crossprod3(Code, rows, cols, lda, cores, A);return;
    default: BUG;
    }
    return;
  case FourByteGeno :
    ASSERT_NO_TILING(coding, variant);
    switch(variant) {
    case 32 : crossprod_Plain (Code, rows, cols, lda, cores, A);
      return;
    case VARIANT_GPU :
#ifdef USEGPU
      crossprod_PlainGPU(Code, rows, cols, lda, cores, A);
      return;
#else
      BUG;
#endif    
    default : BUG;
    }
  case OneByteGeno :
    
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(dynamic) 
#endif
    for (Long j=0; j<cols; j++) {
      for (Long k=j; k<cols; k++) {
	char *cJ = (char*) (Code + lda * j),
	  *cK = (char*) (Code + lda * k);
	Long  sum = 0L;
	for (Long i=0; i<rows; i++) sum += cJ[i] * cK[i];
	A[j + cols * k] = A[k + cols * j] = (double) sum;
      }
    }
    return;
    
  default:
    ERR1("crossprod does not exist for coding `%.50s'.\n", CODING_NAMES[coding]);
  }

  if (scalar == NULL) BUG;

  //  printf("minigroup = %d %d\n", minigroupsize, BlockSizeFactor);

#define minBlocksPCore 5

  indivGroupSize = (1 + (indivGroupSize -1) / minigroupsize) * minigroupsize;
  const Long
    rowGroupSizePlus = rowGroupSize + BlockSizeFactor / 4,
    blockSize = (rowGroupSize == 0 || rowGroupSize > blocks
		 ? blocks
		 : BlockSizeFactor == 0 || rowGroupSizePlus < BlockSizeFactor
		 || !smoothRowGroupSize ? rowGroupSize
		 : (rowGroupSizePlus / BlockSizeFactor) * BlockSizeFactor),
    lastRegBlock = blockSize * ((blocks-1) / blockSize),
    blockGsize[2] = {blockSize, blocks - lastRegBlock},
    rest = cols % indivGroupSize,
    lastRegIndi = cols - rest,
    grouprest = rest % minigroupsize,
    indivGsize[3] = {indivGroupSize, rest-grouprest, grouprest};
  

 
  //  printf("blocksize = %d %d %d : %d %d; rowGroupSize=%d blocks=%d\n", blockSize, rowGroupSize <= 1 || rowGroupSize > blocks * CpB,	 BlockSizeFactor == 0 || rowGroupSizePlus < BlockSizeFactor || !smoothRowGroupSize,	 rowGroupSizePlus, BlockSizeFactor, rowGroupSize, blocks	 );
 


  //  printf("\n\nrows=%d D=%d lda=%d i=%d BitsPBlock=%d/%d\niGrS=%d (%d, %d, %d) bs=%d (%d %d) lastBl=%d %d\n",	 rows, DeltaPart2, lda, cols , BpB * 8, UpB,	 indivGroupSize, indivGsize[0], indivGsize[1], indivGsize[2], blockSize,	 blockGsize[0], blockGsize[1], lastRegBlock, lastRegIndi );
  // BUG;

  // printf("indic = %ld %ld\n", cols, sizeof(*A) * cols * cols);
  
  MEMSET(A, 0, sizeof(*A) * cols * cols);
  //  if (opt->Cprintlevel) printf("crossprod 2 %ld %ld\n",
  //			       ALONG cols, ALONG indivGroupSize);

#ifdef DO_PARALLEL
  //#pragma omp parallel for num_threads(cores) collapse(1) schedule(static)
#pragma omp parallel for num_threads(cores) collapse(2) schedule(dynamic)
#endif
  for(Long iGroup = 0; iGroup < cols; iGroup+=indivGroupSize) {
    for(Long jGroup = 0; jGroup<cols; jGroup+=indivGroupSize) {
      if (jGroup < iGroup) continue;
      const bool last_reg = iGroup >= lastRegIndi;
      const Long lEnd_i = iGroup + indivGsize[last_reg];
      const Long lEnd_j = jGroup + indivGsize[jGroup >= lastRegIndi];      
      for(Long b = 0; b < blocks; b += blockSize) {	  
	const Long bsize = blockGsize[b == lastRegBlock];
	unit_t *Code0 = Code + b * UpB;
	for(Long i = iGroup; i < lEnd_i; i+=minigroupsize) {
	  unit_t *Codei = Code0 + i * lda;
	  for(Long j = MAX(i, jGroup); j < lEnd_j; j+=minigroupsize) {
	    //	      printf("iGr=%d %d; i=%d %d b=%d %d blocks=%d lda=%d addr=%ld %ld\n", iGroup, jGroup, i, j, b, bsize, blocks, lda, Code0 - Address, Codei - Address);
	    
	    assert(j * cols + i < cols * cols);
	    // printf("%ld %ld\n", Codei-Code, Code0 + j * lda-Code);
	    
	    multi(Codei, Code0 + j * lda, cols, bsize, lda, A + j * cols + i);
	    //	      if (*A > 2000) { printf("%f %d/%d %d/%d %d\n", *A, indivGroupSize, lastRegIndi, blockSize, blocks, minigroupsize); BUG;} BUG;
	  }
	}
      }
    }
  }
    
  // if (opt->Cprintlevel)  printf("crossprod 3\n");
  if (indivGsize[2] > 0) {
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
    for(Long iGroup = 0; iGroup < cols; iGroup+=indivGroupSize) {
      const bool last_reg = iGroup >= lastRegIndi;
      const Long xEnd_i = last_reg ? cols : iGroup + indivGroupSize,
	lEnd_j = cols;
      Long iG = iGroup,
	jGroup = cols - grouprest;
      for(Long b = 0; b < blocks; b += blockSize) {	  
	const Long bsize = blockGsize[b == lastRegBlock];
	unit_t *Code0 = Code + b * UpB;
	for(Long i = iG; i < xEnd_i; ++i) {
	  unit_t *Codei = Code0 + i * lda;
	  for(Long j = MAX(i, jGroup); j < lEnd_j; ++j) {
	    //	    printf("i=%d j=%d\n", i, j);
	    assert(j * cols + i < cols * cols);
	    A[j * cols + i] += (double)
	      scalar(Codei, Code0 + j * lda, bsize, DeltaPart2);
	  }
	}
      }
    } // for iGroup
  }
     
  // if (opt->Cprintlevel)  printf("crossprod 4\n");
  for (Long i=0; i<cols; i++)
    for (Long j=0; j<i; j++)
      A[j * cols + i] = A[i * cols + j];
  // if (opt->Cprintlevel)  printf("crossprod 5\n");
}



void do_centering(Long rows, Long cols, centering_type centered,
		  normalizing_type normalized, bool squared,
		  LongDouble *Precision,
		  basic_options VARIABLE_IS_NOT_USED *opt,
		  tuning_options VARIABLE_IS_NOT_USED *tuning,
		  double *A) {
  if ((centered == NoCentering && normalized == NoNormalizing )
      || centered == User) return;
  assert(Precision != NULL);  
  assert(cols > 0);

  //  printf("cetered = %d normali=%d\n", centered, normalized);
  //printf("A=%f %f\n", A[0], A[10]);


  // const double cols_D = (double) cols;
  const double rows_D = (double) rows;
  double *f = (double*) MALLOC(sizeof(double) * cols);
  
  switch(centered) {
  case NoCentering: break;
  case RowMeans: {
#define maxlong 9223372036854775000.0 // for safty
    LongDouble *FreqSxI = Precision + RowFreqSxIIndex;
    double norm2f = 4.0 * (double) Precision[RowFreqNorm2Index];
    //    printf("\n norm2f=%f %d %ld %ld/%ld\n", norm2f, RowFreqSxIIndex, ALONG Precision, rows, cols);
    for (Long i=0; i<cols; i++) {
      f[i] = 2.0 * (double) FreqSxI[i];
      //      printf("%4.2f ", f[i]);
      double *a = A + i * cols;
      for (Long j=0; j<=i; j++) a[j] += norm2f - f[i] - f[j];
    }
  }
    break;
    
  case ColMeans : {
    //    printf("rows / cols = %ld %ld\n", rows, cols);
    LongDouble *freq = Precision + ColFreqIndex;
    LongDouble *colSum = Precision + ColSumIndex;
    double *sums = (double*) MALLOC(sizeof(double) * cols);
    for (Long i=0; i<cols; i++) {
      f[i] = 2.0 * (double) freq[i];
      sums[i] = (double) colSum[i];
      //      if (i < 210) printf("i=%d r=%f %f %f\n", i, rows_D, f[i], sums[i]);
      // assert(sums[i]);
      //      printf("%4.2f %4.2f; ", f[i], sums[i]);
      double *a = A + i * cols;
      for (Long j=0; j<=i; j++) {
	a[j] += f[i] * (rows_D * f[j] - sums[j]) - sums[i] * f[j];
      }
    }
    FREE(sums);
    //     printf("CM A=%f %f\n", A[0], A[10]);
 
  }
    break;
    
  default :
    ERR0("user defined centering to be programmed\n");
  }

  //  printf("centered / noramlized %d %d \n", centered, normalized);

  if (normalized == AccordingCentering) {
    switch(centered) {
    case RowMeans : normalized = RowNormalized; break;
    case ColMeans : normalized = ColNormalized; break;
    case User :
    case NoCentering : normalized = NoNormalizing; break;
    default: BUG;
    }
  }
  
  double factor = 1.0;
  switch (normalized) {
  case CorrNormalizing :
    for (Long i=0; i<cols; i++) {
      f[i] = 1 / SQRT(A[i * (cols + 1)]); // 1/ SQRT(diag elements)
      double *a = A + i * cols;
      for (Long j=0; j<=i; j++) a[j] *= f[i] * f[j];
    }
    break;
  case RowNormalized : factor *= Precision[RowSigmaSqIndex]; break;
  case ColNormalized : factor *= Precision[ColSigmaSqIndex]; break;
  case NoNormalizing : break;
  default : PRINTF("normalized = %d\n", normalized); BUG;
  }
  
  
  if (factor <= 0.0) ERR0("strange input matrix?");
  bool notSquared = !squared;
  for (Long i=0; i<cols; i++) {
    double *a = A + i * cols;
    double *aT = A + i;
    for (Long j=0; j<=i; j++) {
      a[j] = factor == 1.0 ? a[j] : a[j] / factor;
      a[j] = notSquared ? a[j] : a[j] * a[j];
      aT[j * cols] = a[j];
    }
  }

  //  printf("Ende A=%f %f\n", A[0], A[10]);
    
  FREE(f);
  return;
}


void crossprodI(unit_t * Code, Long rows, Long individuals, Long lda,
		coding_type coding, int variant,
		centering_type centered, normalizing_type normalized,
		bool squared,
		LongDouble *Precision,
		basic_options *opt, tuning_options *tuning,
		double *A) {
  //  printf("\ncrossprodI %s #%d \n", CODING_NAMES[coding], variant);
  crossprod(Code, rows, individuals, lda, coding, variant,
	    tuning->logRowGroupSize,
	    tuning->smoothRowGroupSize, 
	    tuning->colGroupSize,
	    opt, A);
  // printf("crosprod done %s %f\n", CODING_NAMES[coding], *A);
 
  assert(A[0] >= 0.0);

  do_centering(rows, individuals,
	       centered, normalized, squared, Precision,
	       opt, tuning, A);
}



double *crossprod(unit_t * Code, Long rows, Long individuals, Long lda,
		  coding_type coding, int variant,		  
		  centering_type centered, normalizing_type normalized,
		  bool squared,
		  LongDouble *Precision,
		  basic_options *opt, tuning_options *tuning) {
  // never squared here!!!
  double *A = (double*) MALLOC(individuals * individuals * sizeof(double));

  crossprodI(Code, rows, individuals, lda, coding, variant,
	     centered, normalized, squared, Precision,
	     opt, tuning, A);
 
  return A;
}
 


int t_crossprodI(unit_t * Code, Long rows, Long individuals, Long lda,
		  coding_type coding,
		  int VARIABLE_IS_NOT_USED variant,
		  centering_type centered, // with respect to the
		  // original orientation of the matrix
		  normalizing_type normalized,
		  bool squared,
		  LongDouble *Precision,
		  basic_options *opt, tuning_options *tuning,
		  double *Ans) {
  Long ldAns = rows;
  int  VARIABLE_IS_NOT_USED cores =  GreaterZero(opt->cores);
  switch(coding) {
  case OneByteGeno :
    if (sizeof(double) != sizeof(Long)) BUG; // OK
#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(dynamic) 
#endif
    for (Long k=0; k<rows; k++) {
      for (Long i=0; i<individuals; i++) {
	_1Byte* C = (_1Byte*) (Code + i * lda);
 	Long z = C[k];
	Long *a = ((Long*) Ans) + k * ldAns;
	for (Long j=k; j<rows; j++) {
	  a[j] += (Long) C[j] * z;
	}
      }
    }
    for (Long k=0; k<rows; k++) {
      for (Long j=k+1; j<rows; j++)
	Ans[j * ldAns + k] = Ans[k * ldAns + j] =
	  (double) (((Long*) Ans)[k * ldAns + j]);
    }
    break;
  default :
    PRINTF("t_crossprod not coded for '%s'.\n", CODING_NAMES[coding]);
    return 1;
    BUG;
  }
  
  assert(Ans[0] >= 0.0);

  do_centering(rows, individuals,
	       centered, normalized, squared, Precision,
	       opt, tuning, Ans);

  return 0;
}



Ulong colSums(unit_t *code, Long origrows, Long origcols, Long lda,
	      coding_type coding, int variant, int cores,
	      Ulong *ans // [0..cols-1]
	      ) {
  // I.e. summing up all rows for each column
  // isHaplo(coding) doubles the amount of returned information
  // the function return the total sum besides the 'ans'

  Long rows=origrows,
    cols=origcols;
  if (doubledCols(coding, false)) cols <<= 1;
  if (doubledRows(coding, false)) rows <<= 1;

  colSums_t sG = NULL;
  Ulong *sum = ans;
  MEMSET(sum, 0, cols * sizeof(*sum));

  switch (coding) {
  case OneBitGeno : sG = colSums1; break;
  case TwoBitGeno :
    switch(variant) {
    case 512:
    case VARIANT_GPU:
    case 256 : sG = colSums2v256; break;
    case 128: sG = colSums2v128; break;
    default :
      sG = colSums2; 
    }
    break;
  case ThreeBit : sG = colSums3; break;
  case FourByteGeno: sG = colSumsPlain; break;
  case OneByteHaplo :
  case OneByteGeno : sG = colSumsOneByte; break;
  case Plink : sG = colSumsPlink; break;
  case OrigPlink : BUG; 
  case FiveCodes : 
    // calculation with arguments as information not possible
    BUG;
    break;

  case FourByteSingleBit:
  case FourByteHaplo: {// ToDo: SIMD version
    assert(exists_allelefreq(coding));
    Ulong total = 0;
    for (Long i=0; i<cols; i++) {
      Uint *c = (Uint*) code + lda * i;
      Ulong S = 0;
      for (Long j=0; j<rows; j++) S += c[j];
      sum[i] = S;
      total += S; 
    }
    if (sum != ans) { FREE(sum); }
    return total;
  }
    
  case EightByteHaplo: {
    assert(exists_allelefreq(coding));
    Ulong total = 0;
    for (Long i=0; i<cols; i++) {
      Uint *c = (Uint*) (code + lda * i);
      Ulong S = 0, T=0;
      for (Long j=0; j<rows;) {
	S += c[j++];
	T += c[j++];
      }
      sum[2 * i] = S;
      sum[2 * i + 1] = T;
      total += S + T;
    }
    return total;
  }

     
  default : {
    GetOptions; 
    if (!exists_allelefreq(coding)) BUG;
    Ulong *E = (Ulong *) MALLOC(sizeof(Ulong) * origrows);
    for (Long i=0; i<origrows; E[i++] = 1.0);
    //   printf("before gv vg Long\n");
    Long ldAns = origrows * sizeof(*ans) / sizeof(unit_t);
    vector_Ulong(code, origrows, origcols, coding, lda, variant, NULL,
		 E, 1, origrows, opt, &(global->tuning), ans, ldAns, true);
    FREE(E);
    Ulong total = 0;
    for (Long i=0; i<origcols; total += sum[i++]);
    return total;
  }
  }
  
  //  printf("xok %s [%d]\n", CODING_NAMES[coding], variant);
  return sG(code, rows, cols, lda, cores, ans);
}


Ulong rowSums(unit_t *code, Long origrows, Long origcols, Long lda,
	      coding_type coding,  int variant, int cores, 
	      Ulong *ans // [0..cols-1]
	     ) {
  // I.e. summing up all columns for each row
   // isHaplo(coding) doubles the amount of returned information
 
   Long rows = origrows, cols=origcols;
  if (doubledRows(coding, false)) rows <<= 1;
  if (doubledCols(coding, false)) cols <<= 1;
  
  Ulong *sum = ans;
  MEMSET(sum, 0, rows * sizeof(*sum));

  switch (coding) {     
  case TwoBitGeno : {
    assert(exists_allelefreq(coding));
    
    switch(variant) {
    case 512:
    case VARIANT_GPU:
    case 256 : rowSums_2v256(code, rows, cols, lda, cores, sum); break;
    case 128 : rowSums_2v128(code, rows, cols, lda, cores, sum); break;
    default: rowSums2(code, rows, cols, lda, cores, sum);
    }
  }
    break;
    
  case ThreeBit :
    assert(exists_allelefreq(coding));
    rowSums3(code, rows, cols, lda, cores, sum);
    break;
    
  case FourByteHaplo:
  case FourByteSingleBit:
  case FourByteGeno:  // ToDo: SIMD version
    assert(exists_allelefreq(coding));
    for (Long i=0; i<cols; i++) {
      Uint *c = (Uint*) (code + lda * i);
      for (Long j=0; j<rows; j++) sum[j] += c[j];
    }
    break;
    
  case EightByteHaplo: {
    assert(exists_allelefreq(coding));
    for (Long i=0; i<cols; i++) {
      unit_t *c = code + lda * i;
      for (Long j=0; j<rows; j++) sum[j] += c[j];
    }
    break;
  }
    
  case OneByteHaplo:
  case OneByteGeno: 
    assert(exists_allelefreq(coding));
    rowSums_OneByte(code, rows, cols, lda, cores, sum);
    break;
    
    
  default :
    GetOptions; 
    if (!exists_allelefreq(coding)) BUG;
    Ulong *E = (Ulong *) MALLOC(sizeof(Ulong) * origcols);
    for (Long i=0; i<origcols; E[i++] = 1.0);
    //   printf("before gv vg Long\n");
    Long ldAns = origcols * sizeof(*ans) / sizeof(unit_t);
    vector_Ulong(code, origrows, origcols, coding, lda, variant, NULL,
		  E, 1, origrows, opt, &(global->tuning), ans, ldAns, false);
    FREE(E);
  }
  
  Ulong total = 0;
  for (Long i=0; i<origrows; total += sum[i++]);
  return total;
}

 
#define divide_by_nonmissings_fctn(DOUBLE)				\
  void divide_by_nonmissings_##DOUBLE(SEXP SxI,				\
				      bool colmeans,			\
				      bool perAllele,			\
				      Ulong *sums, /* in */		\
				      DOUBLE *Sums, DOUBLE *ans /*out*/) { \
    basic_options *opt = NULL;						\
    condExtractInfo(SxI, colmeans);					\
    if (false) PRINTF("divide %ld %d %d; r/c=%ld %ld\n", P2LONG Sums, colmeans, transposed, ALONG rows, ALONG cols); \
    SEXP Miss = getAttribPointer(SxI, Missings);			\
    Long *mssngs = Miss == R_NilValue ? NULL : LONG(Miss);		\
    Long n_miss = info[MISSINGS];					\
    if (Sums == NULL) Sums = ans;					\
    for (Long i=0; i<rows; i++) Sums[i] = (DOUBLE) sums[i];		\
    if (mssngs == NULL) {						\
      if (false) {PRINTF("missings = null; %ld\n", ALONG n_miss);}	\
      assert(n_miss == 0 || n_miss == NA_LONG);				\
      DOUBLE factor = (DOUBLE) (cols << (int) perAllele);		\
      if (false) PRINTF("cols=%ld %f\n, ", ALONG cols, factor);		\
      for (Long i=0; i<rows; i++) ans[i] = Sums[i] / factor;		\
    } else {								\
      Long missings = n_miss << 1;					\
      if (false) {PRINTF("missings non null; %ld\n", ALONG n_miss);printINFO(SxI); /* *rint */ } \
      assert(missings > 0);						\
      Long *nonmiss =  (Long*) MALLOC(rows * sizeof(Long));		\
      for (Long i=0; i<rows; nonmiss[i++] = cols);			\
      /* if col missings are summed colwise: */				\
      for (Long i= (Long) colmeans; i<missings; i+=2) nonmiss[mssngs[i]]--; \
      for (Long i=0; i<rows; i++) {					\
 	ans[i] = Sums[i] / (DOUBLE) (nonmiss[i] << (int) perAllele);	\
      }									\
      FREE(nonmiss);							\
    }									\
    if (false) PRINTF("dividing done \n");				\
  }

#if defined compatibility_to_R_h
divide_by_nonmissings_fctn(double)
#endif
divide_by_nonmissings_fctn(LongDouble)


#define rowMeans_fctn(DOUBLE)						\
  Ulong rowMeans_##DOUBLE(SEXP SxI,					\
			  bool perAllele,				\
			  option_type VARIABLE_IS_NOT_USED  *global,	\
			  utilsoption_type *utils,			\
			  DOUBLE *Sums, /* might be NULL */		\
			  DOUBLE *ans) {				\
    basic_options *opt = &(utils->basic);				\
    int cores = GreaterZero(opt->cores);				\
    extractInfo(SxI);							\
    variant = main_variant(check_variant(coding, variant, opt->efficient)); \
    ASSERT_LITTLE_ENDIAN;						\
    Ulong *sums =							\
      (Ulong*) MALLOC(sizeof(Ulong) * rows * (1 + (Long) isHaplo(coding))); \
     Ulong total =							\
      rowSums(code, rows, cols, lda, coding, variant, cores, sums);	\
    divide_by_nonmissings_##DOUBLE(SxI, false, perAllele, sums, Sums, ans); \
   FREE(sums);								\
    return total;							\
}


#define colMeans_fctn(DOUBLE)						\
  Ulong colMeans_##DOUBLE(SEXP SxI,					\
			  bool perAllele,				\
			  option_type VARIABLE_IS_NOT_USED*global,	\
			  utilsoption_type *utils,			\
			  DOUBLE *Sums, /* might be NULL */		\
			  DOUBLE *ans) {				\
    basic_options *opt = &(utils->basic);				\
    int cores = GreaterZero(opt->cores);				\
    extractInfo(SxI);							\
    variant = main_variant(check_variant(coding, variant, opt->efficient)); \
    ASSERT_LITTLE_ENDIAN;						\
    Ulong *sums =							\
      (Ulong*) MALLOC(sizeof(Ulong) * cols * (1 + (Long) isHaplo(coding))); \
    Ulong total =							\
      colSums(code, rows, cols, lda, coding, variant, cores, sums);	\
    divide_by_nonmissings_##DOUBLE(SxI, true, perAllele, sums, Sums, ans); \
    FREE(sums);								\
    return total;							\
}


#if defined compatibility_to_R_h
rowMeans_fctn(double)
colMeans_fctn(double)
#endif
rowMeans_fctn(LongDouble)
colMeans_fctn(LongDouble)



#define allele_freq_fctn(DOUBLE)					\
  Ulong allele_freq_##DOUBLE(SEXP SxI,					\
			     bool col_freq, /* standard: false */	\
			     option_type *global, utilsoption_type *utils, \
			     DOUBLE *Sums, /* standard: NULL */		\
			     DOUBLE *ans) {				\
    /* returns vector of means in 'ans'.  */				\
    /* But also the vector of correspondings Sums, and the totalsum */	\
    if (false) PRINTF("start allele_freq\n");				\
    Long *info = GetInfo(SxI);						\
    usr_bool transposed = info[TRANSPOSED] == 0 ? False : True;		\
    bool rowmeans = col_freq xor (transposed == False);		\
    bool rowMeansPreferred = uprightlyPacked(info[CODING]);		\
    if (rowMeansPreferred xor rowmeans) {				\
      SEXP next = getAttribPointer(SxI, Next);				\
      if (next != R_NilValue)						\
	return allele_freq_##DOUBLE(next, col_freq, global, utils, Sums, ans); \
    }									\
    if (rowmeans) {							\
      return rowMeans_##DOUBLE(SxI, true, global, utils, Sums, ans); \
    } else {							     \
      return colMeans_##DOUBLE(SxI, true, global, utils, Sums, ans); \
    }									\
  }


#if defined compatibility_to_R_h
allele_freq_fctn(double)
#endif
allele_freq_fctn(LongDouble)


LongDouble getTotalSum(SEXP SxI){
  SEXP PP = getAttribPointer(SxI, Precise);
  if (PP == R_NilValue) BUG;
  return (LONGREAL(PP))[TotalSumIndex];
}

LongDouble *getRowFreq(SEXP SxI){
  //  printf("SxI!!\n");
  printSEXP(SxI);
  SEXP PP = getAttribPointer(SxI, Precise);
  if (PP == R_NilValue) BUG;
  return (LONGREAL(PP)) + RowFreqIndex;
}


LongDouble *getRowSum(SEXP SxI){
  basic_options *opt = NULL;
  extractInfo(SxI);
  SEXP PP = getAttribPointer(SxI, Precise);
  if (PP == R_NilValue) BUG;
  return (LONGREAL(PP)) + RowSumIndex;
}


LongDouble *getRowFreqSxI(SEXP SxI){
  basic_options *opt = NULL;
  extractInfo(SxI);
  SEXP PP = getAttribPointer(SxI, Precise);
  if (PP == R_NilValue) BUG;
  return (LONGREAL(PP)) + RowFreqSxIIndex;
}


LongDouble getRowFreqNorm2(SEXP SxI){
  SEXP PP = getAttribPointer(SxI, Precise);
  if (PP == R_NilValue) BUG;
   return (LONGREAL(PP))[RowFreqNorm2Index];
}


LongDouble getRowSigmaSq(SEXP SxI){
  SEXP PP = getAttribPointer(SxI, Precise);
  if (PP == R_NilValue) BUG;
  return (LONGREAL(PP))[RowSigmaSqIndex];
}

LongDouble getRowSumFreq(SEXP SxI){
  assert(RowSumFreqIndex == 4);
  SEXP PP = getAttribPointer(SxI, Precise);
  if (PP == R_NilValue) BUG;
  return (LONGREAL(PP))[RowSumFreqIndex];
}

LongDouble *getColFreq(SEXP SxI){
  basic_options *opt = NULL;
  extractInfo(SxI);
  SEXP PP = getAttribPointer(SxI, Precise);
  if (PP == R_NilValue) BUG;
  return (LONGREAL(PP)) + ColFreqIndex;
}


LongDouble *getColSum(SEXP SxI){
  basic_options *opt = NULL;
  extractInfo(SxI);
  SEXP PP = getAttribPointer(SxI, Precise);
  if (PP == R_NilValue) BUG;
  return (LONGREAL(PP)) + ColSumIndex;
}


LongDouble *getColFreqSxI(SEXP SxI){
   basic_options *opt = NULL;
 extractInfo(SxI);
  SEXP PP = getAttribPointer(SxI, Precise);
  if (PP == R_NilValue) BUG;
  return (LONGREAL(PP)) + ColFreqSxIIndex;}


LongDouble getColFreqNorm2(SEXP SxI){
  basic_options *opt = NULL;
  extractInfo(SxI);
  SEXP PP = getAttribPointer(SxI, Precise);
  if (PP == R_NilValue) BUG;
  return (LONGREAL(PP))[ColFreqNorm2Index];
}


LongDouble getColSigmaSq(SEXP SxI){
  basic_options *opt = NULL;
  extractInfo(SxI);
  SEXP PP = getAttribPointer(SxI, Precise);
  if (PP == R_NilValue) BUG;
  return (LONGREAL(PP))[ColSigmaSqIndex];
}

LongDouble getColSumFreq(SEXP SxI){
  basic_options *opt = NULL;
  extractInfo(SxI);
  SEXP PP = getAttribPointer(SxI, Precise);
  if (PP == R_NilValue) BUG;
 return (LONGREAL(PP))[ColSumFreqIndex];
}

  
void calculateFreq(SEXP SxI, double *externalFreq,
		   option_type *global, utilsoption_type *utils){
  const bool debug = false;
  basic_options *opt = &(utils->basic);
  extractInfo(SxI);

  SEXP PP = getAttribPointer(SxI, Precise);
  if (debug)
    PRINTF("entering getfreq... %ld Nil=%d \n", ALONG info[30], PP==R_NilValue);
  if (PP != R_NilValue) return; // (LONGREAL(PP)) + RowFreqIndex;

  PP = allocVectorExtra(LONGREALSXP, TotalLengthIndices);
  setAttrib(SxI, Precise, PP);
  LongDouble *P = LONGREAL(PP);
 
  centering_type safe_centered = global->genetics.centered;
  normalizing_type safe_normalized = global->genetics.normalized;
  global->genetics.centered = NoCentering;
  global->genetics.normalized = NoNormalizing;
  
  P[IsExternal] = externalFreq != NULL;
  P[ColIsExternal] = 0.0; 
  for (int cM=0; cM<=1; cM++) { // cM==0: rowMeans; cM==1:colMeans
    //    printf("cM=%d %ld\n", cM, P2LONG SxI);
    Long r = cM ? cols : rows;
    Long c = cM ? rows : cols;
    Long dI = cM * ColIndex;
    LongDouble *f = P + RowFreqIndex + dI;
    //  printf("herT %ld\n", P2LONG SxI);
 
    P[TotalSumIndex + dI] = (LongDouble)
      allele_freq_LongDouble(SxI, cM, global, utils, P + RowFreqIndex +r+dI, f);

    //printf("her\n");
    if (P[IsExternal + dI]) { // keep sums etc, but overwrite freq, FreqSxI, !
      LongDouble total = 0.0;
      for (Long j=0; j<r; j++) {
	f[j] = (LongDouble) externalFreq[j];
	total += f[j] * f[j];
      }
      P[TotalSumIndex + dI] = total * (LongDouble) (c * c);
      //  if (getAttribPointer(SxI, Next) != R_NilValue) BUG; 
    }
   
    //printf("herA\n");
    LongDouble sigmaSq = 0;
    LongDouble sumFreq = 0;
    for (Long i=0; i<r; i++) {
      sumFreq += f[i];
      sigmaSq += f[i] * (1.0 - f[i]);    
    }
    P[RowSigmaSqIndex + dI] = 2.0 * sigmaSq;
    P[RowSumFreqIndex + dI] = sumFreq;

    // printf("herB\n");
   double *fSxI = P + RowFreqIndex + 2 * r + dI;
    assert(RowFreqIndex + 2 * r  + dI == RowFreqSxIIndex ||
	   RowFreqIndex + 2 * r  + dI == ColFreqSxIIndex);
    vector_raw_LongDouble_t
      vR = cM ? SxIvector_raw_LongDouble : vectorSxI_raw_LongDouble;
    vR(SxI, f, 1, r, global, utils, fSxI, c);
    
    LongDouble norm2f = 0.0;
    for (Long i=0; i<r; i++) norm2f += f[i] * f[i];
    P[RowFreqNorm2Index + dI] = norm2f;
  }
  //printf("done\n");
 
  if (P[IsExternal]==0.0 && P[TotalSumIndex] !=  P[ColTotalSumIndex]) BUG; // just a check
 

  global->genetics.centered = safe_centered;
  global->genetics.normalized = safe_normalized;
}


			   
void calculateFreq(SEXP SxI, option_type *global, utilsoption_type *utils){
  while (SxI != R_NilValue) {
    calculateFreq(SxI, NULL, global, utils);
    SxI = getAttribPointer(SxI, Next);
  }
}



void sparsevectorGeno(Uchar *code,
		 Long nrow_code,
		 Long ncol_code,
		 Long ldX, // in Byte or unit_t, depending on coding
		 coding_type coding,
		 double *valueB,
		 int nIdx, // 2nd dimension of sparse; == length(rowIdxB)
		 int *rowIdxB,
		 int *colIdxB,
		 bool tSparse,
		 option_type *global, utilsoption_type *utils,
		 double *C,
		 Long Ldc) {
  //   printINFO(SxI);
  MEMSET(C, 0, sizeof(*C) * Ldc * nrow_code);
  if (!has_ld_in_Byte(coding)) ldX *= sizeof(unit_t);
  if (tSparse) BUG;
  sparsevectorGeno_t sTG = NULL;
  switch(coding) {
  case Plink : case OrigPlink : sTG = sparsevectorGenoPlink; break;    
  case TwoBitGeno : sTG = sparsevectorGeno2Bit; break;
  case OneByteGeno : sTG = sparsevectorGenoOneByte; break;
  default : BUG;
  }

  sTG(code, nrow_code, ncol_code, ldX, coding,
      valueB, nIdx, rowIdxB, colIdxB, tSparse,
      global, utils, C, Ldc);
  
}


void sparsevectorGeno(SEXP SxI,
		bool t_SxI,
		double *valueB,
		int nIdx, // 2nd dimension of sparse; == length(rowIdxB)
		int *rowIdxB,
		int *colIdxB,
		int tSparse,
		 option_type *global, utilsoption_type *utils,
		double *C,
		Long Ldc) {
  if (!t_SxI) SxI = getAttribPointer(SxI, Next);
  basic_options *opt = &(utils->basic);	
  extractInfo(SxI);
  sparsevectorGeno((Uchar*) code, rows, cols, lda, coding,
	      valueB, nIdx, rowIdxB, colIdxB, tSparse,
	      global, utils,
	      C, Ldc);
}


int bitsPerCode(coding_type coding) {
  int bpc = 0;
  switch(coding) {
  case OneBitGeno : case OneBitHaplo : bpc = BitsPerCode1Bit(); break;
  case TwoBitGeno : case TwoBitHaplo : bpc = BitsPerCode2Bit(); break;
  case ThreeBit :BUG; //  bpc = BitsPerCode3(); break;
  case FourBit : BUG;
  case OneByteGeno :
  case OneByteHaplo : bpc = BitsPerCodeOneByte(); break;
  case TwoByte: BUG;
  case FourByteGeno : bpc = BitsPerCodePlain(); break;
   case FourByteHaplo : bpc = BitsPerCodePlain(); break;
  case Plink : bpc = BitsPerCodePlink(); break;
  case OrigPlink : BUG; // bpc = BitsPerCodeOrigPlink(); break; // ldaInByte
  case FiveCodes : BUG; //  bpc = BitsPerCodeFiveCodes(); break;
  case FourByteSingleBit : bpc = BitsPerCodePlain(); break;
  case EightByteHaplo : BUG; // bpc = BitsPerCodePlainDoubled(); break;
    break;
  default :
    PRINTF("unknown '%s' %d\n", CODING_NAMES[coding],coding);
    BUG;
  }
  return bpc;
}

SEXP SNPbind(SEXP S1, SEXP S2) {
  GetOptions;
  extractNamedInfo(S1);
  extractNamedInfo(S2);
  if (individualsS1 != individualsS2) ERR0("number of individuals differ.");
  if (codingS1 != codingS2) ERR0("codings of 'S1' and 'S2' differ.");
  if (doubledRows(codingS1, true) || uprightlyPacked(codingS1))
    ERR1("'%s' has not been programmed yet.", CODING_NAMES[codingS1]);
  if (transposedS1 != transposedS2)
    ERR0("one matrix is transposed, the other not");
  if (infoS1[BIGENDIAN] != infoS2[BIGENDIAN]) ERR0("endians differ.");
  if (infoS1[MISSINGS] + infoS2[MISSINGS] != 0)
    ERR0("missings not programmed yet.");
  if (infoS1[ISHAPLO] != infoS2[ISHAPLO])
    ERR0("one matrix is a haplo matrix, the other not.");
  if (infoS1[ISHAPLO] != infoS2[ISHAPLO])
    ERR0("one matrix is a haplo matrix, the other not.");
  if (infoS1[ONEHAPLOONLY] != infoS2[ONEHAPLOONLY])
    ERR0("one matrix contains only one haplo, the other not.");
  if (infoS1[ONEHAPLOONLY]) ERR0("'one haplo' not programmed yet.");
  // if (infoS1[] != infoS2[]) ERR0(" differ");
  SEXP nextS1 = getAttribPointer(S1, Next);
  SEXP nextS2 = getAttribPointer(S2, Next);
  if ((nextS1 == NULL) xor (nextS2 == NULL))
    ERR0("one matrix contains also its transposed, the other not");
  Long lda1 = infoS1[LDABITALIGN],
    lda2 = infoS2[LDABITALIGN];
 
  SEXP Ans = PROTECT(CreateEmptyCodeVector(snpsS1 + snpsS2, individualsS1,
					 codingS1, transposedS1,
					 nextS1 != NULL,
					 variantS1 < variantS2
					 ? variantS1 : variantS2,
					 lda1 > lda2 ? lda1 : lda2,
					 infoS1[ONEHAPLOONLY],
					 global, utils));

  SEXP A = Ans;
  SEXP O1 = S1;
  SEXP O2 = S2;
  int loops = doubledCols(codingS1, true) ? 2 : 1;
  while (A != NULL) {
    extractNamedInfo(A);
    extractNamedInfo(O1);
    extractNamedInfo(O2);
    int variant =
      main_variant(check_variant(codingA, variantA, opt->efficient));
    fill_t fill;
    switch(variant) {
    case 512:
    case 256: fill = fillIn256; break;
    case 128: fill = fillIn128; break;
    default: fill = fillIn64;
    }
    Long bits = bitsPerCode(codingO1),
      totalbits1 = bits * rowsO1,
      totalbits2 = bits * rowsO2,
      bytes1 = DIV_GEQ(totalbits1, BitsPerByte),
      bytes2 = DIV_GEQ(totalbits2, BitsPerByte);
    int rest1 = (int) (totalbits1 % BitsPerByte);
    for (int l=0; l<loops; l++) {
      Uint *cA = codeA + ldaA * colsA;
      Uint *c1 = codeO1 + ldaO1 * colsO1;
      Uint *c2 = codeO2 + ldaO2 * colsO2;
      for (Long i=0; i<colsO1; i++, cA += ldaA,	c1 += ldaO1, c2 += ldaO2) {
	MEMCOPY(cA, c1, bytes1);
	Uint *cAplus = cA + bytes1;
	if (rest1) {
	  fill(cAplus, BitsPerByte - rest1, c2, totalbits2);
	} else {
	  MEMCOPY(cAplus, c2, bytes2);
	}
      }
    }
    A = getAttribPointer(A, Next);
    O1 = getAttribPointer(O1, Next);
    O2 = getAttribPointer(O2, Next);    
  }

  ERR0("snpbind for '%s' not programmed yet\n");

  UNPROTECT(1);
  return Ans;
}
