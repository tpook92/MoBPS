
/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/


#include "Basic_miraculix.h"

#if defined compatibility_to_R_h
#include "miraculix.h"
#include "options.h"
#include "haplogeno.h"
#include "utils_miraculix.h"
#include "MXinfo.h"
#include "transform.h"
#include "Files.h"


SEXP TransformNullInfo(SEXP SxI, SEXP Transposed,
		       SEXP Coding, 
		       SEXP SelSNPS, SEXP SelIndiv,
		       SEXP AnsTransposed) {  
  GetOptions;
  int
    lenSelSnps = LENGTH(SelSNPS),
    lenSelIndiv = LENGTH(SelIndiv);
  int
    *selSnps = lenSelSnps == 0 ? NULL : INTEGER(SelSNPS),
    *selIndiv = lenSelIndiv == 0 ? NULL : INTEGER(SelIndiv);
  coding_type coding = (coding_type) INTEGER(Coding)[0];
  const usr_bool set1 =  global->genetics.haplo_set1;
  usr_bool transposed = LOGICAL(Transposed)[0] == 1 ? True : False; 
  usr_bool ansTransposed = LOGICAL(AnsTransposed)[0] == 1 ? True : False; 

  ToIntGlobal(SxI);
  unit_t *code = (unit_t*) SxIint;
  Long snps, individuals;
  if (LENGTH(SxI) == 0) ERR0("'SxI' has length 0.");
  if (isMatrix(SxI)) {
    individuals = ncols(SxI); // OK
    snps = nrows(SxI); // OK
  } else {
    individuals = 1;
    snps = LENGTH(SxI);
  }
  if (isOneByte(coding)) snps *= BytesPerUnit; // OK
  if (isHaplo(coding)) {
    if (doubledRows(coding, false) xor (transposed == True)) {
      if (snps % 2 != 0) ERR0("snps are not doubled");
      snps /= 2;
    } else {
      if (individuals % 2 != 0) ERR0("indviduals are not doubled");
      individuals /= 2;
    }
  }
  
  coding_type ansCoding = global->genetics.coding;
  if (coding == AutoCoding) coding = FourByteGeno;
  if (ansCoding == CorrespondingGeno)
    ansCoding = swapHaploGeno(coding, false);
  else if (!global->genetics.interprete_coding_as_is)
    ansCoding = swapHaploGeno(ansCoding, isHaplo(coding));
  
   SEXP Ans = PROTECT(transform(code, NULL, snps, individuals, coding,
				transposed, 0,
				selSnps, lenSelSnps, selIndiv, lenSelIndiv,
				set1, global->tuning.addtransposed,
				global, utils,
				ansCoding, ansTransposed, 0));
  FREEglobal();
  UNPROTECT(1);
  return Ans;  
}



SEXP Transform(SEXP SxI, SEXP Transposed, SEXP Coding, SEXP SelSNPS,
	       SEXP SelIndiv, SEXP AnsTransposed) {
  // from user: Coding == oldcoding
  // to user: Coding == newcoding
  //
  // (i) AutoCoding or given SelSNPS/SelIndiv makes always a copy
  //     AutoCoding takes the coding from options$snpcoding
  // (ii) UnknownSNPcoding or (identical old coding and new coding)
  //            completes information without copying
  
   // if (TYPEOF(SxI) == INTSXP)  printf("hier %d %d\n", INTEGER(SxI)[0], INTEGER(SxI)[1]); else if (TYPEOF(SxI) == STRSXP) printf("file %d %s\n", LENGTH(SxI), CHAR(STRING_ELT(SxI, 0))); else printf("Aaahh %f %f\n", REAL(SxI)[0], REAL(SxI)[1]);
  Long *info = GetInfo(SxI, true);
  if (info == NULL && TYPEOF(SxI) != STRSXP)
   return TransformNullInfo(SxI, Transposed, Coding, SelSNPS, SelIndiv,
			    AnsTransposed);
 
  GetOptions;
  ASSERT_LITTLE_ENDIAN; 

  int
    lenSelSnps = LENGTH(SelSNPS),
    lenSelIndiv = LENGTH(SelIndiv);
  int
    *selSnps = lenSelSnps == 0 ? NULL : INTEGER(SelSNPS),
    *selIndiv = lenSelIndiv == 0 ? NULL : INTEGER(SelIndiv);
  coding_type coding = (coding_type) INTEGER(Coding)[0];
  
  
  assert(LastGenoCoding == 13);
  const usr_bool set1 =  global->genetics.haplo_set1;
  
 const bool
    only_complete = coding == UnknownSNPcoding,
    no_select = lenSelSnps == 0 && lenSelIndiv == 0,
    transformOnPlace =  no_select &&
    (only_complete || (info != NULL && info[CODING] == coding));
 int n_protect = 0;  
 int variant = //  info != NULL ? info[VARIANT] :
    global->tuning.variant;

 SEXP
    filecoding = R_NilValue,
    filename = R_NilValue,
    newSxI = R_NilValue;
 
  
 coding_type
    ansCoding = (coding == AutoCoding ||
		      (only_complete && info == NULL)
		      ? global->genetics.coding
		      : only_complete ? (coding_type) info[CODING]
		      : coding); 
  
 if (ansCoding == FourBit || ansCoding == TwoByte)
    ERR0("'FourBit' and 'TwoByte' are not programmed yet.");  
  if (!(isNarrowGeno(ansCoding) || isHaplo(ansCoding))) {
    // printf("%d %s\n", (int) ansCoding, CODING_NAMES[ansCoding]);
    BUG;
  }
  
   
  if (TYPEOF(SxI) == STRSXP) { /// is file
    if (isCompressed(ansCoding) &&
	!global->genetics.interprete_coding_as_is)
      ansCoding = swapHaploGeno(ansCoding, false);
    filename = PROTECT(COPY_SEXP_STRING(SxI)); n_protect++;
    usr_bool ansTransp= info != NULL && ((usr_bool) info[TRANSPOSED]) != Nan
      ? (usr_bool) info[TRANSPOSED] : False,
      tmpTransp = ansTransp;    
    bool early_ret = only_complete ||
      (no_select &&
       matrix_coding_1Byte(ansCoding, &tmpTransp, 0, opt->bigendian) != NULL);
    coding_type tmpCoding = early_ret ? ansCoding :
      isHaplo(ansCoding) ? OneByteHaplo : OneByteGeno;
    
  
    PROTECT(newSxI = file_intern(SxI, // ToDo: hier gleich auswahl!
				 // dann muss tmpCoding nicht auf OneByteGeno
				 // gesetzt werden.
				 tmpCoding, ansTransp, variant,
				 global, utils, only_complete,
				 R_NilValue));

    //printf("************* early_ret=%d complete=%d\n", early_ret, only_complete);
    
    n_protect++;
    if (early_ret) goto ende;
    FREE_SEXP(&SxI);
    SxI = newSxI;
    info = GetInfoUnchecked(SxI); // OK
    assert(info != NULL && ansCoding != CorrespondingGeno);
  }

  
  if (transformOnPlace) {
    SEXP tmp = getAttribPointer(SxI, Filecoding);
    if (tmp != R_NilValue) {
      filecoding = PROTECT(COPY_SEXP_STRING(tmp)); n_protect++;
    }
    tmp = getAttribPointer(SxI, Filename);
    if (tmp != R_NilValue) {
      filename = PROTECT(COPY_SEXP_STRING(tmp)); n_protect++;
    }
  }
   
  ASSERT_LITTLE_ENDIAN;
  
  if (ansCoding == CorrespondingGeno)
    ansCoding = swapHaploGeno(coding, false);
  
  PROTECT(newSxI = transform(SxI,
			     selSnps, lenSelSnps, selIndiv, lenSelIndiv,
			     set1, global->tuning.addtransposed,
			     global, utils, transformOnPlace,
			     ansCoding, info[TRANSPOSED] == 0 ? False : True,
			     variant));

   
  n_protect++;
  

 ende:
  

 SEXP dummy = newSxI;
  while (dummy != R_NilValue) {
    if (filename != R_NilValue) setAttrib(dummy, Filename, filename);//install!
    if (filecoding != R_NilValue) setAttrib(dummy, Filecoding, filecoding);
    copyAttribInfos(dummy, SxI, false, lenSelSnps + lenSelIndiv != 0);
    dummy = getAttribPointer(dummy, Next);
  }
  
  if (n_protect) UNPROTECT(n_protect);
  return newSxI;  
}


SEXP transpose(SEXP SxI){
  GetOptions;
  return transpose(SxI, global, utils);
 }


#endif
