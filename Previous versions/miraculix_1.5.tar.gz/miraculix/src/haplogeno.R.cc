/*
 Authors 
 Martin Schlather, martin.schlather@uni-mannheim.de

 Copyright (C) 2022-2023 Martin Schlather

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/


#include "Basic_miraculix.h"

#if defined compatibility_to_R_h

#include "miraculix.h"
#include "options.h"
#include "utils_miraculix.h"
#include "extern.h"
#include "mmagpu.h"
#include "Template.h"
#include "transform.h"

#include "haplogeno.h"
#include "intrinsicsCheck.h"
#include "intrinsics_specific.h"

#include "MXinfo.h"
#include "Haplo.h"
#include "Files.h"
#include "1bit.h"
#include "2bit.h"
#include "3bit.h"
//#include "OneByte.h"



SEXP get_centered() {
  GetOptions;
  int len = global->genetics.ncentered ;
  double *centered = global->genetics.pcentered;
  assert (centered != NULL && global->genetics.centered==User);
  SEXP Ans;
  PROTECT(Ans = allocVector(REALSXP, len));
  MEMCOPY(REAL(Ans), centered, Memory(REALSXP) * len);
  UNPROTECT(1);
  return Ans;
}


SEXP createSNPmatrix(SEXP SNPs, SEXP Individuals) {
  GetOptions;
  int 
    n = Int0(Individuals),
    snps = Int0(SNPs);
  coding_type coding = global->genetics.coding;
  int
    variant = check_variant(coding, global->tuning.variant, opt->efficient);
  return createSNPmatrix(snps, n, coding, variant, 0, global, utils);
}

SEXP crossprodGen(SEXP SxI, centering_type SxIcentering, usr_bool Transp, 
		  normalizing_type normalizing, bool squared, SEXP Ans){
  // 
  int n_prot=0;
  GetOptions;
  SEXP next = getAttribPointer(SxI, Next);
  if (((usr_bool) GetInfo(SxI)[TRANSPOSED]) != Transp && next != R_NilValue) {
    //BUG;
    SxI = next;
  }
  extractInfo(SxI);
  stopIfNotInt(individuals);
  stopIfNotInt(snps);
  stopIfNotInt(lda);  
  if ((int) coding == NA_LONG) ERR0("looks like an uninitialised matrix");
  if (isHaplo(coding))
     ERR0("matrix is a haplotype matrix, not a genomic matric");
  if (coding == UnknownSNPcoding) ERR0("not a coded Z matrix");
  if (uprightlyPacked(coding) && Transp == True)
    ERR1("'%s' does not allow LD calculation yet", CODING_NAMES[coding]);
  variant = check_variant(coding, variant, opt->efficient);

   if (Ans == R_NilValue) {
     int rowsAns = stopIfNotInt(Transp == False ? individuals : snps);
     Ans = PROTECT(allocMatrix(REALSXP, rowsAns, rowsAns));
     n_prot ++;
   }
  double *ans = REAL(Ans);

  centering_type
    centering = (transposed == False ? SxIcentering : // else Transp == True
		 SxIcentering == SNPmeans ? ColMeans :
		 SxIcentering == INDIVmeans ? RowMeans : SxIcentering),
    newCentering = (Transp == transposed ? centering : // else Transp == True
		    centering == RowMeans ? ColMeans :
		    centering == ColMeans ? RowMeans : centering);
  
  //  printf("**************** transposed %d %d; centering %d->%d->%d\n", transposed, Transp, SxIcentering, centering, newCentering);
  
  calculateFreq(SxI, global, utils);

  //  printf("Freq calculated\n");
  
  if (transposed == Transp) {
    crossprodI(code, rows, cols, lda, coding, variant, newCentering,
	       normalizing, squared,
	       LONGREAL(getAttribPointer(SxI, Precise)),
	       opt, &(global->tuning), ans);
  } else {
    int err = t_crossprodI(code, rows, cols, lda, coding, variant, newCentering,
			   normalizing, squared,
			   LONGREAL(getAttribPointer(SxI, Precise)),
			   opt, &(global->tuning), ans);
    if (err) {
      crossprodGen(PROTECT(transpose(SxI, global, utils)), SxIcentering, 
		   Transp,
		   normalizing, squared, Ans);
      n_prot++;
    }
  }
  if (n_prot) UNPROTECT(n_prot);
  return Ans;
}

SEXP gencrossprod(SEXP SxI) {
  GetOptions;
  return crossprodGen(SxI, global->genetics.centered, False,
		      getNormalized(global->genetics),
		      global->genetics.squared, R_NilValue);
}

SEXP crossprod(SEXP SxI) {
  return crossprodGen(SxI, NoCentering, False, NoNormalizing, false,
		      R_NilValue);
}


//  return crossprodGen(SxI, SNPmeans,  False,  NoNormalizing, false, R_NilValue);  // crossprod(geno - rowMeans(geno)), crossprod(M) = t(M) %*% M

// return crossprodGen(SxI, INDIVmeans, True, NoNormalizing, false, R_NilValue); //  crossprod(t(geno) - rowMeans(t(geno))), crossprod(M) = t(M) %*% M
  //*************** transposed 0 1; centering 2->2->1
  //************** transposed 1 1; centering 2->1->1


SEXP LD(SEXP SxI, SEXP r2) {
  return crossprodGen(SxI, SNPmeans, True, CorrNormalizing, LOGICAL(r2)[0], R_NilValue); //  tcrossprod(geno - rowMeans(geno)) ## == LD unnormed
  //************* transposed 0 1; centering 1->1->2
  //************ transposed 1 1; centering 1->2->2
}


SEXP relationship(SEXP VARIABLE_IS_NOT_USED SxI) {
  BUG; // unused
}

SEXP zeroGeno(SEXP SxI, SEXP Snps, SEXP Individuals, SEXP Copy) {
  GetOptions;
  extractBasicInfo(SxI);
  Uint
    *SnpsList = (Uint*) INTEGER(Snps),
    lenSnps = LENGTH(Snps),
    *IndivList =(Uint*) INTEGER(Individuals),
    lenIndiv = LENGTH(Individuals);
  ASSERT_LITTLE_ENDIAN;
  
  SEXP Ans = SxI;
  SEXP next = getAttribPointer(SxI, Next);

  if (LOGICAL(Copy)[0]) {
    Ans = PROTECT(createSNPmatrix(snps, individuals,
				  coding, (usr_bool) info[TRANSPOSED],
				  next != NULL,
				  global->tuning.variant, 0,
				  false, R_NilValue, global, utils));
    SEXP tmpAns = Ans,
      tmpSxI = SxI;
    while (tmpAns != NULL) {
      info = GetInfo(tmpSxI);
      MEMCOPY(Align(tmpAns, opt), Align(tmpSxI, opt),
	      info[MEMinUNITS] * BytesPerUnit); // OK      
      tmpSxI = getAttribPointer(tmpSxI, Next);
      tmpAns = getAttribPointer(tmpAns, Next);
    }
  }
    
  if (next != NULL) ERR0("not programmed yet");
  switch(coding) {
  case OneBitGeno :
  case OneBitHaplo :
    zeroGeno1(Ans, SnpsList, lenSnps, IndivList, lenIndiv, opt);break;
  case TwoBitGeno :case TwoBitHaplo :
    zeroGeno2(Ans, SnpsList, lenSnps, IndivList, lenIndiv, opt);break;
  case ThreeBit :
    zeroGeno3(Ans, SnpsList, lenSnps, IndivList, lenIndiv, opt);break;
  default :  ERR0("zero-ing does not work (yet) for given coding");
  }

  if (LOGICAL(Copy)[0]) UNPROTECT(1);

  return Ans;
}



SEXP allele_freq(SEXP SxI) {
  GetOptions;
  Long *info = GetInfo(SxI),
    snps = info[SNPS];
  SEXP Ans = PROTECT(allocVector(REALSXP, snps));
  allele_freq_double(SxI, false, global, utils, NULL, REAL(Ans));
  UNPROTECT(1);
  return Ans;
}


SEXP matrix_get(SEXP SxI) {
  GetCores;
  extractInfo(SxI);
  ASSERT_LITTLE_ENDIAN;
  SEXP Ans =  PROTECT(allocMatrix(INTSXP,
				  stopIfNotInt(rows), stopIfNotInt(cols)));
  
  matrix_get_4Byte(code, rows, cols, 
		   coding, lda, cores,
		   (unit_t*) INTEGER(Ans),
		   GetNatLDA(transposed == False ? rows : cols, FourByteGeno),
		   transposed);
  UNPROTECT(1);
  return Ans;
}


SEXP fillSNPmatrix(SEXP Z, SEXP Idx, SEXP Vector) {
  GetOptions;
  ToIntLocal(Idx);
  extractInfo(Z);
  extractNamedInfo(Vector);
  if (rows != snpsVector) ERR0("number of rows differ.");
  if (!isRoughlyGeno(coding)) ERR0("not a geno matrix that is filled");
  if (coding != codingVector) ERR0("codings of 'SxI' and 'values' differ.");
  if (variant != variantVector) ERR0("variants differ");
  if (info[BIGENDIAN] != infoVector[BIGENDIAN]) ERR0("endians differ");
  
  Long len = LENGTH(Idx),
    bytes = BytesPerUnit * MIN(lda, ldaVector);// OK
  for (Long i=0; i<len; i++, codeVector += ldaVector) {
    Long idx = Idxint[i] - 1;
    if (idx >= cols) ERR0("Idx out of bound");
    MEMCOPY(code + idx * lda, codeVector, bytes);
  }
  FREEcreated(Idx);
  return R_NilValue;
}



SEXP substract_centered(SEXP SnpXindiv) {
  GetCores;
  Long len = global->genetics.ncentered;
  int individuals = ncols(SnpXindiv);
  int snps = nrows(SnpXindiv);
  SEXP Ans;
  PROTECT(Ans = allocMatrix(REALSXP, snps, individuals));
  double *ans = REAL(Ans),
    *snpXindiv = REAL(SnpXindiv),
    *centered = global->genetics.pcentered;
  assert(centered != NULL && global->genetics.centered==User);
  if (snps != len) ERR0("length of 'centered' must equal the number of SNPs.");

#ifdef DO_PARALLEL
#pragma omp parallel for num_threads(cores) schedule(static)
#endif
  for (Long i=0; i<individuals; i++) {
    Long i_snps = i * snps;
    double *s = i_snps + snpXindiv,
      *a = ans + i_snps;
    for (Long j=0; j<snps; j++) a[j] = s[j] - centered[j];
  }
  UNPROTECT(1);
  return Ans;
}


bool debugging = false;
SEXP Debug() { debugging = true; return R_NilValue; }
SEXP StopDebug() { debugging = false;  return R_NilValue; }

SEXP is2BitMethod(SEXP Meth) { // 'Method' is global already
  SEXP Ans;
  int coding = INTEGER(Meth)[0];
  PROTECT(Ans = allocVector(LGLSXP, 1));
  LOGICAL(Ans)[0] = is2Bit(coding);
  UNPROTECT(1);
  return Ans;
}



SEXP snpbind(SEXP S1, SEXP S2, SEXP force) {
  GetOptions;
  extractNamedInfo(S1);
  extractNamedInfo(S2);
  if (!false || !LOGICAL(force)[0] &&
      (double) snpsS1 + (double) snpsS2 > MAXINT)
    ERR3("number of snps (%ld + %ld = %10.0f) exceeds the range of integers. Set 'force = TRUE' iff you know the consequences.",
	 ALONG snpsS1, ALONG snpsS2, (double) snpsS1 + (double) snpsS2);
  return SNPbind(S1, S2);
}


#endif
