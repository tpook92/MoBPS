## Authors 
## Martin Schlather, martin.schlather@uni-mannheim.de
##
##
## Copyright (C) 2017 -- 2021 Martin Schlather
##
## This program is free software; you can redistribute it and/or
## modify it under the terms of the GNU General Public License
## as published by the Free Software Foundation; either version 3
## of the License, or (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  


ENV <- environment()

transpose <- function(x) .Call(C_transpose, x)

Transform <- function(SNPxIndiv, isIndividualsPerColumn=TRUE, snpcoding, 
		      sel.snps=NULL, sel.individuals=NULL,
		      targetIndividualsPerColumn=TRUE) {
  
  ## NOTE!! snpXindiv might point to SNPxIndiv. This may happen,
  ## * if snpcoding = UnknownSNPcoding  or
  ## * if codings are both equal and
  ##         (users coding (e.g. FourByteGeno) || SNPxIndiv is a string)
  ## cases depending of SNPxIndiv:
  ## (a) character
  ##     SNPxIndiv gives the file name. The filename with be always attached.
  ##     Important information can only be read from the file. Partial
  ##     information is however available. Hence info always exists, but might
  ##     be in complete.
  ##     (i) if snpcoding is AutoCoding, the file is read, info is completed
  ##         and the new coding is given by RFoptions(snpcoding)
  ##     (ii) if snpcoding equals UnknownSNPcoding, info is completed, but the
  ##         file is not read in.
  ## (b) compressed matrix
  ##     snpcoding gives the new coding;
  ##     if snpcoding=AutoCoding then RFoption(snpcoding) is the new coding
  ##     if snpcoding=UnknownSNPcoding then the current coding is kept
  ## (c) numeric matrix with no info is attached, snpcoding
  ##    gives the current coding (type of haplo coding) and the new coding
  ##    is given by RFoption(snpcoding).



  ##  Print(isIndividualsPerColumn, targetIndividualsPerColumn)
  
  if (!isIndividualsPerColumn || !targetIndividualsPerColumn)
    stop("transposed not programmed yet")

  snpXindiv <- .Call(C_Transform, SNPxIndiv, !isIndividualsPerColumn,
		     snpcoding, 
                     if (length(sel.snps) > 0) as.integer(sel.snps - 1),
                     if (length(sel.individuals) > 0)
                       as.integer(sel.individuals - 1),
		     !targetIndividualsPerColumn)
  return(snpXindiv)
}

perColumn2coding <- function(IndividualsPerColumn, DoubledIndividuals)
  if (IndividualsPerColumn) {
    if (IndividualsPerColumn == 1) {
      if (DoubledIndividuals) {
        if (DoubledIndividuals == 1) FourByteSingleBit
	else FourByteHaplo
      } else EightByteHaplo
    } else if (DoubledIndividuals == 2) OneByteHaplo
    else stop("IndividualsPerColumn==2 requires DoubledIndividuals == 2")
  } else if (DoubledIndividuals) {
    if (DoubledIndividuals == 1) EightByteHaplo
    else
      stop("DoubledIndividuals must be logical if IndividualsPerColumn=FALSE")
  } else FourByteSingleBit


haplomatrix <- function(M, # haplomatrix converts between usr and intern code
                        ##  and reversely!
                        IndividualsPerColumn=TRUE,
                        DoubledIndividuals=TRUE,
                        sel.snps=NULL, sel.individuals=NULL, ## selection
                        ...
                        ) {## coding checked in C
  internalRFoptions(COPY=TRUE, RETURN=FALSE, ...)
  haplomatrixIntern(M=M, IndividualsPerColumn=IndividualsPerColumn,
                    DoubledIndividuals=DoubledIndividuals,
                    sel.snps=sel.snps, sel.individuals=sel.individuals)
}

IS <- function(M, what) {
  if (is(M, what)) return(TRUE)
  info <- GetAttr(M, "information")
  if (length(info) != INFO_LAST + 1) return(FALSE)
  return (xor(info[ISHAPLO+1], what=="genomatrix"))
}
                        
haplomatrixIntern <- function(M, 
                        IndividualsPerColumn=TRUE,
                        DoubledIndividuals=TRUE,
                        sel.snps=NULL, sel.individuals=NULL 
                        ) {
   
  is.compressed <- IS(M, HAPLOMATRIX)
 
  ##  Print("AAA", M, is.compressed);
  coding <-perColumn2coding(IndividualsPerColumn, DoubledIndividuals)
  ans <- Transform(M, snpcoding=coding,
		   isIndividualsPerColumn=IndividualsPerColumn,
		   sel.snps=sel.snps,
                   sel.individuals=sel.individuals)
  if (is.compressed) {
    info <- GetAttr(ans, "information")
    rows <- info[SNPS + 1]
    cols <- info[INDIVIDUALS + 1]
    coding <- info[CODING + 1]
    transposed <- as.logical(info[TRANSPOSED + 1])
    attributes(ans) <- NULL
    class(ans) <- NULL
    if (transposed) { tmp <- rows; rows <- cols; cols <- tmp  }
    if (coding %in% c(OneBitHaplo, TwoBitHaplo, OneByteHaplo, FourByteHaplo,
                      FourByteSingleBit))
      cols <- 2 * cols
    else if (coding %in% c(EightByteHaplo)) rows <- 2 * rows
    dim(ans) <- c(rows, cols)
  }
  ans
}


decodeGeno <- function(SNPxIndiv, sel.snps=NULL, sel.individuals=NULL,
                       do.centering=FALSE, ..., COPY=TRUE) {
  ## may not used internally!
		    ##  Print("decode", SNPxIndiv, "do");
  RFopt <- internalRFoptions(COPY=COPY, getoptions_="genetics", ...)
  snpcoding <- NULL
  if (IS(SNPxIndiv, GENOMICMATRIX) || is.character(SNPxIndiv) ||
      (is.numeric(SNPxIndiv) &&
	  length(sel.snps) + length(sel.individuals) + do.centering > 0)) {
    ans <- Transform(SNPxIndiv, snpcoding=FourByteGeno, 
                     sel.snps=sel.snps, sel.individuals=sel.individuals)
    
    if (do.centering) {
      if (GetAttr(ans, "information")[1 + CODING] != FourByteGeno)
	stop("do.centering = TRUE not allowed", CONTACT)
      centered <- getRFoptions(getoptions_="genetics")$centered    
	if (centered=="user") return(.Call(C_substract_centered, ans))
	else if (centered=="row means") return(ans - rowMeans(ans))
	else stop("snp matrix cannot be centered on the fly through '",
		  centered, "'.")
    } 

    
    ##   Print(ans); xxxxx    
    info <- GetAttr(ans, "information")
    rows <- info[SNPS + 1]
    cols <- info[INDIVIDUALS + 1]
    coding <- info[CODING + 1]
    transposed <- as.logical(info[TRANSPOSED + 1])
    attributes(ans) <- NULL
    class(ans) <- NULL
    if (transposed) { tmp <- rows; rows <- cols; cols <- tmp }
    dim(ans) <- c(rows, cols)
    return(ans)
  }
  if (is.numeric(SNPxIndiv)) return(SNPxIndiv)
  stop("unknow SNPxIndiv format")
}


genomicmatrix <- function(snps, individuals, IndividualsPerColumn=NULL,
			  file.type=NULL, file.coding = NULL, header=NULL,
                          DoubledIndividuals=NULL, leadingcolumns=NULL,
                          loading = TRUE, sel.snps=NULL, sel.individuals = NULL,
			  targetIndividualsPerColumn=TRUE,
                          ...) {
  isIndividualsPerColumn <-
    if (length(IndividualsPerColumn)==0) TRUE else IndividualsPerColumn;
  RFopt <- internalRFoptions(COPY=TRUE, getoptions_="genetics", ...)
      
  L <- length(list(...))
  if (IS(snps, GENOMICMATRIX)) {
    warning("'snps' is already of class '", GENOMICMATRIX,
            "'. Its original definition is kept.");
    if (length(list(match.call())) > 2 + L)
      stop("further arguments may not be given")
    return(snps)
  }

   if (hasArg("individuals")) { ## create empty matrix
    if (length(as.list(match.call())) != 3 + L)
      stop("if 'individuals' is given exactly 'snps' and 'individuals' must be given.")
    if (!is.numeric(snps) || length(snps) != 1)
      stop("'snps' and 'individuals' must be integers that give the size of the SNP matrix.")
    return (.Call(C_createSNPmatrix, as.integer(snps), as.integer(individuals)))
  }

   if (is.character(snps)) {
    if (length(GetAttr(snps, "information")) == 0) {
      snps <- fileInfo(filename = snps,
                       file.type=file.type, file.coding = file.coding,
                       header= header,
                       IndividualsPerColumn=IndividualsPerColumn,
                       DoubledIndividuals=DoubledIndividuals,
                       leadingcolumns=leadingcolumns, loading=loading)
    }
    stopifnot(length(attr(snps, "filecoding")) != 0)
					#
#  Print("XX", snps)
   return(Transform(snps,
		    snpcoding=if (loading) AutoCoding else UnknownSNPcoding,
		    isIndividualsPerColumn = isIndividualsPerColumn,
		    targetIndividualsPerColumn = targetIndividualsPerColumn))
  }

  ##  Print("X", snps)
  
  coding <- if (IS(snps, HAPLOMATRIX)) CorrespondingGeno else FourByteGeno

#  Print(snps)
  Transform(snps, snpcoding = coding,
	    isIndividualsPerColumn = isIndividualsPerColumn,
            sel.snps=sel.snps, sel.individuals = sel.individuals)
}


copyGeno <-function(SNPxIndiv, snpcoding=NULL) {
##  Print("copyGeno")
  internalRFoptions(COPY=TRUE, RETURN=FALSE)
  Transform(SNPxIndiv,
	    snpcoding = if (length(snpcoding) > 0) snpcoding
			else if (!is.character(SNPxIndiv)) AutoCoding
			else UnknownSNPcoding)
}


fillGeno <- function(SNPxIndiv, sel.individuals, values,
                     IndividualsPerColumn=NULL,
                     DoubledIndividuals=NULL) {## coding checked in C
  ##  Print("fillGeno")
  ## SNPxIndiv[, sel.individuals] <- values
  ## note: values can be anything: haplo, geno, coded or uncoded
  internalRFoptions(COPY=TRUE, RETURN=FALSE)
  if (is.character(SNPxIndiv))
    SNPxIndiv <- Transform(SNPxIndiv, snpcoding=AutoCoding,
			   isIndividualsPerColumn = IndividualsPerColumn)
  stopifnot(IS(SNPxIndiv, GENOMICMATRIX))
  info <- GetAttr(SNPxIndiv, "information")
  internalRFoptions(COPY=FALSE, RETURN=FALSE,
		    snpcoding=info[CODING+1], interprete_as_is = TRUE)
  
  if (!IS(values, GENOMICMATRIX)) {
    H <- (length(IndividualsPerColumn) > 0) + (length(DoubledIndividuals) > 0)
    if (H > 0) {
      if (IS(values, HAPLOMATRIX)) stop("'IndividualsPerColumn' may not be given if 'values' is already a compressed matrix")
      if (H != 2)
        stop("'IndividualsPerColumn' and 'DoubledIndividuals' must be given")
    }
    coding <- if (IS(values, HAPLOMATRIX)) AutoCoding
              else if (H == 0) FourByteGeno  #usr geno
              else perColumn2coding(IndividualsPerColumn, DoubledIndividuals)#==
    values <- Transform(values, snpcoding=coding,
			isIndividualsPerColumn=IndividualsPerColumn)
  }
  stopifnot(IS(values, GENOMICMATRIX) ||
            info[CODING+1] != GetAttr(values, "information")[CODING+1])
  
  if (is.logical(sel.individuals))
    sel.individuals <- which(rep(sel.individuals, length=info[INDIVIDUALS + 1]))
  .Call(C_fillSNPmatrix, SNPxIndiv, as.integer(sel.individuals), values)
}



relMatrixIntern <- function(SNPxIndiv, COPY=TRUE, ...) {
  RFopt <- internalRFoptions(COPY=COPY, getoptions_=c("basic", "genetics"), ...)
  ##if (!hasArg("COPY")) on.exit(optionsDelete(RFopt))

  centered <- RFopt$genetics$centered
    
  if (!IS(SNPxIndiv, GENOMICMATRIX) || is.character(SNPxIndiv))
    SNPxIndiv <- genomicmatrix(SNPxIndiv, COPY=FALSE)
  info <- GetAttr(SNPxIndiv, "information")
  coding <- info[CODING + 1]
  variant <- info[VARIANT + 1]
  n <- info[INDIVIDUALS]
  p <- info[SNPS]

  if (RFopt$basic$verbose) cat("coding =", CODING_NAMES[coding + 1],
                       "variant =", variant,
		       "using", RFopt$basic$cores, "core(s).\n")

 A <- if (variant >= VARIANT_R) {
        stopifnot(coding == FourByteGeno)
        if (variant == VARIANT_R) base::crossprod(SNPxIndiv)
        else if (is.double(SNPxIndiv)) {
	  stop("'variant > VARIANT_R' not possible anymore")
	  ## RandomFieldsUtils::crossprodx(SNPxIndiv)
	}	
        else .Call(C_crossprodInt, SNPxIndiv, SNPxIndiv, as.integer(-1))
      } else .Call(C_gencrossprod, SNPxIndiv)
  attr(A, "centered") <- centered
  if (centered != "user" && variant < VARIANT_R) return(A) ## centered by .Call

  if (info[TRANSPOSED]) stop("not programmed yet")
  
  normalized <- RFopt$genetics$normalized
  if (centered == "user") {
    if (ncol(SNPxIndiv) == nrow(SNPxIndiv))
      stop("unclear what kind of user defined centering is meant as SNPxIndiv is quadratic.")
    m  <- .Call(C_get_centered)
    centered <- if (length(m) == nrow(SNPxIndiv)) "row means"
                else if (length(m) == ncol(SNPxIndiv)) "column means"
                else stop("size of centering vector doesn't match snp matrix.")
    attr(A, "centered") <- centered
  } else  m <- if (centered == "column means") colMeans(SNPxIndiv)
               else rowMeans(SNPxIndiv)
  

  if (centered == "column means") {  
    A <- A - tcrossprod(m) * p
    if (normalized) A <- A * tcrossprod( 1/sqrt(diag(A)) )
  } else if (centered == "row means"){
    ## row means
    pA <- vectorGenoIntern(V=m, SNPxIndiv=SNPxIndiv) ##, do.centering=FALSE)
    A <- A - pA - base::'%*%'(rep(1, length(pA)), t(pA)) + sum(m^2)
    if (normalized) A <- A / sum(m * (1 - m / 2))
  } else stopifnot(centered == "no centering")

  return(if (RFopt$genetics$squared) A^2 else A)
}

relationshipMatrix <- function(SNPxIndiv, ...) relMatrixIntern(SNPxIndiv,...)
## called by crossprodx

XXrelationshipMatrix <- function(SNPxIndiv, ...) { ## may not be called internall 
   if (!IS(SNPxIndiv, GENOMICMATRIX) || is.character(SNPxIndiv))
    SNPxIndiv <- genomicmatrix(SNPxIndiv, targetIndividualsPerColumn=TRUE, ...)
   else internalRFoptions(COPY=TRUE, RETURN=FALSE)  
  .Call(C_relationship, SNPxIndiv)
}
  
 
crossprodx <- function(SNPxIndiv, ...) { ## may not be called internall 
  if (!IS(SNPxIndiv, GENOMICMATRIX) || is.character(SNPxIndiv))
    SNPxIndiv <- genomicmatrix(SNPxIndiv, targetIndividualsPerColumn=TRUE, ...)
  else internalRFoptions(COPY=TRUE, RETURN=FALSE) 
  .Call(C_crossprod, SNPxIndiv)
}
  
  

LD <- function(SNPxIndiv, r2=TRUE, ...) {
  ## if ((num <- is.numeric(SNPxIndiv))) SNPxIndiv <- t(SNPxIndiv)
  if ((not_gm <- !IS(SNPxIndiv, GENOMICMATRIX) || is.character(SNPxIndiv))) 
    SNPxIndiv <- genomicmatrix(SNPxIndiv, ..., targetIndividualsPerColumn=FALSE)
  else internalRFoptions(COPY=TRUE, RETURN=FALSE)  
  .Call(C_LD, SNPxIndiv, r2)
}
  


solveRelMat <- function(A, tau, vec, betahat = NULL, destroy_A=FALSE) {
  ## if not destroyed, more memory is consumed
  ## implements ( t(Z) Z + tau \1_{ind x ind} )^{-1} %*% vec
  internalRFoptions(COPY=TRUE, RETURN=FALSE)
  .Call(C_solveRelMat, A, as.double(tau), as.double(vec),
        if (!is.null(betahat)) as.double(betahat),
        destroy_A)
}

                
SNPeffect <- function(SNPxIndiv, vec, centered=TRUE, tau=0) {
  ## !! FKT darf nicht intern verwendet werden wegen COPY=TRUE!! 
  rM <- relMatrixIntern(SNPxIndiv,
                        COPY=TRUE, ## da bereits genomicmatrix kopiert
                        centered=centered, normalized=FALSE)
  if (tau != 0) rM <- rM + diag(nrow(rM)) * tau ## ehemals eps
  rM <- solvex(rM, vec)
  genoVector(SNPxIndiv, rM)
}



allele_freq <- function(SNPxIndiv) { 
  ## !! FKT darf nicht intern verwendet werden wegen genomicmatrix(COPY=TRUE)!! 
  ## name <- as.character(as.list(match.call(envir=parent.frame(2L)))[[1]])
  #Print(is.character(SNPxIndiv),is.matrix(SNPxIndiv),    IS(SNPxIndiv, GENOMICMATRIX))
  if (is.character(SNPxIndiv)) SNPxIndiv <- genomicmatrix(SNPxIndiv)
  else internalRFoptions(COPY=TRUE, RETURN=FALSE)
  if (is.matrix(SNPxIndiv)) return(rowMeans(SNPxIndiv) * 0.5)
  stopifnot(IS(SNPxIndiv, GENOMICMATRIX))
##   s ave(file="snp.rda", SNPxIndiv); print("delete");
  .Call(C_allele_freq, SNPxIndiv)
}




 #  else if (any(!is.finite(snps) | snps < 1))
 ##   stop("all values of 'snps' must be positive integers")
zeroGeno <- function(SNPxIndiv, sel.snps, sel.individuals) {
  COPY <- TRUE
  internalRFoptions(COPY=COPY, RETURN=FALSE)
  
  if (is.matrix(SNPxIndiv)) {
    if (missing(sel.snps)) sel.snps <- TRUE
    if (missing(sel.individuals)) sel.individuals <- TRUE
    SNPxIndiv[sel.snps, sel.individuals] <- 0L
    return(SNPxIndiv)
  }

  info <- GetAttr(SNPxIndiv, "information")
  snps <- info[1 + SNPS]
  if (missing(sel.snps)) sel.snps <- 1:snps
  else if (is.logical(sel.snps)) sel.snps <- which(rep(sel.snps, length=snps))
 
  indiv <- info[1 + INDIVIDUALS]
  if (missing(sel.individuals)) sel.individuals <- 1 : indiv
  else if (is.logical(sel.individuals))
    sel.individuals <- which(rep(sel.individuals, length=indiv))
    
  stopifnot(IS(SNPxIndiv, GENOMICMATRIX))
  .Call(C_zeroGeno, SNPxIndiv, as.integer(sel.snps - 1),
        as.integer(sel.individuals - 1), TRUE)
}

zeroNthGeno <- function(SNPxIndiv, snps) {
  warning("'zeroNthGeno' is obsolete. Use zeroGeno instead.")
  zeroGeno(SNPxIndiv, sel.snps=snps)
}


existingAllelefreq <- function(snpcoding, as.character=TRUE) {
  x <- .Call(C_existsAllelefreq, snpcoding)
  return(if ((missing(snpcoding) || length(snpcoding) == 0) &&
             as.character) CODING_NAMES[x + 1] else x)
}

existingCrossprod <- function(snpcoding, as.character=TRUE) {
  x <- .Call(C_existsCrossprod, snpcoding)
  return(if ((missing(snpcoding) || length(snpcoding) == 0) &&
             as.character) CODING_NAMES[x + 1] else x)
}

existingVariant <- function(snpcoding, variant=NULL, indeed=FALSE)
  .Call(C_existsVariant, snpcoding, variant, indeed)

existingTiling <- function(snpcoding, variant, tiling=NULL, indeed=FALSE) {
  if (!existingVariant(snpcoding=snpcoding, variant=variant, indeed=indeed))
    stop("indicated variant does not exist.")
  .Call(C_existsTiling, snpcoding, variant, tiling)
}

existingCoding <- function(snpcoding, internal) {
  .Call(C_existsCoding, snpcoding, internal)
}


snpbind <- function(M, N, force=FALSE) {
  internalRFoptions(COPY=TRUE)
  .Call(C_snpbind, M, N, as.logical(force));
}
