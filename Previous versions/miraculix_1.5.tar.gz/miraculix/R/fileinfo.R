## Authors 
## Martin Schlather, martin.schlather@uni-mannheim.de
##
##
## Copyright (C) 2017 -- 2021 Martin Schlather
##
## This program is free software; you can redistribute it and/or
## modify it under the terms of the GNU General Public License
## as published by the Free Software Foundation; either version 3
## of the License, or (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  


FileCoding <-c(beagle="AB? ", plink="AB? ", plink2="12? ", plinkbinary="12345")
Header <-    c(beagle=1,    plink=0,    plink2=0,     plinkbinary=-3)
IndivPerCol <- c(beagle=TRUE, plink=TRUE, plink2=FALSE, plinkbinary=TRUE)
DoubledIndiv <-c(beagle=TRUE, plink=TRUE, plink2=FALSE, plinkbinary=FALSE)
LeadingCol <-c(beagle=2,    plink=4,    plink2=6,     plinkbinary=0)
Extension <- c(beagle="bgl", plink="phased", plink2="ped", plinkbinary="bed")

fileInfo <- function(filename,
                     file.type=NULL, file.coding = NULL, header=NULL,
                     IndividualsPerColumn=NULL,
                     DoubledIndividuals=NULL, leadingcolumns=NULL,
                     loading=loading) {
  split <- strsplit(filename, "\\.")[[1]]
    file.ext <-  c("txt", "bgl", "phased", "tped", "ped", "bed")
    s <- pmatch(split[length(split)], file.ext)
    if (!is.na(s)) { 
      file.type <- c(txt="beagle", bgl="beagle", phased="plink",
                     tped="plink2", ped="plink2",
                     bed="plinkbinary")[file.ext[s]]
    } else {
      message("Note: file.type could not be detected.")
    }

  snps <- individuals <- NA
  if (0 != length(file.type)) {
    if (0 == length(file.coding)) file.coding <- FileCoding[file.type]
    if (0 == length(header)) header <- Header[file.type]
    if (0 == length(IndividualsPerColumn))
      IndividualsPerColumn <- IndivPerCol[file.type]
    if (0 == length(DoubledIndividuals))
      DoubledIndividuals <- DoubledIndiv[file.type]
    if (0 == length(leadingcolumns)) leadingcolumns <- LeadingCol[file.type]
    
    if (file.type == "plinkbinary") {
      s <- paste(split[-length(split)], collapse=".")
      
      file.lines <- function(filename) {
        sys <- strsplit(system(paste("wc", filename), intern=TRUE), " ")[[1]]
        sys <- sys[nchar(sys) > 0]
        as.integer(sys[1])
      }
      
      ##  #lines of the files give the snps or individuals
      individuals <- file.lines(paste(s, ".fam", sep=""))
      snps <- file.lines(paste(s, ".bim", sep=""))
    }
  }
  
  if (nchar(file.coding) != 4 && nchar(file.coding) != 5)
    stop("haplotype must be given as 4 characters, e.g. 'AB? '; genomic information 5 characters")
  if (nchar(file.coding) == 4) {
    ## never change this file.coding
    file.coding <- paste(substr(file.coding, 1, 2), substr(file.coding, 2, 4), sep="")
  }
  
  if (0 == length(file.coding) || 0 == length(header) ||
      0 == length(IndividualsPerColumn) ||
      0 == length(DoubledIndividuals) || 0 == length(leadingcolumns)) {
    
    if (0 == length(file.coding) && 0 == length(header) &&
          0 == length(IndividualsPerColumn) &&
          0 == length(DoubledIndividuals) && 0 == length(leadingcolumns))
      stop("unknown file.type. Please give the file.type")
    
    stopifnot(0 != length(file.coding))
    stopifnot(0 != length(header))
    stopifnot(0 != length(IndividualsPerColumn))
    stopifnot(0 != length(DoubledIndividuals))
    stopifnot(0 != length(leadingcolumns))
    
  }
  
  info <-rep(NA, INFO_LAST + 1)
  info[SNPS + 1] <- snps
  info[INDIVIDUALS + 1]<- individuals
  info[CODING + 1] <- if (loading) AutoCoding else UnknownSNPcoding
  info[TRANSPOSED + 1] <- FALSE;
  info[ORIGINALLY_HAPLO + 1] <- FALSE
  info[FILE_SNPxIND_READ_BYROW + 1] <- IndividualsPerColumn
  info[FILE_HEADER + 1] <- header
  info[FILE_DOUBLEINDIV + 1] <- DoubledIndividuals
  info[FILE_LEADINGCOL + 1] <- leadingcolumns
  GetAttr(filename, "information") <- info
  attr(filename, "filecoding") <-  as.character(file.coding)
  attr(filename, "filename") <-  as.character(filename)

#  print("fileInfo !!!!!!!!!!!!!!! ")
  Transform(filename, snpcoding = UnknownSNPcoding)
}


rhaploFile <- function(freq, indiv, loci, freq2, file, file.type) {
  file <- paste0(file, ".", Extension[file.type])
  header <- Header[file.type]
  leadingcol <- LeadingCol[file.type]
  doubledIndiv <- DoubledIndiv[file.type]
  IndivPerColumn <- IndivPerCol[file.type]
  FileCoding <- FileCoding[file.type]
  file_coding <- character(nchar(FileCoding))
  for (i in 1:length(file_coding)) file_coding[i] <- substring(FileCoding, i, i)

  codes <- file_coding[1 + (stats::runif( 2 * indiv * loci) < c(freq, freq2))]
 
  haplo <- length(file_coding) == 4
  M <- matrix(ncol = indiv * 2, codes)
  if (haplo) {
    if (!doubledIndiv) {stop("not programmed yet")
      M2 <- matrix(nrow = 2 * loci, ncol = indiv)
      M2[c(TRUE, FALSE), ] <- M[, c(TRUE, FALSE)]
      M2[c(FALSE, TRUE), ] <- M[, c(FALSE, TRUE)]
      M <- M2
    }
    if (!IndivPerColumn) {stop("not programmed yet")
      M <- t(M)
    }
  } else M <- M[, c(TRUE, FALSE)] + M[, c(FALSE, TRUE)]

  if (file.type == "plinkbinary") {
    stop("not programmed yet")
  } else { ## ASCII file
    if (header == 0) file.create(file)
    else write(file=file, paste("This is header line no", 1:header))
    if (leadingcol > 0) M <- cbind(matrix("X", ncol=leadingcol, nrow=nrow(M)),M)
    sep <-file_coding[length(file_coding)]
    write.table(M, file=file, append=TRUE, quote=FALSE, sep = sep,
                row.names=FALSE, col.names=FALSE)
  }
  
  info <- rep(NA, INFO_LAST + 1)
  info[FILE_SNPxIND_READ_BYROW + 1] <- IndivPerColumn
  info[FILE_HEADER + 1] <- header
  info[FILE_DOUBLEINDIV + 1] <- doubledIndiv
  info[FILE_LEADINGCOL + 1] <- leadingcol
  info[ORIGINALLY_HAPLO + 1] <- TRUE
  info
  GetAttr(file, "information") <- info
  attr(file, "filecoding") <-  as.character(FileCoding)
  attr(file, "filename") <-  as.character(file)
  str(file)

#  Print("rhaploFile !!!!!!!!!!!!!!! ")
  H <- Transform(file, snpcoding=UnknownSNPcoding)
  str(H)
  H
}
