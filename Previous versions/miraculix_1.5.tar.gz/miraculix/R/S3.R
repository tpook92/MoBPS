## Authors 
## Martin Schlather, martin.schlather@uni-mannheim.de
##
##
## Copyright (C) 2017 -- 2021 Martin Schlather
##               2014 Florian Skene
##
## This program is free software; you can redistribute it and/or
## modify it under the terms of the GNU General Public License
## as published by the Free Software Foundation; either version 3
## of the License, or (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  



Int2Long <- function(x, bigendian=RFoptions()$basic$bigendian) {
  idx <- is.na(x)
  x[idx] <- 0L  
  y <- rep(0L, length(x))
  y[idx] <- NA
 # Print(x, idx, y)
  return(if (bigendian) rbind(y, x) else rbind(x, y))  
}


Long2Int <- function(a, bigendian=RFoptions()$basic$bigendian) {
  if (length(a) %% 2 != 0) stop("found unsound vector length for 'long'");
  idx <- c(!bigendian, bigendian) 
  null <- a[!idx]
  null[is.na(null)] <- 999
  a <- a[idx]
  a[null != 0] <- NA
  a
}

GetAttr <- function(x, what) {
  a <- attr(x, what)
  if (is.na(pmatch(what, "information")) || length(a) == 0) return(a)
  bigendian <- RFoptions()$basic$bigendian
  if (a[IMPLEMENTATION + 1 + bigendian] < 7) return(a)
  a <- Long2Int(a, bigendian=bigendian)
  a
}
 
"GetAttr<-" <- function(x, what, value) {
  if (!is.na(pmatch(what, "information"))) value <- Int2Long(value)
  attr(x, what) <- value
  x
}
  
print_haplogeno <- function(x, name, values=9) {
  #cat("print_haplogeno ....")
  info <- GetAttr(x, "information")
  xx <- x;   class(xx) <- NULL;   str(xx)
  stopifnot(length(info) > 0)
  ##  print.default(x)
  ##  print.default(info)
  indiv <- info[INDIVIDUALS + 1]
  snps <- info[SNPS + 1]
  coding <- info[CODING + 1]
  isorighaplo <- info[ORIGINALLY_HAPLO + 1]
  ishaplo <- !is.na(isorighaplo) && IS(x, HAPLOMATRIX)
#  Print(isorighaplo, IS(x, HAPLOMATRIX))
  cat(if(is.na(isorighaplo)) "Loci" else if (ishaplo) "Haplo" else "SNP",
      "")
  if (is.na(indiv) || is.na(snps)) cat("information")
  else if (indiv > 1) {
    cat("x Indiv ", name, " matrix", sep="")
    if (!is.na(snps)) cat(" [1:", snps, ", 1:", indiv,"]", sep="")
 } else cat("information at ", info[SNPS + 1], " loci", sep="")

  variant  <- as.integer(info[VARIANT + 1])  
  if (!is.na(coding) && !is.na(variant)) {    
    main.var <- if (variant <= 128) variant else as.integer(variant / 128) *128
    cat(" with ",
        CODING_NAMES[coding + 1],
        "-snpcoding (",
        if (main.var != 0) "using ",
        switch(as.character(main.var),
                     "0" = "default",
                     "32" = "32bit",
                     "64" = "64bit",
                     "128" = "SSE",
                     "256" = "AVX2",
                     "512" = "AVX512",
                     "768" = "GPU",
                     "896" = "R",
                     "unknown"
                     ),  if (ishaplo) ", " else ")",
        sep="")
  } else if (ishaplo) cat(" (")
  if (ishaplo)  cat("twice)")
 
  if (is.character(x)) cat("\n<", x, "> (unloaded)", sep="")
  else if (length(f <- attr(x, "filename")) > 0)
    cat("\n<", f, "> (loaded)", sep="")
  cat("\n")
  ##  y<-x; class(y) <- NULL; Print(values, y, GetAttr(y,"information")[LDABITALIGN + 1], GetAttr(y,"information")[LDA + 1], CODING_NAMES[GetAttr(y,"information")[CODING+1] + 1])
  if (values > 0 && !is.character(x)) {
    values <- min(values, length(x))
    print(c(as.integer(x[1:values]), ## OK
            if (values < length(x)) "..."), quote=FALSE)
  }
}


as.haplomatrix <- function(object, ...)   haplomatrix(object, ...)
as.matrix.haplomatrix <- function(x, ...) haplomatrix(x, ...)
print.haplomatrix <- function(x, ...)  print_haplogeno(x, "haplo", ...)
str.haplomatrix <- function(object, ...) {
  ##  Print("XXX", list(...))
  print.haplomatrix(object)
  cat("Attributes are ")
  utils::str(base::attributes(object)) ## OK
}


as.matrix.genomicmatrix <- function(x, ...) decodeGeno(x, ...)
print.genomicmatrix <- function(x, ...) print_haplogeno(x, "genomic", ...)
str.genomicmatrix <- function(object, ...) {
#  print("here")
  print.genomicmatrix(object, ...)
  cat("Attributes are ")
  utils::str(base::attributes(object)) ## OK
  ##class(object) <- NULL;    str(object)
}  
as.genomicmatrix <- function(object, ...) genomicmatrix(object, ...,
                                                        loading = FALSE)


t.haplomatrix <- t.genomicmatrix <- function(x) transpose(x) 
