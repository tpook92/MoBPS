
## Authors 
## Martin Schlather, martin.schlather@uni-mannheim.de
##
##
## Copyright (C) 2017 -- 2021 Martin Schlather
## functions designed for package MoBPS
##
## This program is free software; you can redistribute it and/or
## modify it under the terms of the GNU General Public License
## as published by the Free Software Foundation; either version 3
## of the License, or (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  


## code "all" information of the animals effectively



## computeSNPS
## 1: In bp[start1:(start1 + nsnp[index] - 1)] <- ceiling((1:nsnp[index] -  : Anzahl der zu ersetzenden Elemente ist kein Vielfaches der Ersetzungslaenge


## for debugging  
.XXCall <- function(...)  {   Print(list(...)[[1]]) ## OK
##  base::.Call(...)
}



rhaplo <- function(freq, indiv, loci, freq2, file,
                   file.type = c("beagle", "plink", "plink2")) {
   
  RFopt <- internalRFoptions(COPY=TRUE, getoptions_="genetics")
  coding <- which(RFopt$snpcoding == CODING_NAMES) - 1
  coding <- if (coding %in% c(OneBitGeno, OneBitHaplo)) OneBitHaplo
            else if (coding %in% c(TwoBitGeno, TwoBitHaplo)) TwoBitHaplo
            else stop("haplo coding for 'snpcoding=", coding, "' not possible")
  
  freq <- if (hasArg("freq")) as.double(freq)
          else {
            if (!hasArg("loci")) stop("both 'freq' and 'loci' are not given")
            1/2
          }
  
  if (hasArg("loci")) {
    loci <- as.integer(loci)
    freq <- rep(freq, length.out=loci)
  } else loci <- length(freq)

  freq2 <- if (!hasArg("freq2")) freq
           else if (length(freq2)==1 || hasArg("loci"))
               rep(as.double(freq2), length.out=loci)
           else as.double(freq2)
  stopifnot(length(freq2) == length(freq))
 
  indiv <- as.integer(indiv)
 
  if (hasArg("file")) {
    internalRFoptions(COPY=FALSE, RETURN=FALSE, snpcoding=coding)
    return(rhaploFile(freq=freq, indiv= indiv, loci= loci, freq2 =freq2,
                      file = file, file.type = file.type))
  }
 
  return(.Call(C_rhaplomatrix, freq, freq2, indiv, coding))
}



codeOrigins <- function(M) .Call(C_codeOrigins, M)
 
decodeOrigins <- function(CM, row) .Call(C_decodeOrigins, CM, row)

computeSNPS <- function(population, gen, sex, nr,
			from_p = 1, to_p = Inf,
			output_compressed=FALSE,			
			select = NULL,
			what = c("geno", "haplo")
			) {
  internalRFoptions(COPY=TRUE, RETURN=FALSE)
##  name <- as.character(as.list(match.call(envir=parent.frame(2L)))[[1]])
    
  if (is.matrix(gen)) {
    if (!is.missing(sex) || !is.missing(nr))
      stop("if 'gen' is matrix, sex and nr may not be given")
    gen <- gen[, 1]
    sex <- gen[,2]
    nr <- gen[, 3]
  }
  geno <- what[1] != "haplo"
 
  ans <-  .Call(C_computeSNPS, population,
		as.integer(gen),
		as.integer(sex),
		as.integer(nr), as.integer(from_p),
		as.integer(if (is.finite(to_p)) to_p else NA), select,
		geno)
 
  if (!output_compressed) {
     ans <- if (geno) decodeGeno(ans, COPY=FALSE) else haplomatrixIntern(ans)
  }
  
  ##  if (PB(name)) RETURN(name) else SAVE(name, ans)
  ## genomicmatrix or haplomatrix
  return(ans)
}


compute <- function(population, gen, sex, nr, tau, vec, betahat,
		    select = NULL, matrix.return=FALSE) {
  internalRFoptions(COPY=TRUE, RETURN=FALSE)
  ## implements ( t(Z) Z + tau \1_{ind x ind} )^{-1} %*% vec

    
  if (is.matrix(gen)) {
    gen <- gen[, 1]
    sex <- gen[,2]
    nr <- gen[, 3]
  }
  stopifnot(length(tau) == 1 && length(betahat) == 1)

  ## returns a list
   .Call(C_compute, population,
	as.integer(gen),
	as.integer(sex),
	as.integer(nr),
	as.double(tau),
	as.double(vec),
	as.double(betahat),
	as.integer(select),
	as.logical(matrix.return)
	)
}





## function for debugging only

SAVE <- function(name, ans) {
  print(name) ## OK
  variable.name <- "__Z"
  ENV <- .GlobalEnv
  name <- paste(variable.name, name, sep=".")
  name <- name[length(name)]
  if (!exists(name, envir=ENV)) assign(name, 0, envir=ENV)
  cur <- get(name, envir=ENV) + 1
  file <- paste(name, cur, "rda", sep=".")
  Print(file, ans) ## OK
  assign(name, cur, envir=ENV)
  save (file=file, ans) 
  return(ans)
}

RETURN <- function(name) {
  variable.name <- "__Z"
  ENV <- .GlobalEnv
  name <- paste(variable.name, name, sep=".")
  name <- name[length(name)]
  if (!exists(name, envir=ENV)) assign(name, 0, envir=ENV)
  cur <- get(name, envir=ENV) + 1
  file <- paste(name, cur, "rda", sep=".")  
  if (file.exists(file)) {
    cat("playback", file, "\n")
    load (file) 
    assign(name, cur, envir=ENV)
    return(name)
  }
  stop("hierher und nicht weiter")
}

PB <- function(name) {
  variable.name <- "__Z"
  ENV <- .GlobalEnv
  name <- paste(variable.name, name, sep=".")
  name <- name[length(name)]
  if (!exists(name, envir=ENV)) assign(name, 0, envir=ENV)
  cur <- get(name, envir=ENV) + 1
  file <- paste(name, cur, "rda", sep=".")  
  return(file.exists(file))
}


DEBUG <- function(name, population, gen, sex, nr) {
  variable.name <- "__Z"
  ENV <- .GlobalEnv
  name <- paste(variable.name, name, sep=".")
  name <- name[length(name)]
  if (!exists(name, envir=ENV)) assign(name, 0, envir=ENV)
  cur <- get(name, envir=ENV) + 1
  file <- paste(name, cur, "rda", sep=".")  
  if (cur == 2866) {
    .Call(C_Debug);
##    str(population$breeding[[1]][[1]][[318]])
##    str(population$breeding[[gen]][[sex]][[nr]])
##    print(population$breeding[[gen]][[sex]][[nr]][1:2])
  } # else .Call(C_StopDebug);
}


## only for development of rmCoded needed
## check: how to remove an object that has been defined on the upper level
## no further use
RM <- function(...) {
  env <- parent.env(environment())
  L <- list(...)
  if (is.character(L[[1]])) {
    if (!all(sapply(L, is.character)))
      stop("arguments must be all variables or all character vectors")
    L <- unlist(L)
  } else {
    L <- as.character(substitute(list(...)))[-1]
  }
  rm(list=L, envir=env)
}


