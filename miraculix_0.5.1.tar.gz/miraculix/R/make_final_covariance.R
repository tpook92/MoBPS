## Authors 
## Malena Erbe malena.erbe@agr.uni-goettingen.de 
## Copyright (C) 2015 -- 2019 Malena Erbe
#
##
## This program is free software; you can redistribute it and/or
## modify it under the terms of the GNU General Public License
## as published by the Free Software Foundation; either version 3
## of the License, or (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  




finalCov<-function(G,A,perc) {
	# following Meuwissen et al. (2011)
	# step 1: calculate Fit_i
	Fit<-diag(G)-1
	# step 2: calculate Fst_G
	FstG<-mean(diag(G))-1
	# step 3: calculate Fst_A
	FstA<-mean(diag(A))-1
	# step 4: calculate Fis_i
	Fis<-(diag(G)-1-FstG)/(1-FstG)
	# step 5: new elements in G
	keepDiag<-diag(G)
	newDiag<-FstA+(1-FstA)*Fis+1
	kin<-(G/2-FstG)/(1-FstG)
	G<-2*(FstA+(1-FstA)*kin)
	diag(G)<-newDiag
	# step 6: combine A and G
	finalCov<-(1-perc/100)*G+(perc/100)*A
	return(finalCov)
}
