## Authors 
## Malena Erbe malena.erbe@agr.uni-goettingen.de 
## Copyright (C) 2015 -- 2019 Malena Erbe
#
##
## This program is free software; you can redistribute it and/or
## modify it under the terms of the GNU General Public License
## as published by the Free Software Foundation; either version 3
## of the License, or (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  




Gmatrix<-function(zahl=5,genos.gen,roundit=3,asreml=TRUE,freq=NULL,teiler=NULL) {
  if (is.null(freq)) {
    cat('berechne Frequenzen','\n')
    freq<-round(apply(genos.gen,2,mean)/2,roundit)
  }
  cat('erstelle Z','\n')
  Z<-sweep(genos.gen,2,2.0 * freq,'-')
  #library(multicore)  ## martin:sollte ohne gehen
  nsnps<-dim(Z)[2]
  nind<-dim(Z)[1]

                                                                                 ##zahl<-5
  cat('berechne Einzelteile von G','\n')
  teile<-mclapply(1:zahl,function(x){
    nn <- as.integer(floor(nsnps/zahl))
    y <- double((nind+1)*nind/2)
     if (x<zahl) {
      cat(x,'\n')
      xx<-t(Z[,((x-1)*nn+1):(x*nn)])
      .Fortran(C_gmatrix, xx, y, nn, nind)
    } else if (x==zahl) {
      cat(x,'\n')
      xx<-t(Z[,((x-1)*nn+1):nsnps])
      .Fortran(C_gmatrix, xx, y, as.integer(nsnps-nn*(zahl-1)), nind)
    }
  }
                  ,mc.cores=zahl)
  cat('verbinde Einzelteile','\n')
  for (j in 1:zahl) {
    if (j==1) loesung<-teile[[j]][[2]] ## geaendert von Malena Mitte Jan 2014
    if (j!=1) loesung<-loesung+teile[[j]][[2]]
  }
  G<-matrix(0,nind,nind)
  G[lower.tri(G,diag=TRUE)]<-loesung
  G<-G+t(G)-diag(diag(G))
  if (is.null(teiler)) {
    G<-G/sum(2*freq*(1-freq))
  } else {
    G<-G/teiler
  }
  if (asreml) {
    cat('bereite G fuer ASReml vor','\n')
    Glong<-G[upper.tri(G,diag=TRUE)]
    Glong<-cbind(rep(1:nind,1:nind),sequence(1:nind),Glong)
    return(Glong)
  } else {
    return(G)
  }
}
