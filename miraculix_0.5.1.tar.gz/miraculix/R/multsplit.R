
## Authors 
## Malena Erbe malena.erbe@agr.uni-goettingen.de 
## Copyright (C) 2015 -- 2019 Malena Erbe
#
##
## This program is free software; you can redistribute it and/or
## modify it under the terms of the GNU General Public License
## as published by the Free Software Foundation; either version 3
## of the License, or (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  


multSplit<-function(eins,zwei,zahl) {

	n<-dim(eins)[1]
	nn<-floor(n/zahl)
	teile<-mclapply(1:zahl,function(x){
		if (x<zahl) {
#			cat(x,'\n')
			xx<-eins[((x-1)*nn+1):(x*nn),]
		} else if (x==zahl) {
#			cat(x,'\n')
			xx<-eins[((x-1)*nn+1):n,]    
		}
		xx%*%zwei
	}
	)
	
	for (j in 1:zahl) {
		if (j==1) loesung<-teile[[j]]
		if (j!=1) loesung<-rbind(loesung,teile[[j]])
	}
	
	return(loesung)
	
}
