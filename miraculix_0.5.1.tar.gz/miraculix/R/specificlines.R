
## Authors 
## Malena Erbe malena.erbe@agr.uni-goettingen.de 
## Copyright (C) 2015 -- 2019 Malena Erbe
#
##
## This program is free software; you can redistribute it and/or
## modify it under the terms of the GNU General Public License
## as published by the Free Software Foundation; either version 3
## of the License, or (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  


SpecificLines<-function(infile,ntotal,whichlines,idcols,datacols) {
  stop("function must be rewritten")
  ntotal <- as.integer(ntotal)
  whichlines <- as.integer(whichlines)
  idcols <- as.integer(idcols)
  datacols <- as.integer(datacols)
	
  write.table(infile,'paramfile_specificlines',col.names=FALSE,
	      row.names=FALSE,quote=FALSE,sep='\t')

  nlines<-length(whichlines)
  datamat<-matrix(0L,nrow=nlines,ncol=datacols)
  
  dataresults<-.Fortran(C_specific_lines, ntotal, nlines, whichlines,
			datacols, idcols, datamat)		

	idresults<-read.table('idfile_specificlines',header=FALSE,colClasses='character')
	
	results<-list(datamat=dataresults[[6]],id=idresults)
	
	system('rm idfile_specificlines paramfile_specificlines')
	
	return(results)
}
