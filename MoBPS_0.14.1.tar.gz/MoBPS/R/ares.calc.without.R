'#
  Authors
Torsten Pook, torsten.pook@uni-goettingen.de

Copyright (C) 2017 -- 2018  Torsten Pook

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
'#

#' Bestimme Kinship nach Sitzenstock
#'
#' Bestimme erwartete Kinship nach Sitzenstock im 2M,5F Cattle-breedingprogram
#' @param ngen Zu simulierende Generationen
#' @param m Anzahl maennliche Tiere
#' @param w Anzahl weibliche Tiere
#' @export

ares.calc.without <- function(ngen, m, w){

  # nag = Anzahl der Altersgruppen (AGs)
  nag <- 7

  # matrix der kinship der jeweils neugeborenen
  knew <- matrix (0,nrow=ngen, ncol=2)

  # apop = Array mit einer 3 x nag Matrix f?r jede age group:
  # 1. Zeile 1. Element: Anzahl Tiere
  # 1. Zeile 2. Element: Reproduktion = 1; Alterung = 2
  # 2. Zeile Herkunft der v?terlichen Allele  (Summe = 1, bei Alterung 1 in die Spalte der Herkunfts-AG)
  # 3. Zeile Herkunft der m?tterlichen Allele (Summe = 1, bei Alterung 1 in die Spalte der Herkunfts-AG)

  apop <- array(data = c( m,  1,  0,  0,  0,  0,  0,
                          0,1.0,  0,  0,  0,  0,  0,
                          0,  0,  0,  0.25 ,  0.25,  0.25,  0.25,

                          m,  2,  0,  0,  0,  0,  0,
                          1.0,  0,  0,  0,  0,  0,  0,
                          1.0,  0,  0,  0,  0,  0,  0,

                          w,  1,  0,  0,  0,  0,  0,
                          0,1.0,  0,  0,  0,  0,  0,
                          0,  0,  0,  0.25 ,  0.25,  0.25,  0.25,

                          w,  2,  0,  0,  0,  0,  0,
                          0,  0,  1,  0,  0,  0,  0,
                          0,  0,  1,  0,  0,  0,  0,

                          w,  2,  0,  0,  0,  0,  0,
                          0,  0,  0,  1,  0,  0,  0,
                          0,  0,  0,  1,  0,  0,  0,

                          w,  2,  0,  0,  0,  0,  0,
                          0,  0,  0,  0,  1,  0,  0,
                          0,  0,  0,  0,  1,  0,  0,

                          w,  2,  0,  0,  0,  0,  0,
                          0,  0,  0,  0,  0,  1,  0,
                          0,  0,  0,  0,  0,  1,  0),

                dim = c(nag,3,nag))


  nn <- apop[1,1,]
  nn

  #
  # av = alterungsvektor
  # ai = alterungsindex
  #
  av <- vector(mode="numeric",length=nag)
  ai <- vector(mode="numeric",length=nag)
  for (i in 1:nag){
    if (apop[2,1,i]==2) {
      for (j in 1:nag)  {
        if(apop[j,2,i]==1){av[i]=j;ai[i]=1 }
      }
    }
  }
  av;ai

  # ft = matrix der mittleren kinship zum Zeitpunkt t (mit null vorbesetzt)
  # ft1 = = matrix der mittleren kinship zum Zeitpunkt t+1
  #

  ft <- matrix (0,nrow=nag, ncol=nag)

  # Diagonale besetzen #

  # for (ii in 1:nag)  {
  # ft[ii,ii] <- 1/(2*nn[ii])
  # }

  ft1 <- matrix (0,nrow=nag, ncol=nag)


  # loop over generations
  ares <- array(0,dim=c(nag,nag,ngen))
  fres <- vector(mode="numeric",length=ngen)

  for (igen in 1:ngen) { #igen#

    for (iag in 1:nag)   { #iag#


      ipop <- apop[,,iag]
      ialt <- ai[iag]

      for (jag in iag:nag)  {  #jag#


        jpop <- apop[,,jag]
        jalt <- ai[jag]

        #
        # F?lle durchgehen
        #
        if((jalt*ialt)==1)   { #beide altern#
          ll<-av[iag]
          kk<-av[jag]
          ft1[iag,jag]=ft[ll,kk]
        } #beide altern beendet#

        if(ialt==1 & jalt==0)  { #nur i altert#

          ll<-av[iag]    #ll = Herkunft der Population i
          vj <- jpop[,2]
          vk <- jpop[,3]
          for (jj in 1:nag) { #jj#
            for (kk in 1:nag)  { #kk#

              pp <- vj[jj]*vk[kk]   # probability of this specific combination
              if (pp != 0.)  { #nur existierende F?lle
                # 3 F?lle:

                if (jj == ll) { #j=l
                  fnew = 1/(2*apop[1,1,jj])
                  foldj=(1-fnew)*ft[jj,jj]
                  foldkl=ft[kk,ll]
                  ft1[iag,jag]=ft1[iag,jag]+pp*0.5*(fnew+foldj+foldkl)
                } #j=l fertig

                if (kk == ll) { #k=l
                  fnew = 1/(2*apop[1,1,kk])
                  foldk=(1-fnew)*ft[kk,kk]
                  foldjl=ft[jj,ll]
                  ft1[iag,jag]=ft1[iag,jag]+pp*0.5*(fnew+foldk+foldjl)
                } #k=l fertig

                if (jj != ll & kk != ll) { #alle drei verschieden
                  if (iag != jj & iag != kk)  { # alternde Pop ist keiner der Eltern
                    ft1[iag,jag]=ft1[iag,jag]+pp*0.5*(ft[jj,ll]+ft[kk,ll])
                  } # alternde Pop ist keiner der Eltern - fertig
                  else  {  # alternde Pop ist einer der Eltern
                    ###ft1[iag,jag]=ft1[iag,jag]+pp*0.5*(ft[jag,jj]+ft[jag,kk])
                    ft1[iag,jag]=ft1[iag,jag]+pp*0.5*(ft[ll,jj]+ft[ll,kk])
                  } # alternde Pop ist keiner der Eltern - fertig
                } #alle drei verschieden fertig

              }  #nur existierende F?lle fertig
            } #kk zu
          } #jj zu
        }  #nur i altert beendet

        if(ialt==0 & jalt==1)  { #nur j altert#

          ll<-av[jag]    #ll = Herkunft der Population j
          vj <- ipop[,2]
          vk <- ipop[,3]
          for (jj in 1:nag) { #jj#
            for (kk in 1:nag)  { #kk#

              pp <- vj[jj]*vk[kk]   # probability of this specific combination
              if (pp != 0.)  { #nur existierende F?lle
                # 3 F?lle:

                if (jj == ll) { #j=l
                  fnew = 1/(2*apop[1,1,jj])
                  foldj=(1-fnew)*ft[jj,jj]
                  foldkl=ft[kk,ll]
                  ft1[iag,jag]=ft1[iag,jag]+pp*0.5*(fnew+foldj+foldkl)
                } #j=l fertig

                if (kk == ll) { #k=l
                  fnew = 1/(2*apop[1,1,kk])
                  foldk=(1-fnew)*ft[kk,kk]
                  foldjl=ft[jj,ll]
                  ft1[iag,jag]=ft1[iag,jag]+pp*0.5*(fnew+foldk+foldjl)
                } #k=l fertig

                if (jj != ll & kk != ll) { #alle drei verschieden
                  if (jag != jj & jag != kk)  { # alternde Pop ist keiner der Eltern
                    ft1[iag,jag]=ft1[iag,jag]+pp*0.5*(ft[jj,ll]+ft[kk,ll])
                  } # alternde Pop ist keiner der Eltern - fertig
                  else  {  # alternde Pop ist einer der Eltern
                    ###ft1[iag,jag]=ft1[iag,jag]+pp*0.5*(ft[iag,jj]+ft[iag,kk])
                    ft1[iag,jag]=ft1[iag,jag]+pp*0.5*(ft[ll,jj]+ft[ll,kk])
                  } # alternde Pop ist keiner der Eltern - fertig
                } #alle drei verschieden fertig


              }  #nur existierende F?lle fertig

            } #kk zu
          } #jj zu

        }  #nur j altert beendet


        if(ialt==0 & jalt==0)  { #beide reproduziert#

          # loop over origin of first allele
          for (i1 in 2:3) { #i1

            v1 <- ipop[,i1]

            # loop over origin of second allele

            for (i2 in 2:3) { #i2

              v2 <- jpop[,i2]

              # double loop over combinations of parental populations

              for (j1 in 1:nag) { #j1
                for (j2 in 1:nag) { #j2

                  # probability of this specific combination

                  pp <- 0.25*v1[j1]*v2[j2]

                  # ibd-probabilities given the combination

                  if (j1 == j2) { #allele ibd

                    # allele is from the same population - new + old ibd

                    fnew = 1/(2*apop[1,1,j1])
                    fold=(1-fnew)*ft[j1,j1]
                    ft1[iag,jag]=ft1[iag,jag]+pp*(fnew+fold)
                  } #allele ibd beendet

                  else { #allele nibd
                    # allele is from the different populations - only old ibd
                    fold=ft[j1,j2]
                    ft1[iag,jag]=ft1[iag,jag]+pp*fold
                  } #allele nibd beendet
                } #j2 zu
              } #j1 zu
            } #i2 zu
          } #i1 zu
        } #beide reproduziert beendet

        ft1[jag,iag] <- ft1[iag,jag]
      }  # jag zu
    }  # iag zu





    #Mittlere Kinship, gewichtet
    sk <- 0
    sn <- 0
    for (i in 1:nag) {
      for (j in 1:nag) {
        sk <- sk + 2*apop[1,1,i]*apop[1,1,j]*ft1[i,j]
        sn <- sn + 2*apop[1,1,i]*apop[1,1,j]
      }
      sk <- sk - apop[1,1,i]^2*ft1[i,i]
      sn <- sn - apop[1,1,i]^2
    }
    fres[igen] <- sk/sn

    # Matrix ?berschreiben

    ares[,,igen] <- ft1
    ft <- ft1
    ft1 <- matrix (0,nrow=nag, ncol=nag)

    knew[igen,1] <- ft[1,1]
    knew[igen,2] <- ft[3,3]

  }  # igen zu


  return(list(ares))
}
