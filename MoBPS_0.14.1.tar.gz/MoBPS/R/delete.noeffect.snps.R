'#
  Authors
Torsten Pook, torsten.pook@uni-goettingen.de

Copyright (C) 2017 -- 2018  Torsten Pook

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
'#

#' Loesche alle SNPs ohne Effekte
#'
#' Funktion zur entfernung saemtlicher SNPs ohne Effekte auf die Zuchtwerte. NUR FALLS BISHER KEINE MUTATION IM DATENSATZ
#' @param population Bisherigere Populationsliste (nur relevant wenn zusaetzliche Daten hinzugefuegt werden sollen)
#' @export

delete.noeffect.snps <- function(population){
  #NUR FALLS BISHER KEINE MUTATION IM DATENSATZ
  relevant <- NULL
  for(index in 1:length(population$info$real.bv.add)){
    relevant <- rbind(relevant, population$info$real.bv.add[[index]][,1:2] )
  }
  for(index in 1:length(population$info$real.bv.mult)){
    relevant <- rbind(relevant, population$info$real.bv.mult[[index]][,1:2], population$info$real.bv.mult[[index]][,3:4] )
  }

  relevant <- unique(relevant)
  chromo <- 1:population$info$chromosome
  chromo.size <- numeric(population$info$chromosome)
  # $info$snp
  for(index in chromo){
    chromo.size[index] <- sum(relevant[,2]==index)
  }

  # $info$position
  previous.snps <- c(0,population$info$snp)
  old.position <- relevant[,1]+ previous.snps[relevant[,2]]

  # Editieren in population
  population$info$snp <- chromo.size
  population$info$snp.position <- population$info$snp.position[old.position]
  population$info$snp.base <- population$info$snp.base[,old.position]
  for(index in chromo){
    population$info$position[[index]] <- population$info$position[[index]][relevant[relevant[,2]==index,1]]
  }

  for(index in 1:length(population$info$real.bv.add)){
    if(sum(population$info$real.bv.add[[index]][,2]==index)>0){
      naming <- sort(population$info$real.bv.add[[index]][population$info$real.bv.add[[index]][,2]==index,1], index.return=TRUE)$ix
      population$info$real.bv.add[[index]][population$info$real.bv.add[[index]][,2]==index,1][naming] <- 1:length(naming)
    }
  }

  for(index in 1:length(population$info$real.bv.mult)){
    if(sum(population$info$real.bv.mult[[index]][,2]==index)>0){
      naming <- sort(population$info$real.bv.mult[[index]][population$info$real.bv.mult[[index]][,2]==index,1], index.return=TRUE)$ix
      population$info$real.bv.mult[[index]][population$info$real.bv.mult[[index]][,2]==index,1][naming] <- 1:length(naming)
    }
    if(sum(population$info$real.bv.mult[[index]][,4]==index)>0){
      naming <- sort(population$info$real.bv.mult[[index]][population$info$real.bv.mult[[index]][,4]==index,3], index.return=TRUE)$ix
      population$info$real.bv.mult[[index]][population$info$real.bv.mult[[index]][,4]==index,3][naming] <- 1:length(naming)
    }
  }

  for(gen in 1:length(population$breeding)){
    for(sex in 1:2){
      if(length(population$breeding[[gen]][[sex]])>0){
        for(index in 1:length(population$breeding[[gen]][[sex]])){
          population$breeding[[gen]][[sex]][[1]][[9]] <- population$breeding[[gen]][[sex]][[1]][[9]][old.position]
          population$breeding[[gen]][[sex]][[1]][[10]] <- population$breeding[[gen]][[sex]][[1]][[10]][old.position]
        }
      }
    }
  }

  return(population)

}
