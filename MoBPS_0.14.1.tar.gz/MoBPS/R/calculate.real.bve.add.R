'#
  Authors
Torsten Pook, torsten.pook@uni-goettingen.de

Copyright (C) 2017 -- 2018  Torsten Pook

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
'#

#' Vergleich mit genetischem Mittel einer anderen Population
#'
#' Funktion zur Aufstellung einer additiven Zuchtwertfunktion zum Vergleich mit Mittel einer Population
#' @param species Matrix die alle fuer die Selektion relevanten SNPs mit Populationsmittel enthaelt (pro Zeile: SNP/Chromosom/mittlererGenotyp)
#' @param mult Multiplikativer Faktor
#' @param poly Potenz Faktor
#' @export

calculate.real.bv.add <- function(species, mult=1, poly=1){
  distance0 <- mult* species[,3]^poly
  distance1 <- mult* abs(1-species[,3])^poly
  distance2 <- mult* (2-species[,3])^poly

  bve.add.new <- cbind(species[,1:2], distance0, distance1, distance2)

  return(bve.add.new)
}
