'#
  Authors
Torsten Pook, torsten.pook@uni-goettingen.de

Copyright (C) 2017 -- 2018  Torsten Pook

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
'#

#' Codiere SNP-Sequence binaer
#'
#' Funktion zur effizienten Speicherung der Haplotypen (9,10)
#' @param snpseq SNP-Sequenz
#' @param nbits Anzahl nutzbarer bits (default: 30)
#' @export


bit.storing <- function(snpseq, nbits){
  n <- length(snpseq)
  q <- ceiling(n/nbits)
  if(n!=q*nbits){
    snpseq <- c(snpseq, rep(0, q*nbits-n))
  }
  mult <- c(1,rep(2,nbits-1))
  bit.seq <- as.integer(cumprod(mult) %*% matrix(snpseq, nrow=nbits))
}

#' Recodierung der SNP-Sequenz auf binaerer Speicherung
#'
#' Funktion zur effizienten Speicherung der Haplotypen (9,10)
#' @param bit.seq bitweise gespeicherte SNP-Sequenz
#' @param nbits Anzahl genutzter bits (default: 30)
#' @param population Population list
#' @param from_p_bit Bit to start on
#' @export

bit.snps <- function(bit.seq, nbits, population=NULL, from_p_bit=1){
  raw <- intToBits(bit.seq)
  keep <- rep(1:nbits, length(bit.seq)) + rep(32*(0:(length(bit.seq)-1)+ from_p_bit - 1), each=nbits)
  if(length(population) >0 && keep[length(keep)] > floor(sum(population$info$snp)/nbits)*32+population$info$leftover){
    keep <- keep[keep<=floor(sum(population$info$snp)/nbits)*32+population$info$leftover]
  }
  snp_seq <- as.integer(raw[keep])
}
