'#
  Authors
Torsten Pook, torsten.pook@uni-goettingen.de

Copyright (C) 2017 -- 2018  Torsten Pook

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
'#

#' Entwicklung der Korrelation der verschiedenen Zuchtwerte
#'
#' Plot der Entwicklung der Korrelation des realen/beobachten/geschaetzen ZWS
#' @param population Populationsliste
#' @param bvrow Betrachteter Zuchtwert (default: 1)
#' @param bw Bandbreite zur Glaettung der Korrelationskurve (default: 25)
#' @export

correlation.development <- function(population, bvrow=1, bw=25){
  bve.data <- population$info$bve.data
  n.step <- length(bve.data)
  heritability <- numeric(n.step)
  cor_obs <- numeric(n.step)
  cor_hat <- numeric(n.step)

  for(index in 1:n.step){
    heritability[index] <- bve.data[[index]][[3]][bvrow] / (bve.data[[index]][[3]][bvrow] + bve.data[[index]][[2]][1])
    cor_obs[index] <- stats::cor(bve.data[[index]][[6]][,bvrow], bve.data[[index]][[7]][,bvrow])
    cor_hat[index] <- stats::cor(bve.data[[index]][[6]][,bvrow], bve.data[[index]][[8]][,bvrow])
  }

  km1 <- stats::ksmooth(1:n.step,heritability, bandwidth = bw)
  km2<- stats::ksmooth(1:n.step, cor_obs, bandwidth = bw)
  km3<- stats::ksmooth(1:n.step, cor_hat, bandwidth = bw)

  graphics::plot(km1$x, sqrt(km1$y), type="l", ylim=c(min(c(0, sqrt(km1$y), km2$y, km3$y)),max(c(0, sqrt(km1$y), km2$y, km3$y)) ), main="Entwicklung der Korrelation zum realen Zuchtwert und Heritabilitaet", xlab="Nr. ZWS", ylab="")
  graphics::lines(km2, col="red")
  graphics::lines(km3, col="blue")
  graphics::legend("bottomleft", c("sqrt(h^2)", "y_obs", "y_hat"), lty=c(1,1,1), col=c("black","blue","red"))
}
